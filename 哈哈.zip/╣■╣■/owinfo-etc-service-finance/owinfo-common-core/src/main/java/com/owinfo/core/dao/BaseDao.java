package com.owinfo.core.dao;


import java.util.List;
import java.util.Map;


/**
 * 
 * @描述: 数据访问层基础支撑接口.
 * @author : redstar.
 * @创建时间: 2018-8-22.
 *
 *     更新为只为DAO提供一些基础方法  没有实现
 *     17.9.29
 * @版本: 2.0 .
 * @param <T>
 */
public interface BaseDao<T> {

	/**
	 * 根据实体对象新增记录.
	 * @param entity
	 * @return
	 */
	int insert(T entity);

	/**
	 * 批量保存对象.
	 * @param list
	 * @return
	 */
	long insert(List<T> list);

	/**
	 * 更新实体对应的记录.
	 * @param entity
	 * @return
	 */
	int update(T entity);

	/**
	 * 批量更新对象.
	 * @param list
	 * @return
	 */
	int update(List<T> list);

	/**
	 * 根据ID查找记录.
	 * @param id
	 * @return
	 */
	T getById(long id);

	/**
	 * 根据ID删除记录.
	 * @param id
	 * @return
	 */
	T getById(String id);

	/**
	 * 根据ID删除记录.
	 * @param id
	 * @return
	 */
	int deleteById(long id);

	/**
	 * 根据ID删除记录.
	 * @param id
	 * @return
	 */
	int deleteById(String id);
	
	/**
	 * 根据条件查询 listBy
	 * @param paramMap
	 * @return
	 */
	List<T> listBy(Map<String, Object> paramMap);

	/**
	 * 根据条件查询 listBy
	 * @param paramMap
	 * @return
	 */
	T getBy(Map<String, Object> paramMap);

}
