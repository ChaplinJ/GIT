package com.owinfo.object.dto;

import java.util.Date;

/**
 * @author Created by hekunlin on 2018年02月02日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class AccountRechargeDTO {

    private Date operationTime;
    private String certificateNumber;
    private String clientName;
    private Integer rechargeType;
    private Integer operationType;
    private Integer preOperationBalance;
    private Integer operationAmount;
    private Integer sufOperationBalance;

    public AccountRechargeDTO() {
    }

    public AccountRechargeDTO(Date operationTime, String certificateNumber, String clientName, Integer rechargeType, Integer operationType, Integer preOperationBalance, Integer operationAmount, Integer sufOperationBalance) {
        this.operationTime = operationTime;
        this.certificateNumber = certificateNumber;
        this.clientName = clientName;
        this.rechargeType = rechargeType;
        this.operationType = operationType;
        this.preOperationBalance = preOperationBalance;
        this.operationAmount = operationAmount;
        this.sufOperationBalance = sufOperationBalance;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Integer getRechargeType() {
        return rechargeType;
    }

    public void setRechargeType(Integer rechargeType) {
        this.rechargeType = rechargeType;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public Integer getPreOperationBalance() {
        return preOperationBalance;
    }

    public void setPreOperationBalance(Integer preOperationBalance) {
        this.preOperationBalance = preOperationBalance;
    }

    public Integer getOperationAmount() {
        return operationAmount;
    }

    public void setOperationAmount(Integer operationAmount) {
        this.operationAmount = operationAmount;
    }

    public Integer getSufOperationBalance() {
        return sufOperationBalance;
    }

    public void setSufOperationBalance(Integer sufOperationBalance) {
        this.sufOperationBalance = sufOperationBalance;
    }
}
