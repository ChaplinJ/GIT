package com.owinfo.object.dto;

import java.util.Date;

/**
 * @author Created by chenxiaofeng on 2018年04月10日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class ExportFinanceFlowDTO {

    private String accountSubject;  //账户类型（操作对象）
    private Date operationTime;     //流动时间
    private String operationType;  //操作类型
    private String rechargeType;   //充值方式
    private String operationMark;   //操作符号
    private String fillTransferStatus;  //补圈存状态
    private String preOperationBalance;  //操作前金额
    private String operationAmount;      //操作金额
    private String sufOperationBalance;   //操作后金额
    private String accountSubjectNo;       //账号号码（卡账户的时候是ETC卡号；用户账户时是用户账号）
    private String certificateNumber;      //客户证件号
    private String clientName;             //客户名称
    private String cardStatus;            //卡状态

    public ExportFinanceFlowDTO() {
    }

    public ExportFinanceFlowDTO(String accountSubject, Date operationTime, String operationType, String rechargeType, String operationMark, String fillTransferStatus, String preOperationBalance, String operationAmount, String sufOperationBalance, String accountSubjectNo, String certificateNumber, String clientName, String cardStatus) {
        this.accountSubject = accountSubject;
        this.operationTime = operationTime;
        this.operationType = operationType;
        this.rechargeType = rechargeType;
        this.operationMark = operationMark;
        this.fillTransferStatus = fillTransferStatus;
        this.preOperationBalance = preOperationBalance;
        this.operationAmount = operationAmount;
        this.sufOperationBalance = sufOperationBalance;
        this.accountSubjectNo = accountSubjectNo;
        this.certificateNumber = certificateNumber;
        this.clientName = clientName;
        this.cardStatus = cardStatus;
    }

    public String getAccountSubject() {
        return accountSubject;
    }

    public void setAccountSubject(String accountSubject) {
        this.accountSubject = accountSubject;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getRechargeType() {
        return rechargeType;
    }

    public void setRechargeType(String rechargeType) {
        this.rechargeType = rechargeType;
    }

    public String getOperationMark() {
        return operationMark;
    }

    public void setOperationMark(String operationMark) {
        this.operationMark = operationMark;
    }

    public String getFillTransferStatus() {
        return fillTransferStatus;
    }

    public void setFillTransferStatus(String fillTransferStatus) {
        this.fillTransferStatus = fillTransferStatus;
    }

    public String getPreOperationBalance() {
        return preOperationBalance;
    }

    public void setPreOperationBalance(String preOperationBalance) {
        this.preOperationBalance = preOperationBalance;
    }

    public String getOperationAmount() {
        return operationAmount;
    }

    public void setOperationAmount(String operationAmount) {
        this.operationAmount = operationAmount;
    }

    public String getSufOperationBalance() {
        return sufOperationBalance;
    }

    public void setSufOperationBalance(String sufOperationBalance) {
        this.sufOperationBalance = sufOperationBalance;
    }

    public String getAccountSubjectNo() {
        return accountSubjectNo;
    }

    public void setAccountSubjectNo(String accountSubjectNo) {
        this.accountSubjectNo = accountSubjectNo;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCardStatus() {
        return cardStatus;
    }

    public void setCardStatus(String cardStatus) {
        this.cardStatus = cardStatus;
    }
}
