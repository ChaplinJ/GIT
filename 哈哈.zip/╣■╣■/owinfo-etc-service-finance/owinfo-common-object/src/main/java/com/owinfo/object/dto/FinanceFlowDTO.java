package com.owinfo.object.dto;

import java.util.Date;

/**
 * @author Created by hekunlin on 2018年02月02日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class FinanceFlowDTO {

    private String accountSubject;  //账户类型（操作对象）
    private Date operationTime;     //流动时间
    private Integer operationType;  //操作类型
    private Integer rechargeType;   //充值方式
    private Integer operationMark;   //操作符号
    private Integer fillTransferStatus;  //补圈存状态
    private Integer preOperationBalance;  //操作前金额
    private Integer operationAmount;      //操作金额
    private Integer sufOperationBalance;   //操作后金额
    private String accountSubjectNo;       //账号号码（卡账户的时候是ETC卡号；用户账户时是用户账号）
    private String certificateNumber;      //客户证件号
    private String clientName;             //客户名称
    private String cardStatus;            //卡状态

    public FinanceFlowDTO() {
    }

    public FinanceFlowDTO(String accountSubject, Date operationTime, Integer operationType, Integer rechargeType, Integer operationMark, Integer fillTransferStatus, Integer preOperationBalance, Integer operationAmount, Integer sufOperationBalance, String accountSubjectNo, String certificateNumber, String clientName, String cardStatus) {
        this.accountSubject = accountSubject;
        this.operationTime = operationTime;
        this.operationType = operationType;
        this.rechargeType = rechargeType;
        this.operationMark = operationMark;
        this.fillTransferStatus = fillTransferStatus;
        this.preOperationBalance = preOperationBalance;
        this.operationAmount = operationAmount;
        this.sufOperationBalance = sufOperationBalance;
        this.accountSubjectNo = accountSubjectNo;
        this.certificateNumber = certificateNumber;
        this.clientName = clientName;
        this.cardStatus = cardStatus;
    }

    public String getAccountSubject() {
        return accountSubject;
    }

    public void setAccountSubject(String accountSubject) {
        this.accountSubject = accountSubject;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public Integer getRechargeType() {
        return rechargeType;
    }

    public void setRechargeType(Integer rechargeType) {
        this.rechargeType = rechargeType;
    }

    public Integer getOperationMark() {
        return operationMark;
    }

    public void setOperationMark(Integer operationMark) {
        this.operationMark = operationMark;
    }

    public Integer getFillTransferStatus() {
        return fillTransferStatus;
    }

    public void setFillTransferStatus(Integer fillTransferStatus) {
        this.fillTransferStatus = fillTransferStatus;
    }

    public Integer getPreOperationBalance() {
        return preOperationBalance;
    }

    public void setPreOperationBalance(Integer preOperationBalance) {
        this.preOperationBalance = preOperationBalance;
    }

    public Integer getOperationAmount() {
        return operationAmount;
    }

    public void setOperationAmount(Integer operationAmount) {
        this.operationAmount = operationAmount;
    }

    public Integer getSufOperationBalance() {
        return sufOperationBalance;
    }

    public void setSufOperationBalance(Integer sufOperationBalance) {
        this.sufOperationBalance = sufOperationBalance;
    }

    public String getAccountSubjectNo() {
        return accountSubjectNo;
    }

    public void setAccountSubjectNo(String accountSubjectNo) {
        this.accountSubjectNo = accountSubjectNo;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCardStatus() {
        return cardStatus;
    }

    public void setCardStatus(String cardStatus) {
        this.cardStatus = cardStatus;
    }
}
