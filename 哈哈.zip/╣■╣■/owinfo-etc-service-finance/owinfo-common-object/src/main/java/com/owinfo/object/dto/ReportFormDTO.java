package com.owinfo.object.dto;

/**
 * @author Created by hekunlin on 2017年12月08日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class ReportFormDTO {

    private String channelNum;

    private String  channelName;

    private Integer channelCount;

    private Integer siteCountBalance;

    private Integer passengerCarCount;

    private Integer passengerCarBalance;

    private Integer trunkCount;

    private Integer trunkCountBalance;

    public ReportFormDTO() {
    }

    public ReportFormDTO(String channelNum, String channelName, Integer channelCount, Integer siteCountBalance, Integer passengerCarCount, Integer passengerCarBalance, Integer trunkCount, Integer trunkCountBalance) {
        this.channelNum = channelNum;
        this.channelName = channelName;
        this.channelCount = channelCount;
        this.siteCountBalance = siteCountBalance;
        this.passengerCarCount = passengerCarCount;
        this.passengerCarBalance = passengerCarBalance;
        this.trunkCount = trunkCount;
        this.trunkCountBalance = trunkCountBalance;
    }

    public String getChannelNum() {
        return channelNum;
    }

    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getChannelCount() {
        return channelCount;
    }

    public void setChannelCount(Integer channelCount) {
        this.channelCount = channelCount;
    }

    public Integer getSiteCountBalance() {
        return siteCountBalance;
    }

    public void setSiteCountBalance(Integer siteCountBalance) {
        this.siteCountBalance = siteCountBalance;
    }

    public Integer getPassengerCarCount() {
        return passengerCarCount;
    }

    public void setPassengerCarCount(Integer passengerCarCount) {
        this.passengerCarCount = passengerCarCount;
    }

    public Integer getPassengerCarBalance() {
        return passengerCarBalance;
    }

    public void setPassengerCarBalance(Integer passengerCarBalance) {
        this.passengerCarBalance = passengerCarBalance;
    }

    public Integer getTrunkCount() {
        return trunkCount;
    }

    public void setTrunkCount(Integer trunkCount) {
        this.trunkCount = trunkCount;
    }

    public Integer getTrunkCountBalance() {
        return trunkCountBalance;
    }

    public void setTrunkCountBalance(Integer trunkCountBalance) {
        this.trunkCountBalance = trunkCountBalance;
    }
}
