package com.owinfo.object.entity;

/**
 * @author Created by hekunlin on 2018年01月17日
 *         github : https://github.com/rexlin600/
 * @Description app圈存初始化
 */
public class AppInit {

    /**
     * 卡号截取8-10位 22：储值卡  23：记账卡
     *
     */
    private String cardNo;

    private String se;

    private Integer amount;

    private String signDate;

    private String cardInfo;

    private String terminal;

    private String optTime;


    // 以下为待组装参数

    private String random;

    private String clientNo;

    private int operationMoney;

    private String tradeNum;

    private String channelNum;

    private String channelType;

    private String channelName;

    private String acquirerNo;

    private String siteName;

    private String employeeNo;

    private Integer clientType;

    private String clientName;

    private String certificateNumber;

    private String vehicleLicense;

    private String vehicleType;

    private String accountSubject;

    private String accountSubjectNo;

    private int preOperationBalance;

    private int operationBalance;

    private int sufOperationBalance;

    private String operationUser;

    private String operationTime;

    private String createBy;

    public AppInit() {
    }

    public AppInit(String cardNo, String se, Integer amount, String signDate, String cardInfo, String random, String terminal, String clientNo, int operationMoney, String tradeNum, String channelNum, String channelType, String channelName, String acquirerNo, String siteName, String employeeNo, Integer clientType, String clientName, String certificateNumber, String vehicleLicense, String vehicleType, String accountSubject, String accountSubjectNo, int preOperationBalance, int operationBalance, int sufOperationBalance, String operationUser, String operationTime, String createBy, String optTime) {
        this.cardNo = cardNo;
        this.se = se;
        this.amount = amount;
        this.signDate = signDate;
        this.cardInfo = cardInfo;
        this.random = random;
        this.terminal = terminal;
        this.clientNo = clientNo;
        this.operationMoney = operationMoney;
        this.tradeNum = tradeNum;
        this.channelNum = channelNum;
        this.channelType = channelType;
        this.channelName = channelName;
        this.acquirerNo = acquirerNo;
        this.siteName = siteName;
        this.employeeNo = employeeNo;
        this.clientType = clientType;
        this.clientName = clientName;
        this.certificateNumber = certificateNumber;
        this.vehicleLicense = vehicleLicense;
        this.vehicleType = vehicleType;
        this.accountSubject = accountSubject;
        this.accountSubjectNo = accountSubjectNo;
        this.preOperationBalance = preOperationBalance;
        this.operationBalance = operationBalance;
        this.sufOperationBalance = sufOperationBalance;
        this.operationUser = operationUser;
        this.operationTime = operationTime;
        this.createBy = createBy;
        this.optTime = optTime;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getSe() {
        return se;
    }

    public void setSe(String se) {
        this.se = se;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getSignDate() {
        return signDate;
    }

    public void setSignDate(String signDate) {
        this.signDate = signDate;
    }

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo;
    }

    public String getRandom() {
        return random;
    }

    public void setRandom(String random) {
        this.random = random;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    public int getOperationMoney() {
        return operationMoney;
    }

    public void setOperationMoney(int operationMoney) {
        this.operationMoney = operationMoney;
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum;
    }

    public String getChannelNum() {
        return channelNum;
    }

    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getAcquirerNo() {
        return acquirerNo;
    }

    public void setAcquirerNo(String acquirerNo) {
        this.acquirerNo = acquirerNo;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getVehicleLicense() {
        return vehicleLicense;
    }

    public void setVehicleLicense(String vehicleLicense) {
        this.vehicleLicense = vehicleLicense;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getAccountSubject() {
        return accountSubject;
    }

    public void setAccountSubject(String accountSubject) {
        this.accountSubject = accountSubject;
    }

    public String getAccountSubjectNo() {
        return accountSubjectNo;
    }

    public void setAccountSubjectNo(String accountSubjectNo) {
        this.accountSubjectNo = accountSubjectNo;
    }

    public int getPreOperationBalance() {
        return preOperationBalance;
    }

    public void setPreOperationBalance(int preOperationBalance) {
        this.preOperationBalance = preOperationBalance;
    }

    public int getOperationBalance() {
        return operationBalance;
    }

    public void setOperationBalance(int operationBalance) {
        this.operationBalance = operationBalance;
    }

    public int getSufOperationBalance() {
        return sufOperationBalance;
    }

    public void setSufOperationBalance(int sufOperationBalance) {
        this.sufOperationBalance = sufOperationBalance;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public String getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(String operationTime) {
        this.operationTime = operationTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getOptTime() {
        return optTime;
    }

    public void setOptTime(String optTime) {
        this.optTime = optTime;
    }

    @Override
    public String toString() {
        return "AppInit{" +
                "cardNo='" + cardNo + '\'' +
                ", se='" + se + '\'' +
                ", amount=" + amount +
                ", signDate='" + signDate + '\'' +
                ", cardInfo='" + cardInfo + '\'' +
                ", random='" + random + '\'' +
                ", terminal='" + terminal + '\'' +
                ", clientNo='" + clientNo + '\'' +
                ", operationMoney=" + operationMoney +
                ", tradeNum='" + tradeNum + '\'' +
                ", channelNum='" + channelNum + '\'' +
                ", channelType='" + channelType + '\'' +
                ", channelName='" + channelName + '\'' +
                ", acquirerNo='" + acquirerNo + '\'' +
                ", siteName='" + siteName + '\'' +
                ", employeeNo='" + employeeNo + '\'' +
                ", clientType=" + clientType +
                ", clientName='" + clientName + '\'' +
                ", certificateNumber='" + certificateNumber + '\'' +
                ", vehicleLicense='" + vehicleLicense + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", accountSubject='" + accountSubject + '\'' +
                ", accountSubjectNo='" + accountSubjectNo + '\'' +
                ", preOperationBalance=" + preOperationBalance +
                ", operationBalance=" + operationBalance +
                ", sufOperationBalance=" + sufOperationBalance +
                ", operationUser='" + operationUser + '\'' +
                ", operationTime='" + operationTime + '\'' +
                ", createBy='" + createBy + '\'' +
                ", optTime='" + optTime + '\'' +
                '}';
    }
}
