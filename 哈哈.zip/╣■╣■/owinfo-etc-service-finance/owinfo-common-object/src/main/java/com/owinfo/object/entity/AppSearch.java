package com.owinfo.object.entity;

/**
 * @author Created by hekunlin on 2018年01月17日
 *         github : https://github.com/rexlin600/
 * @Description app圈存卡账查询参数
 */
public class AppSearch {

    private String cardNo;

    private String cardInfo;

    private String se;

    public AppSearch() {
    }

    public AppSearch(String cardNo, String cardInfo, String se) {
        this.cardNo = cardNo;
        this.cardInfo = cardInfo;
        this.se = se;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo;
    }

    public String getSe() {
        return se;
    }

    public void setSe(String se) {
        this.se = se;
    }

    @Override
    public String toString() {
        return "AppSearch{" +
                "cardNo='" + cardNo + '\'' +
                ", cardInfo='" + cardInfo + '\'' +
                ", se='" + se + '\'' +
                '}';
    }
}
