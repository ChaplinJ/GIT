package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class BankRechargeOperation {

    private String id;

    private String tradeNum;

    private String businessNo;

    private String channelType;

    private String channelNum;

    private String channelName;

    private String acquirerNo;

    private String clientName;

    private String certNo;

    private String cardNumber;

    private String clientAcount;

    private String bankAccountOfThings;

    private Integer transferType;

    private Integer operationType;

    private Integer transferMode;

    private Integer paidAmount;

    private Integer giftAmount;

    private Integer rechargeAmount;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date operatorTime;

    private String employeeNo;

    private String createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private Integer remove;

    private String spare1;

    private String spare2;

    private String spare3;

    public BankRechargeOperation() {
    }

    public BankRechargeOperation(String id, String tradeNum, String businessNo, String channelType, String channelNum, String channelName, String acquirerNo, String clientName, String certNo, String cardNumber, String clientAcount, String bankAccountOfThings, Integer transferType, Integer operationType, Integer transferMode, Integer paidAmount, Integer giftAmount, Integer rechargeAmount, Date operatorTime, String employeeNo, String createBy, Date createTime, Integer remove, String spare1, String spare2, String spare3) {
        this.id = id;
        this.tradeNum = tradeNum;
        this.businessNo = businessNo;
        this.channelType = channelType;
        this.channelNum = channelNum;
        this.channelName = channelName;
        this.acquirerNo = acquirerNo;
        this.clientName = clientName;
        this.certNo = certNo;
        this.cardNumber = cardNumber;
        this.clientAcount = clientAcount;
        this.bankAccountOfThings = bankAccountOfThings;
        this.transferType = transferType;
        this.operationType = operationType;
        this.transferMode = transferMode;
        this.paidAmount = paidAmount;
        this.giftAmount = giftAmount;
        this.rechargeAmount = rechargeAmount;
        this.operatorTime = operatorTime;
        this.employeeNo = employeeNo;
        this.createBy = createBy;
        this.createTime = createTime;
        this.remove = remove;
        this.spare1 = spare1;
        this.spare2 = spare2;
        this.spare3 = spare3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum;
    }

    public String getBusinessNo() {
        return businessNo;
    }

    public void setBusinessNo(String businessNo) {
        this.businessNo = businessNo;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelNum() {
        return channelNum;
    }

    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getAcquirerNo() {
        return acquirerNo;
    }

    public void setAcquirerNo(String acquirerNo) {
        this.acquirerNo = acquirerNo;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getClientAcount() {
        return clientAcount;
    }

    public void setClientAcount(String clientAcount) {
        this.clientAcount = clientAcount;
    }

    public String getBankAccountOfThings() {
        return bankAccountOfThings;
    }

    public void setBankAccountOfThings(String bankAccountOfThings) {
        this.bankAccountOfThings = bankAccountOfThings;
    }

    public Integer getTransferType() {
        return transferType;
    }

    public void setTransferType(Integer transferType) {
        this.transferType = transferType;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public Integer getTransferMode() {
        return transferMode;
    }

    public void setTransferMode(Integer transferMode) {
        this.transferMode = transferMode;
    }

    public Integer getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Integer paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Integer getGiftAmount() {
        return giftAmount;
    }

    public void setGiftAmount(Integer giftAmount) {
        this.giftAmount = giftAmount;
    }

    public Integer getRechargeAmount() {
        return rechargeAmount;
    }

    public void setRechargeAmount(Integer rechargeAmount) {
        this.rechargeAmount = rechargeAmount;
    }

    public Date getOperatorTime() {
        return operatorTime;
    }

    public void setOperatorTime(Date operatorTime) {
        this.operatorTime = operatorTime;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1;
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2;
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3;
    }
}