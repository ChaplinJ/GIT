package com.owinfo.object.entity;

import com.owinfo.core.entity.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

public class Etccardinfo extends BaseEntity{
    private String id;

    private String cardId;

    private Date tradeTime;

    private String cardStatus;

    private BigDecimal cardBalance;

    private BigDecimal cardAccountBalance;

    private String clientNo;

    private BigDecimal cardPrice;

    private String billPoSt;

    private Date liquidateTime;

    private BigDecimal liquidateNumber;

    private Date cardLiquidateTime;

    private String liquidateStatus;

    private String operateType;

    private String stationId;

    private String obuId;

    private String bindStatus;

    private String vehicleLicense;

    private String payType;

    private String favorRate;

    private String operatorId;

    private String verifyCode;

    private String transferMark;

    private String createBy;

    private Date createTime;

    private String updateBy;

    private Date updateTime;

    private String remove;

    private String spare;

    private String spare1;

    private String spare2;

    private String certificateNumber;

    private String clientName;

    private String signCardId;

    private String signStatus;

    private String clientType;

    private String cardType;    //营改增

    private String brand;   //营改增

    private String model;   //营改增

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId == null ? null : cardId.trim();
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public String getCardStatus() {
        return cardStatus;
    }

    public void setCardStatus(String cardStatus) {
        this.cardStatus = cardStatus == null ? null : cardStatus.trim();
    }

    public BigDecimal getCardBalance() {
        return cardBalance;
    }

    public void setCardBalance(BigDecimal cardBalance) {
        this.cardBalance = cardBalance;
    }

    public BigDecimal getCardAccountBalance() {
        return cardAccountBalance;
    }

    public void setCardAccountBalance(BigDecimal cardAccountBalance) {
        this.cardAccountBalance = cardAccountBalance;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo == null ? null : clientNo.trim();
    }

    public BigDecimal getCardPrice() {
        return cardPrice;
    }

    public void setCardPrice(BigDecimal cardPrice) {
        this.cardPrice = cardPrice;
    }

    public String getBillPoSt() {
        return billPoSt;
    }

    public void setBillPoSt(String billPoSt) {
        this.billPoSt = billPoSt == null ? null : billPoSt.trim();
    }

    public Date getLiquidateTime() {
        return liquidateTime;
    }

    public void setLiquidateTime(Date liquidateTime) {
        this.liquidateTime = liquidateTime;
    }

    public BigDecimal getLiquidateNumber() {
        return liquidateNumber;
    }

    public void setLiquidateNumber(BigDecimal liquidateNumber) {
        this.liquidateNumber = liquidateNumber;
    }

    public Date getCardLiquidateTime() {
        return cardLiquidateTime;
    }

    public void setCardLiquidateTime(Date cardLiquidateTime) {
        this.cardLiquidateTime = cardLiquidateTime;
    }

    public String getLiquidateStatus() {
        return liquidateStatus;
    }

    public void setLiquidateStatus(String liquidateStatus) {
        this.liquidateStatus = liquidateStatus == null ? null : liquidateStatus.trim();
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType == null ? null : operateType.trim();
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId == null ? null : stationId.trim();
    }

    public String getObuId() {
        return obuId;
    }

    public void setObuId(String obuId) {
        this.obuId = obuId == null ? null : obuId.trim();
    }

    public String getBindStatus() {
        return bindStatus;
    }

    public void setBindStatus(String bindStatus) {
        this.bindStatus = bindStatus == null ? null : bindStatus.trim();
    }

    public String getVehicleLicense() {
        return vehicleLicense;
    }

    public void setVehicleLicense(String vehicleLicense) {
        this.vehicleLicense = vehicleLicense == null ? null : vehicleLicense.trim();
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType == null ? null : payType.trim();
    }

    public String getFavorRate() {
        return favorRate;
    }

    public void setFavorRate(String favorRate) {
        this.favorRate = favorRate;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId == null ? null : operatorId.trim();
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode == null ? null : verifyCode.trim();
    }

    public String getTransferMark() {
        return transferMark;
    }

    public void setTransferMark(String transferMark) {
        this.transferMark = transferMark == null ? null : transferMark.trim();
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemove() {
        return remove;
    }

    public void setRemove(String remove) {
        this.remove = remove == null ? null : remove.trim();
    }

    public String getSpare() {
        return spare;
    }

    public void setSpare(String spare) {
        this.spare = spare == null ? null : spare.trim();
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber == null ? null : certificateNumber.trim();
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName == null ? null : clientName.trim();
    }

    public String getSignCardId() {
        return signCardId;
    }

    public void setSignCardId(String signCardId) {
        this.signCardId = signCardId == null ? null : signCardId.trim();
    }

    public String getSignStatus() {
        return signStatus;
    }

    public void setSignStatus(String signStatus) {
        this.signStatus = signStatus == null ? null : signStatus.trim();
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return "Etccardinfo{" +
                "id='" + id + '\'' +
                ", cardId='" + cardId + '\'' +
                ", tradeTime=" + tradeTime +
                ", cardStatus='" + cardStatus + '\'' +
                ", cardBalance=" + cardBalance +
                ", cardAccountBalance=" + cardAccountBalance +
                ", clientNo='" + clientNo + '\'' +
                ", cardPrice=" + cardPrice +
                ", billPoSt='" + billPoSt + '\'' +
                ", liquidateTime=" + liquidateTime +
                ", liquidateNumber=" + liquidateNumber +
                ", cardLiquidateTime=" + cardLiquidateTime +
                ", liquidateStatus='" + liquidateStatus + '\'' +
                ", operateType='" + operateType + '\'' +
                ", stationId='" + stationId + '\'' +
                ", obuId='" + obuId + '\'' +
                ", bindStatus='" + bindStatus + '\'' +
                ", vehicleLicense='" + vehicleLicense + '\'' +
                ", payType='" + payType + '\'' +
                ", favorRate='" + favorRate + '\'' +
                ", operatorId='" + operatorId + '\'' +
                ", verifyCode='" + verifyCode + '\'' +
                ", transferMark='" + transferMark + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", remove='" + remove + '\'' +
                ", spare='" + spare + '\'' +
                ", spare1='" + spare1 + '\'' +
                ", spare2='" + spare2 + '\'' +
                ", certificateNumber='" + certificateNumber + '\'' +
                ", clientName='" + clientName + '\'' +
                ", signCardId='" + signCardId + '\'' +
                ", signStatus='" + signStatus + '\'' +
                ", clientType='" + clientType + '\'' +
                ", cardType='" + cardType + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                '}';
    }
}