package com.owinfo.object.entity;

import com.owinfo.core.entity.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

public class Etcclientinfo extends BaseEntity{
    private String id;

    private Date tradeTime;

    private String operateType;

    private String clientNo;

    private String certificateType;

    private String certificateNumber;

    private String telephone;

    private String phoneNumber;

    private String address;

    private String postCode;

    private String accountPass;

    private String bankStatus;

    private String bankName;

    private String bankId;

    private String bankNumber;

    private BigDecimal accountBalance;

    private String cipherBalance;

    private String clientType;

    private String unitCertificateType;

    private String unitName;

    private String unitCertificateNo;

    private String unitDeptName;

    private String faxNumber;

    private String email;

    private String infoEnable;

    private String stationId;

    private String machineCode;

    private String clientName;

    private String sex;

    private String verifyCode;

    private String transferMark;

    private String operatorId;

    private String managerId;

    private String createBy;

    private Date createTime;

    private String updateBy;

    private Date updateTime;

    private String remove;

    private String spare;

    private String spare1;

    private String spare2;

    private String unitAddress;

    private BigDecimal payBalance;

    private String contactName;//经办人姓名

    private String contactType;//经办人证件类型

    private String contactCertificate;//经办人证件号

    private String contactTelephone;//经办人联系电话

    private String flag;//标记参数   group企业证件号关联

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public String getContactCertificate() {
        return contactCertificate;
    }

    public void setContactCertificate(String contactCertificate) {
        this.contactCertificate = contactCertificate;
    }

    public String getContactTelephone() {
        return contactTelephone;
    }

    public void setContactTelephone(String contactTelephone) {
        this.contactTelephone = contactTelephone;
    }

    public BigDecimal getPayBalance() {
        return payBalance;
    }

    public void setPayBalance(BigDecimal payBalance) {
        this.payBalance = payBalance;
    }

    public String getUnitAddress() {
        return unitAddress;
    }

    public void setUnitAddress(String unitAddress) {
        this.unitAddress = unitAddress;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public String getOperateType() {
        return operateType;
    }

    public void setOperateType(String operateType) {
        this.operateType = operateType;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    public String getCertificateType() {
        return certificateType;
    }

    public void setCertificateType(String certificateType) {
        this.certificateType = certificateType;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getAccountPass() {
        return accountPass;
    }

    public void setAccountPass(String accountPass) {
        this.accountPass = accountPass;
    }

    public String getBankStatus() {
        return bankStatus;
    }

    public void setBankStatus(String bankStatus) {
        this.bankStatus = bankStatus;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber;
    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }

    public String getCipherBalance() {
        return cipherBalance;
    }

    public void setCipherBalance(String cipherBalance) {
        this.cipherBalance = cipherBalance;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public String getUnitCertificateType() {
        return unitCertificateType;
    }

    public void setUnitCertificateType(String unitCertificateType) {
        this.unitCertificateType = unitCertificateType;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getUnitCertificateNo() {
        return unitCertificateNo;
    }

    public void setUnitCertificateNo(String unitCertificateNo) {
        this.unitCertificateNo = unitCertificateNo;
    }

    public String getUnitDeptName() {
        return unitDeptName;
    }

    public void setUnitDeptName(String unitDeptName) {
        this.unitDeptName = unitDeptName;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInfoEnable() {
        return infoEnable;
    }

    public void setInfoEnable(String infoEnable) {
        this.infoEnable = infoEnable;
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

    public String getMachineCode() {
        return machineCode;
    }

    public void setMachineCode(String machineCode) {
        this.machineCode = machineCode;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public String getTransferMark() {
        return transferMark;
    }

    public void setTransferMark(String transferMark) {
        this.transferMark = transferMark;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getManagerId() {
        return managerId;
    }

    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemove() {
        return remove;
    }

    public void setRemove(String remove) {
        this.remove = remove;
    }

    public String getSpare() {
        return spare;
    }

    public void setSpare(String spare) {
        this.spare = spare;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1;
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2;
    }

    @Override
    public String toString() {
        return "Etcclientinfo{" +
                "id='" + id + '\'' +
                ", tradeTime=" + tradeTime +
                ", operateType='" + operateType + '\'' +
                ", clientNo='" + clientNo + '\'' +
                ", certificateType='" + certificateType + '\'' +
                ", certificateNumber='" + certificateNumber + '\'' +
                ", telephone='" + telephone + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", address='" + address + '\'' +
                ", postCode='" + postCode + '\'' +
                ", accountPass='" + accountPass + '\'' +
                ", bankStatus='" + bankStatus + '\'' +
                ", bankName='" + bankName + '\'' +
                ", bankId='" + bankId + '\'' +
                ", bankNumber='" + bankNumber + '\'' +
                ", accountBalance=" + accountBalance +
                ", cipherBalance='" + cipherBalance + '\'' +
                ", clientType='" + clientType + '\'' +
                ", unitCertificateType='" + unitCertificateType + '\'' +
                ", unitName='" + unitName + '\'' +
                ", unitCertificateNo='" + unitCertificateNo + '\'' +
                ", unitDeptName='" + unitDeptName + '\'' +
                ", faxNumber='" + faxNumber + '\'' +
                ", email='" + email + '\'' +
                ", infoEnable='" + infoEnable + '\'' +
                ", stationId='" + stationId + '\'' +
                ", machineCode='" + machineCode + '\'' +
                ", clientName='" + clientName + '\'' +
                ", sex='" + sex + '\'' +
                ", verifyCode='" + verifyCode + '\'' +
                ", transferMark='" + transferMark + '\'' +
                ", operatorId='" + operatorId + '\'' +
                ", managerId='" + managerId + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", remove='" + remove + '\'' +
                ", spare='" + spare + '\'' +
                ", spare1='" + spare1 + '\'' +
                ", spare2='" + spare2 + '\'' +
                ", unitAddress='" + unitAddress + '\'' +
                ", payBalance=" + payBalance +
                ", contactName='" + contactName + '\'' +
                ", contactType='" + contactType + '\'' +
                ", contactCertificate='" + contactCertificate + '\'' +
                ", contactTelephone='" + contactTelephone + '\'' +
                ", flag='" + flag + '\'' +
                '}';
    }
}