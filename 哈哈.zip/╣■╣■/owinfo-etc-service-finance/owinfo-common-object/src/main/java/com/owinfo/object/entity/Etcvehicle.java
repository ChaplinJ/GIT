package com.owinfo.object.entity;

import java.math.BigDecimal;
import java.util.Date;

public class Etcvehicle {
    private String id;

    private Date tradeTime;

    private String vehicleLicense;

    private String vehicleColor;

    private String vehicleType;

    private String driveLicenseType;

    private String driveUseType;

    private String contactName;

    private String driveBrandType;

    private String driveIdentifyNo;

    private String archiveNo;

    private String engineNo;

    private String registrationDate;

    private String issueDate;

    private Integer approveNo;

    private BigDecimal totalQuality;

    private BigDecimal serviceQuality;

    private BigDecimal approveQuality;

    private String vehicleSize;

    private BigDecimal tractionQuality;

    private Integer wheelNo;

    private Integer axleNo;

    private BigDecimal wheelbase;

    private String axleType;

    private String inspectionRecord;

    private String isOwner;

    private String createBy;

    private Date createTime;

    private String updateBy;

    private Date updateTime;

    private String remove;

    private String spare;

    private String spare1;

    private String certificateOwn;

    private String ownName;

    private String certificateType;

    private String ownPhone;

    private String ownAddress;

    private String certificateNumber;

    private String cardId;

    private String cardStatus;

    private String obuId;

    private String obuStatus;

    private Date suspendTime;

    private String status;

    private String stationId;

    private String flag;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getSuspendTime() {
        return suspendTime;
    }

    public void setSuspendTime(Date suspendTime) {
        this.suspendTime = suspendTime;
    }

    public String getCertificateOwn() {
        return certificateOwn;
    }

    public void setCertificateOwn(String certificateOwn) {
        this.certificateOwn = certificateOwn;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getCardStatus() {
        return cardStatus;
    }

    public void setCardStatus(String cardStatus) {
        this.cardStatus = cardStatus;
    }

    public String getObuId() {
        return obuId;
    }

    public void setObuId(String obuId) {
        this.obuId = obuId;
    }

    public String getObuStatus() {
        return obuStatus;
    }

    public void setObuStatus(String obuStatus) {
        this.obuStatus = obuStatus;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public String getVehicleLicense() {
        return vehicleLicense;
    }

    public void setVehicleLicense(String vehicleLicense) {
        this.vehicleLicense = vehicleLicense;
    }

    public String getVehicleColor() {
        return vehicleColor;
    }

    public void setVehicleColor(String vehicleColor) {
        this.vehicleColor = vehicleColor;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getDriveLicenseType() {
        return driveLicenseType;
    }

    public void setDriveLicenseType(String driveLicenseType) {
        this.driveLicenseType = driveLicenseType;
    }

    public String getDriveUseType() {
        return driveUseType;
    }

    public void setDriveUseType(String driveUseType) {
        this.driveUseType = driveUseType;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getDriveBrandType() {
        return driveBrandType;
    }

    public void setDriveBrandType(String driveBrandType) {
        this.driveBrandType = driveBrandType;
    }

    public String getDriveIdentifyNo() {
        return driveIdentifyNo;
    }

    public void setDriveIdentifyNo(String driveIdentifyNo) {
        this.driveIdentifyNo = driveIdentifyNo;
    }

    public String getArchiveNo() {
        return archiveNo;
    }

    public void setArchiveNo(String archiveNo) {
        this.archiveNo = archiveNo;
    }

    public String getEngineNo() {
        return engineNo;
    }

    public void setEngineNo(String engineNo) {
        this.engineNo = engineNo;
    }

    public String getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public Integer getApproveNo() {
        return approveNo;
    }

    public void setApproveNo(Integer approveNo) {
        this.approveNo = approveNo;
    }

    public BigDecimal getTotalQuality() {
        return totalQuality;
    }

    public void setTotalQuality(BigDecimal totalQuality) {
        this.totalQuality = totalQuality;
    }

    public BigDecimal getServiceQuality() {
        return serviceQuality;
    }

    public void setServiceQuality(BigDecimal serviceQuality) {
        this.serviceQuality = serviceQuality;
    }

    public BigDecimal getApproveQuality() {
        return approveQuality;
    }

    public void setApproveQuality(BigDecimal approveQuality) {
        this.approveQuality = approveQuality;
    }

    public String getVehicleSize() {
        return vehicleSize;
    }

    public void setVehicleSize(String vehicleSize) {
        this.vehicleSize = vehicleSize;
    }

    public BigDecimal getTractionQuality() {
        return tractionQuality;
    }

    public void setTractionQuality(BigDecimal tractionQuality) {
        this.tractionQuality = tractionQuality;
    }

    public Integer getWheelNo() {
        return wheelNo;
    }

    public void setWheelNo(Integer wheelNo) {
        this.wheelNo = wheelNo;
    }

    public Integer getAxleNo() {
        return axleNo;
    }

    public void setAxleNo(Integer axleNo) {
        this.axleNo = axleNo;
    }

    public BigDecimal getWheelbase() {
        return wheelbase;
    }

    public void setWheelbase(BigDecimal wheelbase) {
        this.wheelbase = wheelbase;
    }

    public String getAxleType() {
        return axleType;
    }

    public void setAxleType(String axleType) {
        this.axleType = axleType;
    }

    public String getInspectionRecord() {
        return inspectionRecord;
    }

    public void setInspectionRecord(String inspectionRecord) {
        this.inspectionRecord = inspectionRecord;
    }

    public String getIsOwner() {
        return isOwner;
    }

    public void setIsOwner(String isOwner) {
        this.isOwner = isOwner;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRemove() {
        return remove;
    }

    public void setRemove(String remove) {
        this.remove = remove;
    }

    public String getSpare() {
        return spare;
    }

    public void setSpare(String spare) {
        this.spare = spare;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1;
    }

    public String getOwnName() {
        return ownName;
    }

    public void setOwnName(String ownName) {
        this.ownName = ownName;
    }

    public String getCertificateType() {
        return certificateType;
    }

    public void setCertificateType(String certificateType) {
        this.certificateType = certificateType;
    }

    public String getOwnPhone() {
        return ownPhone;
    }

    public void setOwnPhone(String ownPhone) {
        this.ownPhone = ownPhone;
    }

    public String getOwnAddress() {
        return ownAddress;
    }

    public void setOwnAddress(String ownAddress) {
        this.ownAddress = ownAddress;
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }
}