package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FrontAllocationOperation {

    private String id;

    private String tradeNum;

    private String siteName;

    private String employeeNo;

    private String clientNo;

    private String clientName;

    private Integer clientType;

    private Integer allocationOperation;

    private Integer accountBalance;

    private Integer allocateAmount;

    private Integer allocateCountAmount;

    private String cardNo;

    private String vehicleNo;

    private Integer cardBalance;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date tradeTime;

    private Integer remove;

    private String createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private String spare3;

    private String spare2;

    private String spare1;

    public FrontAllocationOperation() {
    }

    public FrontAllocationOperation(String id, String tradeNum, String siteName, String employeeNo, String clientNo, String clientName, Integer clientType, Integer allocationOperation, Integer accountBalance, Integer allocateAmount, Integer allocateCountAmount, String cardNo, String vehicleNo, Integer cardBalance, Date tradeTime, Integer remove, String createBy, Date createTime, String spare3, String spare2, String spare1) {
        this.id = id;
        this.tradeNum = tradeNum;
        this.siteName = siteName;
        this.employeeNo = employeeNo;
        this.clientNo = clientNo;
        this.clientName = clientName;
        this.clientType = clientType;
        this.allocationOperation = allocationOperation;
        this.accountBalance = accountBalance;
        this.allocateAmount = allocateAmount;
        this.allocateCountAmount = allocateCountAmount;
        this.cardNo = cardNo;
        this.vehicleNo = vehicleNo;
        this.cardBalance = cardBalance;
        this.tradeTime = tradeTime;
        this.remove = remove;
        this.createBy = createBy;
        this.createTime = createTime;
        this.spare3 = spare3;
        this.spare2 = spare2;
        this.spare1 = spare1;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum == null ? null : tradeNum.trim();
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo == null ? null : clientNo.trim();
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName == null ? null : clientName.trim();
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public Integer getAllocationOperation() {
        return allocationOperation;
    }

    public void setAllocationOperation(Integer allocationOperation) {
        this.allocationOperation = allocationOperation;
    }

    public Integer getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Integer accountBalance) {
        this.accountBalance = accountBalance;
    }

    public Integer getAllocateAmount() {
        return allocateAmount;
    }

    public void setAllocateAmount(Integer allocateAmount) {
        this.allocateAmount = allocateAmount;
    }

    public Integer getAllocateCountAmount() {
        return allocateCountAmount;
    }

    public void setAllocateCountAmount(Integer allocateCountAmount) {
        this.allocateCountAmount = allocateCountAmount;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo == null ? null : cardNo.trim();
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo == null ? null : vehicleNo.trim();
    }

    public Integer getCardBalance() {
        return cardBalance;
    }

    public void setCardBalance(Integer cardBalance) {
        this.cardBalance = cardBalance;
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3 == null ? null : spare3.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }
}