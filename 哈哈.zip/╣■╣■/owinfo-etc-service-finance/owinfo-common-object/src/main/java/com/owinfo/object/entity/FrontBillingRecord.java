package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FrontBillingRecord {

    private String id;

    private String tradeNum;

    private String transId;

    private String channelNum;

    private String channelType;

    private String channelName;

    private String acquirerNo;

    private String siteName;

    private String employeeNo;

    private Integer clientType;

    private String clientName;

    private String certificateNumber;

    private Integer accountSubject;

    private String vehicleLicense;

    private String vehicleType;

    private String accountSubjectNo;

    private Integer accountSubjectStatus;

    private Integer operationType;

    private Integer rechargeType;

    private String rechargeNum;

    private String specificRechargeType;

    private String otherCollectionField;

    private Integer fillTransferStatus;

    private Integer bankType;

    private String clientAcount;

    private Integer clientBalance;

    private String bankAccountOfThings;

    private Integer transferType;

    private Integer transferMode;

    private Integer operationMark;

    private Integer preOperationBalance;

    private Integer operationAmount;

    private Integer sufOperationBalance;

    private String operationUser;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date operationTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date disputeTime;

    private Integer disputeStatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date clearingTime;

    private Integer clearingStatus;

    private String createBy;

    private Integer remove;

    private String spare1;

    private String spare2;

    private String spare3;

    public FrontBillingRecord() {
    }

    public FrontBillingRecord(String id, String tradeNum, String transId, String channelNum, String channelType, String channelName, String acquirerNo, String siteName, String employeeNo, Integer clientType, String clientName, String certificateNumber, Integer accountSubject, String vehicleLicense, String vehicleType, String accountSubjectNo, Integer accountSubjectStatus, Integer operationType, Integer rechargeType, String rechargeNum, String specificRechargeType, String otherCollectionField, Integer fillTransferStatus, Integer bankType, String clientAcount, Integer clientBalance, String bankAccountOfThings, Integer transferType, Integer transferMode, Integer operationMark, Integer preOperationBalance, Integer operationAmount, Integer sufOperationBalance, String operationUser, Date operationTime, Date disputeTime, Integer disputeStatus, Date clearingTime, Integer clearingStatus, String createBy, Integer remove, String spare1, String spare2, String spare3) {
        this.id = id;
        this.tradeNum = tradeNum;
        this.transId = transId;
        this.channelNum = channelNum;
        this.channelType = channelType;
        this.channelName = channelName;
        this.acquirerNo = acquirerNo;
        this.siteName = siteName;
        this.employeeNo = employeeNo;
        this.clientType = clientType;
        this.clientName = clientName;
        this.certificateNumber = certificateNumber;
        this.accountSubject = accountSubject;
        this.vehicleLicense = vehicleLicense;
        this.vehicleType = vehicleType;
        this.accountSubjectNo = accountSubjectNo;
        this.accountSubjectStatus = accountSubjectStatus;
        this.operationType = operationType;
        this.rechargeType = rechargeType;
        this.rechargeNum = rechargeNum;
        this.specificRechargeType = specificRechargeType;
        this.otherCollectionField = otherCollectionField;
        this.fillTransferStatus = fillTransferStatus;
        this.bankType = bankType;
        this.clientAcount = clientAcount;
        this.clientBalance = clientBalance;
        this.bankAccountOfThings = bankAccountOfThings;
        this.transferType = transferType;
        this.transferMode = transferMode;
        this.operationMark = operationMark;
        this.preOperationBalance = preOperationBalance;
        this.operationAmount = operationAmount;
        this.sufOperationBalance = sufOperationBalance;
        this.operationUser = operationUser;
        this.operationTime = operationTime;
        this.disputeTime = disputeTime;
        this.disputeStatus = disputeStatus;
        this.clearingTime = clearingTime;
        this.clearingStatus = clearingStatus;
        this.createBy = createBy;
        this.remove = remove;
        this.spare1 = spare1;
        this.spare2 = spare2;
        this.spare3 = spare3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public String getChannelNum() {
        return channelNum;
    }

    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getAcquirerNo() {
        return acquirerNo;
    }

    public void setAcquirerNo(String acquirerNo) {
        this.acquirerNo = acquirerNo;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public Integer getAccountSubject() {
        return accountSubject;
    }

    public void setAccountSubject(Integer accountSubject) {
        this.accountSubject = accountSubject;
    }

    public String getVehicleLicense() {
        return vehicleLicense;
    }

    public void setVehicleLicense(String vehicleLicense) {
        this.vehicleLicense = vehicleLicense;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getAccountSubjectNo() {
        return accountSubjectNo;
    }

    public void setAccountSubjectNo(String accountSubjectNo) {
        this.accountSubjectNo = accountSubjectNo;
    }

    public Integer getAccountSubjectStatus() {
        return accountSubjectStatus;
    }

    public void setAccountSubjectStatus(Integer accountSubjectStatus) {
        this.accountSubjectStatus = accountSubjectStatus;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public Integer getRechargeType() {
        return rechargeType;
    }

    public void setRechargeType(Integer rechargeType) {
        this.rechargeType = rechargeType;
    }

    public String getSpecificRechargeType() {
        return specificRechargeType;
    }

    public void setSpecificRechargeType(String specificRechargeType) {
        this.specificRechargeType = specificRechargeType;
    }

    public String getOtherCollectionField() {
        return otherCollectionField;
    }

    public void setOtherCollectionField(String otherCollectionField) {
        this.otherCollectionField = otherCollectionField;
    }

    public Integer getFillTransferStatus() {
        return fillTransferStatus;
    }

    public void setFillTransferStatus(Integer fillTransferStatus) {
        this.fillTransferStatus = fillTransferStatus;
    }

    public Integer getBankType() {
        return bankType;
    }

    public void setBankType(Integer bankType) {
        this.bankType = bankType;
    }

    public String getClientAcount() {
        return clientAcount;
    }

    public void setClientAcount(String clientAcount) {
        this.clientAcount = clientAcount;
    }

    public Integer getClientBalance() {
        return clientBalance;
    }

    public void setClientBalance(Integer clientBalance) {
        this.clientBalance = clientBalance;
    }

    public String getBankAccountOfThings() {
        return bankAccountOfThings;
    }

    public void setBankAccountOfThings(String bankAccountOfThings) {
        this.bankAccountOfThings = bankAccountOfThings;
    }

    public Integer getTransferType() {
        return transferType;
    }

    public void setTransferType(Integer transferType) {
        this.transferType = transferType;
    }

    public Integer getTransferMode() {
        return transferMode;
    }

    public void setTransferMode(Integer transferMode) {
        this.transferMode = transferMode;
    }

    public Integer getOperationMark() {
        return operationMark;
    }

    public void setOperationMark(Integer operationMark) {
        this.operationMark = operationMark;
    }

    public Integer getPreOperationBalance() {
        return preOperationBalance;
    }

    public void setPreOperationBalance(Integer preOperationBalance) {
        this.preOperationBalance = preOperationBalance;
    }

    public Integer getOperationAmount() {
        return operationAmount;
    }

    public void setOperationAmount(Integer operationAmount) {
        this.operationAmount = operationAmount;
    }

    public Integer getSufOperationBalance() {
        return sufOperationBalance;
    }

    public void setSufOperationBalance(Integer sufOperationBalance) {
        this.sufOperationBalance = sufOperationBalance;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public Date getDisputeTime() {
        return disputeTime;
    }

    public void setDisputeTime(Date disputeTime) {
        this.disputeTime = disputeTime;
    }

    public Integer getDisputeStatus() {
        return disputeStatus;
    }

    public void setDisputeStatus(Integer disputeStatus) {
        this.disputeStatus = disputeStatus;
    }

    public Date getClearingTime() {
        return clearingTime;
    }

    public void setClearingTime(Date clearingTime) {
        this.clearingTime = clearingTime;
    }

    public Integer getClearingStatus() {
        return clearingStatus;
    }

    public void setClearingStatus(Integer clearingStatus) {
        this.clearingStatus = clearingStatus;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1;
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2;
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3;
    }

    public String getRechargeNum() {
        return rechargeNum;
    }

    public void setRechargeNum(String rechargeNum) {
        this.rechargeNum = rechargeNum;
    }

    @Override
    public String toString() {
        return "FrontBillingRecord{" +
                "id='" + id + '\'' +
                ", tradeNum='" + tradeNum + '\'' +
                ", transId='" + transId + '\'' +
                ", channelNum='" + channelNum + '\'' +
                ", channelType='" + channelType + '\'' +
                ", channelName='" + channelName + '\'' +
                ", acquirerNo='" + acquirerNo + '\'' +
                ", siteName='" + siteName + '\'' +
                ", employeeNo='" + employeeNo + '\'' +
                ", clientType=" + clientType +
                ", clientName='" + clientName + '\'' +
                ", certificateNumber='" + certificateNumber + '\'' +
                ", accountSubject=" + accountSubject +
                ", vehicleLicense='" + vehicleLicense + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", accountSubjectNo='" + accountSubjectNo + '\'' +
                ", accountSubjectStatus=" + accountSubjectStatus +
                ", operationType=" + operationType +
                ", rechargeType=" + rechargeType +
                ", rechargeNum='" + rechargeNum + '\'' +
                ", specificRechargeType='" + specificRechargeType + '\'' +
                ", otherCollectionField='" + otherCollectionField + '\'' +
                ", fillTransferStatus=" + fillTransferStatus +
                ", bankType=" + bankType +
                ", clientAcount='" + clientAcount + '\'' +
                ", clientBalance=" + clientBalance +
                ", bankAccountOfThings='" + bankAccountOfThings + '\'' +
                ", transferType=" + transferType +
                ", transferMode=" + transferMode +
                ", operationMark=" + operationMark +
                ", preOperationBalance=" + preOperationBalance +
                ", operationAmount=" + operationAmount +
                ", sufOperationBalance=" + sufOperationBalance +
                ", operationUser='" + operationUser + '\'' +
                ", operationTime=" + operationTime +
                ", disputeTime=" + disputeTime +
                ", disputeStatus=" + disputeStatus +
                ", clearingTime=" + clearingTime +
                ", clearingStatus=" + clearingStatus +
                ", createBy='" + createBy + '\'' +
                ", remove=" + remove +
                ", spare1='" + spare1 + '\'' +
                ", spare2='" + spare2 + '\'' +
                ", spare3='" + spare3 + '\'' +
                '}';
    }
}