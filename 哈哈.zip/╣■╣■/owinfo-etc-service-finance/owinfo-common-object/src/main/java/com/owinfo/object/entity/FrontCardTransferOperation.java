package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FrontCardTransferOperation {

    private String id;

    private String originalCardId;

    private String clientNo;

    private String clientName;

    private Integer clientType;

    private String certificateNumber;

    private Integer originalAccountBalance;

    private String transferCardId;

    private String vehicleNo;

    private Integer transferAccountBalance;

    private Integer transferAmount;

    private String amountUpper;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date transferTime;

    private String createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private Integer remove;

    private String spare1;

    private String spare2;

    private String spare3;

    public FrontCardTransferOperation() {
    }

    public FrontCardTransferOperation(String id, String originalCardId, String clientNo, String clientName, Integer clientType, String certificateNumber, Integer originalAccountBalance, String transferCardId, String vehicleNo, Integer transferAccountBalance, Integer transferAmount, String amountUpper, Date transferTime, String createBy, Date createTime, Integer remove, String spare1, String spare2, String spare3) {
        this.id = id;
        this.originalCardId = originalCardId;
        this.clientNo = clientNo;
        this.clientName = clientName;
        this.clientType = clientType;
        this.certificateNumber = certificateNumber;
        this.originalAccountBalance = originalAccountBalance;
        this.transferCardId = transferCardId;
        this.vehicleNo = vehicleNo;
        this.transferAccountBalance = transferAccountBalance;
        this.transferAmount = transferAmount;
        this.amountUpper = amountUpper;
        this.transferTime = transferTime;
        this.createBy = createBy;
        this.createTime = createTime;
        this.remove = remove;
        this.spare1 = spare1;
        this.spare2 = spare2;
        this.spare3 = spare3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getOriginalCardId() {
        return originalCardId;
    }

    public void setOriginalCardId(String originalCardId) {
        this.originalCardId = originalCardId == null ? null : originalCardId.trim();
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo == null ? null : clientNo.trim();
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName == null ? null : clientName.trim();
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber == null ? null : certificateNumber.trim();
    }

    public Integer getOriginalAccountBalance() {
        return originalAccountBalance;
    }

    public void setOriginalAccountBalance(Integer originalAccountBalance) {
        this.originalAccountBalance = originalAccountBalance;
    }

    public String getTransferCardId() {
        return transferCardId;
    }

    public void setTransferCardId(String transferCardId) {
        this.transferCardId = transferCardId == null ? null : transferCardId.trim();
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo == null ? null : vehicleNo.trim();
    }

    public Integer getTransferAccountBalance() {
        return transferAccountBalance;
    }

    public void setTransferAccountBalance(Integer transferAccountBalance) {
        this.transferAccountBalance = transferAccountBalance;
    }

    public Integer getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(Integer transferAmount) {
        this.transferAmount = transferAmount;
    }

    public String getAmountUpper() {
        return amountUpper;
    }

    public void setAmountUpper(String amountUpper) {
        this.amountUpper = amountUpper == null ? null : amountUpper.trim();
    }

    public Date getTransferTime() {
        return transferTime;
    }

    public void setTransferTime(Date transferTime) {
        this.transferTime = transferTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3 == null ? null : spare3.trim();
    }
}