package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FrontPaybackOperation {

    private String id;

    private Integer paybackWay;

    private String clientNo;

    private String clientName;

    private String certificateNumber;

    private Integer willPaybackAmount;

    private Integer paybackAmount;

    private String amountUpper;

    private String paybackReason;

    private String createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private String spare1;

    private String spare2;

    private String spare3;

    public FrontPaybackOperation() {
    }

    public FrontPaybackOperation(String id, Integer paybackWay, String clientNo, String clientName, String certificateNumber, Integer willPaybackAmount, Integer paybackAmount, String amountUpper, String paybackReason, String createBy, Date createTime, String spare1, String spare2, String spare3) {
        this.id = id;
        this.paybackWay = paybackWay;
        this.clientNo = clientNo;
        this.clientName = clientName;
        this.certificateNumber = certificateNumber;
        this.willPaybackAmount = willPaybackAmount;
        this.paybackAmount = paybackAmount;
        this.amountUpper = amountUpper;
        this.paybackReason = paybackReason;
        this.createBy = createBy;
        this.createTime = createTime;
        this.spare1 = spare1;
        this.spare2 = spare2;
        this.spare3 = spare3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getPaybackWay() {
        return paybackWay;
    }

    public void setPaybackWay(Integer paybackWay) {
        this.paybackWay = paybackWay;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo == null ? null : clientNo.trim();
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName == null ? null : clientName.trim();
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber == null ? null : certificateNumber.trim();
    }

    public Integer getWillPaybackAmount() {
        return willPaybackAmount;
    }

    public void setWillPaybackAmount(Integer willPaybackAmount) {
        this.willPaybackAmount = willPaybackAmount;
    }

    public Integer getPaybackAmount() {
        return paybackAmount;
    }

    public void setPaybackAmount(Integer paybackAmount) {
        this.paybackAmount = paybackAmount;
    }

    public String getAmountUpper() {
        return amountUpper;
    }

    public void setAmountUpper(String amountUpper) {
        this.amountUpper = amountUpper == null ? null : amountUpper.trim();
    }

    public String getPaybackReason() {
        return paybackReason;
    }

    public void setPaybackReason(String paybackReason) {
        this.paybackReason = paybackReason == null ? null : paybackReason.trim();
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3 == null ? null : spare3.trim();
    }
}