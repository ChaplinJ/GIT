package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FrontRechargeOperation {

    private String id;

    private String transId;

    private String tradeNum;

    private String channelType;

    private String channelNum;

    private String channelName;

    private String siteName;

    private String employeeNo;

    private String certificateNumber;

    private String cardId;

    private String clientNo;

    private String clientName;

    private Integer clientType;

    private Integer operationType;

    private Integer rechargeType;

    private String rechargeNum;

    private Integer accountBalance;

    private Integer paidAmount;

    private Integer giftAmount;

    private Integer rechargeAmount;

    private String amountUpper;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date tradeTime;

    private String correctReason;

    private String createBy;

    private Integer remove;

    public FrontRechargeOperation() {
    }

    public FrontRechargeOperation(String id, String transId, String tradeNum, String channelType, String channelNum, String channelName, String siteName, String employeeNo, String certificateNumber, String cardId, String clientNo, String clientName, Integer clientType, Integer operationType, Integer rechargeType, String rechargeNum, Integer accountBalance, Integer paidAmount, Integer giftAmount, Integer rechargeAmount, String amountUpper, Date tradeTime, String correctReason, String createBy, Integer remove) {
        this.id = id;
        this.transId = transId;
        this.tradeNum = tradeNum;
        this.channelType = channelType;
        this.channelNum = channelNum;
        this.channelName = channelName;
        this.siteName = siteName;
        this.employeeNo = employeeNo;
        this.certificateNumber = certificateNumber;
        this.cardId = cardId;
        this.clientNo = clientNo;
        this.clientName = clientName;
        this.clientType = clientType;
        this.operationType = operationType;
        this.rechargeType = rechargeType;
        this.rechargeNum = rechargeNum;
        this.accountBalance = accountBalance;
        this.paidAmount = paidAmount;
        this.giftAmount = giftAmount;
        this.rechargeAmount = rechargeAmount;
        this.amountUpper = amountUpper;
        this.tradeTime = tradeTime;
        this.correctReason = correctReason;
        this.createBy = createBy;
        this.remove = remove;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum == null ? null : tradeNum.trim();
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelNum() {
        return channelNum;
    }

    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum == null ? null : channelNum.trim();
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName == null ? null : channelName.trim();
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName == null ? null : siteName.trim();
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber == null ? null : certificateNumber.trim();
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId == null ? null : cardId.trim();
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo == null ? null : clientNo.trim();
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName == null ? null : clientName.trim();
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }

    public Integer getRechargeType() {
        return rechargeType;
    }

    public void setRechargeType(Integer rechargeType) {
        this.rechargeType = rechargeType;
    }

    public String getRechargeNum() {
        return rechargeNum;
    }

    public void setRechargeNum(String rechargeNum) {
        this.rechargeNum = rechargeNum == null ? null : rechargeNum.trim();
    }

    public Integer getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Integer accountBalance) {
        this.accountBalance = accountBalance;
    }

    public Integer getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Integer paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Integer getGiftAmount() {
        return giftAmount;
    }

    public void setGiftAmount(Integer giftAmount) {
        this.giftAmount = giftAmount;
    }

    public Integer getRechargeAmount() {
        return rechargeAmount;
    }

    public void setRechargeAmount(Integer rechargeAmount) {
        this.rechargeAmount = rechargeAmount;
    }

    public String getAmountUpper() {
        return amountUpper;
    }

    public void setAmountUpper(String amountUpper) {
        this.amountUpper = amountUpper == null ? null : amountUpper.trim();
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public String getCorrectReason() {
        return correctReason;
    }

    public void setCorrectReason(String correctReason) {
        this.correctReason = correctReason == null ? null : correctReason.trim();
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }
}