package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FrontTransferenceOperation {

    private String id;

    private String tradeNum;

    private String clientNo;

    private String cardInfo;

    private Integer onlineSn;

    private String random;

    private Integer operationStatus;

    private String cardNo;

    private String terminalNo;

    private String siteName;

    private String employeeNo;


    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date optTime;

    private Integer operationPreMoney;

    private Integer operationMoney;

    private Integer operationSufMoney;

    private Integer remove;

    private String signData;

    private String createBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private String updateBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    private Integer keyver;

    private Integer algor;

    private String tac;

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public FrontTransferenceOperation() {
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public FrontTransferenceOperation(String id, String tradeNum, String clientNo, String cardInfo, Integer onlineSn, String random, Integer operationStatus, String cardNo, String terminalNo, Date optTime, Integer operationPreMoney, Integer operationMoney, Integer operationSufMoney, Integer remove, String signData, String createBy, Date createTime, String updateBy, Date updateTime, Integer keyver, Integer algor, String tac) {
        this.id = id;
        this.tradeNum = tradeNum;
        this.clientNo = clientNo;
        this.cardInfo = cardInfo;
        this.onlineSn = onlineSn;
        this.random = random;
        this.operationStatus = operationStatus;
        this.cardNo = cardNo;
        this.terminalNo = terminalNo;
        this.optTime = optTime;
        this.operationPreMoney = operationPreMoney;
        this.operationMoney = operationMoney;
        this.operationSufMoney = operationSufMoney;
        this.remove = remove;
        this.signData = signData;
        this.createBy = createBy;
        this.createTime = createTime;
        this.updateBy = updateBy;
        this.updateTime = updateTime;
        this.keyver = keyver;
        this.algor = algor;
        this.tac = tac;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo;
    }

    public Integer getOnlineSn() {
        return onlineSn;
    }

    public void setOnlineSn(Integer onlineSn) {
        this.onlineSn = onlineSn;
    }

    public String getRandom() {
        return random;
    }

    public void setRandom(String random) {
        this.random = random;
    }

    public Integer getOperationStatus() {
        return operationStatus;
    }

    public void setOperationStatus(Integer operationStatus) {
        this.operationStatus = operationStatus;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getTerminalNo() {
        return terminalNo;
    }

    public void setTerminalNo(String terminalNo) {
        this.terminalNo = terminalNo;
    }

    public Date getOptTime() {
        return optTime;
    }

    public void setOptTime(Date optTime) {
        this.optTime = optTime;
    }

    public Integer getOperationPreMoney() {
        return operationPreMoney;
    }

    public void setOperationPreMoney(Integer operationPreMoney) {
        this.operationPreMoney = operationPreMoney;
    }

    public Integer getOperationMoney() {
        return operationMoney;
    }

    public void setOperationMoney(Integer operationMoney) {
        this.operationMoney = operationMoney;
    }

    public Integer getOperationSufMoney() {
        return operationSufMoney;
    }

    public void setOperationSufMoney(Integer operationSufMoney) {
        this.operationSufMoney = operationSufMoney;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getSignData() {
        return signData;
    }

    public void setSignData(String signData) {
        this.signData = signData;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getKeyver() {
        return keyver;
    }

    public void setKeyver(Integer keyver) {
        this.keyver = keyver;
    }

    public Integer getAlgor() {
        return algor;
    }

    public void setAlgor(Integer algor) {
        this.algor = algor;
    }

    public String getTac() {
        return tac;
    }

    public void setTac(String tac) {
        this.tac = tac;
    }

    @Override
    public String toString() {
        return "FrontTransferenceOperation{" +
                "id='" + id + '\'' +
                ", tradeNum='" + tradeNum + '\'' +
                ", clientNo='" + clientNo + '\'' +
                ", cardInfo='" + cardInfo + '\'' +
                ", onlineSn=" + onlineSn +
                ", random='" + random + '\'' +
                ", operationStatus=" + operationStatus +
                ", cardNo='" + cardNo + '\'' +
                ", terminalNo='" + terminalNo + '\'' +
                ", optTime=" + optTime +
                ", operationPreMoney=" + operationPreMoney +
                ", operationMoney=" + operationMoney +
                ", operationSufMoney=" + operationSufMoney +
                ", remove=" + remove +
                ", signData='" + signData + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", keyver=" + keyver +
                ", algor=" + algor +
                ", tac='" + tac + '\'' +
                '}';
    }
}