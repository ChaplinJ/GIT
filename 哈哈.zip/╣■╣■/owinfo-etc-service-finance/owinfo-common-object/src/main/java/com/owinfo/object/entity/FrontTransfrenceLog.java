package com.owinfo.object.entity;

import java.util.Date;

/**
 * @author Created by hekunlin on 2018年01月16日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class FrontTransfrenceLog {

    private String id;

    private String cardNo;

    private int onlineSn;

    private int preOperationAmount;

    private int operationAmount;

    private int sufOperationAmount;

    private Date createTime;

    private String createBy;

    private int remove;

    private String content;

    public FrontTransfrenceLog() {
    }

    public FrontTransfrenceLog(String id, String cardNo, int onlineSn, int preOperationAmount,
                               int operationAmount, int sufOperationAmount, Date createTime, String createBy,
                               int remove, String content) {
        this.id = id;
        this.cardNo = cardNo;
        this.onlineSn = onlineSn;
        this.preOperationAmount = preOperationAmount;
        this.operationAmount = operationAmount;
        this.sufOperationAmount = sufOperationAmount;
        this.createTime = createTime;
        this.createBy = createBy;
        this.remove = remove;
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public int getOnlineSn() {
        return onlineSn;
    }

    public void setOnlineSn(int onlineSn) {
        this.onlineSn = onlineSn;
    }

    public int getPreOperationAmount() {
        return preOperationAmount;
    }

    public void setPreOperationAmount(int preOperationAmount) {
        this.preOperationAmount = preOperationAmount;
    }

    public int getOperationAmount() {
        return operationAmount;
    }

    public void setOperationAmount(int operationAmount) {
        this.operationAmount = operationAmount;
    }

    public int getSufOperationAmount() {
        return sufOperationAmount;
    }

    public void setSufOperationAmount(int sufOperationAmount) {
        this.sufOperationAmount = sufOperationAmount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public int getRemove() {
        return remove;
    }

    public void setRemove(int remove) {
        this.remove = remove;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
