/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月08日
 */
package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

/**
 * @description
 * @author gongchengping
 * @version [v1.0, 2018/03/08]
 */

public class OrderManage {
    private String id;

    private String orderNo;

    private Integer orderChannel;

    private String customerName;

    private String orderType;

    private Integer realMoney;

    private Integer rechargeMoney;

    private Integer surplusRechargeMoney;

    private Integer oilAmount;

    private Integer sufOilAmount;

    private String obuName;

    private Integer obuNum;

    private Integer obuUnitPrice;

    private Integer sufObuNum;

    private String treasureName;

    private Integer treasureNum;

    private Integer treasureUnitPrice;

    private Integer sufTreasureNum;

    private Integer saleStatus;

    private String inputPerson;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date inputTime;

    private String remove;

    private String updateBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    private String spare1;

    private String spare2;

    private String spare3;

    @Override
    public String toString() {
        return "OrderManage2{" +
                "id='" + id + '\'' +
                ", orderNo='" + orderNo + '\'' +
                ", orderChannel=" + orderChannel +
                ", customerName='" + customerName + '\'' +
                ", orderType='" + orderType + '\'' +
                ", realMoney=" + realMoney +
                ", rechargeMoney=" + rechargeMoney +
                ", surplusRechargeMoney=" + surplusRechargeMoney +
                ", oilAmount=" + oilAmount +
                ", sufOilAmount=" + sufOilAmount +
                ", obuName='" + obuName + '\'' +
                ", obuNum=" + obuNum +
                ", sufObuNum=" + sufObuNum +
                ", treasureName='" + treasureName + '\'' +
                ", treasureNum=" + treasureNum +
                ", sufTreasureNum=" + sufTreasureNum +
                ", saleStatus=" + saleStatus +
                ", inputPerson='" + inputPerson + '\'' +
                ", inputTime=" + inputTime +
                ", remove='" + remove + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", spare1='" + spare1 + '\'' +
                ", spare2='" + spare2 + '\'' +
                ", spare3='" + spare3 + '\'' +
                '}';
    }

    public OrderManage() {

    }

    public OrderManage(String id, String orderNo, Integer orderChannel, String customerName, String orderType, Integer realMoney, Integer rechargeMoney, Integer surplusRechargeMoney, Integer oilAmount, Integer sufOilAmount, String obuName, Integer obuNum, Integer sufObuNum, String treasureName, Integer treasureNum, Integer sufTreasureNum, Integer saleStatus, String inputPerson, Date inputTime, String remove, String updateBy, Date updateTime, String spare1, String spare2, String spare3) {
        this.id = id;
        this.orderNo = orderNo;
        this.orderChannel = orderChannel;
        this.customerName = customerName;
        this.orderType = orderType;
        this.realMoney = realMoney;
        this.rechargeMoney = rechargeMoney;
        this.surplusRechargeMoney = surplusRechargeMoney;
        this.oilAmount = oilAmount;
        this.sufOilAmount = sufOilAmount;
        this.obuName = obuName;
        this.obuNum = obuNum;
        this.sufObuNum = sufObuNum;
        this.treasureName = treasureName;
        this.treasureNum = treasureNum;
        this.sufTreasureNum = sufTreasureNum;
        this.saleStatus = saleStatus;
        this.inputPerson = inputPerson;
        this.inputTime = inputTime;
        this.remove = remove;
        this.updateBy = updateBy;
        this.updateTime = updateTime;
        this.spare1 = spare1;
        this.spare2 = spare2;
        this.spare3 = spare3;
    }

    public Integer getObuUnitPrice() {
        return obuUnitPrice;
    }

    public void setObuUnitPrice(Integer obuUnitPrice) {
        this.obuUnitPrice = obuUnitPrice;
    }

    public Integer getTreasureUnitPrice() {
        return treasureUnitPrice;
    }

    public void setTreasureUnitPrice(Integer treasureUnitPrice) {
        this.treasureUnitPrice = treasureUnitPrice;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getOrderChannel() {
        return orderChannel;
    }

    public void setOrderChannel(Integer orderChannel) {
        this.orderChannel = orderChannel;
    }

    public String getCustomerName() {
        return customerName;
    }


    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }



    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public Integer getRealMoney() {
        return realMoney;
    }

    public void setRealMoney(Integer realMoney) {
        this.realMoney = realMoney;
    }

    public Integer getRechargeMoney() {
        return rechargeMoney;
    }

    public void setRechargeMoney(Integer rechargeMoney) {
        this.rechargeMoney = rechargeMoney;
    }

    public Integer getSurplusRechargeMoney() {
        return surplusRechargeMoney;
    }

    public void setSurplusRechargeMoney(Integer surplusRechargeMoney) {
        this.surplusRechargeMoney = surplusRechargeMoney;
    }

    public Integer getOilAmount() {
        return oilAmount;
    }

    public void setOilAmount(Integer oilAmount) {
        this.oilAmount = oilAmount;
    }

    public Integer getSufOilAmount() {
        return sufOilAmount;
    }

    public void setSufOilAmount(Integer sufOilAmount) {
        this.sufOilAmount = sufOilAmount;
    }

    public String getObuName() {
        return obuName;
    }

    public void setObuName(String obuName) {
        this.obuName = obuName;
    }

    public Integer getObuNum() {
        return obuNum;
    }

    public void setObuNum(Integer obuNum) {
        this.obuNum = obuNum;
    }

    public Integer getSufObuNum() {
        return sufObuNum;
    }

    public void setSufObuNum(Integer sufObuNum) {
        this.sufObuNum = sufObuNum;
    }

    public String getTreasureName() {
        return treasureName;
    }

    public void setTreasureName(String treasureName) {
        this.treasureName = treasureName;
    }

    public Integer getTreasureNum() {
        return treasureNum;
    }

    public void setTreasureNum(Integer treasureNum) {
        this.treasureNum = treasureNum;
    }

    public Integer getSufTreasureNum() {
        return sufTreasureNum;
    }

    public void setSufTreasureNum(Integer sufTreasureNum) {
        this.sufTreasureNum = sufTreasureNum;
    }

    public Integer getSaleStatus() {
        return saleStatus;
    }

    public void setSaleStatus(Integer saleStatus) {
        this.saleStatus = saleStatus;
    }

    public String getInputPerson() {
        return inputPerson;
    }

    public void setInputPerson(String inputPerson) {
        this.inputPerson = inputPerson;
    }

    public Date getInputTime() {
        return inputTime;
    }

    public void setInputTime(Date inputTime) {
        this.inputTime = inputTime;
    }

    public String getRemove() {
        return remove;
    }

    public void     setRemove(String remove) {
        this.remove = remove;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1;
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2;
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3;
    }
}
