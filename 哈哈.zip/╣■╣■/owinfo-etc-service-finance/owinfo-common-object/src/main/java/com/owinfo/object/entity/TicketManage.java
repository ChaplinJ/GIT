package com.owinfo.object.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
* @description: 
* @author hekunlin on 2017/10/25 10:15
*/
public class TicketManage {

    private String id;

    private String ticketNo;

    private String ticketName;

    private String ticketType;

    private int ticketFaceValue;

    private String password;

    private String saleStatus;

    private String saleType;

    private String inputPerson;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date inputTime;

    private String startPerson;

    private int saleMoney;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    private String recoveryPerson;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date recoveryTime;

    private String remove;

    private String createBy;

    private String updateBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    private String spare1;

    private String spare2;

    private String spare3;

    public TicketManage() {
    }

    public TicketManage(String id, String ticketNo, String ticketName, String ticketType, int ticketFaceValue, String password, String saleStatus, String saleType, String inputPerson, Date inputTime, String startPerson, int saleMoney, Date startTime, String recoveryPerson, Date recoveryTime, String remove, String createBy, String updateBy, Date createTime, Date updateTime, String spare1, String spare2, String spare3) {
        this.id = id;
        this.ticketNo = ticketNo;
        this.ticketName = ticketName;
        this.ticketType = ticketType;
        this.ticketFaceValue = ticketFaceValue;
        this.password = password;
        this.saleStatus = saleStatus;
        this.saleType = saleType;
        this.inputPerson = inputPerson;
        this.inputTime = inputTime;
        this.startPerson = startPerson;
        this.saleMoney = saleMoney;
        this.startTime = startTime;
        this.recoveryPerson = recoveryPerson;
        this.recoveryTime = recoveryTime;
        this.remove = remove;
        this.createBy = createBy;
        this.updateBy = updateBy;
        this.createTime = createTime;
        this.updateTime = updateTime;
        this.spare1 = spare1;
        this.spare2 = spare2;
        this.spare3 = spare3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo == null ? null : ticketNo.trim();
    }

    public String getTicketName() {
        return ticketName;
    }

    public void setTicketName(String ticketName) {
        this.ticketName = ticketName == null ? null : ticketName.trim();
    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType == null ? null : ticketType.trim();
    }

    public int getTicketFaceValue() {
        return ticketFaceValue;
    }

    public void setTicketFaceValue(int ticketFaceValue) {
        this.ticketFaceValue = ticketFaceValue;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getSaleStatus() {
        return saleStatus;
    }

    public void setSaleStatus(String saleStatus) {
        this.saleStatus = saleStatus == null ? null : saleStatus.trim();
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType == null ? null : saleType.trim();
    }

    public String getInputPerson() {
        return inputPerson;
    }

    public void setInputPerson(String inputPerson) {
        this.inputPerson = inputPerson == null ? null : inputPerson.trim();
    }

    public Date getInputTime() {
        return inputTime;
    }

    public void setInputTime(Date inputTime) {
        this.inputTime = inputTime;
    }

    public String getStartPerson() {
        return startPerson;
    }

    public void setStartPerson(String startPerson) {
        this.startPerson = startPerson == null ? null : startPerson.trim();
    }

    public int getSaleMoney() {
        return saleMoney;
    }

    public void setSaleMoney(int saleMoney) {
        this.saleMoney = saleMoney;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public String getRecoveryPerson() {
        return recoveryPerson;
    }

    public void setRecoveryPerson(String recoveryPerson) {
        this.recoveryPerson = recoveryPerson == null ? null : recoveryPerson.trim();
    }

    public Date getRecoveryTime() {
        return recoveryTime;
    }

    public void setRecoveryTime(Date recoveryTime) {
        this.recoveryTime = recoveryTime;
    }

    public String getRemove() {
        return remove;
    }

    public void setRemove(String remove) {
        this.remove = remove == null ? null : remove.trim();
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3 == null ? null : spare3.trim();
    }
}