package com.owinfo.object.entity;

import java.util.Date;

public class TransferAccountsManage {
    private String id;

    private String random;

    private String customerName;

    private Integer transferAmount;

    private String transferUse;

    private Integer rechargeAmount;

    private Integer sufRechargeAmount;

    private Integer oilAmount;

    private Integer sufOilAmount;

    private String obuName;

    private Integer obuPrice;

    private Integer obuNum;

    private Integer sufObuNum;

    private String treasureName;

    private Integer treasurePrice;

    private Integer treasureNum;

    private Integer sufTreasureNum;

    private Integer consumeStatus;

    private String inputPerson;

    private Date inputTime;

    private Date transferTime;

    private Integer remove;

    private String updateBy;

    private Date updateTime;

    private String spare1;

    private String spare2;

    private String spare3;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getRandom() {
        return random;
    }

    public void setRandom(String random) {
        this.random = random == null ? null : random.trim();
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName == null ? null : customerName.trim();
    }

    public Integer getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(Integer transferAmount) {
        this.transferAmount = transferAmount;
    }

    public String getTransferUse() {
        return transferUse;
    }

    public void setTransferUse(String transferUse) {
        this.transferUse = transferUse == null ? null : transferUse.trim();
    }

    public Integer getRechargeAmount() {
        return rechargeAmount;
    }

    public void setRechargeAmount(Integer rechargeAmount) {
        this.rechargeAmount = rechargeAmount;
    }

    public Integer getSufRechargeAmount() {
        return sufRechargeAmount;
    }

    public void setSufRechargeAmount(Integer sufRechargeAmount) {
        this.sufRechargeAmount = sufRechargeAmount;
    }

    public Integer getOilAmount() {
        return oilAmount;
    }

    public void setOilAmount(Integer oilAmount) {
        this.oilAmount = oilAmount;
    }

    public Integer getSufOilAmount() {
        return sufOilAmount;
    }

    public void setSufOilAmount(Integer sufOilAmount) {
        this.sufOilAmount = sufOilAmount;
    }

    public String getObuName() {
        return obuName;
    }

    public void setObuName(String obuName) {
        this.obuName = obuName == null ? null : obuName.trim();
    }

    public Integer getObuPrice() {
        return obuPrice;
    }

    public void setObuPrice(Integer obuPrice) {
        this.obuPrice = obuPrice;
    }

    public Integer getObuNum() {
        return obuNum;
    }

    public void setObuNum(Integer obuNum) {
        this.obuNum = obuNum;
    }

    public Integer getSufObuNum() {
        return sufObuNum;
    }

    public void setSufObuNum(Integer sufObuNum) {
        this.sufObuNum = sufObuNum;
    }

    public String getTreasureName() {
        return treasureName;
    }

    public void setTreasureName(String treasureName) {
        this.treasureName = treasureName == null ? null : treasureName.trim();
    }

    public Integer getTreasurePrice() {
        return treasurePrice;
    }

    public void setTreasurePrice(Integer treasurePrice) {
        this.treasurePrice = treasurePrice;
    }

    public Integer getTreasureNum() {
        return treasureNum;
    }

    public void setTreasureNum(Integer treasureNum) {
        this.treasureNum = treasureNum;
    }

    public Integer getSufTreasureNum() {
        return sufTreasureNum;
    }

    public void setSufTreasureNum(Integer sufTreasureNum) {
        this.sufTreasureNum = sufTreasureNum;
    }

    public Integer getConsumeStatus() {
        return consumeStatus;
    }

    public void setConsumeStatus(Integer consumeStatus) {
        this.consumeStatus = consumeStatus;
    }

    public String getInputPerson() {
        return inputPerson;
    }

    public void setInputPerson(String inputPerson) {
        this.inputPerson = inputPerson == null ? null : inputPerson.trim();
    }

    public Date getInputTime() {
        return inputTime;
    }

    public void setInputTime(Date inputTime) {
        this.inputTime = inputTime;
    }

    public Date getTransferTime() {
        return transferTime;
    }

    public void setTransferTime(Date transferTime) {
        this.transferTime = transferTime;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3 == null ? null : spare3.trim();
    }
}