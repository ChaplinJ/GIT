/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月12日
 */
package com.owinfo.service.config.annotation;

/**
 * @Description 电商订单JSR303 校验分组
 * @author gongchengping
 * @version [v1.0, 2018年03月12日]
 */
public interface OrderCheckGroups {
    interface Base{}
    interface AddOrderCheck{}
    interface UpdateOrderSurplysCheck{}
    interface validateOrderNo{}
}
