/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月09日
 */
package com.owinfo.service.config.exception;

import com.alibaba.fastjson.JSONObject;
import com.owinfo.service.util.JSONResultUtil;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.List;

/**
 * @author Created by gongchengping on 2018年03月02日
 * @Description 统一JSR303校验
 */
@ControllerAdvice
public class JSR303Exception {

    private static final Logger logger = Logger.getLogger(JSR303Exception.class);

    /**
     * 重要说明：
     * 1：Spring提供了@Validated注解对方法参数进行校验,这个@Validated注解必须放在类的前面
     * 2：光有这个注解是不够的，还需要定义一个ControllerAdvice去处理对应的异常，否则会出现报500错误
     */

    /**
     * 处理校验失败
     *
     * @param e
     * @return
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public JSONObject handleValidationException(ConstraintViolationException e) {
        for (ConstraintViolation<?> s : e.getConstraintViolations()) {
            logger.error("<== 校验失败 " + s.getInvalidValue() + " : " + s.getMessage());
            return JSONResultUtil.errorResult(null,s.getMessage());
        }
        return JSONResultUtil.errorResult(null,"参数不合法");
    }


    /**
     * Bean对象的校验异常处理
     *
     * @param e
     * @return
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public JSONObject handleValidationException(MethodArgumentNotValidException e) {
        BindingResult bindingResult = e.getBindingResult();
        System.out.println(e.getMessage());
        System.out.println(e.getParameter().toString());
        List<FieldError> fieldErrorList = bindingResult.getFieldErrors();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 0);

        StringBuffer stringBuffer = new StringBuffer();
        if (bindingResult.hasErrors()) {
            for (FieldError fieldError : fieldErrorList) {
                logger.error("<== 校验失败 " + fieldError.getRejectedValue() + " : " + fieldError.getDefaultMessage());
//                jsonObject.put(fieldError.getField(), fieldError.getDefaultMessage());
//                stringBuffer.append(fieldError.getField() + " ");
                stringBuffer.append(" " + fieldError.getDefaultMessage());
            }

            jsonObject.put("msg", stringBuffer.toString());
            return jsonObject;
        }

        return JSONResultUtil.errorResult(null,"参数不合法");
    }

}

