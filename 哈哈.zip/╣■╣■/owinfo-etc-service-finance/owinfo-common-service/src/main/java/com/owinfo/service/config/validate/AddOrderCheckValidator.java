/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月09日
 */
package com.owinfo.service.config.validate;

import com.owinfo.service.config.annotation.AddOrderCheck;
import com.owinfo.service.util.OrderManageDTO;
import com.owinfo.service.util.ValidateUtils;
import org.apache.log4j.Logger;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

/**
 *
 * @Description 基于jsr303标准，使用注解对OrderManageDTO对象进行具体校验的逻辑实现
 * @author gongchengping
 * @version [V1.0, 2018/03/09]
 */
public class AddOrderCheckValidator implements ConstraintValidator<AddOrderCheck,  OrderManageDTO> {

    private static Logger logger = Logger.getLogger(AddOrderCheckValidator.class);
    @Override
    public void initialize(AddOrderCheck constraintAnnotation) {

    }

    @Override
    public boolean isValid(OrderManageDTO order, ConstraintValidatorContext context) {

        boolean result = true;
        BigDecimal money = order.getRealMoney().setScale(2);
        BigDecimal rechargeMoney = new BigDecimal(0);
        BigDecimal obuMoney = new BigDecimal(0);
        BigDecimal treasureMoney = new BigDecimal(0);
        BigDecimal oilMoney = new BigDecimal(0);
        /**
         * 验证添加订单勾选状态是否符合要求,
         * (例:如果勾选了充值复选框，那么对应的金额字段不能为空)
         * (例:如果勾选了购买电子标签的复选框，那么对应的字段都必须满足不为空的要求)
         */

        if(order.getRechargeStatus()) { //判断充值字段
            if(ValidateUtils.isEmpty(order.getRechargeMoney())) { //失败状态
                addContextReturnMeg(context, "rechargeStatus", "充值金额不能为空");
                result = false;
                return result;
            } else { //成功状态
                rechargeMoney = order.getRechargeMoney();
            }
        }

        if(order.getObuStatus()) { //判断电子标签
            if(ValidateUtils.isEmpty(order.getObuName())) {
                addContextReturnMeg(context, "obuName", "电子蓝牙标签名不能为空");
                result = false;
                return result;
            }
            if(ValidateUtils.isEmpty(order.getObuUnitPrice())) {
                addContextReturnMeg(context, "obuUnitPrice", "电子蓝牙标签单价不能为空");
                result = false;
                return result;
            }
            if(ValidateUtils.isEmpty(order.getObuNum())) {
                addContextReturnMeg(context, "obuNum", "电子蓝牙标签数量不能为空");
                result = false;
                return result;
            }
            obuMoney = order.getObuUnitPrice().multiply(new BigDecimal(order.getObuNum()));
        }

        if(order.getTreasureStatus()) { //判断充值宝
            if(ValidateUtils.isEmpty(order.getTreasureName())) {
                addContextReturnMeg(context, "treasureName", "充值宝名不能为空");
                result = false;
                return result;
            }
            if(ValidateUtils.isEmpty(order.getTreasureUnitPrice())) {
                addContextReturnMeg(context, "treasureUnitPrice", "充值宝单价不能为空");
                result = false;
                return result;
            }
            if(ValidateUtils.isEmpty(order.getTreasureNum())) {
                addContextReturnMeg(context, "treasureNum", "充值宝数量不能为空");
                result = false;
                return result;
            }
            treasureMoney = order.getTreasureUnitPrice().multiply(new BigDecimal(order.getTreasureNum()));
        }

        if(order.getOilStatus()) { //判断中石油加油
            if(ValidateUtils.isEmpty(order.getOilAmount())) {
                addContextReturnMeg(context, "oilAmount", "中石油金额不能为空");
                result = false;
                return result;
            } else {
                oilMoney = order.getOilAmount();
            }
        }

        /**
         * 判断所有用户购买得所有商品（充值，蓝牙标签，充值宝，中石油）和该电商订单的金额是否一致，
         */

        BigDecimal costMoney = rechargeMoney.add(obuMoney).add(treasureMoney).add(oilMoney).setScale(2);
        logger.info("obuMoney:" + obuMoney.toString());
        logger.info("treasureMoney:" + treasureMoney.toString());
        logger.info("oilMoney:" + oilMoney.toString());
        logger.info("costMoney:" + costMoney.toString());
        logger.info("money:" + money.toString());
        if(!costMoney.equals(money)) {
            addContextReturnMeg(context, "rechargeStatus", "商品价值不一致");
            result = false;
            return result;
        }
        return result;

    }

    private void addContextReturnMeg(ConstraintValidatorContext context , String paramName, String msg) {
        context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate(msg)
                .addPropertyNode(paramName)
                .addConstraintViolation();
    }
}
