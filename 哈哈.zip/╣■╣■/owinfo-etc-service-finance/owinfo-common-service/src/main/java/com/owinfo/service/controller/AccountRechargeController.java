package com.owinfo.service.controller;

import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.service.core.service.AccountRechargeService;
import com.owinfo.service.core.service.FrontRechargeOperationService;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月29日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/accountRecharge")
@CrossOrigin(maxAge = 3600,origins = "*")
public class AccountRechargeController {

    private static final Logger logger = Logger.getLogger(AccountRechargeController.class);

    @Autowired
    private AccountRechargeService accountRechargeService;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    /**
    * @description 用户账户充值查询
    * @author hekunlin 2018/1/29 14:44 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/accountRearch")
    public Map<String, Object> accountRearch(@RequestBody Map<String,Object> params){
        logger.info("<==  方法accountRearch的参数::" + params + "   开始执行");

        String certificateNumber = (String) params.get("certificateNumber");
        logger.info("<==  用户账户[" + certificateNumber + "]充值查询");

        logger.info("<==  方法accountRearch执行结束");
        return accountRechargeService.getClient(certificateNumber);
    }

    /**
    * @description 用户账户充值
    * @author hekunlin 2018/1/29 15:25 Version 1.0
    * @param
    * @return 
    */
    @PostMapping("/userAccountRecharge")
    public Map<String, Object> userAccountRecharge(@RequestBody Map<String,Object> params){
        logger.info("<==  方法userAccountRecharge的参数::" + params + "   开始执行");

        Date date = new Date();

        // region 证件编号、充值金额
        String certificateNumber = (String) params.get("certificateNumber");
        String chargeAmount = getParams(params.get("chargeAmount"));
        BigDecimal accountBalance = new BigDecimal(chargeAmount);
        logger.info("<==   证件编号[" + certificateNumber + "]用户账户充值[" + chargeAmount + "]");

        if (accountBalance.compareTo(BigDecimal.ZERO) == -1 || accountBalance.compareTo(BigDecimal.ZERO) == 0){
            logger.error(" <-- 充值金额不正确，不能为负数或者为0");
            return ReturnResult.errors("充值失败，充值金额必须大于0");
        }
        // endregion

        // region 用户账户充值操作记录
        logger.info("<==  新增用户账户[" + certificateNumber + "]充值操作记录");
        int rechargeType = Integer.parseInt(ParamClassUtils.getParams(params.get("chargeType")));
        Double m = Double.parseDouble((String) params.get("chargeAmount"));
        FrontRechargeOperation frontRechargeOperation = new FrontRechargeOperation();
        frontRechargeOperation.setId(UUIDUtils.getUUID());
        frontRechargeOperation.setTradeNum((String) params.get("tradeNum"));
        frontRechargeOperation.setTransId((String) params.get("transId"));
        frontRechargeOperation.setChannelType((String) params.get("channelType"));
        frontRechargeOperation.setChannelNum((String) params.get("channelNum"));
        frontRechargeOperation.setChannelName((String) params.get("channelName"));
        frontRechargeOperation.setSiteName((String) params.get("siteName"));
        frontRechargeOperation.setEmployeeNo((String) params.get("employeeNo"));
        frontRechargeOperation.setCertificateNumber(certificateNumber);
        frontRechargeOperation.setClientNo((String) params.get("clientNo"));
        frontRechargeOperation.setClientName((String) params.get("clientName"));
        frontRechargeOperation.setClientType(Integer.valueOf((String) params.get("clientType")));
        frontRechargeOperation.setOperationType(Integer.valueOf((String) params.get("operationType")));
        frontRechargeOperation.setRechargeType(rechargeType);
        frontRechargeOperation.setRechargeNum(ParamClassUtils.getParams(params.get("rechargeNum")));
        Double x = Double.parseDouble((String) params.get("accountBalance"));
        frontRechargeOperation.setAccountBalance((int)(x*100));
        frontRechargeOperation.setPaidAmount((int)(x*100));
        if (rechargeType == 0 || rechargeType == 1 || rechargeType == 2 || rechargeType == 3){ // POS、转账、电商
            frontRechargeOperation.setPaidAmount((int)(m*100)); // 支付金额/实收金额
            frontRechargeOperation.setGiftAmount(0); // 赠送金额
            frontRechargeOperation.setRechargeAmount((int)(m*100)); // 充值金额
        }
        if (rechargeType == 4){ // 体验券
            frontRechargeOperation.setPaidAmount(0); // 支付金额/实收金额
            frontRechargeOperation.setGiftAmount((int)(m*100)); // 赠送金额
            frontRechargeOperation.setRechargeAmount((int)(m*100)); // 充值金额
        }
        frontRechargeOperation.setAmountUpper((String) params.get("AmountUpper"));
        frontRechargeOperation.setTradeTime(date);
        frontRechargeOperation.setCreateBy((String) params.get("createBy"));
        frontRechargeOperationService.addRechargeOperationRecord(frontRechargeOperation);
        // endregion

        logger.info("<==  方法userAccountRecharge执行结束");
        return accountRechargeService.userAccountRecharge(params);
    }

}
