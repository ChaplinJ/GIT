package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontAllocationOperation;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.service.AllocationService;
import com.owinfo.service.core.service.FrontAllocationOperationService;
import com.owinfo.service.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.bouncycastle.asn1.ua.DSTU4145NamedCurves.params;

/**
 * @author Created by hekunlin on 2017年11月25日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/allocation")
@CrossOrigin(maxAge = 3600,origins = "*")
public class AllocationController {

    private static final Logger logger = Logger.getLogger(AllocationController.class);

    @Autowired
    private FrontAllocationOperationService frontAllocationOperationService;

    @Autowired
    private AllocationService allocationService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    /**
    * @description 批量分配验证
    * @author hekunlin 2018/1/23 10:33 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/validateBatchPoint")
    public Map<String,Object> validateBatchPoint(@RequestBody Map<String,Object> params){
        logger.info("<==  方法validateBatchPoint的参数::" + params + "   开始执行");

        String certificateNumber = (String) params.get("certificateNumber");
        if (StringUtils.isEmpty(certificateNumber)){
            logger.error("<==  证件编号不允许为空certificateNumber=[" + certificateNumber + "]");
            return ReturnResult.errors("用户证件编号不能为空");
        }

        logger.info("<==  方法validateBatchPoint执行结束");
        return allocationService.validateBatchPoint(params);
    }

    /**
    * @description 批量分配
    * @author hekunlin 2018/1/23 10:35 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/batchTransfer")
    public Map<String,Object> batchTransfer(@RequestBody Map<String,Object> params){
        logger.info("<==  方法batchTransfer的参数::" + params + "   开始执行");

        Date date = new Date();

        // region 获取用户信息、分配信息
        Map<String,Object> allocatedUserMap = (Map<String, Object>) params.get("userMap");
        List allocatedCardList = (List) params.get("tempCardList");
        String certificateNumber = (String) allocatedUserMap.get("certificateNumber");

        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
        if (etcclientinfo == null){
            logger.info("<==  证件编号[" + certificateNumber + "]不是个人用户");
            etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<== 未查到[" + certificateNumber + "]对应的用户信息");
                return ReturnResult.errors("未查到相应的用户信息");
            }
        }
        // 账户余额不能为负数
        BigDecimal accountBalance = etcclientinfo.getAccountBalance();
        if (accountBalance.compareTo(BigDecimal.ZERO) == -1){
            logger.info("<==  账户余额不能为负数");
            return ReturnResult.errors("账户余额不能为负数");
        }
        // 分配金额
        Double x = 0D;
        for (int i = 0; i < allocatedCardList.size(); i++) {
            Map<String,Object> temp = new HashMap<>();
            temp = (Map<String, Object>) allocatedCardList.get(i);
            Double y = Double.parseDouble(ParamClassUtils.getParams(temp.get("allocateAmount")));
            x += y;
        }
        // 转账总金额
        int allocationMoney = (int) (x*100);
        logger.info("<==  本次待分配总金额[" + allocationMoney + "]，单位分");
        // 验证是否支撑分配
        Double m = etcclientinfo.getAccountBalance().doubleValue();
        int suf = (int)(m*100);
        if (suf - allocationMoney < 0){
            logger.error("<==  账户余额[" + suf + "] 待分配金额[" + allocationMoney + "] 单位分");
            return ReturnResult.errors("账户余额不足");
        }
        // endregion

        // region 新增用户账户资金分配操作记录 1条
        FrontAllocationOperation accountOperation = new FrontAllocationOperation();
        accountOperation.setId(UUIDUtils.getUUID());
        accountOperation.setClientNo(etcclientinfo.getClientNo());
        accountOperation.setClientName(etcclientinfo.getClientName());
        accountOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        accountOperation.setAllocationOperation(1); // 批量分配
        accountOperation.setCreateBy((String) params.get("createBy"));
        accountOperation.setTradeTime(date);
        accountOperation.setTradeNum((String) params.get("tradeNum"));
        Double d1 = etcclientinfo.getAccountBalance().doubleValue();
        accountOperation.setAccountBalance((int)(d1*100));
        accountOperation.setAllocateAmount(allocationMoney);
        accountOperation.setAllocateCountAmount(allocationMoney);
        accountOperation.setCreateTime(date);
        accountOperation.setSiteName((String) params.get("siteName"));
        accountOperation.setEmployeeNo((String) params.get("employeeNo"));
        // 新增资金分配操作--用户账户
        frontAllocationOperationService.addAllocationOperationRecord(accountOperation);
//        frontAllocationOperation.setCardBalance();
//        frontAllocationOperation.setVehicleNo();
        // endregion

        // region 新增卡账户资金分配操作记录 N条
        for (int i = 0; i < allocatedCardList.size(); i++) {
            Map<String,Object> temp = new HashMap<>();
            temp = (Map<String, Object>) allocatedCardList.get(i);
            FrontAllocationOperation frontAllocationOperation = new FrontAllocationOperation();
            // 补圈参数
            frontAllocationOperation.setId(UUIDUtils.getUUID());
            frontAllocationOperation.setClientNo(etcclientinfo.getClientNo());
            frontAllocationOperation.setClientName(etcclientinfo.getClientName());
            frontAllocationOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            frontAllocationOperation.setAllocationOperation(1); // 批量分配
            frontAllocationOperation.setCreateBy((String) params.get("createBy"));
            frontAllocationOperation.setTradeTime(date);
            frontAllocationOperation.setCardNo((String) temp.get("cardId"));
            frontAllocationOperation.setVehicleNo((String) temp.get("vehicleLicense"));
            frontAllocationOperation.setSiteName((String) params.get("siteName"));
            frontAllocationOperation.setEmployeeNo((String) params.get("employeeNo"));
            // 交易流水号
            frontAllocationOperation.setTradeNum((String) temp.get("tradeNum"));
//            frontAllocationOperation.setAccountBalance((int)(d1*100));
            Double y = Double.parseDouble(ParamClassUtils.getParams(temp.get("cardAccountBalance")));
            int beforeCardAccountBalance = (int) (y*100);
            frontAllocationOperation.setAccountBalance(beforeCardAccountBalance);
            frontAllocationOperation.setAllocateCountAmount(allocationMoney);
            Double z = Double.parseDouble(ParamClassUtils.getParams(temp.get("allocateAmount")));
            int allocateAmount = (int)(z*100);
            frontAllocationOperation.setAllocateAmount(allocateAmount);
            frontAllocationOperation.setCreateTime(date);
            // 新增资金分配操作--卡账户
            frontAllocationOperationService.addAllocationOperationRecord(frontAllocationOperation);
//        frontAllocationOperation.setCardBalance();
//        frontAllocationOperation.setVehicleNo();
        }
        // endregion

        logger.info("<==  方法batchTransfer执行结束");
        return allocationService.batchTransfer(params);
    }


    /**
     * 新增资金分配记录
     * @param params
     * @return
     */
    @PostMapping("/addAllocationRecord")
    public Map<String,Object> addAllocationRecord(@RequestBody Map<String,Object> params) {
        MapRemoveNullUtil.removeNullEntry(params);
        FrontAllocationOperation frontAllocationOperation = new FrontAllocationOperation();
        try {
            BeanToMapUtil.convertMap(params,frontAllocationOperation);
        } catch (IntrospectionException e) {
            logger.error("<==  新增资金分配操作记录失败" + e.getMessage());
            return ReturnResult.error("新增资金分配操作记录失败");
        } catch (IllegalAccessException e) {
            logger.error("<==  新增资金分配操作记录失败" + e.getMessage());
            return ReturnResult.error("新增资金分配操作记录失败");
        } catch (InvocationTargetException e) {
            logger.error("<==  新增资金分配操作记录失败" + e.getMessage());
            return ReturnResult.error("新增资金分配操作记录失败");
        }
        frontAllocationOperation.setId(UUIDUtils.getUUID());
        frontAllocationOperation.setCreateTime(new Date());
        frontAllocationOperation.setTradeTime(new Date());
        int result = frontAllocationOperationService.addAllocationOperationRecord(frontAllocationOperation);
        if (result <= 0){
            logger.info("<==  新增资金分配操作记录失败");
            return ReturnResult.error("新增资金分配操作记录失败");
        }
        logger.info("<==  新增资金分配操作记录成功");
        return ReturnResult.success("新增资金分配操作记录成功");
    }

}
