package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.object.entity.MapOnline;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.MapOnlineMapper;
import com.owinfo.service.core.service.BankOfflineRechargeService;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.core.service.FrontRechargeOperationService;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2018年01月22日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/bankOffline")
@CrossOrigin(maxAge = 3600,origins = "*")
public class BankOfflineController {

    private static final Logger logger = Logger.getLogger(BankOfflineController.class);

    @Autowired
    private BankOfflineRechargeService bankOfflineRechargeService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private MapOnlineMapper mapOnlineMapper;

    @Autowired
    private ReportFeign reportFeign;

    @Autowired
    private CardMapper cardMapper;

    @PostMapping("/jdRecharge")
    /**
     * @description 京东充值、嘉应观退费（充值到卡）
     * @author hekunlin 2018/1/22 13:20 Version 1.0
     * @param [params]
     * @return java.util.Map<java.lang.String,java.lang.Object>
     */
    public Map<String,Object> jdRecharge(@RequestBody Map<String, Object> params){
        logger.info("<==  方法jdRecharge的参数::" + params + "   开始执行");

        Map<String, Object> errorMap = new HashMap<>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        // region 校验金额
        String totalBalance = ParamClassUtils.getParams(params.get("totalAmount"));
        String giftBalacne = ParamClassUtils.getParams(params.get("giftAmount"));
        String etcBalance = ParamClassUtils.getParams(params.get("etcAmount"));
        String channelNo = ParamClassUtils.getParams(params.get(""));
        if (totalBalance.equals("")){
            totalBalance = "0";
            logger.info("<==  充值总额为空 " + totalBalance);
        }
        if (giftBalacne.equals("")){
            giftBalacne = "0";
            logger.info("<==  赠送总额为空 " + totalBalance);
        }
        if (etcBalance.equals("")){
            etcBalance = "0";
            logger.info("<==  充值金额为空 " + totalBalance);
        }
        // endregion

        // region 获取充值类型、银行编号、卡号并传入校验(去掉多余的0)
        String accountType = String.valueOf(params.get("accountType")).replaceFirst("^0*","");
        int rechargeType = Integer.valueOf(accountType);
        if (!(rechargeType == 1 || rechargeType == 2)){
            logger.error("<==  没有这种充值类型 " + rechargeType);
            errorMap.put("stateCode","1111");
            errorMap.put("field","没有这种充值类型");
            return errorMap;
        }
        String channelCode = String.valueOf(params.get("channelCode"));
        String channelTransId = String.valueOf(params.get("channelTransId"));
        String channelFinTime = String.valueOf(params.get("channelFinTime"));
        // 充值金额
        int etcAmount = Integer.valueOf(etcBalance);
        int giftAmount = Integer.valueOf(giftBalacne);
        // 相当于amount
        int totalAmount = Integer.valueOf(totalBalance);
        if (((etcAmount + giftAmount) - totalAmount) != 0){
            logger.error("<== 充值金额不等于赠送金额加缴费金额异常 " + ((etcAmount + giftAmount) - totalAmount));
            errorMap.put("stateCode","1111");
            errorMap.put("field","充值金额不等于赠送金额加缴费金额异常,无法充值");
            return errorMap;
        }
        // endregion

        // region 校验渠道流水号是否重复
        boolean flag = frontBillingRecordService.TransIdValidate(channelTransId);
        if (flag){
            logger.error("<== 已存在相同的渠道流水号,重复充值");
            errorMap.put("stateCode","2222");
            errorMap.put("field","渠道流水号重复,重复充值");
            return errorMap;
        }
        // endregion

        // region 输入参数验证
        if (accountType.isEmpty() || channelCode.isEmpty() || channelTransId.isEmpty() || channelFinTime.isEmpty()){
            logger.error("<== 充值参数存在空值");
            errorMap.put("stateCode","1111");
            errorMap.put("field","请检查充值参数");
            return errorMap;
        }
        // endregion

        // region 渠道认证 网点认证
        MapOnline mapOnline = mapOnlineMapper.selectByPrimaryKey(channelCode);
        String channelId = null;
        String channelName = null;

        if (mapOnline == null ){
            logger.error("<== 不存在这个线上渠道编号");
            errorMap.put("stateCode","1111");
            errorMap.put("field","不存在这个线上渠道编号,不允许充值");
            return errorMap;
        } else {
            channelId = mapOnline.getId();
            channelName = mapOnline.getName();
        }

        // 京东渠道没有站点信息
        String dotContactName = null;
        String dotName = null;
        String dotNo = null;
        // endregion

        // region 获取交易流水号
        String tradeNumber = (String) params.get("tradeNumber");
        logger.info("<==  本次交易交易流水号为tradeNumber= " + tradeNumber);
        // endregion

        // region 查询卡信息、客户信息
        Etccardinfo etccardinfo = null;
        Etcclientinfo etcclientinfo = null;
        if (rechargeType == 1){
            String cardId = (String) params.get("etcCardId");
            etccardinfo = cardMapper.getCard(cardId);
            if (etccardinfo == null){
                logger.error("<==  未找到该卡片[" + cardId + "]对应的卡片信息");
                errorMap.put("stateCode","1111");
                errorMap.put("field","未找到该卡片信息");
                return errorMap;
            }
            String spare = etccardinfo.getSpare();
            etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.error("<== 不存在这个[" + cardId + "]对应的用户信息");
                errorMap.put("stateCode","1111");
                errorMap.put("field","未查到该卡片对应的用户信息");
                return errorMap;
            }
        }
        if (rechargeType == 2){
            String certificateNumber = ParamClassUtils.getParams(params.get("etcCertNum"));
            Map<String, Object> tempMap = new HashMap<>();
            tempMap.put("certificateNumber",certificateNumber);
            etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  不是个人客户充值，集团客户充值");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<== 不存在这个用户信息");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","未查到该用户信息");
                    return errorMap;
                }
            }
        }
        // endregion

        // region 新增充值操作记录
        FrontRechargeOperation frontRechargeOperation = new FrontRechargeOperation();
        frontRechargeOperation.setId(UUIDUtils.getUUID());
        frontRechargeOperation.setTransId(channelTransId);
        frontRechargeOperation.setTradeNum(tradeNumber);
        frontRechargeOperation.setChannelName(channelName);
        frontRechargeOperation.setChannelNum(channelCode.substring(0,10));
        frontRechargeOperation.setChannelType("3");
        frontRechargeOperation.setSiteName(dotName);
        frontRechargeOperation.setEmployeeNo(dotContactName);
        frontRechargeOperation.setPaidAmount(etcAmount);
        frontRechargeOperation.setGiftAmount(giftAmount);
        frontRechargeOperation.setRechargeAmount(totalAmount);
        frontRechargeOperation.setTradeTime(date);

        // 完善卡充值操作记录 + 执行新增充值操作记录
        if (rechargeType == 1){
            frontRechargeOperation.setCardId((String) params.get("etcCardId"));
            frontRechargeOperation.setOperationType(2);
//            rechargeOperationMap.put("cardAccountBalance",0); // 未知
        }
        if (rechargeType == 2){
//            frontRechargeOperation.setCertificateNumber(ParamClassUtils.getParams(params.get("etcCertNum")));
            frontRechargeOperation.setCertificateNumber(etcclientinfo.getSpare());
            frontRechargeOperation.setOperationType(0);
//            rechargeOperationMap.put("accountBalance",0); // 未知
        }
        frontRechargeOperation.setRechargeType(5);
        // 应要求：操作类型中客户类型、以下参数均不能保证一定有，全部统一设为固定值
        frontRechargeOperation.setClientName(etcclientinfo.getClientName());
        frontRechargeOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        frontRechargeOperationService.addRechargeOperationRecord(frontRechargeOperation);
        logger.info("<==  新增充值操作记录成功");
        // endregion

        logger.info("<==  方法jdRecharge执行结束");
        return bankOfflineRechargeService.bankOfflineRecharge(params);
    }


}
