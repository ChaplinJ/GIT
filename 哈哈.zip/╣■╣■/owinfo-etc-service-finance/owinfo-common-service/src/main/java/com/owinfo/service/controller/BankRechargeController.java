package com.owinfo.service.controller;

import com.owinfo.object.entity.BankRechargeOperation;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.service.BankRechargeOperationService;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.util.BeanToMapUtil;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import com.owinfo.service.util.ValidateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 新增银行充值冲正记录接口
 */
@RestController
@RequestMapping("/bank")
@CrossOrigin(maxAge = 3600,origins = "*")
public class BankRechargeController {

    private static final Logger logger = Logger.getLogger(BankRechargeController.class);

    @Autowired
    private BankRechargeOperationService bankRechargeOperationService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    /**
     * 新增银行充值冲正操作记录
     * @param params
     * @return
     */
    @PostMapping("/addBankOperationRecord")
    public int addBankOperationRecord(@RequestBody Map<String,Object> params){
        BankRechargeOperation bankRechargeOperation = new BankRechargeOperation();
        try {
            BeanToMapUtil.convertMap(params,bankRechargeOperation);
        } catch (IntrospectionException e) {
            logger.error("<==  " + e.getMessage());
            return 0;
        } catch (IllegalAccessException e) {
            logger.error("<==  " + e.getMessage());
            return 0;
        } catch (InvocationTargetException e) {
            logger.error("<==  " + e.getMessage());
            return 0;
        }
        /**
         * 补全参数
         */
        bankRechargeOperation.setId(UUIDUtils.getUUID());
        bankRechargeOperation.setCreateTime(new Date());
        bankRechargeOperation.setOperatorTime(new Date());
        bankRechargeOperation.setRemove(0);
        int result = bankRechargeOperationService.addBankOperationRecord(bankRechargeOperation);
        if (result == 0){
            return 0;
        }
        return 1;
    }

    /**
     * 获取最新的一条银行交易记录（可能是充值、可能是冲正）
     * @param params
     * @return
     */
    @PostMapping("/getLastBankRechargeRecord")
    public Map<String,Object> getLastBankRechargeRecord(@RequestBody Map<String,Object> params){
        Map<String,Object> map  = new HashMap<>();
        FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
        frontBillingRecord = frontBillingRecordService.getLastBankRechargeRecord(params);
        if (ValidateUtils.isEmpty(frontBillingRecord)){
            logger.error("<== 获取最新的一条银行充值记录为空");
            return ReturnResult.error("不存在最新的充值记录");
        }
        map.put("frontBillingRecord",frontBillingRecord);
        return ReturnResult.successResult("获取成功",map);
    }

}
