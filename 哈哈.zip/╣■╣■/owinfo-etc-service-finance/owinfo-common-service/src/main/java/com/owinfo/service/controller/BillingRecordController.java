package com.owinfo.service.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.owinfo.object.dto.AccountRechargeDTO;
import com.owinfo.object.dto.FinanceFlowDTO;
import com.owinfo.object.dto.ExportFinanceFlowDTO;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * @author Created by hekunlin on 2017年10月18日
 *         github : https://github.com/rexlin600/
 * @Description 交易管理模块--充值交易(ETC卡资金流动查询、用户账户充值查询)
 */
@RestController
@RequestMapping("/finance/back/recharge")
@CrossOrigin(maxAge = 3600,origins = "*")
public class BillingRecordController {

    private static Logger logger = Logger.getLogger(BillingRecordController.class);

    private static final String ZERO = "0";

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;


    /**
     * ETC资金流动查询(卡账户和用户账户都需要)：用户证件号、卡号均不为空
     * @param params
     * @return
     */
    @PostMapping("/etcFinanceFlowSearch")
    public Map<String,Object> etcFinanceFlowSearch(@RequestBody Map<String,Object> params){
        logger.info("请求参数 params= " + params);
        boolean flag = ValidateUtils.isEmpty(params);
        if (flag){
            return ReturnResult.error("传入参数为空！");
        }
        // 取出无用的参数
        MapRemoveNullUtil.removeNullEntry(params);
        //int page = (int) params.get("page");
        //int pageSize = (int) params.get("pageSize");
        Integer page = Integer.parseInt(String.valueOf(params.get("page")));
        Integer pageSize = Integer.parseInt(String.valueOf(params.get("pageSize")));
        PageHelper.startPage(page,pageSize);

        String certificateNumber = (String) params.get("certificateNumber");
        String cardId = (String) params.get("cardId");
        String accountSubject = (String) params.get("accountSubject");

        List<FinanceFlowDTO> frontBillingRecordList = null;

        //卡号和证件号都为空 -- 这个不允许
        if (StringUtils.isEmpty(certificateNumber) && StringUtils.isEmpty(cardId)){
            logger.error("<==  证件编号[" + certificateNumber +"]" + "和ETC卡号[" + cardId +"]不能都为空");
            return ReturnResult.error("证件编号和ETC卡号不能都为空");
        }

        //卡号不为空  -- 查当前ETC卡的资金流动
        if((!StringUtils.isEmpty(cardId) && StringUtils.isEmpty(certificateNumber)) || (!StringUtils.isEmpty(cardId) && !StringUtils.isEmpty(certificateNumber))){

            // 查询列表
            frontBillingRecordList = frontBillingRecordService.etcCardFinanceFlowSearch(params);

        }

        //卡号为空、证件号不为空  -- 查用户以及用户名下所有卡的资金流动（先通过证件号去用户表中查spare值，再拿spare去账单表中查询用户本身以及此用户名下的卡资金流动）
        if(StringUtils.isEmpty(cardId) && !StringUtils.isEmpty(certificateNumber)){
            Etcclientinfo etcclientinfo =  etcclientinfoMapper.selectByPrimaryKey(certificateNumber.trim());
            if (etcclientinfo == null){
                logger.info("<==  证件编号[" + certificateNumber + "]不是个人客户.");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber.trim());
                if (etcclientinfo == null){
                    logger.error("<==  证件编号[" + certificateNumber + "]不是集团客户，没找到该证件号对应的客户信息");
                    return ReturnResult.error("未找到该证件号对应的充值信息");
                }
            }
            // 注入参数
            logger.info("<==  用户账户[" + certificateNumber + "]充值查询,唯一标识为[" + etcclientinfo.getSpare() + "]");
            params.put("spare",etcclientinfo.getSpare());

            PageHelper.startPage(page,pageSize);

            // 查询列表
            frontBillingRecordList = frontBillingRecordService.etcAccountFinanceFlowSearch(params);
        }

        PageInfo pageInfo = new PageInfo(frontBillingRecordList);
        // 组装返回的分页查询结果
        Map<String,Object> pageBean = PageDataUtils.pagePut(pageInfo.getTotal()
                ,pageInfo.getPageSize()
                ,pageInfo.isIsFirstPage()
                ,pageInfo.isIsLastPage()
                ,pageInfo.getPageNum()
        );
        // 将分页查询到的数据放入List中
        pageBean.put("etcTransactionDetailList",pageInfo.getList());
        logger.info("PageInfo数据为：" + pageInfo+ " 获取分页的数据为：" + pageInfo.getList().toString());
        return ReturnResult.successResult("ETC卡充圈转三合一查询数据成功",pageBean);
    }



    /**
     * ETC卡资金流动查询：用户证件号、卡号均不为空
     * @param params
     * @return
     */
    @PostMapping("/financeFlowSearch")
    public Map<String,Object> financeFlowSearch(@RequestBody Map<String,Object> params){
        logger.info("请求参数 params= " + params);
        boolean flag = ValidateUtils.isEmpty(params);
        if (flag){
            return ReturnResult.error("传入参数为空！");
        }
        // 取出无用的参数
        MapRemoveNullUtil.removeNullEntry(params);
        int page = (int) params.get("page");
        int pageSize = (int) params.get("pageSize");
        PageHelper.startPage(page,pageSize);
        // 查询列表
        List<FinanceFlowDTO> frontBillingRecordList = frontBillingRecordService.financeflowSearch(params);
        PageInfo pageInfo = new PageInfo(frontBillingRecordList);
        // 组装返回的分页查询结果
        Map<String,Object> pageBean = PageDataUtils.pagePut(pageInfo.getTotal()
                ,pageInfo.getPageSize()
                ,pageInfo.isIsFirstPage()
                ,pageInfo.isIsLastPage()
                ,pageInfo.getPageNum()
        );
        // 将分页查询到的数据放入List中
        pageBean.put("etcTransactionDetailList",pageInfo.getList());
        logger.info("PageInfo数据为：" + pageInfo+ " 获取分页的数据为：" + pageInfo.getList().toString());
        return ReturnResult.successResult("ETC卡充圈转三合一查询数据成功",pageBean);
    }

    /**
     * 导出ETC资金流动查询数据
     * @param params
     * @return
     */
    @PostMapping("/exportUnitSearch")
    public byte[] exportUnitSearch(@RequestBody Map<String,Object> params){
        byte[] bytes = new byte[1024];
        Map<String, Object> resutObject = etcFinanceFlowSearch(params);

        Map<String,Object> datas= (Map<String, Object>) resutObject.get("data");
        List<FinanceFlowDTO> financeFlowDTO = (List<FinanceFlowDTO>) datas.get("etcTransactionDetailList");
        List<String[]> colums = new ArrayList<>();
        List<String[]> fileds = new ArrayList<>();
        LinkedHashMap<String, List<?>> dataMap = new LinkedHashMap<>();
        List<ExportFinanceFlowDTO> exportFinanceFlowDTO = new ArrayList<ExportFinanceFlowDTO>();
        ExportFinanceFlowDTO exportFinanceFlow = null;
        String value;
        for(FinanceFlowDTO financeFlow : financeFlowDTO){
            exportFinanceFlow = new ExportFinanceFlowDTO();
            value = financeFlow.getAccountSubject();
            if("1".equals(value)){
                exportFinanceFlow.setAccountSubject("用户账户");
                exportFinanceFlow.setFillTransferStatus("—");
            }
            if("2".equals(value)){
                exportFinanceFlow.setAccountSubject("卡账户");
                exportFinanceFlow.setFillTransferStatus("—");
            }
            if("3".equals(value)){
                exportFinanceFlow.setAccountSubject("卡钱包");
                value = String.valueOf(financeFlow.getFillTransferStatus());
                if("0".equals(value)){
                    exportFinanceFlow.setFillTransferStatus("需补圈");
                }
                if("1".equals(value)){
                    exportFinanceFlow.setFillTransferStatus("不需要补圈");
                }
            }
            exportFinanceFlow.setOperationTime(financeFlow.getOperationTime());  //流动时间

            value = String.valueOf(financeFlow.getOperationType()); //操作类型
            if("1".equals(value)){
                exportFinanceFlow.setOperationType("充值");
            }else if("2".equals(value)){
                exportFinanceFlow.setOperationType("充正");
            }else if("3".equals(value)){
                exportFinanceFlow.setOperationType("圈存");
            }else if("4".equals(value)){
                exportFinanceFlow.setOperationType("点对点分配");
            }else if("5".equals(value)){
                exportFinanceFlow.setOperationType("批量分配");
            }else if("6".equals(value)){
                exportFinanceFlow.setOperationType("卡转账");
            }else if("7".equals(value)){
                exportFinanceFlow.setOperationType("补交收款");
            }else if("8".equals(value)){
                exportFinanceFlow.setOperationType("银行充值转账");
            }else if("9".equals(value)){
                exportFinanceFlow.setOperationType("银行转账冲正");
            }else if("10".equals(value)){
                exportFinanceFlow.setOperationType("注销退费");
            }else if("11".equals(value)){
                exportFinanceFlow.setOperationType("清账");
            }else if("12".equals(value)){
                exportFinanceFlow.setOperationType("清户");
            }else if("131".equals(value)){
                exportFinanceFlow.setOperationType("充正补款-储值卡退");
            }else if("132".equals(value)){
                exportFinanceFlow.setOperationType("充正补款-争议返款正");
            }else if("133".equals(value)){
                exportFinanceFlow.setOperationType("充正补款-补充值");
            }else if("14".equals(value)){
                exportFinanceFlow.setOperationType("清算退卡补款");
            }else if("15".equals(value)){
                exportFinanceFlow.setOperationType("线上卡充值");
            }else if("16".equals(value)){
                exportFinanceFlow.setOperationType("线上用户账户充值");
            }else if("17".equals(value)){
                exportFinanceFlow.setOperationType("银行增值资金分配");
            }else if("18".equals(value)){
                exportFinanceFlow.setOperationType("退卡补款");
            }else if("19".equals(value)){
                exportFinanceFlow.setOperationType("补卡");
            }else if("20".equals(value)){
                exportFinanceFlow.setOperationType("换卡");
            }else{
                exportFinanceFlow.setOperationType("—");
            }

            value = String.valueOf(financeFlow.getRechargeType()); //充值方式
            if("0".equals(value)){
                exportFinanceFlow.setRechargeType("现金");
            }else if("1".equals(value)){
                exportFinanceFlow.setRechargeType("POS");
            }else if("2".equals(value)){
                exportFinanceFlow.setRechargeType("转账");
            }else  if("3".equals(value)){
                exportFinanceFlow.setRechargeType("电商");
            }else if("4".equals(value)){
                exportFinanceFlow.setRechargeType("卡券");
            }else{
                exportFinanceFlow.setRechargeType("其他");
            }

            value = String.valueOf(financeFlow.getOperationMark());  //操作符号
            if("1".equals(value)){
                exportFinanceFlow.setOperationMark("+");
            }else{
                exportFinanceFlow.setOperationMark("-");
            }
            exportFinanceFlow.setPreOperationBalance(String.valueOf(financeFlow.getPreOperationBalance()*0.01)); //操作前金额
            exportFinanceFlow.setOperationAmount(String.valueOf(financeFlow.getOperationAmount()*0.01));  //操作金额
            exportFinanceFlow.setSufOperationBalance(String.valueOf(financeFlow.getSufOperationBalance()*0.01));  //操作后金额
            exportFinanceFlow.setAccountSubjectNo(financeFlow.getAccountSubjectNo());
            exportFinanceFlow.setCertificateNumber(financeFlow.getCertificateNumber());
            exportFinanceFlow.setClientName(financeFlow.getClientName());
            exportFinanceFlow.setCardStatus("正常"); //卡状态
            exportFinanceFlowDTO.add(exportFinanceFlow);
        }

        colums.add(PARAM.FINANCEFIOW_COLUMS.getParams());
        fileds.add(PARAM.FINANCEFIOW_FIELDS.getParams());
        dataMap.put(TITLE.FINANCEFIOW_TITLE.getTitle(), exportFinanceFlowDTO);
        ExcelUtil.ExcelExportData data = new ExcelUtil.ExcelExportData();
        data.setDataMap(dataMap);
        data.setColumnNames(colums);
        data.setFieldNames(fileds);
        data.setTitles(PARAM.FINANCEFIOW_SHEET.getParams());
        try {
            return ExcelUtil.export2ByteArray(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bytes;
    }

    /**
     * 用户账户充值查询：卡号必为空，用户账户不为空
     * @param params
     * @return
     */
    @PostMapping("/userAccountRechargeSearch")
    public Map<String,Object> userAccountRechargeSearch(@RequestBody Map<String,Object> params){
        logger.info("请求参数 params= " + params);
        boolean flag = ValidateUtils.isEmpty(params);
        if (flag){
            return ReturnResult.error("传入参数为空！");
        }
        // 取出无用的参数
        MapRemoveNullUtil.removeNullEntry(params);
        int page = (int) params.get("page");
        int pageSize = (int) params.get("pageSize");
        PageHelper.startPage(page,pageSize);

        // 20180202证件编号转换
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        String certificateNumber = (String) params.get("certificateNumber");
        if (StringUtils.isEmpty(certificateNumber)){
            logger.error("<==  证件编号[" + certificateNumber +"]不能为空");
            return ReturnResult.error("证件编号不能为空");
        }
        etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber.trim());
        if (etcclientinfo == null){
            logger.info("<==  证件编号[" + certificateNumber + "]不是个人客户");
            etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber.trim());
            if (etcclientinfo == null){
                logger.error("<==  证件编号[" + certificateNumber + "]不是集团客户，没找到该证件号对应的客户信息");
                return ReturnResult.error("未找到该证件号对应的充值信息");
            }
        }
        // 注入参数
        logger.info("<==  用户账户[" + certificateNumber + "]充值查询,唯一标识为[" + etcclientinfo.getSpare() + "]");
        params.put("spare",etcclientinfo.getSpare());

        // 获取分页查询结果pageInfo
        List<AccountRechargeDTO> frontBillingRecordList = frontBillingRecordService.userAccountRechargeSearch(params);
        PageInfo pageInfo = new PageInfo(frontBillingRecordList);
        // 组装返回的分页查询结果
        Map<String,Object> pageBean = PageDataUtils.pagePut(pageInfo.getTotal()
                ,pageInfo.getPageSize()
                ,pageInfo.isIsFirstPage()
                ,pageInfo.isIsLastPage()
                ,pageInfo.getPageNum()
        );
        // 将分页查询到的数据放入List中
        pageBean.put("etcTransactionDetailList",pageInfo.getList());
        logger.info("PageInfo数据为：" + pageInfo+ " 获取分页的数据为：" + pageInfo.getList().toString());
        return ReturnResult.successResult("用户账户充值记录查询数据成功",pageBean);
    }

    /**
     * 导出用户账户充值数据
     * @param params
     * @return
     */
    @PostMapping("/exportUserRechargeSearch")
    public Map<String,Object> exportUserRechargeSearch(@RequestBody Map<String,Object> params){

        return null;
    }

    /**
     * 更新补圈存状态
     * @param params
     * @return
     */
    @PostMapping("/updateTransferRecord")
    public Map<String,Object> updateTransferRecord(@RequestBody Map<String,Object> params){
        String cardNo = ParamClassUtils.getParams(params.get("cardNo"));
        String tradeNum = ParamClassUtils.getParams(params.get("tradeNum"));
        logger.info("<==  补圈存记录参数 cardNo=" + cardNo + " tradeNum=" + tradeNum);
        // 取出需要新增记录的参数
        Map<String,Object> map = new HashMap<>();
        map.put("cardNo",cardNo);
        map.put("tradeNum",tradeNum);
        int result = frontBillingRecordService.updateTransferRecord(map);
        if (result <= 0){
            logger.error("更新补圈存状态账单记录失败");
            return ReturnResult.error("更新补圈存状态账单记录失败");
        }
        logger.info("更新补圈存状态账单记录成功");
        return ReturnResult.success("更新补圈存状态账单记录成功");
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 查询用户账户、卡账户充值、转账、圈存操作记录
     * @Params:  * @param null
     * @Date: 2017/12/7 12:53
     */
    @RequestMapping("/financeSelect")
    public Map<String, Object> financeSelect(@RequestBody Map<String, Object> map){
        Map<String, Object> objectMap = new HashMap<>();
        // 取出无用的参数
        MapRemoveNullUtil.removeNullEntry(map);
        if (map.get("page") != null && map.get("pageSize") != null){
            int page = (int) map.get("page");
            int pageSize = (int) map.get("pageSize");
            PageHelper.startPage(page,pageSize);
            // 获取分页查询结果pageInfo
            List<FrontBillingRecord> frontBillingRecords = frontBillingRecordService.financeSelect(map);
            PageInfo pageInfo = new PageInfo(frontBillingRecords);
            // 组装返回的分页查询结果
            objectMap.put("list", pageInfo.getList());
            objectMap.put("total", pageInfo.getTotal());
            objectMap.put("pageSize", pageSize);
            objectMap.put("page", page);
            objectMap.put("isFirstPage", pageInfo.isIsFirstPage());
            objectMap.put("isLastPage", pageInfo.isIsLastPage());
            // 将分页查询到的数据放入List中
            objectMap.put("list",pageInfo.getList());
            return ReturnResult.successResult2("查询成功", objectMap);
        }
        List<FrontBillingRecord> frontBillingRecords = frontBillingRecordService.financeSelect(map);
        objectMap.put("list", frontBillingRecords);
        return ReturnResult.successResult2("查询成功", objectMap);
    }


    /**
     * 银行充值渠道流水号验重
     * @param transId
     * @return
     */
    @PostMapping("/transIdValidate")
    public Boolean TransIdValidate(@RequestParam(value = "transId") String transId){
        return frontBillingRecordService.TransIdValidate(transId);
    }

}
