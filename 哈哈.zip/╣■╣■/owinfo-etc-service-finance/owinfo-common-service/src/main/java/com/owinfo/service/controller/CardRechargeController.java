package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.service.CardRechargeService;
import com.owinfo.service.core.service.FrontRechargeOperationService;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2018年01月18日
 *         github : https://github.com/rexlin600/
 * @Description 卡充值重构
 */
@RestController
@RequestMapping("/cardRecharge")
@CrossOrigin(maxAge = 3600,origins = "*")
public class CardRechargeController {

    private static final Logger logger = Logger.getLogger(CardRechargeController.class);

    @Autowired
    private CardRechargeService cardRechargeService;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    /**
    * @description 获取卡信息
    * @author hekunlin 2018/1/30 19:50 Version 1.2
    * @param
    * @return
    */
    @PostMapping("/getCard")
    public Etccardinfo getCard(@RequestParam(value = "cardId",required = true) String cardId){
        return cardMapper.getCard(cardId);
    }

    /**
    * @description 获取卡信息
    * @author hekunlin 2018/1/30 19:50 Version 1.2
    * @param
    * @return
    */
    @PostMapping("/getCardInfo")
    public Map<String, Object> getCardInfo(String cardId){
        logger.info("<==  方法getCardInfo的参数::" + cardId + "   开始执行");

        Etccardinfo etccardinfo = cardMapper.getCard(cardId);
        if (etccardinfo == null){
            logger.error("<==  卡号[" + cardId + "]未找到对应的卡信息");
            return ReturnResult.errors("没有该卡片信息");
        }

        // 20180130证件编号修正
        String spare = etccardinfo.getSpare();
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  不存在唯一标识为[" + spare + "]的这个客户");
            return ReturnResult.errors("不存在这个用户信息");
        }
        String clientType = etcclientinfo.getClientType();
        logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());

        // 修正卡信息中的用户信息
        if ("1".equals(clientType)){
            etccardinfo.setCertificateNumber(etcclientinfo.getCertificateNumber());
            etccardinfo.setClientName(etcclientinfo.getClientName());
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
            etccardinfo.setClientType(etcclientinfo.getClientType());
        }
        if ("2".equals(clientType)){
            etccardinfo.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            etccardinfo.setClientName(etcclientinfo.getUnitName());
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
            etccardinfo.setClientType(etcclientinfo.getClientType());
        }

        Map<String, Object> map = new HashMap<>();
        map.put("status",1);
        map.put("msg","获取卡信息成功");
        map.put("data",etccardinfo);

        logger.info("<==  方法getCardInfo执行结束");
        return map;
    }

    /**
    * @description 卡充值
    * @author hekunlin 2018/1/19 0:59 Version 1.2
    * @param
    * @return
    */
    @PostMapping("/cardRecharge")
    public Map<String,Object> cardRecharge(@RequestBody Map<String, Object> params){
        logger.info("<==  方法cardRecharge的参数:: " + params + "   开始执行");

        Date date = new Date();

        // region 新增卡充值操作记录
        FrontRechargeOperation rechargeOperation = new FrontRechargeOperation();
        rechargeOperation.setId(UUIDUtils.getUUID());
        rechargeOperation.setTradeNum((String) params.get("tradeNum"));
        rechargeOperation.setChannelType((String) params.get("channelType"));
        rechargeOperation.setChannelName((String) params.get("channelName"));
        rechargeOperation.setChannelNum((String) params.get("channelNum"));
        rechargeOperation.setEmployeeNo((String) params.get("employeeNo"));
        rechargeOperation.setSiteName((String) params.get("siteName"));
//        rechargeOperation.setCertificateNumber();
        rechargeOperation.setCardId((String) params.get("cardId"));
//        rechargeOperation.setClientNo();
//        rechargeOperation.setClientName();
//        rechargeOperation.setClientType();
        rechargeOperation.setOperationType(2);
        rechargeOperation.setRechargeType(Integer.valueOf((String) params.get("chargeType")));
        rechargeOperation.setRechargeNum((String) params.get("rechargeNum"));
//        rechargeOperation.setAccountBalance();
        String chargeType = (String) params.get("chargeType");
        Double x = Double.parseDouble((String) params.get("chargeAmount"));
        int y = (int)(x*100);
        // 现金、pos
        if ("0".equals(chargeType) || "1".equals(chargeType)){
            rechargeOperation.setPaidAmount(y);
            rechargeOperation.setGiftAmount(0);
            rechargeOperation.setRechargeAmount(y);
        }
        // TODO 电商
        if ("3".equals(chargeType)){

        }
        // 体验券
        if ("4".equals(chargeType)){
            rechargeOperation.setPaidAmount(0);
            rechargeOperation.setGiftAmount(y);
            rechargeOperation.setRechargeAmount(y);
        }
        rechargeOperation.setAmountUpper((String) params.get("AmountUpper"));
        rechargeOperation.setTradeTime(date);
        rechargeOperation.setCreateBy((String) params.get("employeeNo"));
        rechargeOperation.setRemove(0);
        frontRechargeOperationService.addRechargeOperationRecord(rechargeOperation);
        // endregion

        logger.info("<==  方法cardRecharge执行结束");
        return cardRechargeService.cardRecharge(params);
    }


}
