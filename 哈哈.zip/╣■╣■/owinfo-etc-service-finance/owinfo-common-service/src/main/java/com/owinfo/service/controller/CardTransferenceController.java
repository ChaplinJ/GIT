package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontCardTransferOperation;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.service.CardTransferService;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.core.service.FrontCardTransferOperationService;
import com.owinfo.service.util.BeanToMapUtil;
import com.owinfo.service.util.MapRemoveNullUtil;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.*;

import static com.owinfo.service.util.ParamClassUtils.getParams;
import static org.apache.http.client.methods.RequestBuilder.put;

/**
 * @author Created by hekunlin on 2017年11月25日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/cardTransference")
@CrossOrigin(maxAge = 3600,origins = "*")
public class CardTransferenceController {

    private static Logger logger = Logger.getLogger(CardTransferenceController.class);

    @Autowired
    private FrontCardTransferOperationService frontCardTransferOperationService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private CardTransferService cardTransferService;

    /**
    * @description 获取卡转账信息
    * @author hekunlin 2018/1/31 12:35 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/getTransferCards")
    public Map<String,Object> getTransferCards(@RequestBody Map<String,Object> params){
        logger.info("<==  方法getTransferCards的参数::" + params + "   开始执行");

        // region 获取传入卡号获取卡信息并验证
        String cardId = getParams(params.get("cardId"));
        if (StringUtils.isEmpty(cardId)){
            logger.error("<==  卡号为空");
            return ReturnResult.error("卡号为空");
        }

        Etccardinfo etccardinfo = cardMapper.getCard(cardId);
        if (etccardinfo == null){
            logger.error("<==  未获取到卡信息");
            return ReturnResult.error("未获取到卡信息");
        }

        String outCardStatus = etccardinfo.getCardStatus();
        String payType = etccardinfo.getPayType();
        if (!outCardStatus.equals("600202101")){
            logger.error("<== 转出卡状态不正常,不允许转账");
            return ReturnResult.error("转出卡状态不正常,不允许转账");
        }
        if (!payType.equals("1")){
            logger.error("<== 记账卡不允许转账");
            return ReturnResult.error("记账卡不允许转账");
        }
        // endregion

        // region 20180130证件编号修正
        String spare = etccardinfo.getSpare();
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  不存在唯一标识为[" + spare + "]的这个客户");
            return ReturnResult.errors("不存在这个用户信息");
        }
        String certificateNumber = etcclientinfo.getCertificateNumber();
        String clientType = etcclientinfo.getClientType();
        logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());

        List<Etccardinfo> tempCardList = cardMapper.getCards(spare,cardId);
        List<Etccardinfo> cardList = new ArrayList<>();

        // 修正卡表中的用户数据
        for (int i = 0; i < tempCardList.size(); i ++){
            Etccardinfo temp = tempCardList.get(i);
            if ("1".equals(clientType)){
                temp.setCertificateNumber(etcclientinfo.getCertificateNumber());
            }
            if ("2".equals(clientType)){
                temp.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            }
            temp.setClientType(etcclientinfo.getClientType());
            temp.setClientName(etcclientinfo.getClientName());
            temp.setClientNo(etcclientinfo.getClientNo());
            cardList.add(temp);
        }
        if ("1".equals(clientType)){
            etccardinfo.setCertificateNumber(etcclientinfo.getCertificateNumber());
            etccardinfo.setClientType(etcclientinfo.getClientType());
            etccardinfo.setClientName(etcclientinfo.getClientName());
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
        }
        if ("2".equals(clientType)){
            etccardinfo.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            etccardinfo.setClientType(etcclientinfo.getClientType());
            etccardinfo.setClientName(etcclientinfo.getUnitName());
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
        }
        logger.info("<==  修正卡表中用户数据完成");
        // endregion

        // 封装返回的ETC卡列表
        Map<String,Object> cardMap = new HashMap<>();
        cardMap.put("cardList",cardList); // 数组
        cardMap.put("userMap",etccardinfo); // 对象
        logger.info(" <-- 验证成功,获取ETC卡 " + cardId + " 所属用户证件编号 " + certificateNumber);
        logger.info(" <-- 获取ETC卡列表成功 " + cardList + " 获取客户信息成功" + etccardinfo);
        logger.info("<==  方法getTransferCards执行结束");

        Map<String, Object> successResult = new HashMap<>();
        successResult.put("status",1);
        successResult.put("msg","获取成功");
        successResult.put("data",cardMap);
        return successResult;
    }

    /**
    * @description 卡转账
    * @author hekunlin 2018/1/31 12:36 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/cardTransfer")
    public Map<String,Object> cardTransfer(@RequestBody Map<String,Object> params){
        logger.info("<==  方法cardTransfer的参数::" + params + "   开始执行");

        Date date = new Date();

        // region 转出卡信息、转入卡信息
        String outCardId = (String) params.get("outCardId");
        Etccardinfo outCardInfo = cardMapper.getCard(outCardId);

        // 验证是转出卡是否允许转账
        BigDecimal cardAccountBalance = outCardInfo.getCardAccountBalance();
        if (cardAccountBalance.compareTo(BigDecimal.ZERO) == -1){
            logger.error("<==  转出卡账户[" + outCardInfo.getCardId() + "]余额[" + cardAccountBalance + "]不足，不允许转账");
            return ReturnResult.errors("余额不足，不允许转账");
        }

        Map<String,Object> cardList = (Map<String, Object>) params.get("cardList");
        String inputCardId = getParams(cardList.get("cardId"));
        Etccardinfo inCardInfo = cardMapper.getCard(inputCardId);

        // 获取卡数据、用户数据
        Etccardinfo etccardinfo = cardMapper.getCard(outCardId);
        if (etccardinfo == null){
            logger.error("<==  卡号[" + outCardId + "]没有对应的用户信息");
            return ReturnResult.errors("不存在这个卡号信息");
        }

        String spare = etccardinfo.getSpare();
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  不存在唯一标识为[" + spare + "]的这个客户");
            return ReturnResult.errors("不存在这个用户信息");
        }
        String clientType = etcclientinfo.getClientType();
        logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());
        // endregion

        // region 新增卡转账操作记录
        Map<String,Object> cardTransferRecordMap = new HashMap<>();
        FrontCardTransferOperation frontCardTransferOperation = new FrontCardTransferOperation();
        frontCardTransferOperation.setOriginalCardId((String) params.get("outCardId"));
        frontCardTransferOperation.setTransferTime(date);
        frontCardTransferOperation.setCreateTime(date);
        frontCardTransferOperation.setId(UUIDUtils.getUUID());
//        frontCardTransferOperation.setCertificateNumber(outCardInfo.getCertificateNumber());
        if ("1".equals(clientType)){
            frontCardTransferOperation.setCertificateNumber(etcclientinfo.getCertificateNumber());
        }
        if ("2".equals(clientType)){
            frontCardTransferOperation.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
        }
        frontCardTransferOperation.setClientName(etcclientinfo.getClientName());
        frontCardTransferOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        frontCardTransferOperation.setClientNo(etcclientinfo.getClientNo());
        Double d1 = outCardInfo.getCardAccountBalance().doubleValue();
        int cardAccountBalanceOut = (int)(d1*100);
        frontCardTransferOperation.setOriginalAccountBalance(cardAccountBalanceOut);
        frontCardTransferOperation.setTransferCardId(inputCardId);
        frontCardTransferOperation.setVehicleNo(outCardInfo.getVehicleLicense()); // 转出车牌号
        Double d2 = inCardInfo.getCardAccountBalance().doubleValue();
        int cardAccountBalanceIn = (int)(d2*100);
        frontCardTransferOperation.setTransferAccountBalance(cardAccountBalanceIn);
        String transferBalances = getParams(params.get("transferBalance"));
        Double d3 = Double.parseDouble(transferBalances);
        int transferAmount = (int)(d3*100);
        frontCardTransferOperation.setTransferAmount(transferAmount);
        frontCardTransferOperation.setAmountUpper((String) params.get("amountUpper"));
        int result = frontCardTransferOperationService.addCardTransferOperationRecord(frontCardTransferOperation);

        if (result == 0){
            logger.info("<==  新增卡转账操作记录失败");
            return ReturnResult.error("新增卡转账操作记录失败");
        }
        logger.info("<==  新增卡转账操作记录成功");
        // endregion

        logger.info("<==  方法cardTransfer执行结束");
        Map<String, Object> tempMap = new HashMap<>();

        return cardTransferService.cardTransfer(params);
    }


    /**
     * 新增卡转账记录
     * @param params
     * @return
     */
    @PostMapping("/addCardTransferenceRecord")
    public Map<String,Object> addCardTransferenceRecord(@RequestBody Map<String,Object> params) {
        FrontCardTransferOperation frontCardTransferOperation = new FrontCardTransferOperation();
        MapRemoveNullUtil.removeNullEntry(params);
        try {
            BeanToMapUtil.convertMap(params, frontCardTransferOperation);
        } catch (IntrospectionException e) {
            logger.error("<==  新增卡转账操作记录失败" + e.getMessage());
            return ReturnResult.error("新增卡转账操作记录失败");
        } catch (IllegalAccessException e) {
            logger.error("<==  新增卡转账操作记录失败" + e.getMessage());
            return ReturnResult.error("新增卡转账操作记录失败");
        } catch (InvocationTargetException e) {
            logger.error("<==  新增卡转账操作记录失败" + e.getMessage());
            return ReturnResult.error("新增卡转账操作记录失败");
        }
        frontCardTransferOperation.setId(UUIDUtils.getUUID());
        frontCardTransferOperation.setCreateTime(new Date());
        frontCardTransferOperation.setTransferTime(new Date());
        int result = frontCardTransferOperationService.addCardTransferOperationRecord(frontCardTransferOperation);
        if (result <= 0){
            logger.info("<==  新增卡转账操作记录失败");
            return ReturnResult.error("新增卡转账操作记录失败");
        }
        logger.info("<==  新增卡转账操作记录成功");
        return ReturnResult.success("新增卡转账操作记录成功");
    }

}
