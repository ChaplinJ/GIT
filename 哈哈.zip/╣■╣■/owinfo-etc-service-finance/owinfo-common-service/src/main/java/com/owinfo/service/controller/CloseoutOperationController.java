package com.owinfo.service.controller;

import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.service.CloseoutOperationService;
import com.owinfo.service.util.BeanToMapUtil;
import com.owinfo.service.util.MapRemoveNullUtil;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.Map;

/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 清账、清户、退卡补款资金流向操作记录
 * 创建时间：2017年12月21日
 * <p>
 * 〈一句话功能简述〉清账、清户、退卡补款资金流向操作记录〈功能详细描述〉
 *
 * @author sun
 * @version [版本号, 2017年12月21日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@RestController
@RequestMapping("/closeoutOperation")
@CrossOrigin(maxAge = 3600,origins = "*")
public class CloseoutOperationController {

    @Autowired
    private CloseoutOperationService closeoutOperationService;
    private static Logger logger = Logger.getLogger(CloseoutOperationController.class);
    /**
     * 新增退卡补款记录
     * 新增清账记录
     * 新增清户记录
     * @param params
     * @return
     */
    @PostMapping("/addOperation")
    public int addOperation(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法addAccountRecord的参数::" + params);
        FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
        MapRemoveNullUtil.removeNullEntry(params);
        try {
            BeanToMapUtil.convertMap(params,frontBillingRecord);
        } catch (IntrospectionException e) {
            logger.error("<==  解析失败" + e.getMessage());
            return 0;
        } catch (IllegalAccessException e) {
            logger.error("<==  解析失败" + e.getMessage());
            return 0;
        } catch (InvocationTargetException e) {
            logger.error(e.getMessage());
            return 0;
        }
        frontBillingRecord.setId(UUIDUtils.getUUID());
        frontBillingRecord.setOperationTime(new Date());
        return closeoutOperationService.addOperation(frontBillingRecord);
    }
}
