package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.service.CorrectDedutionervice;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.core.service.FrontRechargeOperationService;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import com.owinfo.service.util.ValidateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月30日
 *         github : https://github.com/rexlin600/
 * @Description  冲正扣款
 */
@RestController
@RequestMapping("/correctDedution")
@CrossOrigin(maxAge = 3600,origins = "*")
public class CorrectDedutionController {

    private static final Logger logger = Logger.getLogger(CorrectDedutionController.class);

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @Autowired
    private CorrectDedutionervice correctDedutionervice;

    /**
    * @description 冲正信息校验
    * @author hekunlin 2018/1/30 22:22 Version 1.2
    * @param
    * @return 
    */
    @PostMapping("/validateCorrectDedution")
    public Map<String,Object> validateCorrectDedution(@RequestBody Map<String,Object> params){
        logger.info("<==  方法validateCorrectDedution的参数::" + params + "   开始执行");

        // region 冲正类型
        String certificateNumber = null;
        String cardId = null;
        int accountStatus = (int) params.get("accountStatus");
        // endregion

        FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
        Etcclientinfo etcclientinfo = new Etcclientinfo();

        // region 用户账户冲正
        if (accountStatus == 0){
            certificateNumber = (String) params.get("certificateNumber");
            if (StringUtils.isEmpty(certificateNumber)){
                logger.error("<==  用户账户[" + certificateNumber +"]冲正，证件编号不能为空");
                return ReturnResult.errors("证件编号不能为空");
            }
            logger.info("<==  用户账户[" + certificateNumber + "]冲正");

            // region 用户信息、最新的账单记录
            etcclientinfo = new Etcclientinfo();
            etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  证件编号[" + certificateNumber + "]不是个人用户");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<==  证件编号[" + certificateNumber + "]未找到对应的用户信息");
                    return ReturnResult.errors("未找到对应的用户信息");
                }
            }
            // 获取最新的充值账单记录
            Map<String,Object> tempMap = new HashMap<>();
            // 20180131修正获取冲正记录
            String spare = etcclientinfo.getSpare();
            tempMap.put("certificateNumber",spare);
            // 获取这证件编号对应的唯一标识
            frontBillingRecord = frontBillingRecordService.validateCorrectDedution(tempMap);
            if (frontBillingRecord == null){
                logger.error(" <-- 不存在最新的交易记录或最新交易记录充值方式不是现金/POS/转账");
                return ReturnResult.error("最新的账单记录不是充值");
            }
            // endregion

            // region 冲正站点限制和冲正时间限制、验证
            String originalSiteName = frontBillingRecord.getSiteName();
            String nowSiteName = getParams(params.get("siteName"));
            int rechargeType = frontBillingRecord.getRechargeType();

            //使用转账、电商、卡卷，是不能冲正的
            if(2 == rechargeType || 3 == rechargeType || 4 == rechargeType){
                logger.error("使用转账、电商、卡卷不能冲正");
                return ReturnResult.error("使用转账、电商、卡卷不能冲正");
            }
            if (!originalSiteName.equals(nowSiteName)){
                logger.error("<== 必须在原站点进行冲正");
                return ReturnResult.error("请在  "+ originalSiteName +"  进行冲正");
            }
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String originalDate = sdf.format(frontBillingRecord.getOperationTime());
            Date originalOperationDate = null;
            String effectiveDate  = null;
            try {
                originalOperationDate = sdf.parse(originalDate);
                effectiveDate = sdf.format(new Date());
            } catch (Exception e) {
                logger.error("<==  日期解析失败,无法冲正" + e.getMessage());
                return ReturnResult.error("冲正失败,请联系管理员");
            }
            // 使用LocalDate来比较
            LocalDate operationDate = ZonedDateTime.ofInstant(originalOperationDate.toInstant(),
                    ZoneId.systemDefault()).toLocalDate();
            LocalDate nowDate = ZonedDateTime.ofInstant(new Date().toInstant(),ZoneId.systemDefault()).toLocalDate();
            logger.info("<==  上次充值时间=" + originalDate);
            logger.info("<==  冲正时间=" + effectiveDate);
            boolean flag = operationDate.isEqual(nowDate);
            if (!flag){
                logger.error("<== 无法冲正，两个日期不再同一天");
                return ReturnResult.error("无法冲正,已超过时间限制");
            }
            logger.info("<==  验证通过,允许冲正");
            // endregion

            // region 数据库用户账户余额应该 = 冲正扣款记录中用户账户余额 + 充值金额
            int lastBalance = frontBillingRecord.getPreOperationBalance();
            int rechargeBalance = frontBillingRecord.getOperationAmount();

            // 如果允许冲正，原账户应有余额
            lastBalance = lastBalance + rechargeBalance;

            // 获取该账户的最新账户余额
            Double temp1 = etcclientinfo.getAccountBalance().doubleValue();
            int accountBalance = (int)(temp1 * 100);
            logger.info(" <-- 冲正前用户账户余额[" + accountBalance + "]，单位分");

            // 当前账户余额应该 = 最新记录账户余额 + 充值金额
            int isCorrectResult = accountBalance - lastBalance;
            if (isCorrectResult < 0){
                logger.info(" <-- 产生了消费,无法冲正");
                return ReturnResult.error("不可重复冲正,冲正失败");
            }
            if (isCorrectResult > 0){
                logger.error(" <-- 最新交易记录充值方式不是现金/POS/转账,冲正失败");
                return ReturnResult.error("最新交易记录不是现金/POS/转账充值,冲正失败");
            }
            // endregion

        }
        // endregion

        // region 卡账户冲正
        if (accountStatus ==1){
            cardId = (String) params.get("cardId");
            if (StringUtils.isEmpty(cardId)){
                logger.error("<==  卡账户卡号[" + cardId +"]冲正，卡号不能为空");
                return ReturnResult.errors("卡号不能为空");
            }
            logger.info("<==  卡账户[" + cardId + "]冲正");

            // region 用户信息、卡信息、最新的账单记录
            Etccardinfo etccardinfo = cardMapper.getCard(cardId);
            if (etccardinfo == null){
                logger.error("<==  卡号[" + cardId + "]冲正未查到对应的卡信息");
                return ReturnResult.errors("未找到卡号对应的信息");
            }
            String spare = etccardinfo.getSpare();

            etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.error("<==  证件唯一标识[" + spare + "]未找到对应的用户信息");
                return ReturnResult.errors("未找到对应的用户信息");
            }
            String clientType = etccardinfo.getClientType();
            if ("1".equals(clientType)){
                etccardinfo.setCertificateNumber(etcclientinfo.getCertificateNumber());
            }
            if ("2".equals(clientType)){
                etccardinfo.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            }
            etccardinfo.setClientType(etcclientinfo.getClientType());
            etccardinfo.setClientName(etcclientinfo.getClientName());
            etccardinfo.setClientNo(etcclientinfo.getSpare());

            // 获取最新的充值账单记录
            Map<String,Object> tempMap = new HashMap<>();
            tempMap.put("accountSubjectNo",etccardinfo.getCardId());
            frontBillingRecord = frontBillingRecordService.validateCorrectDedutions(tempMap);
            if (frontBillingRecord == null){
                logger.error(" <-- 不存在最新的交易记录或最新交易记录充值方式不是现金/POS/转账");
                return ReturnResult.error("最新的账单记录不是充值");
            }
            // endregion
            int rechargeType = frontBillingRecord.getRechargeType();

            //卡充值使用电商、卡卷不能冲正
            if(2 == rechargeType || 3 == rechargeType || 4 == rechargeType){
                logger.error("卡充值使用电商、卡卷不能冲正");
                return ReturnResult.error("卡充值使用电商、卡卷不能冲正");
            }

            // region 冲正站点限制和冲正时间限制、验证
            String originalSiteName = frontBillingRecord.getSiteName();
            String nowSiteName = ParamClassUtils.getParams(params.get("siteName"));
            if (!originalSiteName.equals(nowSiteName)){
                logger.error("<== 必须在原站点进行冲正");
                return ReturnResult.error("请在  "+ originalSiteName +"  进行冲正");
            }
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String originalDate = sdf.format(frontBillingRecord.getOperationTime());
            Date originalOperationDate = null;
            String effectiveDate  = null;
            try {
                originalOperationDate = sdf.parse(originalDate);
                effectiveDate = sdf.format(new Date());
            } catch (Exception e) {
                logger.error("<==  日期解析失败,无法冲正" + e.getMessage());
                return ReturnResult.error("冲正失败,请联系管理员");
            }
            // 使用LocalDate来比较
            LocalDate operationDate = ZonedDateTime.ofInstant(originalOperationDate.toInstant(), ZoneId.systemDefault()).toLocalDate();
            LocalDate nowDate = ZonedDateTime.ofInstant(new Date().toInstant(),ZoneId.systemDefault()).toLocalDate();
            logger.info("<==  上次充值时间=" + originalDate);
            logger.info("<==  冲正时间=" + effectiveDate);
            boolean flag = operationDate.isEqual(nowDate);
            if (!flag){
                logger.error("<== 无法冲正，两个日期不再同一天");
                return ReturnResult.error("无法冲正,已超过时间限制");
            }
            logger.info("<==  验证通过,允许冲正");
            // endregion

            // region 数据库用户账户余额应该 = 冲正扣款记录中用户账户余额 + 充值金额
            int lastBalance = frontBillingRecord.getPreOperationBalance();
            int rechargeBalance = frontBillingRecord.getOperationAmount();

            // 如果允许冲正，原账户应有余额
            lastBalance = lastBalance + rechargeBalance;
            // 数据库中账户当前的账户余额
            Double temp1 = etccardinfo.getCardAccountBalance().doubleValue();
            int cardBalance = (int)(temp1 * 100);
            // 当前账户余额应该 = 最新记录账户余额 + 充值金额
            int isCorrectResult = cardBalance - lastBalance;
            if (isCorrectResult < 0){
                logger.error(" <-- 最新记录不是充值或产生了消费或已冲正过,无法冲正");
                return ReturnResult.error("不可重复冲正,冲正失败");
            }
            if (isCorrectResult > 0){
                logger.error("<-- 最新交易记录充值方式不是现金/POS/转账,冲正失败");
                return ReturnResult.error("最新交易记录不是现金/POS/转账充值,冲正失败");
            }
            // endregion
        }
        // endregion

        // region 用户信息修正
        frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        String clientType = etcclientinfo.getClientType();
        if ("1".equals(clientType)){
            frontBillingRecord.setCertificateNumber(etcclientinfo.getCertificateNumber());
            frontBillingRecord.setClientName(etcclientinfo.getClientName());
        }
        if ("2".equals(clientType)){
            frontBillingRecord.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            frontBillingRecord.setClientName(etcclientinfo.getUnitName());
        }
        logger.info(" <-- 获取冲正信息成功=" + frontBillingRecord.toString());
        Map<String, Object> data = new HashMap<>();
        data.put("data",frontBillingRecord);
        data.put("msg","获取冲正数据成功");
        data.put("status",1);
        // endregion

        logger.info("<==  方法validateCorrectDedution执行结束");
        return data;
    }


    /**
     * 冲正扣款
     * @param params
     * @return
     */
    @PostMapping("/correctDeduction")
    public Map<String,Object> correctDeduction(@RequestBody Map<String,Object> params){
        logger.info("<==  方法correctDeduction的参数::" + params + "   开始执行");

        // 冲正类型
        int accountStatus = (int) params.get("accountStatus");
        Date date = new Date();

        // region 冲正金额校验
        int operationAmount = Integer.parseInt(ParamClassUtils.getParams(params.get("operationAmount")));
        Double correctAmount = Double.valueOf(operationAmount*0.01);
        BigDecimal correctBalance = new BigDecimal(String.valueOf(correctAmount));
        if (ValidateUtils.isEmpty(correctBalance)){
            logger.error(" <-- 冲正金额不能为空");
            return ReturnResult.errors("冲正失败,请填写冲正金额");
        }
        // endregion

        // region 新增冲正操作记录
        FrontRechargeOperation correctOperation = new FrontRechargeOperation();
        correctOperation.setId(UUIDUtils.getUUID());
        correctOperation.setTradeNum((String) params.get("tradeNum"));
        correctOperation.setChannelType((String) params.get("channelType"));
        correctOperation.setChannelName((String) params.get("channelName"));
        correctOperation.setChannelNum((String) params.get("channelNum"));
        correctOperation.setEmployeeNo((String) params.get("employeeNo"));
        correctOperation.setSiteName((String) params.get("siteName"));
        correctOperation.setCreateBy((String) params.get("employeeNo"));
        if (accountStatus == 0){
            correctOperation.setCertificateNumber((String) params.get("certificateNumber"));
//            correctOperation.setCardId((String) params.get("cardId"));
//        correctOperation.setClientNo();
//        correctOperation.setClientName();
//        correctOperation.setClientType();
            correctOperation.setOperationType(1);
            correctOperation.setRechargeType(Integer.valueOf(ParamClassUtils.getParams(params.get("rechargeType"))));
//        correctOperation.setRechargeNum();
//        correctOperation.setAccountBalance();
//        correctOperation.setPaidAmount();
//        correctOperation.setGiftAmount();
//        correctOperation.setRechargeAmount();
//        correctOperation.setAmountUpper();
            correctOperation.setTradeTime(date);
//        correctOperation.setCorrectReason();
            correctOperation.setRemove(0);
            frontRechargeOperationService.addRechargeOperationRecord(correctOperation);
        }
        if (accountStatus == 1){
            //        correctOperation.setCertificateNumber();
            correctOperation.setCardId((String) params.get("cardId"));
//        correctOperation.setClientNo();
//        correctOperation.setClientName();
//        correctOperation.setClientType();
            correctOperation.setOperationType(3);
            correctOperation.setRechargeType(Integer.valueOf(ParamClassUtils.getParams(params.get("rechargeType"))));
//        correctOperation.setRechargeNum();
//        correctOperation.setAccountBalance();
//        correctOperation.setPaidAmount();
//        correctOperation.setGiftAmount();
//        correctOperation.setRechargeAmount();
//        correctOperation.setAmountUpper();
            correctOperation.setTradeTime(date);
//        correctOperation.setCorrectReason();
            correctOperation.setRemove(0);
            frontRechargeOperationService.addRechargeOperationRecord(correctOperation);
        }
        // endregion

        logger.info("<==  方法correctDeduction执行结束");
        return correctDedutionervice.correctDeduction(params);
    }

}
