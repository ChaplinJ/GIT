//package com.owinfo.service.controller;
//
//import com.owinfo.object.entity.EtcCardQuancunReq;
//import com.owinfo.object.entity.FrontTransferenceOperation;
//import com.owinfo.service.core.mapper.FrontTransferenceOperationMapper;
//import com.owinfo.service.util.EncryptorUtils;
//import com.owinfo.service.util.ReturnResult;
//import com.owinfo.service.util.ValidateUtils;
//import org.apache.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.math.BigDecimal;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//
///**
// * Created by admin on 2018/1/15.
// */
//@RestController
//@RequestMapping("/etcCard")
//public class EtcCardController {
//
//
//    private static final Logger logger = Logger.getLogger(EtcCardController.class);
//
//    @Autowired
//    private FrontTransferenceOperationMapper frontTransferenceOperationMapper;
//    /*
//    cardinfo            00000000     0000    02    00    7E64DDAC    9C670709
//    16进制
//    cardId
//
//    return
//
//     field
//     amount  需要圈存的金额
//     flag 是否需要补圈
//     卡账户信息
//     */
//    @RequestMapping(value="/quancunQuery",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
//    public Map<String, Object> quancunQuery(@RequestBody EtcCardQuancunReq etcCardQuancunReq){
//
//        Map<String,Object> result = new HashMap<>();
//        result.put("code","0000");
//        result.put("field","");
//        result.put("amount",null);
//        result.put("flag",null);
//        //1.校验数据格式
//
//
//        //2.上次交易的验证和处理，onlineSn-1的处理，补圈存半条的完成记录，
//        String onlineSn = etcCardQuancunReq.getCardInfo().substring(8,12);
//
//        if(!"0000".equals(onlineSn)){    //如果不是第一次圈存，则需要验证onlineSn-1与圈存记录表
//            //比较大小，如果不存在，则
//            //根据onlineSn-1去查询数据库最新的一条圈存记录
//            FrontTransferenceOperation frontTransferenceOperation = new FrontTransferenceOperation();
//            Map<String,Object> query = new HashMap<>();
//            query.put("onlineSn",Integer.parseInt(onlineSn,16)-1);
//            query.put("cardId",etcCardQuancunReq.getCardId());
//            frontTransferenceOperation = frontTransferenceOperationMapper.getLastTransferOperationBySnAndCardId(query);
//
//            //获取上一次圈存记录
//            //校验是否需要补全，如果查询结果状态     operation_status    0未完成，1完成
//
//            if(frontTransferenceOperation == null){    //如果onlineSn不是0000，并且还查询不到圈存记录，则是异常
//                result.put("code","0001");//异常
//                result.put("field","如果onlineSn不是0000，并且还查询不到圈存记录，则是异常");
//                result.put("flag",null);
//                return  result;
//            }
//
//            if("0".equals(frontTransferenceOperation.getOperationStatus())){  //如果查询有，并且状态为失败，则需要补圈存，则需要告诉页面补圈金额和补圈存状态
//
//                result.put("field","如果查询有，并且状态为失败，则需要补圈存，且需要告诉页面补圈金额和补圈存状态");
//                result.put("code","0010");
//                result.put("flag","1");
//                result.put("amount",frontTransferenceOperation.getOperationMoney());
//                return  result;
//
//            }
//
//            if("1".equals(frontTransferenceOperation.getOperationStatus())){   //如果查询有，且状态为成功，则不需要补圈存，告诉页面不需要补圈，然后返回卡信息金额
//
//                Map<String,Object> queryCard = new HashMap<>();
//                queryCard.put("cardId",frontTransferenceOperation.getCardNo());
//                try {
//                    queryCard = frontTransferenceOperationMapper.queryCard(queryCard);
//                    if(queryCard == null){
//
//                        result.put("field","根据卡号查询卡信息失败");
//                        result.put("code","0012");
//                        result.put("amount",null);
//                        result.put("flag",null);
//                        return result;
//
//                    }else{
//                        result.put("flag","0");
//                        result.put("field","如果查询有，且状态为成功，则不需要补圈存，告诉页面不需要补圈，然后返回卡信息金额");
//                        result.put("code","0013");
//                        //返回单位分
//                        result.put("amount",0+new BigDecimal(String.valueOf(queryCard.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue());
//                        return result;
//                    }
//
//                }catch(Exception e){
//                    System.out.println("数据库里有同卡号的数据！！！！！");
//                    result.put("amount",null);
//                    result.put("code","0014");
//                    result.put("field","数据库里有同卡号的数据！！！！！");
//                    result.put("flag",null);
//                    return  result;
//                }
//
//            }
//
//        }
//
//                 //如果是第一次圈存，则返回圈存金额与圈存状态
//        Map<String,Object> queryOneCard = new HashMap<>();
//        queryOneCard.put("cardId",etcCardQuancunReq.getCardId());
//        if(queryOneCard == null){
//
//            result.put("field","根据卡号查询卡信息失败");
//            result.put("code","0012");
//            result.put("amount",null);
//            result.put("flag",null);
//            return result;
//
//        }else{
//            result.put("code","0015");
//            result.put("amount",0+new BigDecimal(String.valueOf(queryOneCard.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue());
//            result.put("flag","0");
//            result.put("field","第一次圈存，查询卡信息成功，返回金额");
//            return result;
//        }
//
//        //3.查询本次交易是否需要补圈，如果需要补全，返回补圈金额和补圈状态
//
//        //4.查询返回卡账户信息
//
//    }
//
//
//
//    /*
//
//        cardId:_this.baseInfo.cardId,
//        cardInfo: this.cardInfo_end,
//        amount:_this.back_money,
//        flag:_this.flag
//
//     */
//
//    @RequestMapping(value="/quancunCmd",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
//    public Map<String, Object> quancunCmd(@RequestBody EtcCardQuancunReq etcCardQuancunReq){
//
//        Map<String,Object> result = new HashMap<>();
//        result.put("code","0000");
//        result.put("field","");
//
//        //验证a014
//        boolean flag = EncryptorUtils.a014(etcCardQuancunReq.getCardId(),etcCardQuancunReq.getAmount(),etcCardQuancunReq.getCardInfo(),"00000000000110");
//        // 测试新增记录、测试手动让其通过
////        boolean flag = true;
//        logger.info(" <-- A014验证MAC结果 " + flag);
//        if (!flag){
//            logger.error(" <-- A014验证失败 flag =" + flag);
//            return ReturnResult.error("圈存失败,A014验证失败");
//        }
//
//        //验证卡内余额
//
//        Map<String,Object> queryCard = new HashMap<>();
//        queryCard.put("cardId",etcCardQuancunReq.getCardId());
//
//        try {
//            queryCard = frontTransferenceOperationMapper.queryCard(queryCard);
//        }catch(Exception e){
//            result.put("code","0001");
//            result.put("field","数据库有同名卡");
//            return result;
//        }
//
//        //查询卡信息失败
//        if(queryCard==null){
//            result.put("code","0002");
//            result.put("field","查询卡信息失败");
//            return result;
//        }
//
//        //先判断补写状态，如果为补圈，则从圈存记录取值，如果不是，再判断卡账户余额
////        if(r)
//
//
//
//        //如果为无需补圈
//    if("1".equals(etcCardQuancunReq.getFlag())) {   //提取到service   非补圈
//        //卡账户余额不足
//        Integer cardAccountBalance = 0 + new BigDecimal(String.valueOf(queryCard.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue();
//        if (etcCardQuancunReq.getAmount() - cardAccountBalance > 0) {
//            result.put("code", "0003");
//            result.put("field", "卡账户余额不足");
//            return result;
//        }
//
//        //扣钱
//        Map<String, Object> updateAccountBalance = new HashMap<>();
//        updateAccountBalance.put("cardId", etcCardQuancunReq.getCardId());
//        updateAccountBalance.put("cardAccountBalance", etcCardQuancunReq.getAmount());
//        Integer i = frontTransferenceOperationMapper.updateAccountBalance(updateAccountBalance);
//
//        if (i != 1) {
//            result.put("code", "0004");
//            result.put("field", "圈存失败，卡账户扣款失败");
//            return result;
//        }
//
//        // 插入圈存初始化记录
//        //插入账单表-圈存
//
//        Map<String, Object> queryBackCard = new HashMap<>();
//        queryBackCard.put("cardId", etcCardQuancunReq.getCardId());
//        queryBackCard = frontTransferenceOperationMapper.queryCard(queryBackCard);
//        if ((0 + new BigDecimal(String.valueOf(queryCard.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue()) < 0) {
//            result.put("code", "0005");
//            result.put("field", "扣多了");
//            return result;
//        }
//
//        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
//        Date date = new Date();
//        String optDateTime = dateFormat.format(date);
//        String cmd  = getShsmk(etcCardQuancunReq.getCardId(),cardAccountBalance,etcCardQuancunReq.getCardInfo(),"000000000001",optDateTime);
//
//        result.put("code","999999999");
//        result.put("field","圈存指令获取成功");
//        //返指令
//        result.put("cmd",cmd);
//        return  result;
//
//    }else{
//
//            //从圈存记录表查需要圈存的金额，查询onlineSn+cardId+传过来金额+表里的金额+无完成记录
//        //算指令
//        Integer amount = etcCardQuancunReq.getAmount();
//        Map<String,Object> queryOperation = new HashMap<>();
//        queryOperation.put("cardId",etcCardQuancunReq.getCardId());
//        queryOperation.put("onlineSn",Integer.parseInt(etcCardQuancunReq.getCardInfo().substring(8,12),16)-1);
//
//        FrontTransferenceOperation frontTransferenceOperation = new FrontTransferenceOperation();
//        frontTransferenceOperation = frontTransferenceOperationMapper.getLastTransferOperationBySnAndCardId(queryOperation);
//
////        if(frontTransferenceOperation.get)
//
//
//
//    }
//
//
//
//
//        result.put("code","999999999");
//        result.put("field","圈存指令获取成功");
//        //返指令
//        result.put("cmd",getCmd(etcCardQuancunReq,));
//        return  result;
//
//
//    }
//
//
//    /**
//     * onlineSn
//     * cardId
//     * flag
//     * @param etcCardQuancunReq
//     * @return
//     */
//    @RequestMapping(value="/backOverGG",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
//    public Map<String, Object> backOverGG(@RequestBody EtcCardQuancunReq etcCardQuancunReq){
//
//
//        //更新圈存记录表
//        return null;
//    }
//
//    public static String getCmd(EtcCardQuancunReq etcCardQuancunReq,Integer cardAccountBalance){
//        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
//        Date date = new Date();
//        String optDateTime = dateFormat.format(date);
//        return getShsmk(etcCardQuancunReq.getCardId(),cardAccountBalance,etcCardQuancunReq.getCardInfo(),"000000000001",optDateTime);
//    }
//
//    public  static String getShsmk(String cardNo,Integer amount,String cardInfo,String terminalNo,String optDateTime){
//        logger.info(" --> 方法getShsmk的参数::" + cardNo + amount + cardInfo + terminalNo + optDateTime);
//        // 8：A015申请MAC
//        //20位卡号、充值金额（分）、卡信息、终端编号、当前时间
//        String shsmk = EncryptorUtils.a015(cardNo,amount,cardInfo,terminalNo,optDateTime);
//        if (ValidateUtils.isEmpty(shsmk)) {
//            logger.error(" <-- A015申请MAC失败");
//            return "";
//        }
//        // 9：加指令 8052 + ...
//        shsmk = "805200000B" + optDateTime + shsmk + "04";
//        logger.info(" <-- 圈存发送数据=" + shsmk);
//        // 10：返回SHSMK
//        return shsmk;
//    }
//
//
//
//
//
//}
