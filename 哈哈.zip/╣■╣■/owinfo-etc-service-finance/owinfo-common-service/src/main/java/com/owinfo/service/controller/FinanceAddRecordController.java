package com.owinfo.service.controller;

import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月18日
 *         github : https://github.com/rexlin600/
 * @Description 前台资金管理--账户、卡充值；冲正扣款；补交收款；
 *                             圈存；资金点对点、批量分配；卡转账等服务
 */
@RestController
@RequestMapping("/finance/front/business")
@CrossOrigin(maxAge = 3600,origins = "*")
public class FinanceAddRecordController {

    private static Logger logger = Logger.getLogger(FinanceAddRecordController.class);

    private static final String FIRST = "1";

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    /**
     * 用户账户、卡账户充值、冲正扣款、补交收款、
     * 圈存、资金点对点分配、资金批量分配、卡转账
     * 统一新增记录接口
     * @param params
     * @return
     */
    @PostMapping("/addAccountRecord")
    public int addAccountRecord(@RequestBody Map<String,Object> params) throws ParseException {
        logger.info(" --> 方法addAccountRecord的参数::" + params);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
        int addRecordStatus = Integer.parseInt(ParamClassUtils.getParams(params.get("addRecordStatus")));
        MapRemoveNullUtil.removeNullEntry(params);
        try {
            BeanToMapUtil.convertMap(params,frontBillingRecord);
        } catch (IntrospectionException e) {
            logger.error("<==  解析失败" + e.getMessage());
            return 0;
        } catch (IllegalAccessException e) {
            logger.error("<==  解析失败" + e.getMessage());
            return 0;
        } catch (InvocationTargetException e) {
            logger.error("<==  解析失败" + e.getMessage());
            return 0;
        }
        /**
         * 用户账户充值
         */
        if (addRecordStatus == 0 ){
            frontBillingRecord.setAccountSubject(1); // 1 用户账户
            frontBillingRecord.setAccountSubjectNo(ParamClassUtils.getParams(params.get("clientNo")));
            frontBillingRecord.setAccountSubjectStatus(1); // 1 账号状态 正常
            frontBillingRecord.setOperationType(1); // 1 充值
            frontBillingRecord.setOperationMark(1); // 1 加
            Double preAmount = Double.parseDouble(ParamClassUtils.getParams(params.get("etcAccountBalance")));
            Double operationAmount = Double.parseDouble(ParamClassUtils.getParams(params.get("chargeAmount")));
            int preOperationBalance = (int)(preAmount * 100);
            int operationAmountBalance = (int)(operationAmount * 100);
            int SufAmountBalance = preOperationBalance + operationAmountBalance;
            frontBillingRecord.setPreOperationBalance(preOperationBalance);
            frontBillingRecord.setOperationAmount(operationAmountBalance);
            frontBillingRecord.setSufOperationBalance(SufAmountBalance);
            frontBillingRecord.setOperationTime(new Date());
        }
        /**
         * 卡账户充值
         */
        if (addRecordStatus == 1 ){
            BigDecimal etcCardAmountBalance = new BigDecimal(ParamClassUtils.getParams(params.get("etcCardAmountBalance")));
            BigDecimal etcCardBalance = new BigDecimal(ParamClassUtils.getParams(params.get("etcCardBalance")));
            BigDecimal chargeAmount = new BigDecimal(ParamClassUtils.getParams(params.get("chargeAmount")));
            frontBillingRecord.setAccountSubject(2); // 2 卡账户
            frontBillingRecord.setAccountSubjectNo(ParamClassUtils.getParams(params.get("cardId")));
            frontBillingRecord.setAccountSubjectStatus(1); // 1 账号状态 正常
            frontBillingRecord.setOperationType(1); // 1 充值
            frontBillingRecord.setOperationMark(1); // 1 加
            Double preAmount = Double.parseDouble(ParamClassUtils.getParams(params.get("cardAccountBalance")));
            Double operationAmount = Double.parseDouble(ParamClassUtils.getParams(params.get("chargeAmount")));
            int preOperationBalance = (int)(preAmount * 100);
            int operationAmountBalance = (int)(operationAmount * 100);
            int SufAmountBalance = preOperationBalance + operationAmountBalance;
            frontBillingRecord.setPreOperationBalance(preOperationBalance);
            frontBillingRecord.setOperationAmount(operationAmountBalance);
            frontBillingRecord.setSufOperationBalance(SufAmountBalance);
            frontBillingRecord.setOperationTime(new Date());
        }
        /**
         * 冲正
         */
        if (addRecordStatus == 2 ){
            frontBillingRecord.setOperationMark(2);
            frontBillingRecord.setOperationType(2);
            frontBillingRecord.setOperationTime(new Date());
        }
        /**
         * 补交收款
         */
        if (addRecordStatus == 3 ){
            frontBillingRecord.setOperationTime(new Date());
        }
        /**
         * 圈存
         */
        if (addRecordStatus == 4 ){
            // 参数处理在biz层
            Date date = dateFormat.parse(ParamClassUtils.getParams(params.get("operationTime")));
            frontBillingRecord.setOperationTime(date);
        }
        /**
         * 资金点对点分配
         */
        if (addRecordStatus == 5 ){
            // 参数处理在biz层
            Date date = dateFormat.parse(ParamClassUtils.getParams(params.get("operationTime")));
            frontBillingRecord.setOperationTime(date);
        }
        /**
         * 资金批量分配
         */
        if (addRecordStatus == 6 ){
            // 参数处理在biz层  1-21 晚 ZZG修改
            Date date = new Date();
            if(params.get("operationTime") != null){
                date = dateFormat.parse(ParamClassUtils.getParams(params.get("operationTime")));
            }else if(params.get("pointTransferMap") != null){
                date = dateFormat.parse(ParamClassUtils.getParams(params.get("pointTransferMap")));
            }
            frontBillingRecord.setOperationTime(date);
        }
        /**
         * 卡转账
         */
        if (addRecordStatus == 7 ){
            // 参数处理在biz层
            Date date = dateFormat.parse(ParamClassUtils.getParams(params.get("operationTime")));
            frontBillingRecord.setOperationTime(date);
        }
        /**
         * 银行充值
         */
        if (addRecordStatus == 8){
            // 参数处理在biz层
            frontBillingRecord.setOperationTime(new Date());
        }
        // 其他参数
        frontBillingRecord.setId(UUIDUtils.getUUID());
        frontBillingRecord.setOperationUser(ParamClassUtils.getParams(params.get("createBy")));
        frontBillingRecord.setEmployeeNo(ParamClassUtils.getParams(params.get("employeeNo")));
        frontBillingRecord.setCreateBy(ParamClassUtils.getParams(params.get("createBy")));
        if (addRecordStatus == 0 || addRecordStatus == 1){ // 充值
            frontBillingRecord.setRechargeType(Integer.parseInt(ParamClassUtils.getParams(params.get("chargeType")))); // 充值方式
        }
        if (addRecordStatus == 2){ // 冲正
            frontBillingRecord.setRechargeType(Integer.parseInt(ParamClassUtils.getParams(params.get("rechargeType")))); // 充值方式
        }
        frontBillingRecord.setRemove(0);
        // 执行插入操作 result:新增结果 0 失败 1 成功
        int result = frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
        if (result <= 0){
            logger.error(" <-- 新增交易记录失败,执行结果result=" + result);
            return 0;
        }
        logger.info(" <-- 新增交易记录成功");
        return 1;
    }

    /**
     * 验证证件号获取用户账户最新的一条记录并且是充值--用户账户冲正
     * @param params
     * @return
     */
    @PostMapping("validateCorrectDedution")
    public Map<String,Object> validateCorrectDedution(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validateCorrectDedution的参数::" + params);
        Map<String,Object> map = new HashMap<>(3);
        Map<String,Object> map2 = new HashMap<>(3);
        String certificateNumber = (String) params.get("certificateNumber");
        map.put("certificateNumber",certificateNumber);
        /**
         * 获取交易记录
         */
        FrontBillingRecord frontBillingRecord = frontBillingRecordService.validateCorrectDedution(map);
        if (ValidateUtils.isEmpty(frontBillingRecord)){
            logger.error(" <-- 不存在最新的一条交易记录,无法冲正");
            return ReturnResult.error("冲正失败,不需要冲正");
        }
        /**
         * 判断交易类型是否为充值
         */
        String operationType = ParamClassUtils.getParams(frontBillingRecord.getOperationType());
        if (!FIRST.equals(operationType)){
            logger.error(" <-- 冲正失败,最新交易类型不是充值");
            return ReturnResult.error("冲正失败,最新交易类型不是充值");
        }
        /**
         * 返回最新的用户账户充值记录
         */
        map2.put("etcTransactionDetail",frontBillingRecord);
        return ReturnResult.successResult("获取交易记录成功",map2);
    }

    /**
     * 验证证件号获取用户账户最新的一条记录并且是充值---ETC卡账户冲正
     * @param params
     * @return
     */
    @PostMapping("validateCorrectDedutions")
    public Map<String,Object> validateCorrectDedutions(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validateCorrectDedutions的参数::" + params);
        Map<String,Object> map = new HashMap<>(3);
        Map<String,Object> map2 = new HashMap<>(3);
        /**
         * 获取用户证件编号
         * 调取资金管理服务接口获取用户最新的一条充值记录(由业务层去判断是什么类型的记录)
         */
        String cardId = (String) params.get("cardId");
        map.put("cardId",cardId);
        FrontBillingRecord frontBillingRecord = frontBillingRecordService.validateCorrectDedutions(map);
        if (ValidateUtils.isEmpty(frontBillingRecord)){
            logger.error(" <-- 不存在最新的一条交易记录,无法冲正");
            return ReturnResult.error("冲正失败,不需要冲正");
        }
        /**
         * 判断交易类型是否为充值
         */
        String operationType = ParamClassUtils.getParams(frontBillingRecord.getOperationType());
        logger.info(" <-- 交易类型为=" + operationType);
        if (!FIRST.equals(operationType)){
            logger.error(" <-- 冲正失败,不需要冲正");
            return ReturnResult.error("冲正失败,不需要冲正");
        }
        logger.info(" <-- 获取待冲正交易记录成功 " + frontBillingRecord );
        map2.put("etcTransactionDetail",frontBillingRecord);
        return ReturnResult.successResult("获取待冲正交易记录成功",map2);
    }


}
