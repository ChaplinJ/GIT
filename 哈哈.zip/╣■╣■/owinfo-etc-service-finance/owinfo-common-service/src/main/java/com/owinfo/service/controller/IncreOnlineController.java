package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.object.entity.MapOnline;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.MapOnlineMapper;
import com.owinfo.service.core.service.FrontRechargeOperationService;
import com.owinfo.service.core.service.IncreRechargeService;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2018年01月22日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/icreOnline")
@CrossOrigin(maxAge = 3600,origins = "*")
public class IncreOnlineController {

    private static final Logger logger = Logger.getLogger(IncreOnlineController.class);

    @Autowired
    private IncreRechargeService increRechargeService;

    @Autowired
    private MapOnlineMapper mapOnlineMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @Autowired
    private CardMapper cardMapper;

    @PostMapping("/increRecharge")
    /**
    * @description 线上渠道增值充值服务
    * @author hekunlin 2018/1/22 13:19 Version 1.0
    * @param [params]
    * @return java.util.Map<java.lang.String,java.lang.Object>
    */
    public Map<String,Object> increRecharge(@RequestBody Map<String, Object> params){
        logger.info("<==  方法increRecharge的参数::" + params + "   开始执行");

        Map<String, Object> errorMap = new HashMap<>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        // region 校验金额
        String totalBalance = ParamClassUtils.getParams(params.get("totalAmount"));
        String giftBalacne = ParamClassUtils.getParams(params.get("giftAmount"));
        String etcBalance = ParamClassUtils.getParams(params.get("etcAmount"));
        if (totalBalance.equals("")){
            totalBalance = "0";
            logger.info("<==  充值总额为空 " + totalBalance);
        }
        if (giftBalacne.equals("")){
            giftBalacne = "0";
            logger.info("<==  赠送总额为空 " + totalBalance);
        }
        if (etcBalance.equals("")){
            etcBalance = "0";
            logger.info("<==  充值金额为空 " + totalBalance);
        }
        // endregion

        // region 获取充值类型、银行编号、卡号并传入校验(去掉多余的0)
        String accountType = String.valueOf(params.get("accountType")).replaceFirst("^0*","");
        int rechargeType = Integer.valueOf(accountType);
        String channelCode = String.valueOf(params.get("channelCode"));
        String channelTransId = String.valueOf(params.get("channelTransId"));
        String channelFinTime = String.valueOf(params.get("channelFinTime"));
        // 充值金额
        int etcAmount = Integer.valueOf(etcBalance);
        int giftAmount = Integer.valueOf(giftBalacne);
        // 相当于amount
        int totalAmount = Integer.valueOf(totalBalance);
        if (((etcAmount + giftAmount) - totalAmount) != 0){
            logger.error("<== 充值金额不等于赠送金额加缴费金额异常 " + ((etcAmount + giftAmount) - totalAmount));
            errorMap.put("stateCode","1111");
            errorMap.put("field","充值金额不等于赠送金额加缴费金额异常,无法充值");
            return errorMap;
        }
        // endregion

        // region 输入参数验证
        if (accountType.isEmpty() || channelCode.isEmpty() || channelTransId.isEmpty() || channelFinTime.isEmpty()){
            logger.error("<== 充值参数存在空值");
            errorMap.put("stateCode","1111");
            errorMap.put("field","请检查充值参数");
            return errorMap;
        }
        // endregion

        // region 渠道网点认证：平安、邮政储蓄
        MapOnline mapOnline = mapOnlineMapper.selectByPrimaryKey(channelCode);
        if (mapOnline == null){
            logger.error("<==  未获取到[" + channelCode + "]对应的渠道相关信息");
            errorMap.put("stateCode","2222");
            errorMap.put("field","未获取到[" + channelCode + "]对应的渠道相关信息");
            return errorMap;
        }
        String dotContactName = null;
        String dotName = null;
        String dotNo = mapOnline.getId();
        String channelName = mapOnline.getName();
        String channelId = mapOnline.getId().substring(0,11);
        if (dotNo.equals("410101020150201")){
            dotContactName = "平安银行";
            dotName = "平安银行郑州市分行";
        }
        if (dotNo.equals("410101020060201")){
            dotContactName = "邮政储蓄";
            dotName = "邮储银行郑州众意西路支行";
        }
        // endregion

        // region 获取交易流水号
        String tradeNumber = (String) params.get("tradeNumber");
        logger.info("<==  本次交易交易流水号为tradeNumber= " + tradeNumber);
        // endregion

        // region 新增充值操作记录
        FrontRechargeOperation frontRechargeOperation = new FrontRechargeOperation();
        frontRechargeOperation.setId(UUIDUtils.getUUID());
        frontRechargeOperation.setTransId(channelTransId);
        frontRechargeOperation.setTradeNum(tradeNumber);
        frontRechargeOperation.setChannelName(channelName);
        frontRechargeOperation.setChannelNum(channelId);
        frontRechargeOperation.setChannelType("3");
        frontRechargeOperation.setSiteName(dotName);
        frontRechargeOperation.setEmployeeNo(dotContactName);
        frontRechargeOperation.setPaidAmount(etcAmount);
        frontRechargeOperation.setGiftAmount(giftAmount);
        frontRechargeOperation.setRechargeAmount(totalAmount);
        frontRechargeOperation.setTradeTime(date);
        // endregion

        // region 卡充值操作记录
        if (rechargeType == 1){
            String cardId = (String) params.get("etcCardId");
            // 校验证件编号是否存在
            if (StringUtils.isEmpty(cardId)){
                logger.error("<== 卡号不能为空");
                errorMap.put("stateCode","1111");
                errorMap.put("field","卡号不能为空");
                return errorMap;
            }
            Etccardinfo etccardinfo = cardMapper.getCard(cardId);
            if (etccardinfo == null){
                logger.error("<==  获取用户信息为空，不允许充值");
                errorMap.put("stateCode","1111");
                errorMap.put("field","未查到该卡片信息");
                return errorMap;
            }
            logger.info("<==  获取卡信息成功 " + etccardinfo.toString());

//            String certificateNumber = etccardinfo.getCertificateNumber();
            String spare = etccardinfo.getSpare();

            Etcclientinfo etcclientinfo = new Etcclientinfo();
            etcclientinfo =  etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.info("<==  唯一标识[" + spare + "]未找到对应的用户信息");
                errorMap.put("stateCode","1111");
                errorMap.put("field","未找到对应的用户信息");
                return errorMap;
            }
            logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());

            // 完善卡充值操作记录 + 执行新增充值操作记录
//            frontRechargeOperation.setCertificateNumber(certificateNumber);
            frontRechargeOperation.setCertificateNumber(etcclientinfo.getSpare());
            frontRechargeOperation.setCardId(cardId);
            frontRechargeOperation.setClientName(etcclientinfo.getClientName());
            frontRechargeOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            frontRechargeOperation.setOperationType(2);
            frontRechargeOperation.setRechargeType(5);
            frontRechargeOperationService.addRechargeOperationRecord(frontRechargeOperation);
            logger.info("<==  新增充值操作记录成功");
        }
        // endregion

        // region 用户账户充值操作记录
        if (rechargeType == 2){
            String certificateNumber = ParamClassUtils.getParams(params.get("etcCertNum"));
            // 校验证件编号是否存在
            if (StringUtils.isEmpty(certificateNumber)){
                logger.error("<== 证件编号不能为空");
                errorMap.put("stateCode","1111");
                errorMap.put("field","证件编号不能为空");
                return errorMap;
            }
            Etcclientinfo etcclientinfo = new Etcclientinfo();
            etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  不是个人客户充值，集团客户充值");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<== 不存在这个用户信息");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","未查到该用户信息");
                    return errorMap;
                }
            }
            logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());
            // 获取用户账户余额、用户证件类型（区别个人和集团）
            String accountBalance = etcclientinfo.getAccountBalance().toString();
//            String accountBalance = String.valueOf(userMap.get("accountBalance"));
            double d3 = Double.valueOf(accountBalance);
            // 计算充值后的账户余额
            int userAccountBalance = (int)(d3*100);
            int laccountnum = userAccountBalance + totalAmount;
            String etcCertNum = certificateNumber;
//            frontRechargeOperation.setCertificateNumber(certificateNumber);
            frontRechargeOperation.setCertificateNumber(etcclientinfo.getSpare());
            String clientType = etcclientinfo.getClientType();
            if (clientType.equals("2")){
                etcCertNum = etcclientinfo.getUnitCertificateNo();
                frontRechargeOperation.setCertificateNumber(etcCertNum);
            }

            // 完善用户账户充值操作记录 + 执行新增充值操作记录
            frontRechargeOperation.setCardId(null);
            frontRechargeOperation.setClientName(etcclientinfo.getClientName());
            frontRechargeOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            frontRechargeOperation.setOperationType(0);
            frontRechargeOperation.setRechargeType(5);
            frontRechargeOperation.setAccountBalance(laccountnum);
            frontRechargeOperationService.addRechargeOperationRecord(frontRechargeOperation);
            logger.info("<==  新增充值操作记录成功");
        }
        // endregion

        logger.info("<==  方法increRecharge执行结束");
        return increRechargeService.increRecharge(params);
    }


}
