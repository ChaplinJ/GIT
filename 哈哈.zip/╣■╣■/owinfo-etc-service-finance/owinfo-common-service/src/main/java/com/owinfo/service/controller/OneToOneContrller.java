package com.owinfo.service.controller;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontAllocationOperation;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.FrontAllocationOperationMapper;
import com.owinfo.service.core.service.OneToOneService;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import com.sun.org.apache.regexp.internal.RE;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月25日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/oneToOne")
@CrossOrigin(maxAge = 3600,origins = "*")
public class OneToOneContrller {

    private static final Logger logger = Logger.getLogger(OneToOneContrller.class);

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private FrontAllocationOperationMapper frontAllocationOperationMapper;

    @Autowired
    private OneToOneService oneToOneService;

    /**
    * @description 点对点分配验证
    * @author hekunlin 2018/1/25 17:27 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/validatePointTransfer")
    public Map<String,Object> validatePointTransfer(@RequestBody Map<String, Object> params){
        logger.info("<==  方法validatePointTransfer的参数::" + params + "   开始执行");

        // region 查询、验证卡号
        String cardId = (String) params.get("cardId");
        if (StringUtils.isEmpty(cardId)){
            logger.error("<==  卡号[" + cardId + "]不能为空");
            return ReturnResult.errors("卡号不能为空");
        }

        Etccardinfo etccardinfo = cardMapper.getCard(cardId);
        if (etccardinfo == null){
            logger.error("<==  未找到卡号[" + cardId + "]对应的卡信息");
            return ReturnResult.errors("未找到该卡号对应的卡片数据");
        }
        if (!etccardinfo.getCardStatus().equals("600202101")){
            logger.error("<==  卡号[" + cardId + "]不正常，不允许点对点分配");
            return ReturnResult.errors("卡状态不正常");
        }
        if (!etccardinfo.getPayType().equals("1")){
            logger.error("<==  记账卡[" + cardId + "]不允许点对点分配");
            return ReturnResult.errors("记账卡不允许点对点分配");
        }
        logger.info("<==  卡号[" + cardId + "]对应的卡片信息=[" + etccardinfo.toString() + "]");
        // endregion

        // region 获取客户信息、余额
        String spare = etccardinfo.getSpare();
        logger.info("<==  待点对点分配卡[" + cardId + "]所属唯一标识[" + spare + "]");
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  卡号[" + cardId + "]对应的唯一标识[" + spare + "]未找到");
            return ReturnResult.errors("未找到该卡片对应的用户信息");
        }
        String clientType = etcclientinfo.getClientType();
        String certificateNumber = null;
        if ("1".equals(clientType)){
            certificateNumber = etcclientinfo.getCertificateNumber();
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
            etccardinfo.setCertificateNumber(etcclientinfo.getCertificateNumber());
            etccardinfo.setClientName(etcclientinfo.getClientName());
            etccardinfo.setClientType(etcclientinfo.getClientType());
        }
        if ("2".equals(clientType)){
            certificateNumber = etcclientinfo.getUnitCertificateNo();
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
            etccardinfo.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            etccardinfo.setClientName(etcclientinfo.getUnitName());
            etccardinfo.setClientType(etcclientinfo.getClientType());
        }
        BigDecimal accountBalance = etcclientinfo.getAccountBalance();
        logger.info("<==  卡号[" + cardId + "]证件编号[" + certificateNumber + "]账户余额[" + accountBalance +
                "]对应的客户信息=[" + etcclientinfo.toString() + "]");
        // endregion

        Map<String, Object> map = new HashMap<>();
        Map<String, Object> data = new HashMap<>();
        map.put("status",1);
        map.put("msg","获取资金点对点信息成功");
        // 客户信息
        data.put("data",etccardinfo);
        data.put("msg","获取成功");
        data.put("status",1);
        data.put("accountBalance",accountBalance);
        map.put("data",data);
        logger.info("<==  方法validatePointTransfer执行结束");
        return map;
    }


    /**
    * @description 点对点分配
    * @author hekunlin 2018/1/25 18:58 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/pointTransfer")
    public Map<String,Object> pointTransfer(@RequestBody Map<String, Object> params){
        logger.info("<==  方法pointTransfer的参数::" + params + "   开始执行");

        Date date = new Date();

        // region 基本参数、卡号、分配金额
        String cardId = (String) params.get("cardId");
        String certificateNumber = (String) params.get("certificateNumber");
        String distributionBalance = getParams(params.get("distributionBalance"));
        BigDecimal distributionBalances = new BigDecimal(distributionBalance);
        // endregion

        // region 卡信息、卡账户余额
        Etccardinfo etccardinfo = cardMapper.getCard(cardId);
        if (etccardinfo == null){
            logger.error("<==  未找到[" + cardId + "]对应的卡片信息");
            return ReturnResult.errors("未找到对应的卡片信息");
        }
        logger.info("<==  点对点分配的卡号[" + cardId + "]对应的卡信息" + etccardinfo);
        BigDecimal cardaccountbalances = etccardinfo.getCardAccountBalance();
        // endregion

        // region 用户信息
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        // 20180129修正证件编号
        String spare = etccardinfo.getSpare();
        if (StringUtils.isEmpty(spare)){
            logger.error("<==  卡号[" + cardId + "]对应的唯一标识[" + spare + "]为空");
            return ReturnResult.errors("未找到对应的用户信息");
        }
        etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  唯一标识[" + spare + "]未找到对应的用户信息");
            return ReturnResult.errors("未找到对应的用户信息");
        }
        String clientType = etcclientinfo.getClientType();
        if ("1".equals(clientType)){
            certificateNumber = etcclientinfo.getCertificateNumber();
        }
        if ("1".equals(clientType)){
            certificateNumber = etcclientinfo.getUnitCertificateNo();
        }
        logger.info("<==  点对点分配证件编号[" + certificateNumber + "]对应的客户信息" + etcclientinfo.toString());
        // endregion

        // region 验证是否支撑分配
        BigDecimal accountBalances = etcclientinfo.getAccountBalance();
        if (accountBalances.compareTo(BigDecimal.ZERO) == -1){
            logger.error("<==  用户账户余额[" + accountBalances + "]小于0，无法分配");
            return ReturnResult.errors("用户余额不足");
        }
        if (accountBalances.compareTo(distributionBalances) == -1){
            logger.error("<==  用户账户余额[" + accountBalances + "]小于将分配的金额[" + distributionBalances + "]，余额不足");
            return ReturnResult.errors("用户余额不足");
        }
        logger.info("<==  卡号[" + cardId + "]允许点对点分配");
        // endregion

        // region 点对点分配操作记录
        FrontAllocationOperation frontAllocationOperation = new FrontAllocationOperation();
        frontAllocationOperation.setId(UUIDUtils.getUUID());
        frontAllocationOperation.setTradeNum((String) params.get("tradeNumber"));
        frontAllocationOperation.setSiteName((String) params.get("siteName"));
        frontAllocationOperation.setCreateBy((String) params.get("createBy"));
        frontAllocationOperation.setEmployeeNo((String) params.get("employeeNo"));
        frontAllocationOperation.setClientNo(etcclientinfo.getClientNo());
        frontAllocationOperation.setClientName(etcclientinfo.getClientName());
        frontAllocationOperation.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        frontAllocationOperation.setAllocationOperation(0);
        Double x = accountBalances.doubleValue();
        Double y = distributionBalances.doubleValue();
        Double z = etccardinfo.getCardBalance().doubleValue();
        frontAllocationOperation.setAccountBalance((int)(x*100));
        frontAllocationOperation.setAllocateAmount((int)(y*100));
        frontAllocationOperation.setAllocateCountAmount((int)(y*100));
        frontAllocationOperation.setCardNo(cardId);
        frontAllocationOperation.setVehicleNo(etccardinfo.getVehicleLicense());
        frontAllocationOperation.setCardBalance((int)(z*100));
        frontAllocationOperation.setTradeTime(date);
        frontAllocationOperation.setCreateTime(date);
        frontAllocationOperationMapper.insertSelective(frontAllocationOperation);
        // endregion

        logger.info("<==  方法pointTransfer执行结束");
        return oneToOneService.pointTransfer(params);
    }

}
