/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月08日
 */
package com.owinfo.service.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.owinfo.object.entity.OrderManage;
import com.owinfo.service.config.annotation.OrderCheckGroups;
import com.owinfo.service.core.service.OrderManageService;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * @author gongchengping
 * @version [v1.0, 2018/03/08]
 * @Description 后台系统--订单/电商管理
 */
@RestController
@RequestMapping("/finance/back/order")
@CrossOrigin(maxAge = 3600, origins = "*")
public class OrderController {

    private static Logger logger = Logger.getLogger(OrderController.class);

    @Autowired
    private OrderManageService orderManageService;

    /**
     * 电商/订单管理--分页查询/模糊查询
     *
     * @param params
     * @return
     */
    @PostMapping("/getOrderList")
    public Map<String, Object> getOrderList(@RequestBody Map<String, Object> params) {
        logger.info(" --> 方法getOrderList的参数::" + params);
        /**
         * 获取电商订单参数验证
         */
        if (ValidateUtils.isEmpty(params)) {
            logger.error("获取电商订单请求参数为空,请检查参数");
            return ReturnResult.error("查询失败");
        }
        /**
         * 获取分页查询参数，准备进行分页查询
         *
         */
        int page = (params.get("page") == null)?1:(int)(params.get("page"));
        int pageSize = (params.get("pageSize") == null)?1:(int)(params.get("pageSize"));
        logger.info(" <-- 获取电商订单列表分页参数 page=" + page + " pageSize=" + pageSize);

        String orderType = (String)params.get("orderType");
        String[] orderTypes = orderType == null ?null:orderType.split(",");
        params.put("orderTypes",orderTypes);

        /**
         * 执行分页查询：PageHelper会拦截到第一条SQL语句并执行LIMIT操作
         * 组装返回的分页查询结果 pageBean
         */
        PageHelper.startPage(page, pageSize);

        List<OrderManage> orderManageList = orderManageService.getOrderList(params);

        PageInfo<OrderManage> pageInfo = new PageInfo<>(orderManageList);
        Map<String, Object> pageBean = PageDataUtils.pagePut(pageInfo.getTotal(), pageInfo.getPageSize()
                , pageInfo.isIsFirstPage()
                , pageInfo.isIsLastPage()
                , pageInfo.getPageNum());

        logger.info(" <-- 获取电商订单列表结果集 pageBean=" + pageBean.toString());
        /**
         * 将分页查询到的数据放入List中并返回
         */
        pageBean.put("orderList", pageInfo.getList());
        logger.info(" <-- 获取电商订单列表为:" + pageInfo.getList().toString());
        return ReturnResult.successResult("获取成功", pageBean);
    }

    /**
     * 新增订单
     *
     * @param order, result
     * @returns
     */
    @PostMapping("/addOrder")
    public Map<String, Object> addOrder(@Validated({OrderCheckGroups.Base.class, OrderCheckGroups.AddOrderCheck.class}) @RequestBody OrderManageDTO order) {

        logger.info(" --> 方法addOrder的参数:" + order.toString());
        /**
         * 验证订单号是否重复
         */
        String orderNo = order.getOrderNo();

        OrderManage tempOrderManage = null;
        try {
            tempOrderManage = orderManageService.validateOrder(orderNo);
        } catch (Exception e) {
            logger.error(" <-- 新增电商订单参数为空" + e.getMessage());
            return ReturnResult.error("新增失败");
        }
        if (!ValidateUtils.isEmpty(tempOrderManage)) {
            logger.error(" <-- 已存在这个订单号 orderNo=" + orderNo);
            return ReturnResult.error("新增失败,已存在这个订单号");
        }
        System.out.println("该订单号不存在,可以使用!");

        /**
         * 构建插入对象
         */
        OrderManage insertOrder = new OrderManage();

        /**
         * 传入的是RMB单位‘元’，数据库中表示￥的单元为分，需要将具体金额设置为
         * 根据勾选状态确定插入的字段数据
         * 订单类型 1充值、2蓝牙电子标签、3充值宝、4中石油加油，因允许自由组合，故存1,2,3,4形式数据
         */
        StringBuffer orderType = new StringBuffer(); //orderType

        logger.info("<-- 开始构建录入电商订单=" + orderNo);

        Integer tempMoney = BigDecimalUtil.getMultiply(order.getRealMoney().doubleValue() + "", "100");

        insertOrder.setId(UUIDUtils.getUUID());
        logger.info(" <-- 订单ID=" + orderNo);

        insertOrder.setOrderNo(orderNo);
        logger.info(" <-- 电商订单号=" + orderNo);

        insertOrder.setOrderChannel(order.getOrderChannel());
        logger.info(" <-- 电商渠道号=" + order.getOrderChannel());

        insertOrder.setCustomerName(order.getCustomerName());
        logger.info(" <-- 用户名=" + order.getCustomerName());

        insertOrder.setInputPerson(order.getInputPerson());
        logger.info(" <-- 录入人员=" + order.getCustomerName());

        insertOrder.setInputTime(new Date()); //录入时间

        insertOrder.setRealMoney(tempMoney);
        logger.info(" <-- 真实金额=" + tempMoney);
        if (order.getRechargeStatus()) { //充值
            tempMoney = BigDecimalUtil.getMultiply(order.getRechargeMoney().doubleValue() + "", "100");
            insertOrder.setRechargeMoney(tempMoney);
            insertOrder.setSurplusRechargeMoney(tempMoney);
            orderType.append("1,");
            logger.info(" <-- 可充值金额=" + tempMoney);
            logger.info(" <-- 剩余可充值金额=" + tempMoney);
        }

        if (order.getObuStatus()) { //电子标签
            orderType.append("2,");
            tempMoney = BigDecimalUtil.getMultiply(order.getObuUnitPrice().doubleValue() + "", "100");
            insertOrder.setObuName(order.getObuName());
            insertOrder.setObuNum(order.getObuNum());
            insertOrder.setSufObuNum(order.getObuNum());
            insertOrder.setObuUnitPrice(tempMoney);
            logger.info(" <-- 电子标签名=" + order.getObuName());
            logger.info(" <-- 原电子标签数量=" + order.getObuNum());
            logger.info(" <-- 剩余电子标签数量=" + order.getObuNum());
            logger.info(" <-- 电子标签单价=" + order.getObuUnitPrice());
        }

        if (order.getTreasureStatus()) { //充值宝
            orderType.append("3,");
            tempMoney = BigDecimalUtil.getMultiply(order.getTreasureUnitPrice().doubleValue() +  "", "100");
            insertOrder.setTreasureName(order.getTreasureName());
            insertOrder.setTreasureNum(order.getTreasureNum());
            insertOrder.setSufTreasureNum(order.getTreasureNum());
            insertOrder.setTreasureUnitPrice(tempMoney);
            logger.info(" <-- 充值宝名=" + order.getTreasureName());
            logger.info(" <-- 原充值宝数量=" + order.getTreasureNum());
            logger.info(" <-- 剩余充值宝数量=" + order.getTreasureNum());
            logger.info(" <-- 充值宝单价=" + order.getTreasureUnitPrice());
        }

        if (order.getOilStatus()) { //中石油
            orderType.append("4,");
            tempMoney = BigDecimalUtil.getMultiply(order.getOilAmount().doubleValue() + "", "100");
            insertOrder.setOilAmount(tempMoney);
            insertOrder.setSufOilAmount(tempMoney);
            logger.info(" <-- 原中石油余额=" + tempMoney);
            logger.info(" <-- 剩余中石油余额=" + tempMoney);
        }

        insertOrder.setOrderType(RegExUtil.getString(orderType.toString(), "(\\d,)*\\d"));
        insertOrder.setSaleStatus(0); //消费状态 0未消费，1消费中，2消费完毕
        insertOrder.setRemove("0"); //移除状态0 未移除 1 已移除
        logger.info("<-- 构建录入电商订单结束");
        int result = orderManageService.addOrder(insertOrder);
        if (result <= 0) {
            logger.error("<-- 新增电商订单失败");
        }
        logger.info(" <-- 新增成功");
        return ReturnResult.success("新增成功");
    }

    /**
     * 批量删除订单
     * 执行逻辑删除，0 未移除 1 已移除
     *
     * @return
     */
    @PostMapping(value = "/deleteOrders")
    public Map<String, Object> deleteOrders(@RequestBody Map<String, Object> params) {

        logger.info(" <-- 方法deleteOrders 的参数:" + params);
        /**
         * 接收需要删除的订单List,这里得orderNos是表中id字段
         */
        ArrayList<String> orderNos = (ArrayList) params.get("orderNos");
        if (ValidateUtils.isEmpty(orderNos)) {
            logger.error(" <-- 批量删除参数为空");
            return ReturnResult.error("删除失败,请选择需要删除的订单");
        }

        /**
         * 如果这个订单已经消费完或则是消费中，那么就不允许删除
         * 循环进行
         * 消费状态 0未消费，1消费中，2消费完毕
         */
        OrderManage orderManage = null;
        for (int i = 0; i < orderNos.size(); i++) {
            orderManage = orderManageService.getOrderManage(orderNos.get(i));
            //判断数据库中是否存在这个订单
            if(ValidateUtils.isEmpty(orderManage)) {
                logger.error(" <== 数据库不存在订单ID=" + orderNos.get(i));
                return ReturnResult.error("不存在订单ID=" + orderNos.get(i));
            }
            if (orderManage.getSaleStatus() == 1 || orderManage.getSaleStatus() == 2) {
                logger.error("订单" + orderNos.get(i) + ((orderManage.getSaleStatus() == 1) ? "消费中!" : "已经消费") + ",无法删除");
                return ReturnResult.error("订单" + orderNos.get(i) + ((orderManage.getSaleStatus() == 1) ? "消费中!" : "已经消费") + ",无法删除");
            }
        }
        /**
         * 执行逻辑删除，remove变为1
         */
        int deleteResult = orderManageService.deleteOrders(orderNos);
        if (deleteResult <= 0) {
            logger.error(" <-- 删除失败 deleteResult= " + deleteResult);
            return ReturnResult.error("批量删除失败");
        }
        logger.info(" <-- 批量删除成功结果=" + deleteResult);
        return ReturnResult.success("批量删除成功");
    }


    /**
     * 通过OrderNo更新订单信息
     * @return
     */
    @PostMapping(value = "/updateOrder")
    public Map<String, Object> updateOrderByOrderNo(@Validated({OrderCheckGroups.Base.class, OrderCheckGroups.AddOrderCheck.class}) @RequestBody OrderManageDTO order) {

        logger.info(" --> 方法updateOrderByOrderNo传送过来的参数");
        /**
         * 验证订单号是否重复
         */
        String orderNo = order.getOrderNo();

        OrderManage tempOrderManage = null;
        try {
            tempOrderManage = orderManageService.validateOrder(orderNo);
        } catch (Exception e) {
            logger.error(" <-- 修改电商订单参数为空" + e.getMessage());
            return ReturnResult.error("修改失败");
        }
        if (ValidateUtils.isEmpty(tempOrderManage)) {
            logger.error(" <-- 不存在这个订单号 orderNo=" + orderNo);
            return ReturnResult.error("修改失败,不存在这个订单号");
        }

        /**
         * 构建更新对象
         */
        OrderManage updateOrder = new OrderManage();

        /**
         * 传入的是RMB单位‘元’，数据库中表示￥的单元为分，需要将具体金额设置为
         * 根据勾选状态确定更新的字段数据
         * 订单类型 1充值、2蓝牙电子标签、3充值宝、4中石油加油，因允许自由组合，故存1,2,3,4形式数据
         */
        StringBuffer orderType = new StringBuffer(); //orderType

        logger.info("<-- 开始更新录入电商订单=" + orderNo);

        Integer tempMoney = BigDecimalUtil.getMultiply(order.getRealMoney().doubleValue() + "", "100");

        updateOrder.setId(UUIDUtils.getUUID());
        logger.info(" <-- 订单ID=" + orderNo);

        updateOrder.setOrderNo(orderNo);
        logger.info(" <-- 电商订单号=" + orderNo);

        updateOrder.setOrderChannel(order.getOrderChannel());
        logger.info(" <-- 电商渠道号=" + order.getOrderChannel());

        updateOrder.setCustomerName(order.getCustomerName());
        logger.info(" <-- 用户名=" + order.getCustomerName());

        updateOrder.setInputPerson(order.getInputPerson());
        logger.info(" <-- 录入人员=" + order.getCustomerName());

        updateOrder.setInputTime(new Date()); //录入时间

        updateOrder.setRealMoney(tempMoney);
        logger.info(" <-- 真实金额=" + tempMoney);
        if (order.getRechargeStatus()) { //充值
            tempMoney = BigDecimalUtil.getMultiply(order.getRechargeMoney().doubleValue() + "", "100");
            updateOrder.setRechargeMoney(tempMoney);
            updateOrder.setSurplusRechargeMoney(tempMoney);
            orderType.append("1,");
            logger.info(" <-- 可充值金额=" + tempMoney);
            logger.info(" <-- 剩余可充值金额=" + tempMoney);
        }

        if (order.getObuStatus()) { //电子标签
            orderType.append("2,");
            tempMoney = BigDecimalUtil.getMultiply(order.getObuUnitPrice().doubleValue() + "", "100");
            updateOrder.setObuName(order.getObuName());
            updateOrder.setObuNum(order.getObuNum());
            updateOrder.setSufObuNum(order.getObuNum());
            updateOrder.setObuUnitPrice(tempMoney);
            logger.info(" <-- 电子标签名=" + order.getObuName());
            logger.info(" <-- 原电子标签数量=" + order.getObuNum());
            logger.info(" <-- 剩余电子标签数量=" + order.getObuNum());
            logger.info(" <-- 电子标签单价=" + order.getObuUnitPrice());
        }

        if (order.getTreasureStatus()) { //充值宝
            orderType.append("3,");
            tempMoney = BigDecimalUtil.getMultiply(order.getTreasureUnitPrice().doubleValue() + "", "100");
            updateOrder.setTreasureName(order.getTreasureName());
            updateOrder.setTreasureNum(order.getTreasureNum());
            updateOrder.setSufTreasureNum(order.getTreasureNum());
            updateOrder.setTreasureUnitPrice(tempMoney);
            logger.info(" <-- 充值宝名=" + order.getTreasureName());
            logger.info(" <-- 原充值宝数量=" + order.getTreasureNum());
            logger.info(" <-- 剩余充值宝数量=" + order.getTreasureNum());
            logger.info(" <-- 充值宝单价=" + order.getTreasureUnitPrice());
        }

        if (order.getOilStatus()) { //中石油
            orderType.append("4,");
            tempMoney = BigDecimalUtil.getMultiply(order.getOilAmount().doubleValue() + "", "100");
            updateOrder.setOilAmount(tempMoney);
            updateOrder.setSufOilAmount(tempMoney);
            logger.info(" <-- 原中石油余额=" + tempMoney);
            logger.info(" <-- 剩余中石油余额=" + tempMoney);
        }

        updateOrder.setOrderType(RegExUtil.getString(orderType.toString(), "(\\w,)*\\w"));
        updateOrder.setSaleStatus(0); //消费状态 0未消费，1消费中，2消费完毕
        updateOrder.setRemove("0"); //移除状态0 未移除 1 已移除
        updateOrder.setUpdateTime(new Date());
        updateOrder.setUpdateBy(order.getUpdateBy());
        logger.info("<-- 构建更新电商订单结束");
        int result = orderManageService.updateOrderByOrderNo(updateOrder);
        if (result <= 0) {
            logger.error("<-- 更新电商订单失败");
        }
        logger.info(" <-- 修改成功");
        return ReturnResult.success("修改成功");
    }

    /**
     * 更新电商订单余额
     * @param order
     * @return
     */

    @PostMapping("/updateOrderSurplys")
    public Map<String,Object> updateOrderSurplys(@RequestBody @Validated({OrderCheckGroups.UpdateOrderSurplysCheck.class}) OrderManageDTO order){

        logger.info(" --> 方法updateOrderSurplys的参数::" + order);

        String orderNo = order.getOrderNo(); //电商订单号码

        /**
         *
         * 这里的操作指的是（充值，蓝牙电子标签，充值宝，中石油）
         * 判断订单所需要进行的操作，是否符合订单实际具有的操作
         * 订单类型 1充值、2蓝牙电子标签、3充值宝、4中石油加油，因允许自由组合，故存1,2,3形式数据
         */
        OrderManage orderManage = orderManageService.getOrderDetail(orderNo); //从数据库中获取这个商品订单
        //判断该订单是否不存在
        if(orderManage == null) {
            logger.error(" <-- 该订单不存在");
            return ReturnResult.error("该订单不存在");
        }
        /**
         * 判断该订单是否已经消费完毕 消费状态 0未消费，1消费中，2消费完毕
         *
         */
        if(orderManage.getSaleStatus() == 2) {
            logger.error(" <-- 该订单已经消费完毕，无法再次进行消费");
            return ReturnResult.error("该订单已经消费完毕，无法再次进行消费");
        }

        String orderManageType = orderManage.getOrderType(); //该订单能够支持的充值方式
        String[] orderUpdateTypes = order.getOrderType().split(","); //获取商品订单需要操作的类型
        //需要传入得更新参数
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("orderNo", orderManage.getOrderNo());
        int surplus = 0; //实际剩余金额或数量
        int recharge = 0; //消费的金额货或数量
        for(String type:orderUpdateTypes) { //判断操作类型是否存在,添加操作逻辑
            if(RegExUtil.getString(orderManageType,"(^(" + type+ ")$)|(^(" + type+ ",))|(,"
                    + type+ ")$|," + type+ ",") != null) { //匹配中部
                //匹配成功
                if("1".equals(type)) {   //充值
                    /**
                     * 是否有拥有足够得充值余额进行充值
                     */
                     surplus = orderManage.getSurplusRechargeMoney(); //数据库中的剩余充值余额
                     recharge = BigDecimalUtil.getMultiply(order.getRechargeMoney().doubleValue() + "","100");

                    if(surplus >= recharge) { //数据库中的剩余充值金额大于消费金额
                        updateMap.put("surplusRechargeMoney",surplus - recharge);
                        logger.info(" <--使用充值，消费充值金额=" + order.getRechargeMoney());
                    } else {
                        logger.error(" <-- 剩余充值金额不足");
                        return ReturnResult.error("剩余充值金额不足");
                    }
                } else if("2".equals(type)) { //蓝牙电子标签
                    surplus = orderManage.getSufObuNum(); //剩余蓝牙电子标签数量
                    recharge = order.getObuNum(); // 消费得蓝牙电子标签数量
                    if(surplus >= recharge) {
                        updateMap.put("sufObuNum", surplus - recharge);
                        logger.info(" <--使用蓝牙电子标签，使用蓝牙电子标签数量=" + recharge);
                    } else {
                        logger.error(" <-- 剩余蓝牙电子标签数量不足");
                        return ReturnResult.error("剩余蓝牙电子标签数量不足");
                    }
                } else if("3".equals(type)) { //充值宝
                    surplus = orderManage.getSufTreasureNum(); //剩余充值宝数量
                    recharge = order.getTreasureNum(); // 消费得充值宝数量
                    if(surplus >= recharge) {
                        updateMap.put("sufTreasureNum",surplus - recharge);
                        logger.info(" <--" + "使用充值宝，消费充值宝数量=" + recharge);
                    } else {
                        logger.error(" <-- 剩余充值宝数量不足");
                        return ReturnResult.error("剩余充值宝数量不足");
                    }
                } else if("4".equals(type)) { //中石油加油
                    surplus = orderManage.getSufOilAmount(); //剩余中石油加油余额
                    recharge = BigDecimalUtil.getMultiply(order.getOilAmount().doubleValue() + "", "100"); // 消费的中石油加油金额
                    if(surplus >= recharge) {
                        updateMap.put("sufOilAmount",surplus - recharge);
                        logger.info(" <--" + "使用中石油加油，消费中石油金额=" + order.getOilAmount());
                    } else {
                        logger.error(" <-- 剩余中石油加油余额不足");
                        return ReturnResult.error("剩余中石油加油余额不足");
                    }
                }

            } else {
                logger.error(" <-- 该电商订单不支持该用途");
                return ReturnResult.error("该电商订单不支持该用途");
            }
        }
        /**
         *
         * 全部操作匹配成功,进行更新操作
         *
         */
        updateMap.put("updateBy",order.getUpdateBy());
        updateMap.put("updateTime",new Date());
        int updateRechargeResult = orderManageService.updateOrderSurplys(updateMap);

        if (updateRechargeResult == 1){ //判断是否执行成功
            logger.info(" <-- 更新电商订单成功");
            /**
             *
             * 消费状态 0未消费，1消费中，2消费完毕
             * 判断该条订单是否全部消费完毕,如果全部消费完毕，则需要修改
             * saleStatus为 2
             */

            orderManage = orderManageService.getOrderDetail(orderNo); //从数据库中获取这个商品订单
            boolean saleStatus = true;

            //充值金额
            if(orderManage.getSurplusRechargeMoney() != null) { //充值

                if(orderManage.getSurplusRechargeMoney() == 0) {
                    //充值金额为空
                    saleStatus = saleStatus && true;
                } else { //还有剩余充值金额
                    saleStatus = saleStatus && false;
                }
            }

            //蓝牙电子标签
            if(orderManage.getSufObuNum() != null) { //蓝牙电子标签
                if(orderManage.getSufObuNum() == 0) {
                    //蓝牙电子标签数量0
                    saleStatus = saleStatus && true;
                } else {//蓝牙电子标签数量大于0
                    saleStatus = saleStatus && false;
                }
            }

            //充值宝
            if(orderManage.getSufTreasureNum() != null) {
                if(orderManage.getSufTreasureNum() == 0) {
                    //充值宝数量0
                    saleStatus = saleStatus && true;
                } else { //充值宝数量大于0
                    saleStatus = saleStatus && false;
                }
            }

            //中石油加油
            if(orderManage.getSufOilAmount() != null) {
                if(orderManage.getSufOilAmount() == 0) {
                    //中石油余额0
                    saleStatus = saleStatus && true;
                } else { //还有剩余中石油余额
                    saleStatus = saleStatus && false;
                }
            }

            /**
             * 如果消费完毕并且上次消费状态为消费中，则将电商订单状态修改为
             * 消费完毕,否则不进行状态修改
             */
            if(saleStatus && orderManage.getSaleStatus() == 1) {
                OrderManage om = new OrderManage();
                om.setOrderNo(orderManage.getOrderNo());
                om.setSaleStatus(2);
                int result = orderManageService.updateOrderSaleStatus(om);
                if(result == 1) {
                    logger.info("更新订单状态为消费完毕");
                }
            }
            return ReturnResult.success("使用成功");
        }
        logger.error("更新电商订单失败");
        return ReturnResult.error("使用失败");

    }

    /**
     * 验证订单
     * @param order
     * @return
     */
    @PostMapping("/validateOrderNo")
    public Map<String,Object> validateOrderNo(@RequestBody OrderManageDTO order) {
        logger.info(" --> 方法validateOrderNo的参数::" + order);

        /**
         * 验证结果 orderManage：对象
        */
        OrderManage orderManage = orderManageService.validateOrder(order.getOrderNo());
        if (ValidateUtils.isEmpty(orderManage)){
            logger.error(" <-- 验证失败,没有这条电商订单数据");
            return ReturnResult.error("不存在这个订单或者该记录已逻辑删除");
        }
        //页面传送过来得订单用途
        String[] orderTypeUsing = order.getOrderType().split(",");
        String orderManageType = orderManage.getOrderType();

        Map<String,Object> data = new HashMap<>();
        data.put("orderChannel",orderManage.getOrderChannel());
        data.put("customerName",orderManage.getCustomerName());
        data.put("orderNo",order.getOrderNo());
        System.out.println(orderTypeUsing.length);

        if(orderTypeUsing == null || orderTypeUsing.length == 0) {
            logger.error(" <-- 没有这个电商订单用途=");
            return ReturnResult.error("验证失败,没有这个订单用途");
        }
        for(String type:orderTypeUsing) { //判断操作类型是否存在,添加操作逻辑
            if(RegExUtil.getString(orderManageType,"(^(" + type+ ")$)|(^(" + type+ ",))|(,"
                    + type+ ")$|," + type+ ",") != null) {

                if("1".equals(type)) { //充值
                    logger.info(" <-- 电商订单用途为充值=");
                    data.put("orderChannel",orderManage.getOrderChannel());
                    data.put("surplusRechargeAmount",orderManage.getSurplusRechargeMoney());
                } if("2".equals(type)) { //蓝牙电子标签
                    logger.info(" <-- 电商订单用途为充值=");
                    data.put("obuName", orderManage.getObuName());
                    data.put("obuNum", orderManage.getObuNum());
                    data.put("obuUnitPrice", orderManage.getObuUnitPrice());
                    data.put("sufObuNum", orderManage.getSufObuNum());
                } if("3".equals(type)) { //充值宝
                    data.put("treasureName", orderManage.getTreasureName());
                    data.put("treasureNum", orderManage.getTreasureNum());
                    data.put("treasureUnitPrice", orderManage.getTreasureUnitPrice());
                    data.put("sufTreasureNum", orderManage.getSufTreasureNum());
                } if("4".equals(type)) {
                    data.put("oilAmount", orderManage.getOilAmount());
                    data.put("sufOilAmount", orderManage.getSufOilAmount());
                }
            } else {
                logger.error(" <-- 没有这个电商订单用途=" + type);
                //获取改订单用途
                StringBuffer sb = new StringBuffer();
                for(String type2:orderManageType.split(",")) {
                    if("1".equals(type2)) { //充值
                        sb.append(" 充值");
                    } if("2".equals(type2)) { //蓝牙电子标签
                        sb.append(" 蓝牙电子标签");
                    } if("3".equals(type2)) { //充值宝
                        sb.append(" 充值宝");
                    } if("4".equals(type2)) { //中石油加油
                        sb.append(" 中石油加油");
                    }
                }
                logger.info(" <-- 电商订单用途为=" + sb.toString());
                return ReturnResult.error("验证失败,该订单只能用于" + sb.toString());
            }
        }
        logger.info(" <-- 返回订单数据=" + data);
        logger.info(" <-- 验证成功");
        return ReturnResult.successResult("验证成功",data);
    }

    /**
     * 传入得字段类型异常处理
     *
     * @param e
     * @return
     */
    @ExceptionHandler(ClassCastException.class)
    @ResponseBody
    public JSONObject handleException(Exception e) {
        e.printStackTrace();
        return JSONResultUtil.errorResult(null, "类型不匹配");
    }

}
