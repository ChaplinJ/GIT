package com.owinfo.service.controller;

import com.owinfo.object.entity.FrontPayBack;
import com.owinfo.service.core.service.FrontPayBackService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月25日
 *         github : https://github.com/rexlin600/
 * @Description  新增补交收款记录
 */
@RestController
@RequestMapping("/payback")
@CrossOrigin(maxAge = 3600,origins = "*")
public class PayBackController {

    private static Logger logger = Logger.getLogger(PayBackController.class);

    @Autowired
    private FrontPayBackService frontPayBackService;

    /**
     * 新增补交收款记录
     * @param frontPayBack
     * @return
     */
    @PostMapping("/addPayBackRecord")
    public int addPayBackRecord(@RequestBody FrontPayBack frontPayBack){
        return frontPayBackService.addPayBackRecord(frontPayBack);
    }

    /**
     * 删除待补交的补交收款记录
     * @param ids
     * @return
     */
    @PostMapping("/delPayBackRecord")
    public int delPayBackRecord(@RequestParam(value = "ids") ArrayList<String> ids){
        return frontPayBackService.delPayBackRecord(ids);
    }

    /**
     * 获取补交收款列表
     * cardId certificateNumber payStatus payBackStart payBackEnd
     * @param params
     * @return
     */
    @PostMapping("/getPayBackList")
    public List<FrontPayBack> getPayBackList(@RequestBody Map<String,Object> params){
        return frontPayBackService.getPayBackList(params);
    }

    /**
     * 更新补交状态
     * id paidMoney payTime updateBy updateTime payNum
     * @param params
     * @return
     */
    @PostMapping("/updatePayBackStatus")
    public int updatePayBackStatus(@RequestBody Map<String,Object> params){
        Map<String,Object> map = params;
        return frontPayBackService.updatePayBackStatus(map);
    }

}