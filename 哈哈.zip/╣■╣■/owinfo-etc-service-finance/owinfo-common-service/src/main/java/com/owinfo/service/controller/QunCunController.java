package com.owinfo.service.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.owinfo.object.entity.AppInit;
import com.owinfo.object.entity.AppSearch;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.FrontTransfrenceMapper;
import com.owinfo.service.core.service.FrontBillingRecordService;
import com.owinfo.service.core.service.FrontTransferenceOperationService;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static com.netflix.appinfo.AmazonInfo.MetaDataKey.mac;
import static org.bouncycastle.asn1.x500.style.RFC4519Style.sn;

/**
 * @author Created by hekunlin on 2018年01月16日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/quanCun")
@CrossOrigin(maxAge = 3600,origins = "*")
public class QunCunController {

    private static final Logger logger = Logger.getLogger(QunCunController.class);

    @Autowired
    private FrontTransferenceOperationService frontTransferenceOperationService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private RedisService redisService;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private FrontTransfrenceMapper transfrenceMapper;

    /**
    * @description 圈存卡账查询
    * @author hekunlin 2018/1/16 14:04 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/cardAccountSearch")
    public Map<String,Object> cardAccountSearch(@RequestBody CardAccountSearchVO cardAccountSearchVO){
        logger.info("<==  方法cardAccountSearch的参数::" + cardAccountSearchVO + "   开始执行");

        // 卡账查询结果：包含补上次圈存完成记录和本次的补圈金额
        Map<String, Object> cardAccountMap = frontTransferenceOperationService.
                cardAccountResearch(cardAccountSearchVO.getCardNo(), cardAccountSearchVO.getCardInfo());

        logger.info("<==  方法cardAccountSearch执行结束");
        return cardAccountMap;
    }


    /**
    * @description 圈存
    * @author hekunlin 2018/1/16 14:06 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/quanCun")
    public Boolean quanCun(@RequestBody QuanCunVO quanCunVO){
        logger.info("<==  方法quanCun的参数::" + quanCunVO + "   开始执行");
        logger.info("<==  方法quanCun执行结束");
        return frontTransferenceOperationService.quanCun(quanCunVO);
    }

    /********************************************* APP圈存 ***********************************************************/

    /**
     * app查询调has验设备、圈存调下面三个
     */
    public static String URL_HAS = "http://10.248.2.11:6001/machine/has";
    public static String URL_GET_CA = "http://10.248.2.11:6001/machine/getBySn";
    public static String URL_MERGE_CA = "http://10.248.2.11:6002/ca/encryptorRaw";
    public static String URL_VALID_SIGN = "http://10.248.2.11:6002/ca/validSignRaw";

//    public static String URL_HAS = "http://10.9.4.9:6001/machine/has";
//    public static String URL_GET_CA = "http://10.9.4.9:6001/machine/getBySn";
//    public static String URL_MERGE_CA = "http://10.9.4.9:6002/ca/encryptorRaw";
//    public static String URL_VALID_SIGN = "http://10.9.4.9:6002/ca/validSignRaw";

    /**
     * 终端机校验 URL_HAS
     * @param data
     * @return
     */
    public boolean querySe(String se) {
        logger.info("<==  终端机数据校验 " + se);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
//        params.add("sn", (String) data.get("sn"));
        params.add("se", se);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        logger.info("<==  SE开始获取证书 ");
        String has = new RestTemplate().postForObject(URL_HAS, request, String.class);
        JSONObject jsonObject = JSON.parseObject(has);

        logger.info("<==  SE获取到的证书 " + jsonObject.toJSONString());
        return jsonObject.getBoolean("has");
    }

    /**
     * 传终端机号返回证书 URL_GET_CA
     * @param sn
     * @return
     */
    public String GetWriteCardCert(String se){
        logger.info("<==  终端机编号 " + se);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("se", se);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        logger.info("<==  通过终端机编号[ " + sn + "] 获取证书");
        GetWriteCardCertDto writeCardCertDto = new RestTemplate().postForObject(URL_GET_CA, request, GetWriteCardCertDto.class);

        logger.info("<==  返回的证书为 [" + writeCardCertDto.toString() + "]");
        return writeCardCertDto.getCert();
    }

    /**
     * 根据证书和指令来加密，返回加密后的指令 URL_MERGE_CA
     * @param cert
     * @param cmd
     * @return
     */
    public String GetWriteCmdCert(String cert,String cmd){
        logger.info("<==  通过证书给数据加密，加密参数 cert=[" + cert + "]" + " cmd=[" + cmd + "]");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("cert", cert);
        params.add("data",cmd);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        logger.info("<==  通过证书和指令加密返回加密指令开始[ " + cert + "]");
        GetWriteCardCertCmdDto writeCardCertCmdDto = new RestTemplate().postForObject(URL_MERGE_CA, request, GetWriteCardCertCmdDto.class);

        logger.info("<==  通过证书和指令加密返回加密指令开始[ " + cmd + "]");
        return writeCardCertCmdDto.getEncData();
    }

    /**
     * 验签
     * @param cert
     * @param cmd
     * @return
     */
    public boolean validSign(String cert, String data, String sign){
        logger.info("<==  验签参数:: " + cert + "  " + data + "  " + sign + "   开始执行");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("cert", cert);
        params.add("data",data);
        params.add("sign",sign);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        logger.info("<==  验签开始cert=[ " + cert + "] " + " data=[" + data + " ] sign=[" + sign + "]");
        ValidSignDTO validSignDTO = new RestTemplate().postForObject(URL_VALID_SIGN, request, ValidSignDTO.class);

        if (!validSignDTO.isSuccess()){
            return false;
        }

        logger.info("<==  验签结束 " + validSignDTO.toString());
        return validSignDTO.isValid();
    }

    /**
     * app圈存卡账查询
     * @param appSearch
     * @return
     */
    @PostMapping("/appTranserSearch")
    public Map<String,Object> appTranserSearch(@RequestBody AppSearch appSearch){
        logger.info("<==  方法appTranserSearch的参数::" + appSearch.toString() + "   开始执行");

        // 验设备
        boolean flag = querySe(appSearch.getSe());

        if (!flag){
            logger.error("<==  APP圈存验设备失败，不允许圈存");
            throw new RuntimeException("APP圈存验设备失败");
        }

        // 卡账查询
        CardAccountSearchVO cardAccountSearchVO = new CardAccountSearchVO(appSearch.getCardNo(),appSearch.getCardInfo());

        logger.info("<==  方法appTranserSearch执行结束");

        Map<String,Object> appCardAccountSearch = new HashMap<>();
        appCardAccountSearch = cardAccountSearch(cardAccountSearchVO);

        //解决空指针
        if( appCardAccountSearch == null ){
            return null;
        }
        appCardAccountSearch.put("cardAccountBalance",0+new BigDecimal(String.valueOf(appCardAccountSearch.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue());
        return appCardAccountSearch;
    }

    /**
     * app圈存初始化
     * *** 模板 ***
     * @return
     */
    @PostMapping("/appTranserInit")
    public Map<String,Object> appTranserInit(@RequestBody AppInit appInit){

        try {
            /**
             * 杂七杂八参数待组装 AppInit ....
             *
             *
             */
//            //验钱
//            if (appInit.getAmount() == 0){
//                logger.error("<==  圈存初始化金额为0");
//                throw new RuntimeException("APP圈存初始化===金额为0,不允许圈存");
//            }


            LocalDateTime localDateTime = LocalDateTime.now();
            String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

            // 生成交易流水号等信息
            String acquirerNo = "4101018802401050635";
            String siteName = "经三路网点";
            String employeeNo = "00000000";
            String createBy = "00000000";
            String channelType = "0";
            String channelNum = "00000000";
            String channelName = "00000000";
            try {
                acquirerNo = "410101999990102";
                siteName = "线上APP";
                employeeNo = appInit.getEmployeeNo();
                createBy = appInit.getEmployeeNo();
//                channelType = "99";
                channelType = "3";

//                channelNum = "41010199999";
                channelNum = "410101999990102";
                channelName = "自营渠道";
            } catch (Exception e) {
                logger.error("<==  获取渠道信息异常");
            }

            // 流水号
            Long incr = redisService.getIncr(formatDate,60L);
            String tradeNum = "";
            if (incr < 99){
                tradeNum = String.format("%02d", incr);
            }
            if (incr > 99){
                localDateTime = localDateTime.plusSeconds(1);
                formatDate = dateFormat.format(localDateTime);
                incr = redisService.getIncr(formatDate,60L);
                tradeNum = String.format("%02d", incr);
            }
            //        String tradeNumFinal = "3"+"410101999990102"+formatDate+tradeNum;
//            String tradeNumber = channelType + channelNum + formatDate + tradeNum;
            String tradeNumber = "3"+"410101999990102" + formatDate + tradeNum;

            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);


            // 验设备
            boolean terFlag = querySe(appInit.getSe());

            if (!terFlag){
                logger.error("<==  APP圈存验设备失败，不允许圈存");
                throw new RuntimeException("APP圈存验设备失败");
            }

            // 获取证书
            String cert = GetWriteCardCert(appInit.getSe());

            // 验签
            boolean cerFlag = validSign(cert, appInit.getCardInfo(), appInit.getSignDate());

            if (!cerFlag){
                logger.error("<==  APP圈存验签失败，不允许圈存");
                throw new RuntimeException(("APP圈存验签失败"));
            }

            // A014验证
            boolean a014Flag = EncryptorUtils.a014(appInit.getCardNo(),appInit.getOperationMoney(),appInit.getCardInfo(),appInit.getTerminal());

            if (!a014Flag){
                logger.error("<==  APP圈存AO14验证结果 " + a014Flag);
                throw new RuntimeException("APP圈存AO14验证异常");
            }

            // 圈存
            QuanCunVO quanCunVO = new QuanCunVO();
            quanCunVO.setCardNo(appInit.getCardNo());
            quanCunVO.setCardInfo(appInit.getCardInfo());
            quanCunVO.setOperationMoney(appInit.getOperationMoney());
            quanCunVO.setChannelName(channelName);
            quanCunVO.setChannelNum(channelNum);
            quanCunVO.setChannelType(channelType);
            quanCunVO.setAcquirerNo(acquirerNo);

            quanCunVO.setTradeNum(tradeNumber);
            quanCunVO.setSiteName(siteName);
            quanCunVO.setEmployeeNo(employeeNo);
            //client_no
            quanCunVO.setSignData(appInit.getSignDate());
            quanCunVO.setCardInfo(appInit.getCardInfo());
            quanCunVO.setCardNo(appInit.getCardNo());
            quanCunVO.setTerminal(appInit.getSe());
            quanCunVO.setCreateBy(appInit.getEmployeeNo());
            quanCunVO.setOperationUser(appInit.getEmployeeNo());


            boolean flag = quanCun(quanCunVO);

            if(flag == false){
                logger.error("<==  圈存初始化失败,flag = "+flag);
                Map<String, Object> map = new HashMap<>();
                map.put("code",0);
                map.put("msg","获取圈存指令失败");
                return map;
            }

            // A015验证
            String optTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            String mac = EncryptorUtils.a015(appInit.getCardNo(),appInit.getOperationMoney(),appInit.getCardInfo(),
                    appInit.getTerminal(), optTime);

            // 返回mac
            String shsmk = "805200000B" + optTime + mac + "04";

            Map<String, Object> map = new HashMap<>();

            shsmk =   GetWriteCmdCert(cert,shsmk);

            map.put("shsmk",shsmk);
            map.put("code",1);
            map.put("tradeNum",quanCunVO.getTradeNum());
            map.put("msg","获取圈存指令成功");

            return map;

        } catch (RuntimeException e) {
            logger.error("<==  圈存初始化失败");
            e.printStackTrace();
            Map<String, Object> map = new HashMap<>();
            map.put("code",0);
            map.put("msg","获取圈存指令失败");
            return map;
        }
    }


    @PostMapping("/transferReturn")
    public Map<String,Object> transferReturn(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法transferReturn的参数::" + params);
        /**
         * 修改圈存操作表和账单表圈存状态、补圈存状态
         */
        String cardAccountBalance = "";
        try {
            frontTransferenceOperationService.quancunWancheng(params);

            Map<String,Object> queryCard = new HashMap<>();
            try {
                queryCard.put("cardId", params.get("cardNo"));
                queryCard = cardMapper.queryCard(queryCard);
                cardAccountBalance = String.valueOf(0+new BigDecimal(String.valueOf(queryCard.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue());
            }catch(Exception e){
                logger.error("圈存完成查询卡账户余额失败");
            }
        } catch (Exception e) {
            logger.error("<==  圈存回调,更新物理圈存状态失败" + e.getMessage());
            return ReturnResult.error("圈存失败,请联系管理员");
        }
        logger.info("<==  圈存回调,更新物理圈存状态成功");
        return ReturnResult.successQuan(cardAccountBalance);
    }


    /**
     * 圈存机圈存卡账查询
     * @param appSearch
     * @return
     */
    @PostMapping("/selfTranserSearch")
    public Map<String,Object> selfTranserSearch(@RequestBody AppSearch appSearch){
        logger.info("<==  方法selfTranserSearch的参数::" + appSearch.toString() + "   开始执行");

//        // 验设备
//        boolean flag = querySe(appSearch.getSe());

//        if (!flag){
//            logger.error("<==  APP圈存验设备失败，不允许圈存");
//            throw new RuntimeException("APP圈存验设备失败");
//        }

        // 卡账查询
        CardAccountSearchVO cardAccountSearchVO = new CardAccountSearchVO(appSearch.getCardNo(),appSearch.getCardInfo());

        logger.info("<==  方法appTranserSearch执行结束");

        Map<String,Object> appCardAccountSearch = new HashMap<>();
        appCardAccountSearch = cardAccountSearch(cardAccountSearchVO);

        //解决空指针
        if( appCardAccountSearch == null ){
            return null;
        }
        appCardAccountSearch.put("cardAccountBalance",0+new BigDecimal(String.valueOf(appCardAccountSearch.get("cardAccountBalance"))).multiply(new BigDecimal(100)).intValue());
        return appCardAccountSearch;
    }

    /**
     * 圈存机圈存初始化
     * *** 模板 ***
     * @return
     */
    @PostMapping("/selfTranserInit")
    public Map<String,Object> selfTranserInit(@RequestBody AppInit appInit){

        try {
            /**
             * 杂七杂八参数待组装 AppInit ....
             *
             *
             */
//            //验钱
//            if (appInit.getAmount() == 0){
//                logger.error("<==  圈存初始化金额为0");
//                throw new RuntimeException("APP圈存初始化===金额为0,不允许圈存");
//            }


            LocalDateTime localDateTime = LocalDateTime.now();
            String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

            // 生成交易流水号等信息
            String acquirerNo = "4101018802401050635";
            String siteName = "经三路网点";
            String employeeNo = "00000000";
            String createBy = "00000000";
            String channelType = "0";
            String channelNum = "00000000";
            String channelName = "00000000";
            try {
//                acquirerNo = "410101999990102";
                //2018年03月30日11:18:52改，圈存机网点编号为传来的编号
                acquirerNo = appInit.getAcquirerNo();

                siteName = "自助圈存机";
                employeeNo = appInit.getEmployeeNo();
                createBy = appInit.getEmployeeNo();
//                channelType = "99";
                channelType = "3";

//                channelNum = "41010199999";
                channelNum = "410101999990102";
                channelName = "自助终端";
            } catch (Exception e) {
                logger.error("<==  获取渠道信息异常");
            }

            // 流水号
            Long incr = redisService.getIncr(formatDate,60L);
            String tradeNum = "";
            if (incr < 99){
                tradeNum = String.format("%02d", incr);
            }
            if (incr > 99){
                localDateTime = localDateTime.plusSeconds(1);
                formatDate = dateFormat.format(localDateTime);
                incr = redisService.getIncr(formatDate,60L);
                tradeNum = String.format("%02d", incr);
            }
            //        String tradeNumFinal = "3"+"410101999990102"+formatDate+tradeNum;
//            String tradeNumber = channelType + channelNum + formatDate + tradeNum;
            String tradeNumber = "3"+"410101999990102" + formatDate + tradeNum;

            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);


//            // 验设备
//            boolean terFlag = querySe(appInit.getSe());
//
//            if (!terFlag){
//                logger.error("<==  APP圈存验设备失败，不允许圈存");
//                throw new RuntimeException("APP圈存验设备失败");
//            }

//            // 获取证书
//            String cert = GetWriteCardCert(appInit.getSe());
//
//            // 验签
//            boolean cerFlag = validSign(cert, appInit.getCardInfo(), appInit.getSignDate());

//            if (!cerFlag){
//                logger.error("<==  APP圈存验签失败，不允许圈存");
//                throw new RuntimeException(("APP圈存验签失败"));
//            }

            // A014验证
            boolean a014Flag = EncryptorUtils.a014(appInit.getCardNo(),appInit.getOperationMoney(),appInit.getCardInfo(),appInit.getTerminal());

            if (!a014Flag){
                logger.error("<==  自助圈存机AO14验证结果 " + a014Flag);
                throw new RuntimeException("APP圈存AO14验证异常");
            }

            // 圈存
            QuanCunVO quanCunVO = new QuanCunVO();
            quanCunVO.setCardNo(appInit.getCardNo());
            quanCunVO.setCardInfo(appInit.getCardInfo());
            quanCunVO.setOperationMoney(appInit.getOperationMoney());
            quanCunVO.setChannelName(channelName);
            quanCunVO.setChannelNum(channelNum);
            quanCunVO.setChannelType(channelType);
            quanCunVO.setAcquirerNo(acquirerNo);

            quanCunVO.setTradeNum(tradeNumber);
            quanCunVO.setSiteName(siteName);
            quanCunVO.setEmployeeNo(employeeNo);
            //client_no
            quanCunVO.setSignData(appInit.getSignDate());
            quanCunVO.setCardInfo(appInit.getCardInfo());
            quanCunVO.setCardNo(appInit.getCardNo());
            quanCunVO.setTerminal(appInit.getSe());
            quanCunVO.setCreateBy(appInit.getEmployeeNo());
            quanCunVO.setOperationUser(appInit.getEmployeeNo());


            boolean flag = quanCun(quanCunVO);

            if(flag == false){
                logger.error("<==  圈存初始化失败,flag = "+flag);
                Map<String, Object> map = new HashMap<>();
                map.put("code",0);
                map.put("msg","获取圈存指令失败");
                return map;
            }

            // A015验证
            String optTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            String mac = EncryptorUtils.a015(appInit.getCardNo(),appInit.getOperationMoney(),appInit.getCardInfo(),
                    appInit.getTerminal(), optTime);

            // 返回mac
            String shsmk = "805200000B" + optTime + mac + "04";

            Map<String, Object> map = new HashMap<>();

//            shsmk =   GetWriteCmdCert(cert,shsmk);

            map.put("shsmk",shsmk);
            map.put("code",1);
            map.put("tradeNum",quanCunVO.getTradeNum());
            map.put("msg","获取圈存指令成功");

            return map;

        } catch (RuntimeException e) {
            logger.error("<==  圈存初始化失败");
            e.printStackTrace();
            Map<String, Object> map = new HashMap<>();
            map.put("code",0);
            map.put("msg","获取圈存指令失败");
            return map;
        }
    }

}
