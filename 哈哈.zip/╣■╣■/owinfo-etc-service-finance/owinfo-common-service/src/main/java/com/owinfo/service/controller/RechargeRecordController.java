package com.owinfo.service.controller;

import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.service.core.service.FrontRechargeOperationService;
import com.owinfo.service.util.DataValidate;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月15日
 *         github : https://github.com/rexlin600/
 * @Description  充值/冲正操作记录
 */
@RestController
@RequestMapping("/finance/back/recharge/operation")
@CrossOrigin(maxAge = 3600,origins = "*")
public class RechargeRecordController {

    private static Logger logger = Logger.getLogger(RechargeRecordController.class);

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @PostMapping("/changeCard")
    public Map<String,Object> changeCard(@RequestBody Map<String,Object> params){
        try{
            DataValidate.validateCard(params);
            int result = frontRechargeOperationService.changeCard(params);
        }catch(Exception e){
            e.printStackTrace();
            return ReturnResult.error("变更失败");
        }
        return ReturnResult.success("变更成功");
    }

    @PostMapping("/addRechargeOperationRecord")
    public Map<String,Object> addRechargeOperationRecord(@RequestBody Map<String,Object> params){
        logger.info("新增用户账户/卡账户（充值/冲正）操作记录参数 params=" + params);
        Map<String,Object> map = new HashMap<>();
        FrontRechargeOperation frontRechargeOperation = new FrontRechargeOperation();
        frontRechargeOperation.setId(UUIDUtils.getUUID());
        frontRechargeOperation.setTradeNum(ParamClassUtils.getParams(params.get("tradeNum"))); // 交易流水号
        frontRechargeOperation.setTransId(ParamClassUtils.getParams(params.get("transId"))); // 银行发送过来的流水号
        frontRechargeOperation.setChannelNum(ParamClassUtils.getParams(params.get("channelNum"))); // 渠道号
        frontRechargeOperation.setChannelType(ParamClassUtils.getParams(params.get("channelType"))); // 渠道类型
        frontRechargeOperation.setChannelName(ParamClassUtils.getParams(params.get("channelName"))); // 渠道名称
        frontRechargeOperation.setSiteName(ParamClassUtils.getParams(params.get("siteName"))); // 站点名称
        frontRechargeOperation.setEmployeeNo(ParamClassUtils.getParams(params.get("employeeNo"))); // 操作员工编号
        frontRechargeOperation.setCreateBy(ParamClassUtils.getParams(params.get("createBy"))); // 操作人
        // 类型（用户账户充值0/冲正1、卡账户充值2/冲正3）
        int operationType = Integer.parseInt(ParamClassUtils.getParams(params.get("operationType")));
        if (operationType == 0){  // 用户账户充值
            frontRechargeOperation.setCertificateNumber(ParamClassUtils.getParams(params.get("certificateNumber"))); // 证件编号
            frontRechargeOperation.setClientNo(ParamClassUtils.getParams(params.get("accountSubjectNo"))); // 客户号
            frontRechargeOperation.setClientName(ParamClassUtils.getParams(params.get("clientName"))); // 客户名称
            frontRechargeOperation.setClientType(Integer.parseInt(ParamClassUtils.getParams(params.get("clientType")))); // 客户类型
            frontRechargeOperation.setOperationType(operationType); // 操作类型
        }
        if (operationType == 1){ // 用户账户冲正
            frontRechargeOperation.setCertificateNumber(ParamClassUtils.getParams(params.get("certificateNumber"))); // 证件编号
            frontRechargeOperation.setClientNo(ParamClassUtils.getParams(params.get("accountSubjectNo"))); // 客户号
            frontRechargeOperation.setClientName(ParamClassUtils.getParams(params.get("clientName"))); // 客户名称
            frontRechargeOperation.setClientType(Integer.parseInt(ParamClassUtils.getParams(params.get("clientType")))); // 客户类型
            frontRechargeOperation.setOperationType(operationType); // 操作类型
        }
        if (operationType == 2){ // 卡账户充值
            frontRechargeOperation.setCertificateNumber(ParamClassUtils.getParams(params.get("certificateNumber")));
            frontRechargeOperation.setClientNo(ParamClassUtils.getParams(params.get("accountSubjectNo")));
            frontRechargeOperation.setClientName(ParamClassUtils.getParams(params.get("clientName")));
            frontRechargeOperation.setClientType(Integer.parseInt(ParamClassUtils.getParams(params.get("clientType"))));
            frontRechargeOperation.setCardId(ParamClassUtils.getParams(params.get("cardId")));
            frontRechargeOperation.setOperationType(operationType);
        }
        if (operationType == 3){ // 卡账户冲正
            frontRechargeOperation.setCertificateNumber(ParamClassUtils.getParams(params.get("certificateNumber")));
//            frontRechargeOperation.setClientNo(ParamClassUtils.getParams(params.get("clientNo")));
            frontRechargeOperation.setClientName(ParamClassUtils.getParams(params.get("clientName")));
            frontRechargeOperation.setClientType(Integer.parseInt(ParamClassUtils.getParams(params.get("clientType"))));
            frontRechargeOperation.setCardId(ParamClassUtils.getParams(params.get("cardId"))); // 卡号
            frontRechargeOperation.setOperationType(operationType);
        }
        // 充值方式/冲正类型,0现金,1POS,2转账,3电商,4卡券(卡充值没有转账)
        int rechargeType = 0;
        if (operationType == 0 || operationType == 2){
            // 充值类型为chargeType
            rechargeType = Integer.parseInt(ParamClassUtils.getParams(params.get("chargeType")));
            frontRechargeOperation.setRechargeType(rechargeType); // 充值方式
        }
        if (operationType == 1 || operationType == 3){
            // 冲正中记录其充值方式字段为rechargeType
            rechargeType = Integer.parseInt(ParamClassUtils.getParams(params.get("rechargeType")));
            frontRechargeOperation.setRechargeType(rechargeType); // 充值方式
        }
        // 非现金充值/冲正
        if (rechargeType == 1 || rechargeType == 2 || rechargeType ==3 || rechargeType == 4){
            // 针对不同的冲正类型，还得返还其需要返还的金额或状态
            frontRechargeOperation.setRechargeNum(ParamClassUtils.getParams(params.get("rechargeNum"))); // 充值,非现金的充值"特征号码"
            // FIXME   POS，暂不作处理
            // TODO 转账,需返回转账金额
            // TODO 电商,需返回消耗的订单金额
            // TODO 卡券,需重置卡券状态为已启用
        }
        // 如果是用户账户充值/冲正
        if (operationType ==0 || operationType == 1){
            int accountNum = 0;
            if (operationType == 0){ // 用户账户充值
                Double d = Double.parseDouble(ParamClassUtils.getParams(params.get("accountBalance")));
                accountNum = (int)(d*100);
            }
            if (operationType == 1){ // 用户账户冲正
                accountNum = Integer.parseInt(ParamClassUtils.getParams(params.get("preOperationBalance"))); // 冲正用户账户余额
            }
            frontRechargeOperation.setAccountBalance(accountNum); // 充值/冲正前的账户余额
        }
        // 如果是卡账户充值/冲正
        if (operationType == 2 || operationType == 3){
            int cardNum = 0;
            if(operationType == 2){ // 卡账户充值
                Double d = Double.parseDouble(ParamClassUtils.getParams(params.get("cardAccountBalance")));
                cardNum = (int)(d*100);
            }
            if(operationType == 3){ // 卡账户冲正
                cardNum = Integer.parseInt(ParamClassUtils.getParams(params.get("preOperationBalance"))); // 冲正卡账户余额
            }
            frontRechargeOperation.setAccountBalance(cardNum); // 充值/冲正前的卡账户余额
        }
        // 充值金额需换算成分的单位，冲正金额不需要
        Double rechargeNum = 0D;
        int chargeAmount = 0;
        if (operationType == 0 || operationType == 2){ // 充值
            rechargeNum = Double.parseDouble((String) params.get("chargeAmount"));
            chargeAmount = (int) (rechargeNum * 100); // 单位精确到分
        }
        if (operationType == 1 || operationType == 3){ // 冲正
            chargeAmount = Integer.parseInt(ParamClassUtils.getParams(params.get("operationAmount")));
        }
        if (rechargeType == 0 || rechargeType == 1 || rechargeType == 2 || rechargeType == 3){ // POS、转账、电商
            frontRechargeOperation.setPaidAmount(chargeAmount); // 支付金额/实收金额
            frontRechargeOperation.setGiftAmount(0); // 赠送金额
            frontRechargeOperation.setRechargeAmount(chargeAmount); // 充值金额/冲正金额
        }
        if (rechargeType == 4){ // 体验券
            frontRechargeOperation.setPaidAmount(0); // 支付金额/实收金额
            frontRechargeOperation.setGiftAmount(0); // 赠送金额
            frontRechargeOperation.setRechargeAmount(chargeAmount); // 充值金额/冲正金额
        }
        if (rechargeType == 5) { // 银行增值充值
            frontRechargeOperation.setPaidAmount((Integer) params.get("paidAmount"));
            frontRechargeOperation.setGiftAmount(0); // 赠送金额
            frontRechargeOperation.setRechargeAmount((Integer) params.get("rechargeAmount"));
        }
        frontRechargeOperation.setAmountUpper((String) params.get("AmountUpper")); // 金额大写
        frontRechargeOperation.setTradeTime(new Date());
        if (operationType == 1 || operationType == 3){
            frontRechargeOperation.setCorrectReason(ParamClassUtils.getParams(params.get("correctReason"))); // 冲正原因
        }
        // 取出需要新增记录的参数
        int result = frontRechargeOperationService.addRechargeOperationRecord(frontRechargeOperation);
        if (result <= 0){
            logger.error("新增充值/冲正操作记录失败");
            return ReturnResult.error("新增操作记录失败");
        }
        logger.info("新增充值/冲正操作记录成功");
        return ReturnResult.success("新增操作记录成功");
    }

}
