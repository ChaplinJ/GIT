package com.owinfo.service.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.owinfo.object.entity.TicketManage;
import com.owinfo.service.core.service.TicketManageService;
import com.owinfo.service.util.PageDataUtils;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.ValidateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月16日
 *         github : https://github.com/rexlin600/
 * @Description 卡券管理模块
 */
@RestController
@RequestMapping("/finance/back/business")
@CrossOrigin(maxAge = 3600,origins = "*")
public class TicketController {

    private static Logger logger = Logger.getLogger(TicketController.class);

    @Autowired
    private TicketManageService ticketService;

    /**
     * 卡券管理--分页查询/模糊查询
     * @param params
     * @return
     */
    @PostMapping("/getTicketList")
    public Map<String,Object> getTicketList(@RequestBody Map<String,Object> params){
        logger.info("请求参数为 params= " + params);
        // 请求参数不能为空
        boolean flag = ValidateUtils.isEmpty(params);
        if (flag){
            return ReturnResult.error("传入参数为空！");
        }
        // 获取分页参数、设置分页查询Start
        int page = (int) params.get("page");
        int pageSize = (int) params.get("pageSize");
        PageHelper.startPage(page,pageSize);
        // 执行分页查询返回分页数据 pageInfo
        List<TicketManage> ticketManageList = ticketService.getTicketList(params);
        PageInfo<TicketManage> pageInfo = new PageInfo<>(ticketManageList);
        // 组装返回的分页查询结果 pageBean
        Map<String,Object> pageBean = PageDataUtils.pagePut(pageInfo.getTotal()
                ,pageInfo.getPageSize()
                ,pageInfo.isIsFirstPage()
                ,pageInfo.isIsLastPage()
                ,pageInfo.getPageNum()
        );
        // 将分页查询List放入pageBean对象中
        pageBean.put("ticketList",pageInfo.getList());
        logger.info("分页查询结果为：" + pageInfo.getList().toString());
        return ReturnResult.successResult("获取卡券管理数据成功",pageBean);
    }

    /**
     * 变更卡券状态：启用、变更    销售状态 0 未启用 1 未使用 2已使用 3已作废
     * @param params
     * @return
     */
    @PostMapping("/changeTicketStatus")
    public Map<String,Object> changeTicketStatus(@RequestBody Map<String,Object> params){
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        // 获取变更类型（0 启用 1 变更）、销售类型
        int changeType = (int) params.get("changeType");
        int saleType = (int) params.get("saleType");
        // 如果是启用则加入启用时间、更新时间、销售类型（0 售出 1 赠送）
        if (changeType == 0){
            params.put("startTime",simpleDateFormat.format(date));
            params.put("updateTime",simpleDateFormat.format(date));
            // 选择售出[参数里包含saleMoney]、将saleStatus设置为1 未使用
            if (saleType == 0){  //售出
                params.put("saleStatus","1");

                Double amount = 0D;
                amount = Double.valueOf((String) params.get("saleMoney"));
                int saleMoney = (int) (amount*100);
                params.put("saleMoney",saleMoney);
            }
            // 选择赠送
            if (saleType == 1){
                params.put("saleStatus","1");
                params.put("saleMoney","0");
            }
        }
        // 如果是变更则修改更新时间、销售类型
        if (changeType == 1){
            params.put("updateTime",simpleDateFormat.format(new Date()).toString());
            // 如果是售出不做处理[参数里包含saleMoney]，如果是赠送则将之前的saleMoney置为0
            if (saleType == 1){  //赠送
                params.put("saleMoney","0");
            }
            if(saleType == 0){ //如果是售出
                Double amount = 0D;
                amount = Double.valueOf((String) params.get("saleMoney"));
                int saleMoney = (int) (amount*100);
                params.put("saleMoney",saleMoney);
            }
        }
        // 更新卡券结果result初始化
        int result = 0;
        // 执行卡券更新
        result = ticketService.changeTicketStatus(params);
        if (result <= 0){
            logger.error("请求参数不正确，请核对！ params= " + params.toString());
            return ReturnResult.error("请求参数不正确，请核对!");
        }
        logger.info("更新卡券状态成功");
        return ReturnResult.success("更新卡券状态成功！");
    }

    /**
     * 验证卡券编号和密码
     * @param params
     * @return
     */
    @PostMapping("/validateTicket")
    public Map<String,Object> validateTicket(@RequestBody Map<String,Object> params){
        logger.info("验证卡券编号和密码参数 params= " + params);
        Map<String,Object> data = new HashMap<>(3);
        boolean validateFlag = ValidateUtils.isEmpty(params);
        if (validateFlag && params.size() != 2){
            return ReturnResult.error("传入参数有误");
        }

        // 验证前台是否传递待使用的卡券类型,即系统必须知道前台页面功能是要使用什么类型的卡券,否则无匹配判断
        int ticketType = Integer.parseInt(ParamClassUtils.getParams(params.get("ticketType")));
        if (ValidateUtils.isEmpty(ticketType)){
            logger.error("没有卡券类型 ticketType=" + ticketType);
            return ReturnResult.error("卡券类型异常");
        }

        // 验证卡号和密码
        int ticketFaceValue = 0;
        try{
            TicketManage ticketManage = ticketService.validateTicket(params);
            if (ValidateUtils.isEmpty(ticketManage)){
                logger.error("校验失败，不存在这个已启用的有效卡券 ticketManage=" + ticketManage);
                return ReturnResult.error("请核对卡号和密码");
            }

            // 使用时的卡券类型不匹配也不允许通过校验
            int ticketTypes = Integer.parseInt(ticketManage.getTicketType());
            if (ticketType != ticketTypes){
                logger.error("需要使用的卡券和实际卡券类型不匹配， ticketType=" + ticketType + " ticketTypes=" + ticketTypes);
                if (ticketTypes == 1){
                    return ReturnResult.error("这是一张电子标签券");
                }else if(ticketTypes == 2){
                    return ReturnResult.error("这是一张充值宝券");
                }else if(ticketTypes == 3){
                    return ReturnResult.error("这是一张中原通卡券");
                }else if(ticketTypes == 4){
                    return ReturnResult.error("这是一张充值卷券");
                }
                return ReturnResult.error("这是一张加油券");
            }

            // 不同类型的券应该做不同处理
            if (ticketManage.getSaleStatus().equals("0")){
                logger.info("<==  该卡券未被启用");
                return ReturnResult.error("该卡券未被售出,不能进行消费");
            }
            if(ticketManage.getSaleStatus().equals("2")){
                logger.info("<==  该卡券已被使用");
                return ReturnResult.error("该卡券已被使用,无法再次消费");
            }
            // 卡券面值
            ticketFaceValue = ticketManage.getTicketFaceValue();
        } catch (Exception e){
            return ReturnResult.error("校验失败");
        }
        if (ticketFaceValue <= 0){
            return ReturnResult.error("充值券无效");
        }
        // 返回验证的结果
        data.put("ticketFaceValue",ticketFaceValue);
        logger.info("该卡券所对应的面值 ticketFaceValue= " + ticketFaceValue);
        return ReturnResult.successResult("充值券有效",data);
    }

    @PostMapping("/addTicket")
    public int addTicket(@RequestBody List<TicketManage> list){
        if (ValidateUtils.isEmpty(list)){
            return 0;
        }
        int addTicketResult =  ticketService.addTicket(list);
        if (addTicketResult <= 0){
            return 0;
        }
        return addTicketResult;
    }

    /**
     * 验证卡券是否存在
     * @param params
     * @return
     */
    @PostMapping("/validateExitTicket")
    public boolean  validateExitTicket(@RequestBody Map<String,Object> params){
        /**
         * 只要有一条数据验证没通过,则返回false
         * true 有这个卡券,反之没有这个卡券
         */
        String ticketNo = (String) params.get("ticketNo");
        TicketManage ticketManage = ticketService.validateExitTicket(ticketNo);
        /**
         * 如果tickeManage为空,则说明没有这个卡券,返回false
         */
        if (ValidateUtils.isEmpty(ticketManage)){
            logger.info(" <-- 可以导入卡券 " + ticketNo);
            return false;
        }
        logger.info(" <-- 不可以导入卡券 " + ticketNo);
        return true;
    }


    /**
     * 1：用户充值时、验证卡券编号和密码通过后允许使用卡券
     * 2：回收卡券，用户充值使用后回收、新增回收人、回收时间
     * @return
     */
    @PostMapping("/recoveryTicket")
    public Map<String,Object> recoveryTicket(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法recoveryTicket的参数::" + params);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tickeNo = (String) params.get("ticketNo");
//        String password = params.get("");
        int ticketTypeUse = Integer.parseInt(ParamClassUtils.getParams(params.get("ticketType")));
        logger.info(" <-- 卡券编号为=" + tickeNo);
        TicketManage ticketManage = ticketService.validateExitTickets(tickeNo);
        if (ValidateUtils.isEmpty(ticketManage)){
            logger.error("不存在这张卡券 ticketManage=" + ticketManage);
            return ReturnResult.error("不存在这张卡券");
        }
        int ticketTypeUses = Integer.parseInt(ticketManage.getTicketType());
        if (ticketTypeUse == 1){
            if ((ticketTypeUse != ticketTypeUses) && (ticketTypeUses != 2) && (ticketTypeUses != 3) && (ticketTypeUses != 4)){
                logger.error(" <-- 此卡券仅限用于加油");
                return ReturnResult.error("此卡券仅限用于加油");
            }
        }
        if (ticketTypeUse == 2){
            if ((ticketTypeUse != ticketTypeUses) && (ticketTypeUses != 1) && (ticketTypeUses != 3) && (ticketTypeUses != 5)){
                logger.error(" <-- 此卡券仅限用于充值");
                return ReturnResult.error("此卡券仅限用于充值");
            }
        }
        if (ticketTypeUse == 3){
            if ((ticketTypeUse != ticketTypeUses) && (ticketTypeUses != 1) && (ticketTypeUses != 4) && (ticketTypeUses != 5)){
                logger.error(" <-- 此卡券仅限用于买充值宝");
                return ReturnResult.error("此卡券仅限用于买充值宝");
            }
        }
        if (ticketTypeUse == 4){
            if ((ticketTypeUse != ticketTypeUses) && (ticketTypeUses != 2) && (ticketTypeUses != 1) && (ticketTypeUses != 5)){
                logger.error(" <-- 此卡券仅限用于买中原通卡");
                return ReturnResult.error("此卡券仅限用于中原通卡");
            }
        }
        if (ticketTypeUse == 5){
            if ((ticketTypeUse != ticketTypeUses) && (ticketTypeUses != 2) && (ticketTypeUses != 3) && (ticketTypeUses != 4)){
                logger.error(" <-- 此卡券仅限用于买标签");
                return ReturnResult.error("此卡券仅限用于买标签");
            }
        }

        // 新增回收时间、更新时间
        params.put("recoveryTime",simpleDateFormat.format(new Date()).toString());
        params.put("updateTime",simpleDateFormat.format(new Date()).toString());
        // 更改销售状态为已回收
        params.put("saleStatus","2");
        // 回收结果 recoveryResult
        int recoveryResult = ticketService.recoveryTicket(params);
        if (recoveryResult == 1){
            logger.info("回收卡券"+ tickeNo +"成功");
            return ReturnResult.success("回收卡券 "+ tickeNo +" 成功");
        }
        logger.info("回收卡券"+ tickeNo +"失败");
        return ReturnResult.error("回收卡券 "+ tickeNo +" 失败");
    }

}
