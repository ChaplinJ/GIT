package com.owinfo.service.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.owinfo.object.entity.TransferAccountsManage;
import com.owinfo.service.core.service.TransferAccountsManageService;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2017年10月17日
 *         github : https://github.com/rexlin600/
 * @Description 后台系统--转账管理
 * @更改 PJJ 2018-3-13
 */
@RestController
@RequestMapping("/finance/back/transfer")
@CrossOrigin(maxAge = 3600,origins = "*")
public class TransferController {

    private static Logger logger = Logger.getLogger(TransferController.class);

    private static final  String ZERO = "0";
    private static final  String FIRST = "1";
    private static final  String SECOND = "2";

    @Autowired
    private TransferAccountsManageService transferService;

    /**
     * 转账管理--分页查询、模糊查询
     * @param params
     * 必须参数[page、pageSize]
     * 可选参数[inputStart、inputEnd、transferUse、consumeStatus、customerName]
     * @return
     */
    @PostMapping("/getTransferList")
    public Map<String,Object> getTransferList(@RequestBody Map<String, Object> params){
        logger.info("请求参数为 params= " + params);
        String inputStart = (String)params.get("inputStart");
        String inputEnd = (String) params.get("inputEnd");
        if (!"".equals(inputStart) && !"".equals(inputEnd) &&
                inputStart != null && inputEnd != null) {
            params.put("inputStart", inputStart + " 00:00:00");
            params.put("inputEnd", inputEnd + " 23:59:59");
        }
        if (ValidateUtils.isEmpty(params)) return ReturnResult.error("传入参数为空");
        // 获取分页参数准备分页查询Start
        int page = (int)params.get("page");
        int pageSize = (int)params.get("pageSize");
//        int page = Integer.parseInt((String)params.get("page"));
//        int pageSize = Integer.parseInt((String)params.get("pageSize"));
        logger.info("开始分页");
        PageHelper.startPage(page,pageSize);
        // 分页查询结果pageInfo
        List<TransferAccountsManage> transferAccountsManageList = transferService.getTransferList(params);
        PageInfo<TransferAccountsManage> pageInfo = new PageInfo<>(transferAccountsManageList);
        // 组装返回的分页查询结果
        Map<String,Object> pageBean = PageDataUtils.pagePut(pageInfo.getTotal()
                ,pageInfo.getPageSize()
                ,pageInfo.isIsFirstPage()
                ,pageInfo.isIsLastPage()
                ,pageInfo.getPageNum()
        );
        // 将分页查询到的数据放入List中
        pageBean.put("transferList",pageInfo.getList());
        logger.info("获取分页的数据为：" + pageInfo.getList().toString());
        return ReturnResult.successResult("分页查询转账管理数据成功",pageBean);
    }

    /**
     * 修改转账 TODO 转账随机码不能重复，导入时要验证，未消费的才能修改
     * @author PJJ 2018-3-13
     * @param transferDto
     * @return
     */
    @PostMapping("/updateTransfer")
    public Map<String, Object> updateTransfer(@RequestBody TransferAccountsManageDto transferDto) {
        if (!transferDto.isCharge()) {
            transferDto.setRechargeAmount("");
        }
        if (!transferDto.isObu()) {
            transferDto.setObuName(null);
            transferDto.setObuNum("");
            transferDto.setObuPrice("");
        }
        if (!transferDto.isTreasure()) {
            transferDto.setTreasureName(null);
            transferDto.setTreasureNum("");
            transferDto.setTreasurePrice("");
        }
        logger.info("请求参数 params= " + transferDto.toString());
        if (transferDto.getId() == null) return ReturnResult.error("请输入转账订单号");
        TransferAccountsManage transferAccountsManage = transferService.getTransAccountManage(transferDto.getId());
        //通过订单ID查询，是否存在并且未消费
        if (transferAccountsManage == null) return ReturnResult.error("该笔转账记录不存在");
        if (transferAccountsManage.getConsumeStatus() != 0 ) return ReturnResult.error("已消费转账订单不能修改");
        Map<String, Object> validateBean = ValidateUtils.validateBean(transferDto, 1);
        //通过code判断位0，验证失败
        if ((Integer)validateBean.get("code") == 0) return validateBean;
        //验证成功，获取transferUse，然后赋值导入数据
        transferAccountsManage.setId(transferDto.getId());
        //注意：后台金额和单价均是按分存储
        transferAccountsManage.setTransferAmount(Integer.valueOf(MoneyUtil.mul(transferDto.getTransferAmount(), "100", 0)));
        transferAccountsManage.setCustomerName(transferDto.getCustomerName());
        transferAccountsManage.setConsumeStatus(0);//0、未消费 1、消费中 2、消费完
        transferAccountsManage.setTransferUse(String.valueOf(validateBean.get("transferUse")));
        try {
            transferAccountsManage.setTransferTime(new SimpleDateFormat("yyyy-MM-dd").parse(transferDto.getTransferTime()));
        } catch (Exception e) {
            return ReturnResult.error("转账日期格式为yyyy-MM-dd");
        }
        transferAccountsManage.setOilAmount(Integer.valueOf(MoneyUtil.mul("100",transferDto.getOilAmount(),0)));
        transferAccountsManage.setSufOilAmount(Integer.valueOf(MoneyUtil.mul("100",transferDto.getOilAmount(),0)));
        transferAccountsManage.setRechargeAmount(Integer.valueOf(MoneyUtil.mul(transferDto.getRechargeAmount(), "100", 0)));
        transferAccountsManage.setSufRechargeAmount(Integer.valueOf(MoneyUtil.mul(transferDto.getRechargeAmount(), "100", 0)));
        transferAccountsManage.setObuName(transferDto.getObuName());
        transferAccountsManage.setObuNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getObuNum())));
        transferAccountsManage.setObuPrice(Integer.valueOf(MoneyUtil.mul(transferDto.getObuPrice(), "100", 0)));
        transferAccountsManage.setSufObuNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getObuNum())));
        transferAccountsManage.setTreasureName(transferDto.getTreasureName());
        transferAccountsManage.setTreasurePrice(Integer.valueOf(MoneyUtil.mul("100", transferDto.getTreasurePrice(), 0)));
        transferAccountsManage.setTreasureNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getTreasureNum())));
        transferAccountsManage.setSufTreasureNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getTreasureNum())));
        transferAccountsManage.setUpdateBy(transferAccountsManage.getInputPerson());
        transferAccountsManage.setUpdateTime(new Date());
        transferAccountsManage.setSpare1(transferDto.getSpare1());
        transferAccountsManage.setSpare2(transferDto.getSpare2());
        transferAccountsManage.setSpare3(transferDto.getSpare3());
        int result = transferService.updateTransAccount(transferAccountsManage);
        if (result < 0) return ReturnResult.error("后台数据处理异常，修改转账失败");
        return ReturnResult.success("修改转账成功");
    }

    /**
     * 录入转账 TODO 转账随机码不能重复，导入时要验证
     * @author PJJ 2018-3-13
     * @param transferDto
     * @return
     */
    @PostMapping("/addTransfer")
    public Map<String,Object> addTransfer(@RequestBody TransferAccountsManageDto transferDto){
        logger.info("请求参数 params= " + transferDto.toString());
        Map<String, Object> validateBean = ValidateUtils.validateBean(transferDto, 1);
        //通过code判断位0，验证失败
        if ((Integer)validateBean.get("code") == 0) return validateBean;
        //验证成功，获取transferUse，然后赋值导入数据
        TransferAccountsManage transferAccountsManage = new TransferAccountsManage();
        //获取随机码并验重，重复则重新提交
        String random = UUIDUtils.getSixRandom();
        TransferAccountsManage haveRandom = transferService.haveRandom(random);
        if (haveRandom != null) return ReturnResult.error("获取随机码重复，请重新提交");
        transferAccountsManage.setRandom(random);
        transferAccountsManage.setId(UUIDUtils.getUUID());
        transferAccountsManage.setInputTime(new Date());
        //1、充值2、电子标签3、充值宝4、充值+电子标签5、充值+充值宝6、电子标签+充值宝7、充值+电子标签+充值宝
        transferAccountsManage.setTransferUse(String.valueOf(validateBean.get("transferUse")));
        //注意：后台金额和单价均是按分存储
        transferAccountsManage.setTransferAmount(Integer.valueOf(MoneyUtil.mul(transferDto.getTransferAmount(), "100", 0)));
        transferAccountsManage.setCustomerName(transferDto.getCustomerName());
        transferAccountsManage.setInputPerson(transferDto.getInputPerson());
        transferAccountsManage.setConsumeStatus(0);//0、未消费 1、消费中 2、消费完
        transferAccountsManage.setRemove(0);//0、正常状态 1、逻辑删除
        try {
            transferAccountsManage.setTransferTime(new SimpleDateFormat("yyyy-MM-dd").parse(transferDto.getTransferTime()));
        } catch (Exception e) {
            return ReturnResult.error("转账日期格式为yyyy-MM-dd");
        }
        transferAccountsManage.setOilAmount(Integer.valueOf(MoneyUtil.mul("100",transferDto.getOilAmount(),0)));
        transferAccountsManage.setSufOilAmount(Integer.valueOf(MoneyUtil.mul("100",transferDto.getOilAmount(),0)));
        transferAccountsManage.setRechargeAmount(Integer.valueOf(MoneyUtil.mul(transferDto.getRechargeAmount(), "100", 0)));
        transferAccountsManage.setSufRechargeAmount(Integer.valueOf(MoneyUtil.mul(transferDto.getRechargeAmount(), "100", 0)));
        transferAccountsManage.setObuName(transferDto.getObuName());
        transferAccountsManage.setObuNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getObuNum())));
        transferAccountsManage.setObuPrice(Integer.valueOf(MoneyUtil.mul(transferDto.getObuPrice(), "100", 0)));
        transferAccountsManage.setSufObuNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getObuNum())));
        transferAccountsManage.setTreasureName(transferDto.getTreasureName());
        transferAccountsManage.setTreasurePrice(Integer.valueOf(MoneyUtil.mul("100", transferDto.getTreasurePrice(), 0)));
        transferAccountsManage.setTreasureNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getTreasureNum())));
        transferAccountsManage.setSufTreasureNum(Integer.valueOf(MoneyUtil.nullToZero(transferDto.getTreasureNum())));
        transferAccountsManage.setSpare1(transferDto.getSpare1());
        transferAccountsManage.setSpare2(transferDto.getSpare2());
        transferAccountsManage.setSpare3(transferDto.getSpare3());
        int result = transferService.insertTransfer(transferAccountsManage);
        if (result < 0) return ReturnResult.error("后台数据处理异常，录入转账失败");
        return ReturnResult.success("录入转账成功");
    }

    /**
     * 删除转账 单笔+批量同一个接口
     * @author PJJ 2018-3-13
     * @param params
     * @return
     */
    @PostMapping("/deleteTransfers")
    public Map<String,Object>  deleteTransfers(@RequestBody Map<String,Object> params){
        logger.info("请求参数 params= " + params);
        // 转账数组，id数组
        ArrayList<String> transferNos = (ArrayList) params.get("transferNos");
        if (ValidateUtils.isEmpty(transferNos)){
            return ReturnResult.error("批量删除参数为空");
        }
        // 如果某个订单已消费则不允许这个订单删除
        for (String str : transferNos){
            TransferAccountsManage transferAccountsManage = new TransferAccountsManage();
            transferAccountsManage = transferService.getTransAccountManage(str);
            if (transferAccountsManage == null) return ReturnResult.error("没有此笔转账记录，请联系管理员核对");
            // 验证是否还有余量,消费中或者消费完毕不能删除
            if (transferAccountsManage.getConsumeStatus() != 0){
                logger.error(" <-- 转账记录已消费,无法删除");
                return ReturnResult.error("转账记录已消费,无法删除");
            }
        }
        //如果都没有消费的情况下才能执行批量删除
        for (String str : transferNos) {
            TransferAccountsManage transferAccountsManage = new TransferAccountsManage();
            transferAccountsManage.setId(str);
            transferAccountsManage.setRemove(1);
            int result = transferService.updateTransAccount(transferAccountsManage);
            if (result < 0) {
                logger.error("<-- 后台数据处理异常，转账记录删除失败");
                return ReturnResult.error("后台数据处理异常，转账记录删除失败");
            }
        }
        logger.info("转账记录删除成功");
        return ReturnResult.success("转账记录删除成功");
    }

    /**
     * 校验随机码
     * 转账用途 0-充值 1-买设备 2充值+买设备
     * // TODO 转账随机码唯一，6位是否合适？
     * @param params
     * @return
     */
    @PostMapping("/validateRandom")
    public Map<String,Object> validateRandom(@RequestBody Map<String,Object> params){
        logger.info("请求参数为 params= " + params);
        // 获取random
        String random = ParamClassUtils.getParams(params.get("random"));
        String transferUse = ParamClassUtils.getParams(params.get("transferUse"));
        Map<String,Object> data = new HashMap<>(5);
        if (ValidateUtils.isEmpty(random) || ValidateUtils.isEmpty(transferUse)){
            logger.error("查询参数不正确 random=" + random + " transferUse=" + transferUse);
            return ReturnResult.error("请填写转账码");
        }
        // 验证结果 transferAccountsManage：对象
        TransferAccountsManage transferAccountsManage = transferService.haveRandom(random);
        if (ValidateUtils.isEmpty(transferAccountsManage)){
            logger.error("验证失败，没有这个转账码 transferAccountsManage=" + transferAccountsManage);
            return ReturnResult.error("不存在这个转账码或者该记录已逻辑删除");
        }
        // 页面传过来的转账用途
        //1、充值2、电子标签3、充值宝4、充值+电子标签5、充值+充值宝6、电子标签+充值宝7、充值+电子标签+充值宝
        //transferUsing 0 充值包括1，4，5，7四种返回
        //transferUsing 1 电子标签包括2、4、6、7四种返回
        //transferUsing 2 充值宝包括 3、5、6、7四种返回
        int transferUsing = Integer.parseInt(transferUse);
        if (transferUsing != 0 && transferUsing != 1 && transferUsing != 2 ){
            logger.error("没有这个转账用途 transferUsing=" + transferUsing);
            return ReturnResult.error("转账用途不匹配");
        }

        // 公司名称、剩余可充值金额、设备名称、剩余设备数量
        switch(transferUsing) {
            case 0:
                if (transferAccountsManage.getRechargeAmount() == 0) return ReturnResult.error("转账记录没有或已用完充值金额");
                logger.info("转账用途为充值 transferUsing = " + transferUsing);
                data.put("customerName", transferAccountsManage.getCustomerName());
                data.put("sufRechargeAmount", transferAccountsManage.getSufRechargeAmount().doubleValue()/100);
                break;
            case 1:
                if (transferAccountsManage.getObuNum() == 0) return ReturnResult.error("转账记录未购买或已用完电子标签");
                logger.info("转账用途为电子标签 transferUsing = " + transferUsing);
                data.put("customerName", transferAccountsManage.getCustomerName());
                data.put("obuName", transferAccountsManage.getObuName());
                data.put("obuPrice", transferAccountsManage.getObuPrice());
                data.put("sufObuNum", transferAccountsManage.getSufObuNum());
                break;
            case 2:
                if(transferAccountsManage.getTreasureNum() == 0) return ReturnResult.error("转账记录没有或已用完充值宝");
                logger.info("转账用途为充值宝 transferUsing = " + transferUsing);
                data.put("customerName", transferAccountsManage.getCustomerName());
                data.put("treasureName", transferAccountsManage.getTreasureName());
                data.put("treasurePrice", transferAccountsManage.getTreasurePrice());
                data.put("sufTreasureNum",transferAccountsManage.getSufTreasureNum());
                break;
        }
        logger.info("验证成功 transferAccountsManage= " + transferAccountsManage.toString());
        return ReturnResult.successResult("验证成功",data);
    }

    /**
     * 更新转账余额/余量
     * @param params
     * @return
     */
    @PostMapping("/updateTransferSurplys")
    public Map<String,Object> updateTransferSurplys(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法updateTransferSurplys的参数::" + params);
        /**
         * 清除Map中无效的key和value
         */
        MapRemoveNullUtil.removeNullEntry(params);
        logger.info(" --> 清除Ma中无效的key-value后updateTransferSurplys的参数::" + params);
        /**
         * 获取转账码、转账用途
         */
        String random = (String) params.get("random");
        int transferUse = Integer.parseInt(ParamClassUtils.getParams(params.get("transferUse")));
        String inputPerson = (String) params.get("inputPerson");
        logger.info(" <-- 转账码=" + random + " 转账用途 transferUse=" + transferUse);

        /**
         * 更新充值金额还是更新设备余量 transferUse 0、充值 1、电子标签 2、充值宝
         * 充值金额、使用设备
         */
        int updateType = 0;
        BigDecimal rechargeMoney = null;
        int rechargeDevice = 0;
        /**
         * 转账用途：充值、买设备（TODO 不同设备的情况的处理）
         */
        //在充值接口中写了0、充值情况(此处未使用) updateType 1、更新充值余量 2、更新电子标签余量 3、更新充值宝余量
        if(transferUse == 0) {
            String chargeAmount = (String) params.get("chargeAmount");
            logger.info(" <-- 对公转账参数 随机码=" + random + " 转账用途=" + transferUse + " 充值金额=" + chargeAmount);
            if (ValidateUtils.isEmpty(random) || ValidateUtils.isEmpty(transferUse) || ValidateUtils.isEmpty(chargeAmount)){
                logger.error("对公转账参数为空 random=" + random + " transferUse=" + transferUse);
                return ReturnResult.error("充值失败,请填写转账随机码或者充值金额");
            }
            TransferAccountsManage transferAccountsManage = transferService.haveRandom(random);
            if (transferAccountsManage == null) return ReturnResult.error("随机码对应的转账记录不存在");
            Double money = new BigDecimal(chargeAmount).doubleValue() * 100; //充值金额转换成分
            if ( transferAccountsManage.getSufRechargeAmount() < money.intValue())
                return ReturnResult.error("充值余额不足");
            transferAccountsManage.setUpdateTime(new Date());
            //消费完条件：剩余充值金额0 无标签或者标签剩余0 无充值宝或者充值宝剩余0
            if (transferAccountsManage.getSufRechargeAmount() - money == 0 &&
                    transferAccountsManage.getSufTreasureNum() == 0 && transferAccountsManage.getSufObuNum() == 0)
                transferAccountsManage.setConsumeStatus(2);
            else
                transferAccountsManage.setConsumeStatus(1);
            transferAccountsManage.setSufRechargeAmount(transferAccountsManage.getSufRechargeAmount() - money.intValue());
            int result = transferService.updateTransAccount(transferAccountsManage);
            if (result < 0) {
                logger.error(" <-- 用户账户充值更新对公转账信息失败");
                return ReturnResult.error("用户账户充值更新对公转账信息失败");
            }
            return ReturnResult.success("更新余额成功");
        }


        //开签情况默认为1个 transferUse=1
        if (transferUse == 1){
            String deviceNum = ParamClassUtils.getParams(params.get("deviceNum"));
            if (ValidateUtils.isEmpty(deviceNum)){
                logger.error(" <-- 原型中未指定电子标签数量,系统强制其每次使用一个电子标签");
                rechargeDevice = 1;
            } else{
                // FIXME 暂时认为每次只用一个，以下情况目前不会执行
                logger.info(" <-- 使用电子标签 deviceNum=" + deviceNum);
                rechargeDevice = Integer.parseInt(deviceNum);
            }
            updateType = 2;
            logger.info(" <-- 使用电子标签 rechargeDevice 为" + rechargeDevice + " 更新设备余量 updateType=" + updateType);
        }

        //transferUse=2 充值宝其他不变
        if (transferUse == 2){
            String deviceNum = ParamClassUtils.getParams(params.get("deviceNum"));
            if (ValidateUtils.isEmpty(deviceNum)){
                logger.error(" <-- 原型中未指定充值宝数量,系统强制其每次使用一个充值宝");
                rechargeDevice = 1;
            } else{
                // FIXME 暂时认为每次只用一个，以下情况目前不会执行
                logger.info(" <-- 使用设备数量 deviceNum=" + deviceNum);
                rechargeDevice = Integer.parseInt(deviceNum);
            }
            updateType = 3;
            logger.info(" <-- 使用充值宝 rechargeDevice 为" + rechargeDevice + " 更新充值宝余量 updateType=" + updateType);
        }
        /**
         * 获取转账信息
         * 数据库中这条转账记录的用处 0 充值 1、电子标签 2、充值宝 包含多种情况
         */
        TransferAccountsManage transferAccountsManage = transferService.haveRandom(random);
        if(transferAccountsManage == null) return ReturnResult.error("随机码转账记录不存在或已逻辑删除");
        /**
         * 更新充值余量
         */
        if (updateType == 1){
            Map<String,Object> map = new HashMap<>();
            /**
             * 充值金额不可大于剩余量 -1小于 0等于 1大于
             */
            if (transferAccountsManage.getSufRechargeAmount() - rechargeMoney.intValue() * 100 < 0){
                logger.error(" <-- 充值金额不可大于剩余余额");
                return ReturnResult.error("充值失败,余额不足");
            }
            /**
             * 充值后剩余金额
             */
            //TODO PJJ 暂未使用该情况
        }

        /**
         * 更新电子标签余量
         */
        if (updateType == 2){
            /**
             * 使用设备不可大于剩余可用设备
             */
            int surPlusNum = 0;
            Integer sufObuNum = transferAccountsManage.getSufObuNum();
            if (ValidateUtils.isEmpty(sufObuNum)){
                logger.error(" <-- 没有剩余可用电子标签");
                return ReturnResult.error("充值失败,没有剩余可用电子标签");
            }
            surPlusNum = sufObuNum - rechargeDevice;
            if (surPlusNum < 0){
                logger.error(" <-- 使用电子标签不可大于剩余电子标签余量");
                return ReturnResult.error("充值失败,电子标签余量不足");
            }
            /**
             * 使用后剩余设备余量
             * 更新转账剩余量参数
             *  0 失败 1 成功
             */
            transferAccountsManage.setUpdateTime(new Date());
            transferAccountsManage.setSufObuNum(surPlusNum);
            transferAccountsManage.setUpdateBy(inputPerson);
            transferAccountsManage.setUpdateTime(new Date());
            if (surPlusNum == 0 && transferAccountsManage.getSufRechargeAmount() == 0 &&
                    transferAccountsManage.getSufTreasureNum() == 0)
                transferAccountsManage.setConsumeStatus(2);
            else
                transferAccountsManage.setConsumeStatus(1);
            int result = transferService.updateTransAccount(transferAccountsManage);
            if (result == 1){
                logger.info(" <-- 更新转账剩余可用电子标签余量成功 result= " + result);
                return ReturnResult.success("使用成功");
            }
            logger.error(" <-- 更新转账剩余可用电子标签余量失败 result= " + result);
            return ReturnResult.error("使用失败");
        }

        if (updateType == 3){
            /**
             * 使用充值宝不可大于剩余可用充值宝
             */
            int surPlusNum = 0;
            Integer sufTreasureNum = transferAccountsManage.getSufTreasureNum();
            if (ValidateUtils.isEmpty(sufTreasureNum)){
                logger.error(" <-- 没有剩余可用充值宝");
                return ReturnResult.error("充值失败,没有剩余可用充值宝");
            }
            surPlusNum = sufTreasureNum - rechargeDevice;
            if (surPlusNum < 0){
                logger.error(" <-- 使用充值宝不可大于剩余充值宝余量");
                return ReturnResult.error("充值失败,充值宝余量不足");
            }
            /**
             * 使用后剩余设备余量
             * 更新转账剩余量参数
             *  0 失败 1 成功
             */
            transferAccountsManage.setUpdateTime(new Date());
            transferAccountsManage.setSufTreasureNum(surPlusNum);
            transferAccountsManage.setUpdateBy(inputPerson);
            transferAccountsManage.setUpdateTime(new Date());
            if (surPlusNum == 0 && transferAccountsManage.getSufRechargeAmount() == 0 &&
                    transferAccountsManage.getSufObuNum() == 0)
                transferAccountsManage.setConsumeStatus(2);
            else
                transferAccountsManage.setConsumeStatus(1);
            int result = transferService.updateTransAccount(transferAccountsManage);
            if (result == 1){
                logger.info(" <-- 更新转账剩余可用充值宝余量成功 result= " + result);
                return ReturnResult.success("使用成功");
            }
            logger.error(" <-- 更新转账剩余可用充值宝余量失败 result= " + result);
            return ReturnResult.error("使用失败");
        }

        logger.error(" <-- 更新转账余量失败,未知的操作类型 updateType=" + updateType);
        return ReturnResult.error("充值失败");
    }

    /**
     * 冲正时加上上次充值扣掉的金额
     * 如果remove为1,则冲正后需要将其置为0,如果是第一次充值后冲正，需要将销售状态改为未消费
     * @param params
     * @return
     */
    @PostMapping("/effectiveTransfer")
    public Map<String,Object> effectiveTransfer(@RequestBody Map<String,Object> params){
//        logger.info("==>  方法effectiveTransfer的参数::" + params);
//        String random = ParamClassUtils.getParams(params.get("random"));
//        BigDecimal operationAmount = new BigDecimal(ParamClassUtils.getParams(params.get("surplusRechargeAmount")));
//        // 根据转账码获取转账对象
//        TransferAccountsManage transferAccountsManage = transferService.validateRandom(random);
//        BigDecimal rechargeAmount = transferAccountsManage.getRechargeAmount();
//        logger.info("<==  原转账金额");
//        BigDecimal surplusRechargeAmount = transferAccountsManage.getSurplusRechargeAmount().add(operationAmount);
//        params.put("surplusRechargeAmount",surplusRechargeAmount);
//        logger.info("<==  冲正后的转账金额");
//        if (rechargeAmount.compareTo(surplusRechargeAmount) == 1){
//            logger.info("<==  原转账金额等于冲正后的转账金额,上一次充值是用户首次充值（需冲正为未消费）");
//            params.put("consumeStatus",0);
//        }
//        // 执行冲正
//        int result = transferService.effectiveTransfer(params);
//        if (result == 0){
//            logger.error("<== 冲正（转账）失败");
//            return ReturnResult.error("冲正（转账）失败");
//        }
//        logger.info("<==  冲正（转账）成功");
        return ReturnResult.error("冲正失败");
    }
}
