package com.owinfo.service.controller;

import com.owinfo.object.entity.FrontTransferenceOperation;
import com.owinfo.service.core.service.FrontTransferenceOperationService;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月08日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/finance/back/transfer/operation")
@CrossOrigin(maxAge = 3600,origins = "*")
public class TransferRecordController {

    private static final Logger logger = Logger.getLogger(TransferRecordController.class);

    @Autowired
    private FrontTransferenceOperationService frontTransferenceOperationService;

    /**
     * 新增圈存操作记录
     * @param params
     * @return
     */
    @PostMapping("/addTransferOperationRecord")
    public int addTransferOperationRecord(@RequestBody Map<String,Object> params){
        FrontTransferenceOperation frontTransferenceOperation = new FrontTransferenceOperation();
        MapRemoveNullUtil.removeNullEntry(params);
        try {
            BeanToMapUtil.convertMap(params,frontTransferenceOperation);
        } catch (IntrospectionException e) {
            logger.error("<==  新增圈存操作记录失败" + e.getMessage());
            return 0;
        } catch (IllegalAccessException e) {
            logger.error("<==  新增圈存操作记录失败" + e.getMessage());
            return 0;
        } catch (InvocationTargetException e) {
            logger.error("<==  新增圈存操作记录失败" + e.getMessage());
            return 0;
        }
        frontTransferenceOperation.setId(UUIDUtils.getUUID());
        frontTransferenceOperation.setCreateTime(new Date());
        frontTransferenceOperation.setUpdateTime(new Date());
        int result = frontTransferenceOperationService.addTransferOperationRecord(frontTransferenceOperation);
        if (result <= 0){
            logger.error("新增圈存操作记录失败");
            return 0;
        }
        logger.info("新增圈存操作记录成功");
        return 1;
    }
//
//    /**
//     * 获取最新的圈存操作记录
//     * @param params
//     * @return
//     */
//    @PostMapping("/getLastTransferOperation")
//    public Map<String,Object> getLastTransferOperation(@RequestBody Map<String,Object> params){
//        Map<String,Object> map = new HashMap<>(1);
//        String cardNo = ParamClassUtils.getParams(params.get("cardNo"));
//        FrontTransferenceOperation frontTransferenceOperation = frontTransferenceOperationService.getLastTransferRecord(cardNo);
//        if (ValidateUtils.isEmpty(frontTransferenceOperation)){
//            logger.error("不存在最新的一条圈存记录");
//            return ReturnResult.error("不存在最新的一条圈存记录");
//        }
//        map.put("transferOperation",frontTransferenceOperation);
//        logger.info("获取最新的一条圈存操作成功");
//        return ReturnResult.successResult("获取最新的一条圈存操作成功",map);
//    }

    /**
     * 补圈存记录
     * @param params
     * @return
     */
    @PostMapping("/updateTransferOperation")
    public Map<String,Object> updateTransferOperation(@RequestBody Map<String,Object> params){
        String cardNo = ParamClassUtils.getParams(params.get("cardNo"));
        int onlineSn = Integer.parseInt(ParamClassUtils.getParams(params.get("onlineSn")));
        logger.info("<==  补圈存记录参数 cardNo=" + cardNo + " onlineSn=" + onlineSn);
//        Map<String,Object> map = new HashMap<>();
//        map.put("cardNo",cardNo);
//        map.put("onlineSn",onlineSn);
        int operationResult = frontTransferenceOperationService.updateTransferOperation(cardNo,onlineSn);
        if (operationResult <= 0){
            logger.error("新增补圈存操作记录失败");
            return ReturnResult.error("补圈存操作记录失败");
        }
        logger.info("新增补圈存操作记录成功");
        return ReturnResult.success("补圈存操作记录成功");
    }

}
