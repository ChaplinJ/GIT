package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.BankRechargeOperation;
import org.springframework.stereotype.Component;

/**
* @description: 银行充值操作记录表
* @author hekunlin on 2017/11/24 16:26
*/

@Component
public interface BankRechargeOperationMapper {

    int insert(BankRechargeOperation record);

    int insertSelective(BankRechargeOperation record);
    
}