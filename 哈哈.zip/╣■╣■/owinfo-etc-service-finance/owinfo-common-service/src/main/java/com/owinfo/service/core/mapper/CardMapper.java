package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.Etccardinfo;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
* @description TODO
* @author hekunlin 2018/1/16 11:59 Version 1.0
* @param
* @return
*/
@Component
public interface CardMapper {

    Etccardinfo getCard(String cardNo);

    int updateCardAccountBalance(BigDecimal amount, String cardNo);

    int updateCardBalance(BigDecimal amount, String cardNo);

    Map<String,Object> getcar(Map<String, Object> car);

    Map<String,Object> queryCard(Map<String, Object> queryCard);

    List<Etccardinfo> getCards(String certificateNumber,String cardId);

    List<Etccardinfo> getAllCards(String spare);

}
