package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.Etcclientinfo;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

@Component
public interface EtcclientinfoMapper {

    int deleteByPrimaryKey(String id);

    int insert(Etcclientinfo record);

    int insertSelective(Etcclientinfo record);

    Etcclientinfo selectByPrimaryKey(String id);

    Etcclientinfo getUserBySpare(String spare);

    Etcclientinfo selectByUnitNo(String id);

    Etcclientinfo selectFinal(String id);

    Etcclientinfo selectByPrimaryKeyTive(Map<String, Object> map);

    int updateByPrimaryKeySelective(Etcclientinfo record);

    int updateClient(Etcclientinfo record);

    int updateAccountPass(Map<String, Object> map);

    int deleteAccount(Map<String, Object> map);

    Integer initClient();

    Etcclientinfo selectById(String id);

    int updateGroup(Etcclientinfo record);

    int updateByyx(Map<String, Object> map);

    int updateByOne(Map<String, Object> map);

}