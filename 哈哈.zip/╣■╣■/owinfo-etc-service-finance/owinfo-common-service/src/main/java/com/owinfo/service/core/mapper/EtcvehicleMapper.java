package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.Etcvehicle;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
@Component
public interface EtcvehicleMapper {

    Etcvehicle selectById(String id);

    int deleteByPrimaryKey(String id);

    int insert(Etcvehicle record);

    int insertSelective(Etcvehicle record);

    Etcvehicle selectByPrimaryKey(Map<String, Object> map);

    int updateByPrimaryKeySelective(Etcvehicle record);

    List<Etcvehicle> selectByCertificateNumber(String CertificateNumber);

    List<Etcvehicle> selecTive(Map<String, Object> map);

    int updateById(Etcvehicle record);

    int vehicleObuCardSetZero(Etcvehicle record);

    String selectStatus(Map<String, Object> map);

    int updateCardLog(Etcvehicle record);

    int updateObuLog(Etcvehicle record);

    int updateCerNo(Map<String, Object> map);

}