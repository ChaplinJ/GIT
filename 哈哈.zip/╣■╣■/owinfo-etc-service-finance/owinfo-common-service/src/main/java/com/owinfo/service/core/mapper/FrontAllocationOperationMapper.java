package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontAllocationOperation;
import org.springframework.stereotype.Component;

/**
* @description: 资金分配操作记录
* @author hekunlin on 2017/11/24 16:27
*/

@Component
public interface FrontAllocationOperationMapper {
  
    int insert(FrontAllocationOperation record);

    int insertSelective(FrontAllocationOperation record);

}