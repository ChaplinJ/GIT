package com.owinfo.service.core.mapper;

import com.owinfo.object.dto.AccountRechargeDTO;
import com.owinfo.object.dto.FinanceFlowDTO;
import com.owinfo.object.entity.FrontBillingRecord;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
* @description: 账单记录
* @author hekunlin on 2017/11/24 16:28
*/

@Component
public interface FrontBillingRecordMapper {

    int insert(FrontBillingRecord record);

    int insertSelective(FrontBillingRecord record);

    List<FinanceFlowDTO> selectFinanceFlowList(Map<String,Object> params);

    List<FinanceFlowDTO> selectEtcCardFinanceFlowList(Map<String,Object> params);

    List<FinanceFlowDTO> selectEtcAccountFinanceFlowList(Map<String,Object> params);

    List<AccountRechargeDTO> selectUserAccountRechargeList(Map<String,Object> params);

    /**
     * 获取用户账户最新一条交易记录信息(由业务层去判断是否为充值记录)
     * @param params
     * @return
     */
    FrontBillingRecord selectUserTransactionDetail(Map<String, Object> params);

    /**
     * 获取卡账户的最新一条交易记录信息(由业务层去判断是否为充值记录)
     * @param params
     * @return
     */
    FrontBillingRecord selectUserTransactionDetails(Map<String, Object> params);

    /**
     * 更新圈存账单状态
     * @param map
     * @return
     */
    int updateTransferRecord(Map<String,Object> map);

    /**
     * 补圈之后，更新圈存账单补圈存状态
     * @param map
     * @return
     */
    int updateRepairTransferRecord(Map<String,Object> map);

    /**
     * 获取最新的一条银行充值记录
     * @param params
     * @return
     */
    FrontBillingRecord getLastBankRechargeRecord(Map<String, Object> params);

    /**
     * @Author: Wei Chunlai
     * @Description: 查询用户账户、卡账户充值、转账、圈存操作记录
     * @Params:  * @param null
     * @Date: 2017/12/7 12:53
     */
    List<FrontBillingRecord> financeSelect(Map<String, Object> map);

    /**
    * @description 银行充值渠道交易流水号验重
    * @author hekunlin 2018/1/2 19:40 Version 1.0
    * @param
    * @return 
    */
    Boolean TransIdValidate(String transId);

}