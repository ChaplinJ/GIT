package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontPayBack;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public interface FrontPayBackMapper {

    int deleteByPrimaryKey(@Param("ids") ArrayList<String> ids);

    int insert(FrontPayBack record);

    int insertSelective(FrontPayBack record);

    FrontPayBack selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(FrontPayBack record);

    int updateByPrimaryKey(FrontPayBack record);

    List<FrontPayBack> getPayBackList(Map<String,Object> params);

    int updatePayBackStatus(Map<String,Object> params);

}