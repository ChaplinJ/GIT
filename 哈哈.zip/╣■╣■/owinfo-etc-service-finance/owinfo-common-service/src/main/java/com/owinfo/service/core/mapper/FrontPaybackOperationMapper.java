package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontPaybackOperation;
import org.springframework.stereotype.Component;

/**
* @description: 补交收款操作
* @author hekunlin on 2017/11/24 16:29
*/
@Component
public interface FrontPaybackOperationMapper {
    
    int insert(FrontPaybackOperation record);

    int insertSelective(FrontPaybackOperation record);

}