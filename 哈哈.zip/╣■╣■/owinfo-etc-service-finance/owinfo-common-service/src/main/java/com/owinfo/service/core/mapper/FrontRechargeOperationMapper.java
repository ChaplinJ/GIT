package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontRechargeOperation;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
* @description: 充值冲正操作记录
* @author hekunlin on 2017/11/24 16:31
*/

@Component
public interface FrontRechargeOperationMapper {

    int insert(FrontRechargeOperation record);

    int insertSelective(FrontRechargeOperation record);

    int changeCard(Map<String, Object> params);
}