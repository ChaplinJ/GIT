package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontTransferenceOperation;
import com.owinfo.object.entity.FrontTransfrenceLog;
import org.springframework.stereotype.Component;

/**
* @description: 圈存操作记录
* @author hekunlin on 2017/11/24 16:31
*/

@Component
public interface FrontTransferenceLogMapper {

    int addTransfrenceLog(FrontTransfrenceLog record);

}