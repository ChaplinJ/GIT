package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontTransferenceOperation;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
* @description: 圈存操作记录
* @author hekunlin on 2017/11/24 16:31
*/

@Component
public interface FrontTransferenceOperationMapper {

    int insert(FrontTransferenceOperation record);

    int insertSelective(FrontTransferenceOperation record);

    FrontTransferenceOperation getLastTransferOperation(String id, int onlineSn);

    int updateTransferOperations(String id);

    int updateTransferOperation(String cardNo, int onlineSn);

    int updateTransferOperationByTradeNumber(String cardNo, String tradeNum);

//    FrontTransferenceOperation getLastTransferOperationBySnAndCardId(Map<String, Object> query);
//
//    Map<String,Object> queryCard(Map<String, Object> queryCard);
//
//    Integer updateAccountBalance(Map<String, Object> updateAccountBalance);
}