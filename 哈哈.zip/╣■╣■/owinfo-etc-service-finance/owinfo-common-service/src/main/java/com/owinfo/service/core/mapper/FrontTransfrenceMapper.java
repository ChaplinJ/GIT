package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.FrontTransfrenceLog;
import org.springframework.stereotype.Component;

/**
* @description TODO
* @author hekunlin 2018/1/16 17:29 Version 1.0
* @param
* @return
*/
@Component
public interface FrontTransfrenceMapper {

    int addTransfrenceLog(FrontTransfrenceLog frontTransfrenceLog);

}
