package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.MapAgency;
import org.springframework.stereotype.Component;

@Component
public interface MapAgencyMapper {

    int insert(MapAgency record);

    int insertSelective(MapAgency record);
}