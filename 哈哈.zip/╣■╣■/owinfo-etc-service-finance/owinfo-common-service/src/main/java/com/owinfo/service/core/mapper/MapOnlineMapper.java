package com.owinfo.service.core.mapper;


import com.owinfo.object.entity.MapOnline;
import org.springframework.stereotype.Component;

@Component
public interface MapOnlineMapper {

    int deleteByPrimaryKey(String id);

    int insert(MapOnline record);

    int insertSelective(MapOnline record);

    MapOnline selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(MapOnline record);

    int updateByPrimaryKey(MapOnline record);
}