package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.OrderManage;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @description 订单管理
 * @author gongchengping
 * @version [v1.0, 2018/03/08]
 */
@Component
public interface OrderManageMapper {

    /**
     * 根据主键删除
     * @param id
     * @return
     */
    int deleteByPrimaryKey(String id);

    /**
     * 插入对象
     * @param orderManage
     * @return
     */
    int insert(OrderManage orderManage);

    /**
     * 插入对象
     * @param orderManage
     * @return
     */
    int insertSelective(OrderManage orderManage);

    /**
     * 根据主键查询
     * @param id
     * @return
     */
    OrderManage selectByPrimaryKey(String id);

    /**
     * 根据OrderNo更新
     * @param orderManage
     * @return
     */
    int updateByOrderNoSelective(OrderManage orderManage);

    /**
     * 更具OrderNo更新(全部字段)
     * @param orderManage
     * @return
     */
    int updateByOrderNo(OrderManage orderManage);

    /**
     * 根据逐渐更新
     * @param orderManage
     * @return
     */
    int updateByPrimaryKey(OrderManage orderManage);

    /**
     * 查询电商列表
     * @param params
     * @return
     */
    List<OrderManage> selectOrderList(Map<String, Object> params);

    /**
     * 验证订单号
     * @param orderNo
     * @return
     */
    OrderManage validateOrder(String orderNo);

    /**
     * 逻辑删除
     * @param orderNos
     * @return
     */
    int deleteByOrderNos(@Param("orderNos") ArrayList<String> orderNos);

    /**
     * 获取订单记录
     * @param id
     * @return
     */
    OrderManage getOrderManage(String id);

    /**
     * 获取订单记录
     * @param orderNo
     * @return
     */
    OrderManage getOrderDetail(String orderNo);

    /**
     * 更新剩余量
     * @param params
     * @return
     */
    int updateOrderSurplys(Map<String, Object> params);

    /**
     * 更新订单状态
     * @param params
     * @return
     */
    int updateOrderSaleStatus(OrderManage orderManage);

}