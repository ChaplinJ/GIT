package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.TicketManage;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
* @description: 卡券管理
* @author hekunlin on 2017/10/18 18:26
*/
@Component
public interface TicketManageMapper {

    /**
     * 根据主键删除
     * @param id
     * @return
     */
    int deleteByPrimaryKey(String id);

    /**
     * 插入
     * @param ticketManage
     * @return
     */
    int insert(TicketManage ticketManage);

    /**
     * 插入
     * @param list
     * @return
     */
    int insertSelective(List<TicketManage> list);

    /**
     * 根据主键查询
     * @param id
     * @return
     */
    TicketManage selectByPrimaryKey(String id);

    /**
     * 更新
     * @param ticketManage
     * @return
     */
    int updateByPrimaryKeySelective(TicketManage ticketManage);

    /**
     * 根据主键更新
     * @param ticketManage
     * @return
     */
    int updateByPrimaryKey(TicketManage ticketManage);

    /**
     * 查询卡券列表
     * @param params
     * @return
     */
    List<TicketManage> selectTicketList(Map<String, Object> params);

    /**
     * 启用、变更卡券状态
     * @param params
     * @return
     */
    int changeTicketStatus(Map<String, Object> params);

    /**
     * 验证卡券编号、密码
     * @param params
     * @return
     */
    TicketManage validateTicket(Map<String, Object> params);

    /**
     * 获取卡券信息
     * @param params
     * @return
     */
    TicketManage getTicket(Map<String, Object> params);

    /**
     * 回收卡券
     * @param params
     * @return
     */
    int recoveryTicket(Map<String, Object> params);

    /**
     * 验证是否存在这个卡券，返回卡券对象，导入卡券时验证
     * @param ticketNo
     * @return
     */
    TicketManage validateExitTicket(String ticketNo);

    /**
     * 验证是否存在这个卡券，返回卡券对象，回收卡券时验证
     * @param ticketNo
     * @return
     */
    TicketManage validateExitTickets(String ticketNo);

}