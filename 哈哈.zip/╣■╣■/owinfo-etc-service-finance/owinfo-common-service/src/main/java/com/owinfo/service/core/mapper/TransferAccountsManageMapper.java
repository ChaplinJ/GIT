package com.owinfo.service.core.mapper;

import com.owinfo.object.entity.TransferAccountsManage;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Mapper
@Repository
public interface TransferAccountsManageMapper {
    int deleteByPrimaryKey(String id);

    int insert(TransferAccountsManage record);

    int insertSelective(TransferAccountsManage record);

    TransferAccountsManage selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TransferAccountsManage record);

    int updateByPrimaryKey(TransferAccountsManage record);

    TransferAccountsManage haveRandom(String random);

    List<TransferAccountsManage> getTransferList(Map<String, Object> map);
}