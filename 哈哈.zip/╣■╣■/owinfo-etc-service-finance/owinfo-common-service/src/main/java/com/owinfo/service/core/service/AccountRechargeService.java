package com.owinfo.service.core.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.object.entity.OrderManage;
import com.owinfo.object.entity.TransferAccountsManage;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.util.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月29日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class AccountRechargeService {

    private static final Logger logger = Logger.getLogger(AccountRechargeService.class);

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private TransferAccountsManageService transferAccountsManageService;

    @Autowired
    private OrderManageService orderManageService;

    @Autowired
    private TicketManageService ticketManageService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    /**
    * @description 用户账户充值查询
    * @author hekunlin 2018/1/29 15:40 Version 1.0
    * @param
    * @return
    */
    public Map<String, Object> getClient(String certificateNumber){
        logger.info("<==  方法getClient的参数::" + certificateNumber + "   开始执行");

        Etcclientinfo etcclientinfo = new Etcclientinfo();

        etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
        if (etcclientinfo == null){
            logger.error("<==  证件编号[" + certificateNumber + "]不是个人用户");
            etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  证件编号[" + certificateNumber + "]未找到对应的用户信息");
                return ReturnResult.errors("未找到对应的用户信息");
            }
        }
        logger.info("<==  证件编号[" + certificateNumber + "]用户信息" + etcclientinfo.toString());

        Map<String, Object> map = new HashMap<>();
        map.put("status",1);
        map.put("msg","查询用户信息成功");
        map.put("data",etcclientinfo);

        logger.info("<==  方法getClient执行结束");
        return map;
    }

    /**
    * @description 用户账户充值
    * @author hekunlin 2018/1/29 18:58 Version 1.0
    * @param
    * @return 
    */
    @Transactional(rollbackFor = {Exception.class})
    public Map<String, Object> userAccountRecharge(@RequestBody Map<String,Object> params){
        logger.info("<==  方法userAccountRecharge的参数::" + params + "   开始执行");

        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();

        try {
            // region 用户信息
            String certificateNumber = (String) params.get("certificateNumber");

            Etcclientinfo etcclientinfo = new Etcclientinfo();
            etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  不是个人客户充值，集团客户充值");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<== 不存在这个用户信息");
                    return ReturnResult.errors("不存在这个用户信息");
                }
            }
            logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());
            // endregion

            // region 充值金额、充值类型
            Double amount = 0D;
            try {
                amount = Double.valueOf((String) params.get("chargeAmount"));
            } catch (NumberFormatException e) {
                logger.error("<==  金额转换异常 chargeAmount=" + (String) params.get("chargeAmount"));
                return ReturnResult.error("用户账户充值金额转换异常");
            }
            String chargeType = (String) params.get("chargeType");

            if (StringUtils.isEmpty(amount)){
                logger.error("<==  用户账户充值金额不能为空  amount=" + amount);
                return ReturnResult.error("用户账户充值金额为空");
            }
            if (StringUtils.isEmpty(chargeType)){
                logger.error("<==  充值类型不能为空 chargeType=" + chargeType);
                return ReturnResult.error("充值类型不能为空");
            }
            // endregion

            // region 充值金额转换、用户账户充值不需要做数据上报
            BigDecimal cardAccountBalance = etcclientinfo.getAccountBalance(); // 用户账户余额
            BigDecimal chargeAmount = BigDecimal.valueOf(amount);  // 充值金额
            // endregion

            // region 不同充值方式的处理流程
            String rechargeNum = null;
            if ("0".equals(chargeType) || "1".equals(chargeType) || "5".equals(chargeType)){  // 现金或POS的充值或其他付款方式（微信支付宝）
                if("5".equals(chargeType)){
                    String specificRechargeType = (String)params.get("specificRechargeType");
                    if("".equals(specificRechargeType)){
                        return ReturnResult.error("不能使用此付款方式进行付款，请选择另外的方式进行。");
                    }
                }
                logger.info("<==  充值方式为现金/POS充值/其他付款方式 chargeType=" + chargeType);
            }

            //TODO PJJ 2018-03-14 充值选用转账新逻辑
            if ("2".equals(chargeType)){  // 转账的方式充值
                String random = (String) params.get("random");
                String transferUse = getParams(params.get("transferUse"));
                logger.info(" <-- 对公转账参数 随机码=" + random + " 转账用途=" + transferUse + " 充值金额=" + chargeAmount);
                if (ValidateUtils.isEmpty(random) || ValidateUtils.isEmpty(transferUse)){
                    logger.error("对公转账参数为空 random=" + random + " transferUse=" + transferUse);
                    return ReturnResult.error("充值失败,请填写转账随机码");
                }
                TransferAccountsManage transferAccountsManage = transferAccountsManageService.haveRandom(random);
                Double chargeMoney = chargeAmount.doubleValue() * 100; //充值金额转换成分
                if ( transferAccountsManage.getSufRechargeAmount() < chargeMoney.intValue())
                    return ReturnResult.error("充值余额不足");
                transferAccountsManage.setUpdateTime(new Date());
                //消费完条件：剩余充值金额0 无标签或者标签剩余0 无充值宝或者充值宝剩余0
                if (transferAccountsManage.getSufRechargeAmount() - chargeMoney.intValue() == 0 &&
                        transferAccountsManage.getSufTreasureNum() == 0 && transferAccountsManage.getSufObuNum() == 0)
                    transferAccountsManage.setConsumeStatus(2);
                else
                    transferAccountsManage.setConsumeStatus(1);
                transferAccountsManage.setSufRechargeAmount(transferAccountsManage.getSufRechargeAmount() - chargeMoney.intValue());
                int result = transferAccountsManageService.updateTransAccount(transferAccountsManage);
                if (result < 0) {
                    logger.error(" <-- 用户账户充值更新对公转账信息失败");
                    return ReturnResult.error("用户账户充值更新对公转账信息失败");
                }
            }
                logger.info(" <-- 更新对公转账信息成功");
            if ("3".equals(chargeType)){  // 电商的充值
                logger.info("<==  充值方式为电商充值 chargeType=" + chargeType);
                String orderNo = (String) params.get("orderNo");
                String orderType = getParams(params.get("orderType"));

                logger.info(" <-- 电商充值参数 电商号=" + orderNo + " 电商用途=" + orderType + " 充值金额=" + chargeAmount);
                if (StringUtils.isEmpty(orderNo) || StringUtils.isEmpty(orderType)){
                    logger.error("<==  电商充值电商号和电商订单类型不能为空 orderNo=[" + orderNo + "]  orderType=[" + orderType + "]" );
                    return ReturnResult.errors("电商订单号及类型不能为空");
                }
                rechargeNum = orderNo;
                OrderManage validateOrder = orderManageService.validateOrder(orderNo); //从数据库中获取验证对应得orderManage
                Map<String,Object> orderMap = new HashMap<>();

                String orderManageType = validateOrder.getOrderType();
                /**
                 * 校验订单类型是否支持充值
                 */
                if(RegExUtil.getString(orderManageType,"(^(1)$)|(^(1,))|(,1)$|,1,") == null) {
                    logger.error(" <-- 该电商订单不支持该用途");
                    return ReturnResult.error("该电商订单不支持该用途");
                }

                /**
                 * 判断是否有余额进行充值
                 */
                int rechargeMoney =  (new BigDecimal(amount.doubleValue() + "")).multiply(new BigDecimal("100")).intValue();
                int surplusMoney = validateOrder.getSurplusRechargeMoney() - rechargeMoney;
                if(surplusMoney < 0) {
                    logger.error("<== 充值余额不足");
                    return ReturnResult.error("充值余额不足");
                }
                orderMap.put("orderNo",orderNo);
                orderMap.put("updateBy", params.get("recoveryPerson"));
                orderMap.put("updateTime", new Date());
                orderMap.put("surplusRechargeMoney",surplusMoney);

                int result = orderManageService.updateOrderSurplys(orderMap);
                if (result == 0){
                    logger.error("<==  更新电商订单号 orderNo=[" + orderNo + "] 充值金额" + amount + " 失败");
                    return ReturnResult.error("充值失败,更新电商订单失败");
                }
                logger.info("<==  更新电商订单 orderNo=[" + orderNo + "] 成功");

                if (result == 1){ //判断是否执行成功
                    /**
                     *
                     * 消费状态 0未消费，1消费中，2消费完毕
                     * 判断该条订单是否全部消费完毕,如果全部消费完毕，则需要修改
                     * saleStatus为 2
                     */
                    OrderManage orderManage = orderManageService.getOrderDetail(orderNo); //从数据库中获取这个商品订单
                    boolean saleStatus = true;

                    //充值金额
                    if(orderManage.getSurplusRechargeMoney() != null) { //充值

                        if(orderManage.getSurplusRechargeMoney() == 0) {
                            //充值金额为空
                            saleStatus = saleStatus && true;
                        } else { //还有剩余充值金额
                            saleStatus = saleStatus && false;
                        }
                    }

                    //蓝牙电子标签
                    if(orderManage.getSufObuNum() != null) { //蓝牙电子标签
                        if(orderManage.getSufObuNum() == 0) {
                            //蓝牙电子标签数量0
                            saleStatus = saleStatus && true;
                        } else {//蓝牙电子标签数量大于0
                            saleStatus = saleStatus && false;
                        }
                    }

                    //充值宝
                    if(orderManage.getSufTreasureNum() != null) {
                        if(orderManage.getSufTreasureNum() == 0) {
                            //充值宝数量0
                            saleStatus = saleStatus && true;
                        } else { //充值宝数量大于0
                            saleStatus = saleStatus && false;
                        }
                    }

                    //中石油加油
                    if(orderManage.getSufOilAmount() != null) {
                        if(orderManage.getSufOilAmount() == 0) {
                            //中石油余额0
                            saleStatus = saleStatus && true;
                        } else { //还有剩余中石油余额
                            saleStatus = saleStatus && false;
                        }
                    }

                    /**
                     * 如果消费完毕并且上次消费状态为消费中，则将电商订单状态修改为
                     * 消费完毕,否则不进行状态修改
                     */
                    if(saleStatus && orderManage.getSaleStatus() == 1) {
                        OrderManage oo = new OrderManage();
                        oo.setSaleStatus(2);
                        oo.setOrderNo(orderManage.getOrderNo());
                        int status = orderManageService.updateOrderSaleStatus(oo);
                        if(status == 1) {
                            logger.info("更新订单状态为消费完毕");
                        }
                    }
                    //return ReturnResult.success("使用成功");
                }
            }

            if ("4".equals(chargeType)){
                logger.info("<==  充值方式为体验券充值 chargeType=" + chargeType);
                Map<String,Object> ticketMap = new HashMap<>();
                String ticketNo = (String) params.get("ticketNo");
                String ticketType = getParams(params.get("ticketType"));

                logger.info(" <-- 体验券充值参数 体验券号=" + ticketNo + " 体验券用途=" + ticketType + " 充值金额=" + chargeAmount);
                if (StringUtils.isEmpty(ticketNo) || StringUtils.isEmpty(ticketType)){
                    logger.error("<==  优惠券充值券号和优惠券类型不能为空 ticketNo=[" + ticketNo + "]  ticketType=[" + ticketType + "]" );
                    return ReturnResult.errors("优惠券券号和优惠券类型不能为空");
                }

                rechargeNum = ticketType;

                ticketMap.put("ticketNo",ticketNo);
                ticketMap.put("recoveryPerson",(String) params.get("recoveryPerson"));
                ticketMap.put("recoveryTime",dateFormat.format(date));
                ticketMap.put("updateTime",dateFormat.format(date));
                ticketMap.put("updateBy",(String) params.get("recoveryPerson"));
                ticketMap.put("saleStatus",2);
                ticketMap.put("password",(String) params.get("password"));
//                ticketMap.put("ticketType",ticketType);

                int result = ticketManageService.recoveryTicket(ticketMap);
                if (result == 0){
                    logger.error("<==  更新优惠券号 ticketNo=[" + ticketNo + "] 充值金额" + amount + " 失败");
                    return ReturnResult.error("请核实卡号和密码");
                }
                logger.info("<==  更新体验券号 ticketNo=[" + ticketNo + "] 成功");
            }
            // endregion

            // region 执行用户账户充值
            Etcclientinfo etcclientinfo1 = new Etcclientinfo();
            etcclientinfo1.setSpare(etcclientinfo.getSpare());
            etcclientinfo1.setAccountBalance(chargeAmount);
            int result = etcclientinfoMapper.updateByPrimaryKeySelective(etcclientinfo1);
            if (result != 1){
                logger.error("<==  用户账户充值失败 result=[" + result + "]");
                throw new RuntimeException("用户账户充值失败");
            }
            // endregion

            // region 操作后金额计算
            Double x = etcclientinfo.getAccountBalance().doubleValue();
            int preAccountBalance = (int) (x*100);
            int operationBalance = (int) (amount*100);
            int sufAccountBalance = preAccountBalance + operationBalance;
            logger.info("<==  金额转换（单位分） 操作前金额=[" + preAccountBalance + "]  操作金额=[" +
                    operationBalance + "]  操作后金额=[" + sufAccountBalance + "]");
            // endregion

            // region 新增账单表
            logger.info("<==  用户账户[" + certificateNumber + "]新增充值账单");
            FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
            frontBillingRecord.setId(UUIDUtils.getUUID());
            frontBillingRecord.setTradeNum((String) params.get("tradeNum"));
            frontBillingRecord.setTransId((String) params.get("transId"));
            frontBillingRecord.setChannelName((String) params.get("channelName"));
            frontBillingRecord.setChannelType((String) params.get("channelType"));
            frontBillingRecord.setChannelNum((String) params.get("channelNum"));
            frontBillingRecord.setAcquirerNo((String) params.get("acquirerNo"));
            frontBillingRecord.setSiteName((String) params.get("siteName"));
            frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            frontBillingRecord.setClientName(etcclientinfo.getClientName());
            frontBillingRecord.setCertificateNumber(etcclientinfo.getSpare());
            frontBillingRecord.setAccountSubject(1);
            frontBillingRecord.setAccountSubjectNo(etcclientinfo.getSpare());
            frontBillingRecord.setAccountSubjectStatus(1);
            frontBillingRecord.setOperationType(1);
            frontBillingRecord.setRechargeType(Integer.valueOf(ParamClassUtils.getParams(params.get("chargeType"))));
            frontBillingRecord.setRechargeNum(ParamClassUtils.getParams(params.get("rechargeNum")));
            frontBillingRecord.setSpecificRechargeType((String)params.get("specificRechargeType"));
            String otherCollectionField = params.get("collectField") == null ? "" : collectField(params);
            frontBillingRecord.setOtherCollectionField(otherCollectionField);

            frontBillingRecord.setOperationMark(1);
            Double m = etcclientinfo.getAccountBalance().doubleValue();
            Double n = amount.doubleValue();
            frontBillingRecord.setPreOperationBalance((int)(m*100));
            frontBillingRecord.setOperationAmount((int)(n*100));
            frontBillingRecord.setSufOperationBalance((int)(m*100) + (int)(n*100));
            frontBillingRecord.setEmployeeNo((String) params.get("employeeNo"));
            frontBillingRecord.setOperationUser((String) params.get("createBy"));
            frontBillingRecord.setCreateBy((String) params.get("createBy"));
            frontBillingRecord.setOperationTime(date);
            frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
            // endregion

        }  catch (DuplicateKeyException e){
            logger.error("<==  唯一索引冲突,交易流水号重复 " + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ReturnResult.errors("充值失败，不允许重复充值");
        } catch (Exception e) {
            logger.error("<==  充值失败，充值异常" + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ReturnResult.errors("充值失败");
        }

        logger.info("<==  方法userAccountRecharge执行结束");
        return ReturnResult.successs("充值成功");
    }

    /**
     * 格式化采集字段
     * @param param
     * @return
     */
    public static String collectField(Map<String, Object> param) {
        List<HashMap<String, Object>> fields = (List<HashMap<String, Object>>) param.get("collectField");
        JSONArray array = new JSONArray();
        if(fields.size() > 0){
            for (HashMap<String, Object> hashMap : fields) {
                JSONObject field = new JSONObject();
                field.put("fieldNo", hashMap.get("fieldNo"));
                field.put("fieIdValue", hashMap.get("fieIdValue"));
                array.add(field);
            }
        }
        return array.toString();
    }

}
