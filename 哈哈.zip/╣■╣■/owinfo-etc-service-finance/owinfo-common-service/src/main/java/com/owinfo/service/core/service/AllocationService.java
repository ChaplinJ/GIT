package com.owinfo.service.core.service;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月23日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class AllocationService {

    private static final Logger logger = Logger.getLogger(AllocationService.class);

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private ReportFeign reportFeign;

    /**
    * @description 批量分配验证
    * @author hekunlin 2018/1/30 19:50 Version 1.0
    * @param 
    * @return 
    */
    public Map<String,Object> validateBatchPoint(Map<String,Object> params){
        logger.info("<==  方法validateBatchPoint的参数::" + params + "   开始执行");

        // region 获取用户
        String certificateNumber = (String) params.get("certificateNumber");
        logger.info("<==  用户证件编号[" + certificateNumber + "]批量分配");
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
        if (etcclientinfo == null){
            logger.info("<==  证件编号[" + certificateNumber + "]不是个人客户");
            etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  证件编号[" + certificateNumber + "]没有对应的客户信息");
                return ReturnResult.errors("未找到相关客户信息");
            }
        }
        logger.info("<==  证件编号[" + certificateNumber + "]获取用户信息成功");
        // endregion

        // region 获取该集团客户名下所有卡
        String spare = etcclientinfo.getSpare();
        List<Etccardinfo> cardList = new ArrayList<>();
        List<Etccardinfo> tempCardList = cardMapper.getAllCards(spare);
        if (tempCardList.size() == 0){
            logger.info("<==  证件编号[" + certificateNumber + "]名下没有绑定卡，卡列表[" + tempCardList + "]");
            return ReturnResult.errors("该集团客户未绑定卡");
        }
        // 卡列表数据修正
        for (int i = 0;i < tempCardList.size(); i++){
            Etccardinfo etccardinfo = tempCardList.get(i);
            if ("1".equals(etcclientinfo.getClientType())){
                etccardinfo.setClientNo(etcclientinfo.getClientNo());
                etccardinfo.setClientName(etcclientinfo.getClientName());
                etccardinfo.setClientType(etcclientinfo.getClientType());
                etccardinfo.setCertificateNumber(etcclientinfo.getCertificateNumber());
            }
            if ("2".equals(etcclientinfo.getClientType())){
                etccardinfo.setClientNo(etcclientinfo.getClientNo());
                etccardinfo.setClientName(etcclientinfo.getUnitName());
                etccardinfo.setClientType(etcclientinfo.getClientType());
                etccardinfo.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            }
            cardList.add(etccardinfo);
        }
        // endregion

        logger.info("<==  获取证件编号[" + certificateNumber + "]名下车辆数量[" + tempCardList.size() + "]");
        Map<String,Object> batchPointInfo = new HashMap<>();
        Map<String,Object> map = new HashMap<>();
        batchPointInfo.put("userMap",etcclientinfo);
        batchPointInfo.put("cardList",cardList);
        map.put("status",1);
        map.put("msg","批量分配查询验证成功");
        map.put("data",batchPointInfo);
        logger.info("<==  方法validateBatchPoint执行结束");
        return map;
    }

    /**
    * @description 批量分配
    * @author hekunlin 2018/1/30 19:51 Version 1.0
    * @param
    * @return
    */
    @Transactional(rollbackFor = {Exception.class})
    public Map<String,Object> batchTransfer(Map<String,Object> params){
        logger.info("<==  方法batchTransfer的参数::" + params + "   开始执行");

        Date date = new Date();

        /**
         * userMap 用户账户参数 cardList 用户的所有卡
         * allocatedList 待分配卡对象 ; allocatedCardList 需要批量分配的卡
         * addRecord 新增记录条数
         */
        Map<String,Object> allocatedUserMap = (Map<String, Object>) params.get("userMap");
        List originalCardList = (List) params.get("cardList");
        List allocatedCardList = (List) params.get("tempCardList");
        List tempCardList = (List) params.get("tempCardList");
        String certificateNumber = getParams(params.get("certificateNumber"));
        int addRecord = allocatedCardList.size();

        // region 获取用户账户信息
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
        if (etcclientinfo == null){
            logger.info("<==  证件编号[" + certificateNumber + "]不是个人客户");
            etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  证件编号[" + certificateNumber + "]没有相应的客户信息");
                return ReturnResult.errors("未找到相应的用户信息");
            }
        }
        int clientType = Integer.valueOf(etcclientinfo.getClientType());
        logger.info("<==  获取用户[" + certificateNumber + "]信息成功" + etcclientinfo.toString());
        // endregion

        // region 用户账户金额
        BigDecimal accountBalance = etcclientinfo.getAccountBalance();
        // 统计将要分配的金额
        BigDecimal count = BigDecimal.ZERO;
        for (int i = 0;i < allocatedCardList.size();i++){
            // 遍历tempCardList中的每一个list
            Map<String,Object> tempListMap = (Map<String, Object>) allocatedCardList.get(i);
            // 获取转账金额
            BigDecimal temp = new BigDecimal(getParams(tempListMap.get("allocateAmount")));
            // 统计转账总额
            count = count.add(temp);
        }
        // endregion

        // region 用户账户扣钱
        Etcclientinfo etcclientinfo1 = new Etcclientinfo();
        etcclientinfo1.setAccountBalance(BigDecimal.ZERO.subtract(count));
        etcclientinfo1.setSpare(etcclientinfo.getSpare());
        int resultA = etcclientinfoMapper.updateByPrimaryKeySelective(etcclientinfo1);
        if (resultA != 1){
            logger.error("<==  唯一标识[" + etcclientinfo.getSpare() + "]批量分配失败");
            throw new RuntimeException("更新用户账户余额失败，批量分配失败！");
        }
        // endregion

        // region 用户账单
        FrontBillingRecord accountRecord = new FrontBillingRecord();
        accountRecord.setId(UUIDUtils.getUUID());
        accountRecord.setTradeNum((String) params.get("tradeNum"));
        // 仅用户账户加一个transId标志唯一防止重试，不满足则事务回滚不会再向下执行
        accountRecord.setTransId((String) params.get("transId"));
        accountRecord.setChannelName((String) params.get("channelName"));
        accountRecord.setChannelType((String) params.get("channelType"));
        accountRecord.setChannelNum((String) params.get("channelNum"));
        accountRecord.setEmployeeNo((String) params.get("employeeNo"));
        accountRecord.setAcquirerNo((String) params.get("acquirerNo"));
        accountRecord.setSiteName((String) params.get("siteName"));
        accountRecord.setCreateBy((String) params.get("createBy"));
        accountRecord.setOperationUser((String) params.get("createBy"));
        accountRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        accountRecord.setClientName(etcclientinfo.getClientName());
        /*if (clientType == 1){
            accountRecord.setCertificateNumber(etcclientinfo.getCertificateNumber());
        }
        if (clientType == 2){
            accountRecord.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
        }*/
        //账单表中的certificate_number字段应该存账户表中的spare字段
        accountRecord.setCertificateNumber(etcclientinfo.getSpare());
        accountRecord.setAccountSubject(1);
        accountRecord.setAccountSubjectNo(etcclientinfo.getSpare());
        accountRecord.setAccountSubjectStatus(1);
        accountRecord.setOperationType(5);
        accountRecord.setOperationMark(2);
        // 操作前金额
        Double x = accountBalance.doubleValue();
        int pre = (int)(x*100);
        // 操作金额
        Double y = count.doubleValue();
        int ope = (int)(y*100);
        accountRecord.setPreOperationBalance(pre);
        accountRecord.setOperationAmount(ope);
        accountRecord.setSufOperationBalance(pre - ope);
        accountRecord.setOperationTime(date);
        frontBillingRecordService.addBillingOperationRecord(accountRecord);
        // endregion

        // region 卡账户加钱、卡账单
        int coun = 0;
        for (int i = 0; i < tempCardList.size(); i++) {
            Map<String,Object> tempListMap = (Map<String, Object>) tempCardList.get(i);
            // 获取卡信息
            String cardId = (String) tempListMap.get("cardId");
            Etccardinfo etccardinfo = cardMapper.getCard(cardId);
            BigDecimal cardAccountBalance = etccardinfo.getCardAccountBalance();
            if (cardAccountBalance.compareTo(BigDecimal.ZERO) == -1){
                logger.error("<==  卡号[" + cardId + "]账户余额为负数，不允许分配");
                return ReturnResult.errors("卡号[" + cardId + "]账户余额为负数，不允许分配");
            }
            BigDecimal transferBalance = new BigDecimal(getParams(tempListMap.get("allocateAmount")));
            cardMapper.updateCardAccountBalance(transferBalance,cardId);
            // 卡账单
            FrontBillingRecord cardRecord = new FrontBillingRecord();
            cardRecord.setId(UUIDUtils.getUUID());
            // 卡账单交易流水号
            cardRecord.setTradeNum((String) tempListMap.get("tradeNum"));
            cardRecord.setChannelName((String) params.get("channelName"));
            cardRecord.setChannelType((String) params.get("channelType"));
            cardRecord.setChannelNum((String) params.get("channelNum"));
            cardRecord.setEmployeeNo((String) params.get("employeeNo"));
            cardRecord.setAcquirerNo((String) params.get("acquirerNo"));
            cardRecord.setSiteName((String) params.get("siteName"));
            cardRecord.setCreateBy((String) params.get("createBy"));
            cardRecord.setOperationUser((String) params.get("createBy"));
            cardRecord.setVehicleLicense((String) tempListMap.get("vehicleLicense"));
//            cardRecord.setVehicleType()
            cardRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            cardRecord.setClientName(etcclientinfo.getClientName());
            // 卡账单证件号也存唯一标识spare
            cardRecord.setCertificateNumber(etcclientinfo.getSpare());
            cardRecord.setAccountSubject(2);
            cardRecord.setAccountSubjectNo(cardId);
            cardRecord.setAccountSubjectStatus(1);
            cardRecord.setOperationType(5);
            cardRecord.setOperationMark(1);
            // 操作前金额
            Double m = cardAccountBalance.doubleValue();
            int pres = (int)(m*100);
            // 操作金额
            Double n = transferBalance.doubleValue();
            int opes = (int)(n*100);
            cardRecord.setPreOperationBalance(pres);
            cardRecord.setOperationAmount(opes);
            cardRecord.setSufOperationBalance(pres + opes);
            cardRecord.setOperationTime(date);
            coun += frontBillingRecordService.addBillingOperationRecord(cardRecord);
            /**
             * FIXME 调用营改增接口实现数据上报
             */
            Map<String,Object> sendRechargeMap = new HashMap<>();
            logger.info("<==  营改增调用数据 paidMoney=[" + opes + "] giftMoney=[" + 0 + "] rechargeMoney="
                    + opes + "]");
            sendRechargeMap.put("id", (String) tempListMap.get("tradeNum"));
            sendRechargeMap.put("paidAmount",opes);
            sendRechargeMap.put("giftAmount","0");
            sendRechargeMap.put("rechargeAmount",opes);
            sendRechargeMap.put("cardId", cardId);
            try {
                reportFeign.sendRecharge(sendRechargeMap);
                logger.info("<==  调用营改增接口实现数据上报结束");
            } catch (Exception e) {
                logger.error("<==  卡号[" + cardId + "] 资金批量分配数据上报服务异常" + e.getMessage());
            }
        }
        // 卡账户加钱次数
        if (coun - tempCardList.size() != 0){
            logger.error("<==  唯一标识[" + etcclientinfo.getSpare() + "]批量分配失败");
            throw new RuntimeException("批量更新卡账户余额失败，批量分配失败！");
        }
        // endregion

        logger.info("<==  方法batchTransfer执行结束");
        return ReturnResult.successs("资金批量分配成功");
    }


}
