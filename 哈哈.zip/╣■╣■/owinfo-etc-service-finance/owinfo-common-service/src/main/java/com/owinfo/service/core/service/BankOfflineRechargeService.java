package com.owinfo.service.core.service;

import com.owinfo.object.entity.*;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.MapOnlineMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.bouncycastle.asn1.x500.style.RFC4519Style.o;

/**
 * @author Created by hekunlin on 2018年01月22日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class BankOfflineRechargeService {

    private static final Logger logger = Logger.getLogger(BankOfflineRechargeService.class);

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private MapOnlineMapper mapOnlineMapper;

    @Autowired
    private ReportFeign reportFeign;

    @Autowired
    private CardMapper cardMapper;

    @Transactional
    public Map<String, Object> bankOfflineRecharge(Map<String, Object> params){
        logger.info("<==  方法bankOfflineRecharge的参数::" + params + "   开始执行");

        Map<String, Object> errorMap = new HashMap<>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        // region 校验金额
        String totalBalance = ParamClassUtils.getParams(params.get("totalAmount"));
        String giftBalacne = ParamClassUtils.getParams(params.get("giftAmount"));
        String etcBalance = ParamClassUtils.getParams(params.get("etcAmount"));
        String channelNo = ParamClassUtils.getParams(params.get(""));
        // endregion

        // region 获取充值类型、银行编号、卡号并传入校验(去掉多余的0)
        String accountType = String.valueOf(params.get("accountType")).replaceFirst("^0*","");
        int rechargeType = Integer.valueOf(accountType);
        if (!(rechargeType == 1 || rechargeType == 2)){
            logger.error("<==  没有这种充值类型 " + rechargeType);
            errorMap.put("stateCode","1111");
            errorMap.put("field","没有这种充值类型");
            return errorMap;
        }
        String channelCode = String.valueOf(params.get("channelCode"));
        String channelTransId = String.valueOf(params.get("channelTransId"));
        String channelFinTime = String.valueOf(params.get("channelFinTime"));
        // 充值金额
        int etcAmount = Integer.valueOf(etcBalance);
        int giftAmount = Integer.valueOf(giftBalacne);
        // 相当于amount
        int totalAmount = Integer.valueOf(totalBalance);
        // endregion

        // region 渠道认证 网点认证
        MapOnline mapOnline = mapOnlineMapper.selectByPrimaryKey(channelCode);
        String channelId = null;
        String channelName = null;

        if (mapOnline == null ){
            logger.error("<== 不存在这个线上渠道编号");
            errorMap.put("stateCode","1111");
            errorMap.put("field","不存在这个线上渠道编号,不允许充值");
            return errorMap;
        } else {
            channelId = mapOnline.getId();
            channelName = mapOnline.getName();
        }

        // 京东渠道没有站点信息
        String dotContactName = null;
        String dotName = null;
        String dotNo = null;
        // endregion

        // region 获取交易流水号
        String tradeNumber = (String) params.get("tradeNumber");
        logger.info("<==  本次交易交易流水号为tradeNumber= " + tradeNumber);
        // endregion

        // region 查询卡信息、客户信息
        Etccardinfo etccardinfo = null;
        Etcclientinfo etcclientinfo = null;
        if (rechargeType == 1){
            String cardId = (String) params.get("etcCardId");
            etccardinfo = cardMapper.getCard(cardId);
            if (etccardinfo == null){
                logger.error("<==  未找到该卡片[" + cardId + "]对应的卡片信息");
                errorMap.put("stateCode","1111");
                errorMap.put("field","未找到该卡片信息");
                return errorMap;
            }
            String spare = etccardinfo.getSpare();
            etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.error("<== 不存在这个[" + cardId + "]对应的用户信息");
                errorMap.put("stateCode","1111");
                errorMap.put("field","未查到该卡片对应的用户信息");
                return errorMap;
            }
        }
        if (rechargeType == 2){
            String certificateNumber = ParamClassUtils.getParams(params.get("etcCertNum"));
            Map<String, Object> tempMap = new HashMap<>();
            tempMap.put("certificateNumber",certificateNumber);
            etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
            if (etcclientinfo == null){
                logger.error("<==  不是个人客户充值，集团客户充值");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<== 不存在这个用户信息");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","未查到该用户信息");
                    return errorMap;
                }
            }
        }
        // endregion

        // region 如果是卡充值
        if (rechargeType == 1){
            // 判断卡状态
            String cardStatus = String.valueOf(etccardinfo.getCardStatus());
            String certificateNumber = String.valueOf(etccardinfo.getCertificateNumber());
            if (!cardStatus.equals("600202101")){
                logger.error("<== 卡状态不正常，不允许充值");
                errorMap.put("stateCode","1111");
                errorMap.put("field","ETC卡状态不正常");
                return errorMap;
            }
            // 验证卡类型
            String payType = ParamClassUtils.getParams(etccardinfo.getPayType());
            if (payType.equals("2")){
                logger.error("<== 记账卡不允许充值");
                errorMap.put("stateCode","1111");
                errorMap.put("field","记账卡不允许充值");
                return errorMap;
            }

            // 金额转换：电子钱包、卡账户余额
            double d1 = etccardinfo.getCardBalance().doubleValue();
            double d2 = etccardinfo.getCardAccountBalance().doubleValue();
            int cardAmount = (int)(d1 * 100);
            int cardAccountAmount = (int)(d2 * 100);

            // 充值后卡余额
            int cardAcountBalance = cardAccountAmount + totalAmount;
            BigDecimal cardAccountBalance = new BigDecimal((double)(cardAcountBalance * 0.01));
            BigDecimal rechargeAmount = new BigDecimal(Double.valueOf(totalAmount*0.01));
            logger.info("<==  充值后[" + etccardinfo.getCardId() + "]卡余额 " + cardAccountBalance);

            // 执行充值
            cardMapper.updateCardAccountBalance(rechargeAmount,etccardinfo.getCardId());
            logger.info("<==  卡[" + etccardinfo.getCardId() + "]充值成功");

            // 新增账单记录
            FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
            frontBillingRecord.setId(UUIDUtils.getUUID());
            frontBillingRecord.setTransId(channelTransId);
            frontBillingRecord.setClearingTime(date);
            frontBillingRecord.setTradeNum(tradeNumber);
            frontBillingRecord.setChannelName(channelName);
            frontBillingRecord.setChannelNum(channelId);
            frontBillingRecord.setChannelType("3");
            frontBillingRecord.setAcquirerNo(dotNo);
            frontBillingRecord.setSiteName(dotName);
            frontBillingRecord.setEmployeeNo(dotContactName);
            if ("1".equals(etcclientinfo.getClientType())){
                frontBillingRecord.setClientName(etcclientinfo.getClientName());
            }
            if ("2".equals(etcclientinfo.getClientType())){
                frontBillingRecord.setClientName(etcclientinfo.getUnitName());
            }
            frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
//            frontBillingRecord.setCertificateNumber(etccardinfo.getCertificateNumber());
            frontBillingRecord.setCertificateNumber(etcclientinfo.getSpare());
            frontBillingRecord.setVehicleLicense(etccardinfo.getVehicleLicense());
            frontBillingRecord.setVehicleType(etccardinfo.getCardType());
            frontBillingRecord.setAccountSubject(2);
            frontBillingRecord.setAccountSubjectNo(etccardinfo.getCardId());
            frontBillingRecord.setAccountSubjectStatus(1);
            frontBillingRecord.setOperationType(15);
            frontBillingRecord.setOperationMark(1);
            frontBillingRecord.setPreOperationBalance(cardAccountAmount);
            frontBillingRecord.setOperationAmount(totalAmount);
            frontBillingRecord.setSufOperationBalance(cardAcountBalance);
            frontBillingRecord.setOperationTime(date);
            frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
            logger.info("<==  新增卡充值账单记录成功");

            // region FIXME 营改增数据上报，京东做数据上报，嘉应观做赠送金额的上报
            if ("410101880030201".equals(channelId)){
                logger.info("<==  卡号[" + etccardinfo.getCardId() +"],京东充值数据上报");
                Map<String, Object> sendRechargeMap = new HashMap<>();
                sendRechargeMap.put("id",tradeNumber);
                sendRechargeMap.put("paidAmount",String.valueOf(etcBalance));
                sendRechargeMap.put("giftAmount",String.valueOf(giftBalacne));
                sendRechargeMap.put("rechargeAmount",String.valueOf(totalBalance));
                sendRechargeMap.put("cardId",etccardinfo.getCardId());
                try {
                    reportFeign.sendRecharge(sendRechargeMap);
                } catch (Exception e) {
                    logger.error("<==  JD上报异常，上报渠道编号 " + channelCode);
                }
            }
            if ("410101999990103".equals(channelId)){
                logger.info("<==  卡号[" + etccardinfo.getCardId() +"],嘉应观退费数据上报");
                Map<String, Object> sendRechargeMap = new HashMap<>();
                sendRechargeMap.put("id",tradeNumber);
                sendRechargeMap.put("paidAmount",0+"");
                sendRechargeMap.put("giftAmount",String.valueOf(giftBalacne));
                sendRechargeMap.put("rechargeAmount",String.valueOf(totalBalance));
                sendRechargeMap.put("cardId",etccardinfo.getCardId());
                try {
                    reportFeign.sendRecharge(sendRechargeMap);
                } catch (Exception e) {
                    logger.error("<==  JD上报异常，上报渠道编号 " + channelCode);
                }
            }
            // endregion

            // 返回相关结果
            Map<String, Object> successMap = new HashMap<>();
            successMap.put("stateCode","0000");
            successMap.put("etcTransId",tradeNumber);
            successMap.put("channelTransId",channelTransId);
            successMap.put("etcCardId",etccardinfo.getCardId());
            successMap.put("totalAmount",totalBalance);
            successMap.put("giftAmount",giftBalacne);
            successMap.put("etcAmount",etcBalance);
            successMap.put("cardBalance",cardAmount);
            successMap.put("cardAcountBalance",cardAcountBalance);
            successMap.put("successTime",LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
            successMap.put("channelFinTime",channelFinTime);
            logger.info("<==  卡充值成功");
            return successMap;
        }
        // endregion

        // region 如果是用户账户充值
        if (rechargeType == 2 && !"410101999990103".equals(channelCode)){
            // 获取用户账户余额、用户证件类型（区别个人和集团）
            double d3 = etcclientinfo.getAccountBalance().doubleValue();
            // 计算充值后的账户余额
            int userAccountBalance = (int)(d3*100);
            int laccountnum = userAccountBalance + totalAmount;
            // 根据客户类型区分证件号
            String clientType = etcclientinfo.getClientType();
            String etcCertNum = etcclientinfo.getCertificateNumber();
            if (clientType.equals("2")){
                etcCertNum = etcclientinfo.getUnitCertificateNo();
            }

            // 充值账户余额
            BigDecimal userAcountBalance = new BigDecimal(Double.valueOf((totalAmount*0.01)));
            BigDecimal accountBalance = userAcountBalance.add(etcclientinfo.getAccountBalance());
            logger.info("<==  充值后用户账户[" + etcCertNum + "]账户金额为 " + accountBalance);
            // 执行充值
            Etcclientinfo tempUser = new Etcclientinfo();
            tempUser.setCertificateNumber(etcCertNum);
            tempUser.setAccountBalance(userAcountBalance);
            etcclientinfoMapper.updateByPrimaryKeySelective(tempUser);

            // region 新增账单记录
            Map<String, Object> rechargeMap = new HashMap<>();
            FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
            frontBillingRecord.setId(UUIDUtils.getUUID());
            frontBillingRecord.setTransId(channelTransId);
            try {
                frontBillingRecord.setClearingTime(dateFormat.parse(channelFinTime));
            } catch (ParseException e) {
                logger.error("<==  清分时间解析异常");
                errorMap.put("stateCode","1111");
                errorMap.put("field","清分时间解析异常");
                return errorMap;
            }
            frontBillingRecord.setTradeNum(tradeNumber);
            frontBillingRecord.setChannelName(channelName);
            frontBillingRecord.setChannelNum(channelId);
            frontBillingRecord.setChannelType("3");
            frontBillingRecord.setAcquirerNo(dotNo);
            frontBillingRecord.setSiteName(dotName);
            frontBillingRecord.setEmployeeNo(dotContactName);
            if ("1".equals(etcclientinfo.getClientType())){
                frontBillingRecord.setClientName(etcclientinfo.getClientName());
            }
            if ("2".equals(etcclientinfo.getClientType())){
                frontBillingRecord.setClientName(etcclientinfo.getUnitName());
            }
            frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
//            frontBillingRecord.setCertificateNumber(etcclientinfo.getCertificateNumber());
            frontBillingRecord.setCertificateNumber(etcclientinfo.getSpare());
            frontBillingRecord.setAccountSubject(1);
            frontBillingRecord.setAccountSubjectNo(etcclientinfo.getSpare());
            frontBillingRecord.setAccountSubjectStatus(1);
            frontBillingRecord.setOperationType(16);
            frontBillingRecord.setOperationMark(1);
            frontBillingRecord.setPreOperationBalance(userAccountBalance);
            frontBillingRecord.setOperationAmount(totalAmount);
            frontBillingRecord.setSufOperationBalance(laccountnum);
            frontBillingRecord.setOperationTime(date);
            frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
            logger.info("<==  新增用户充值账单记录成功");
            // 返回相关结果
            Map<String, Object> successMap = new HashMap<>();
            successMap.put("stateCode","0000");
            successMap.put("etcTransId",tradeNumber);
            successMap.put("totalAmount",totalBalance);
            successMap.put("giftAmount",giftBalacne);
            successMap.put("etcAmount",etcBalance);
            successMap.put("channelTransId",channelTransId);
            successMap.put("etcCertNum",etcCertNum);
            successMap.put("acountBalance",laccountnum);
            successMap.put("successTime",LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
            successMap.put("channelFinTime",channelFinTime);
            logger.info("<==  用户账户充值成功");
            return successMap;

        }
        // endregion

        errorMap.put("stateCode","1111");
        errorMap.put("field","充值类型有误");
        logger.error("<== 充值类型有误");
        logger.info("<==  方法bankOfflineRecharge执行结束");
        return errorMap;
    }

}
