package com.owinfo.service.core.service;

import com.owinfo.object.entity.BankRechargeOperation;
import com.owinfo.service.core.mapper.BankRechargeOperationMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 银行充值冲正
 */
@Service
public class BankRechargeOperationService {

    @Autowired
    private BankRechargeOperationMapper bankRechargeOperationMapper;

    /**
     * 新增银行充值记录
     * 新增银行冲正记录
     * @param bankRechargeOperation
     * @return
     */
    public int addBankOperationRecord(BankRechargeOperation bankRechargeOperation){
        return bankRechargeOperationMapper.insertSelective(bankRechargeOperation);
    }

}
