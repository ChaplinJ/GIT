package com.owinfo.service.core.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.owinfo.object.entity.*;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.EtcvehicleMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.RegExUtil;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import com.owinfo.service.util.ValidateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月18日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class CardRechargeService {

    private static final Logger logger = Logger.getLogger(CardRechargeService.class);

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcvehicleMapper etcvehicleMapper;

    @Autowired
    private TransferAccountsManageService transferAccountsManageService;

    @Autowired
    private OrderManageService orderManageService;

    @Autowired
    private TicketManageService ticketManageService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private ReportFeign reportFeign;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Transactional(rollbackFor = {Exception.class})
    public Map<String,Object> cardRecharge(Map<String, Object> params){

        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();

        try {
            // region 参数校验：卡号、卡状态、卡类型、获取卡信息、用户信息
            String cardId = (String) params.get("cardId");
            logger.info(" <-- 卡账户充值卡号=" + cardId);
            if (ValidateUtils.isEmpty(cardId)){
                logger.error("卡账户充值卡号为空 cardId=" + cardId);
                return ReturnResult.error("充值失败,请填写卡号");
            }

            // 获取卡信息
            Etccardinfo etccardinfo = cardMapper.getCard(cardId);

            if (etccardinfo == null){
                logger.error("<==  未查到对应的卡账户信息 etccardinfo=" + etccardinfo);
                return ReturnResult.error("未查到卡信息，不允许充值");
            }
            if (etccardinfo.getCardAccountBalance().compareTo(BigDecimal.ZERO) == -1){
                logger.error("<==  卡账户余额[" + etccardinfo.getCardAccountBalance() + "]为负数，不允许充值");
                return ReturnResult.error("卡账户余额为负数，不允许充值");
            }

            if (!("600202101".equals(etccardinfo.getCardStatus()))){
                logger.error("<==  卡账号状态异常，不允许充值 cardStatus=" + etccardinfo.getCardStatus());
                return ReturnResult.error("卡账号状态异常，不允许充值");
            }
            if (!("1".equals(etccardinfo.getPayType()))){
                logger.error("<==  记账卡不允许充值 payType=" + etccardinfo.getPayType());
                return ReturnResult.error("记账卡不允许充值");
            }

            // 获取用户信息：20180130证件编号修正
            String spare = etccardinfo.getSpare();
            Etcclientinfo etcclientinfo = new Etcclientinfo();
            etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.error("<==  不存在唯一标识为[" + spare + "]的这个客户");
                return ReturnResult.errors("不存在这个用户信息");
            }
            String clientType = etcclientinfo.getClientType();
            logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());

            // 修正卡信息中的用户信息
            if ("1".equals(clientType)){
                etccardinfo.setCertificateNumber(etcclientinfo.getCertificateNumber());
            }
            if ("2".equals(clientType)){
                etccardinfo.setCertificateNumber(etcclientinfo.getUnitCertificateNo());
            }
            etccardinfo.setClientName(etcclientinfo.getClientName());
            etccardinfo.setClientNo(etcclientinfo.getClientNo());
            etccardinfo.setClientType(etcclientinfo.getClientType());

            // endregion

            // region 充值金额、充值类型
            Double amount = 0D;
            try {
                amount = Double.valueOf((String) params.get("chargeAmount"));
            } catch (NumberFormatException e) {
                logger.error("<==  金额转换异常 chargeAmount=" + (String) params.get("chargeAmount"));
                return ReturnResult.error("卡账户充值金额转换异常");
            }
            String chargeType = (String) params.get("chargeType");

            if (StringUtils.isEmpty(amount)){
                logger.error("<==  卡充值金额不能为空  amount=" + amount);
                return ReturnResult.error("卡充值金额为空");
            }
            if (StringUtils.isEmpty(chargeType)){
                logger.error("<==  充值类型不能为空 chargeType=" + chargeType);
                return ReturnResult.error("充值类型不能为空");
            }
            // endregion

            // region 车辆验证
            Map<String, Object> vehicleMap = new HashMap<>();
            vehicleMap.put("vehicleLicense",etccardinfo.getVehicleLicense());
            vehicleMap.put("vehicleColor",etccardinfo.getFavorRate());
            /**1-20早 临时注释
           /*    * *//*
           Etcvehicle etcvehicle = etcvehicleMapper.selectByPrimaryKey(vehicleMap);

            if (etcvehicle == null){
                logger.error("<==  卡号未绑定车辆");
    //            return ReturnResult.error("卡号未绑定车辆");
            }
            String vehicleType = etcvehicle.getVehicleType();  // 车型*/
            // endregion

            // region 充值金额转换、数据上报金额
            BigDecimal cardAccountBalance = etccardinfo.getCardAccountBalance(); // 卡账户余额
            BigDecimal cardBalance = etccardinfo.getCardBalance();  // 卡余额
            BigDecimal chargeAmount = BigDecimal.valueOf(amount);  // 充值金额

            String paidMoney = null;  // 实付金额
            String giftMoney = null;  // 赠送金额
            String rechargeMoney = null;  // 充值金额
            // endregion

            // region 不同充值方式的处理流程
            String rechargeNum = null;
            if ("0".equals(chargeType) || "1".equals(chargeType) || "5".equals(chargeType)){  // 现金或POS的充值或其他付款方式（微信、支付宝）
                if("5".equals(chargeType)){
                    String specificRechargeType = (String)params.get("specificRechargeType");
                    if("".equals(specificRechargeType)){
                        return ReturnResult.error("不能使用此付款方式进行付款，请选择另外的方式进行。");
                    }
                }
                logger.info("<==  充值方式为现金/POS充值/其他付款方式 chargeType=" + chargeType);
                paidMoney = String.valueOf((int)(amount*100));
                giftMoney = "0";
                rechargeMoney = paidMoney;
                rechargeNum = (String) params.get("rechargeNum");
            }

            if ("3".equals(chargeType)){  // 电商的充值
                logger.info("<==  充值方式为电商充值 chargeType=" + chargeType);
                String orderNo = (String) params.get("orderNo");
                String orderType = getParams(params.get("orderType"));

                rechargeNum = orderNo;

                logger.info(" <-- 电商充值参数 电商号=" + orderNo + " 电商用途=" + orderType + " 充值金额=" + chargeAmount);
                if (StringUtils.isEmpty(orderNo) || StringUtils.isEmpty(orderType)){
                    logger.error("<==  电商充值电商号和电商订单类型不能为空 orderNo=[" + orderNo + "]  orderType=[" + orderType + "]" );
                    return ReturnResult.error("电商订单号及类型不能为空");
                }
                OrderManage validateOrder = orderManageService.validateOrder(orderNo); //从数据库中获取验证对应得orderManage
                Map<String,Object> orderMap = new HashMap<>();

                String orderManageType = validateOrder.getOrderType();
                /**
                 * 校验订单类型是否支持充值
                 */
                if(RegExUtil.getString(orderManageType,"(^(1)$)|(^(1,))|(,1)$|,1,") == null) {
                    logger.error(" <-- 该电商订单不支持该用途");
                    return ReturnResult.error("该电商订单不支持该用途");
                }

                /**
                 * 判断是否有余额进行充值
                 */
                int rechargeMoney2 =  (new BigDecimal(amount.doubleValue() + "")).multiply(new BigDecimal("100")).intValue();
                int surplusMoney = validateOrder.getSurplusRechargeMoney() - rechargeMoney2;
                if(surplusMoney < 0) {
                    logger.error("<== 充值余额不足");
                    return ReturnResult.error("充值余额不足");
                }
                orderMap.put("orderNo",orderNo);
                orderMap.put("updateBy", params.get("recoveryPerson"));
                orderMap.put("updateTime", new Date());
                orderMap.put("surplusRechargeMoney",surplusMoney);

                int result = orderManageService.updateOrderSurplys(orderMap);
                if (result == 0){
                    logger.error("<==  更新电商订单号 orderNo=[" + orderNo + "] 充值金额" + amount + " 失败");
                    return ReturnResult.error("充值失败,更新电商订单失败");
                }
                logger.info("<==  更新电商订单 orderNo=[" + orderNo + "] 成功");

                if (result == 1){ //判断是否执行成功
                    /**
                     *
                     * 消费状态 0未消费，1消费中，2消费完毕
                     * saleStatus为 2
                     */
                    OrderManage orderManage = orderManageService.getOrderDetail(orderNo); //从数据库中获取这个商品订单
                    boolean saleStatus = true;

                    //充值金额
                    if(orderManage.getSurplusRechargeMoney() != null) { //充值

                        if(orderManage.getSurplusRechargeMoney() == 0) {
                            //充值金额为空
                            saleStatus = saleStatus && true;
                        } else { //还有剩余充值金额
                            saleStatus = saleStatus && false;
                        }
                    }

                    //蓝牙电子标签
                    if(orderManage.getSufObuNum() != null) { //蓝牙电子标签
                        if(orderManage.getSufObuNum() == 0) {
                            //蓝牙电子标签数量0
                            saleStatus = saleStatus && true;
                        } else {//蓝牙电子标签数量大于0
                            saleStatus = saleStatus && false;
                        }
                    }

                    //充值宝
                    if(orderManage.getSufTreasureNum() != null) {
                        if(orderManage.getSufTreasureNum() == 0) {
                            //充值宝数量0
                            saleStatus = saleStatus && true;
                        } else { //充值宝数量大于0
                            saleStatus = saleStatus && false;
                        }
                    }

                    //中石油加油
                    if(orderManage.getSufOilAmount() != null) {
                        if(orderManage.getSufOilAmount() == 0) {
                            //中石油余额0
                            saleStatus = saleStatus && true;
                        } else { //还有剩余中石油余额
                            saleStatus = saleStatus && false;
                        }
                    }

                    /**
                     * 如果消费完毕并且上次消费状态为消费中，则将电商订单状态修改为
                     * 消费完毕,否则不进行状态修改
                     */
                    if(saleStatus && orderManage.getSaleStatus() == 1) {
                        OrderManage oo = new OrderManage();
                        oo.setSaleStatus(2);
                        oo.setOrderNo(orderManage.getOrderNo());
                        int status = orderManageService.updateOrderSaleStatus(oo);
                        if(status == 1) {
                            logger.info("更新订单状态为消费完毕");
                        }
                    }
                    //return ReturnResult.success("使用成功");
                }

                // 充值为电商时的上报
                //paidMoney = "0";
                //giftMoney = String.valueOf(amount);
                //rechargeMoney = giftMoney;
                paidMoney = String.valueOf((int)(amount*100));
                giftMoney = "0";
                rechargeMoney = paidMoney;
            }

            if ("4".equals(chargeType)){ // 体验券的充值
                logger.info("<==  充值方式为体验券充值 chargeType=" + chargeType);
                Map<String,Object> ticketMap = new HashMap<>();
                String ticketNo = (String) params.get("ticketNo");
                String ticketType = getParams(params.get("ticketType"));

                logger.info(" <-- 体验券充值参数 体验券号=" + ticketNo + " 体验券用途=" + ticketType + " 充值金额=" + chargeAmount);
                if (StringUtils.isEmpty(ticketNo) || StringUtils.isEmpty(ticketType)){
                    logger.error("<==  优惠券充值券号和优惠券类型不能为空 ticketNo=[" + ticketNo + "]  ticketType=[" + ticketType + "]" );
                    return ReturnResult.errors("优惠券券号和优惠券类型不能为空");
                }

                rechargeNum = ticketNo;

                ticketMap.put("ticketNo",ticketNo);
                ticketMap.put("recoveryPerson",(String) params.get("recoveryPerson"));
                ticketMap.put("recoveryTime",dateFormat.format(date));
                ticketMap.put("updateTime",dateFormat.format(date));
                ticketMap.put("updateBy",(String) params.get("recoveryPerson"));
                ticketMap.put("saleStatus",2);
                ticketMap.put("password",(String) params.get("password"));
//                ticketMap.put("ticketType",ticketType);

                //获取此卡券的信息
                TicketManage ticketManage = ticketManageService.getTicket(params);

                int result = ticketManageService.recoveryTicket(ticketMap);
                if (result == 0){
                    logger.error("<==  更新体验券号 ticketNo=[" + ticketNo + "] 充值金额" + amount + " 失败");
//                    throw new RuntimeException("更新体验券[" + ticketNo + "]状态失败，请核实卡号[" + ticketNo + "]和密码[" +
//                            (String) params.get("password") + "]");
                    return ReturnResult.error("请核实卡号和密码");
                }
                logger.info("<==  更新体验券号 ticketNo=[" + ticketNo + "] 成功");

                // 充值为体验券时的上报
                paidMoney = String.valueOf(ticketManage.getSaleMoney());  //实收金额 = 卡券售出的金额
                rechargeMoney = String.valueOf(ticketManage.getTicketFaceValue());  //卡券面额
                giftMoney = String.valueOf(ticketManage.getTicketFaceValue()-ticketManage.getSaleMoney()); //赠送金额

            }
            // endregion

            // region 执行卡充值
            int result = cardMapper.updateCardAccountBalance(chargeAmount,cardId);
            if (result != 1){
                logger.error("<==  卡充值失败 result=[" + result + "]");
                throw new RuntimeException("卡账户充值失败");
            }
            logger.info("<==  卡[" + cardId + "] 充值金额[" + amount + "] 充值成功 ");
            // endregion

            // region 调用营改增接口实现数据上报
            /**
             * FIXME 调用营改增接口实现数据上报
             * 不同的充值方式，其支付、赠送、充值金额可能是不同的
             */
            Map<String,Object> sendRechargeMap = new HashMap<>();
            logger.info("<==  营改增调用数据 paidMoney=[" + paidMoney + "] giftMoney=[" + giftMoney + "] rechargeMoney="
                    + rechargeMoney + "]");
            sendRechargeMap.put("id", getParams(params.get("tradeNum")));
            sendRechargeMap.put("paidAmount",paidMoney);
            sendRechargeMap.put("giftAmount",giftMoney);
            sendRechargeMap.put("rechargeAmount",rechargeMoney);
            sendRechargeMap.put("cardId", getParams(params.get("cardId")));
            try {
                logger.info("<==  调用营改增接口实现数据上报开始");
                reportFeign.sendRecharge(sendRechargeMap);
                logger.info("<==  调用营改增接口实现数据上报结束");
            } catch (Exception e) {
                logger.error("<==  卡号[" + cardId + "] 充值方式[" + chargeType + "] 充值数据上报服务异常" + e.getMessage());
            }
            // endregion

            // region 操作前后金额计算
            int preAccountBalance = BigDecimal.valueOf(100L).multiply(etccardinfo.getCardAccountBalance()).intValue();
            int operationBalance = (int) (amount*100);
            int sufAccountBalance = preAccountBalance + operationBalance;
            logger.info("<==  金额转换（单位分） 操作前金额=[" + preAccountBalance + "]  操作金额=[" +
                    operationBalance + "]  操作后金额=[" + sufAccountBalance + "]");
            // endregion

            // region 新增账单记录
            FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
            frontBillingRecord.setId(UUIDUtils.getUUID());
            frontBillingRecord.setTransId((String) params.get("transId"));
            frontBillingRecord.setTradeNum((String) params.get("tradeNum"));
            frontBillingRecord.setChannelType((String) params.get("channelType"));
            frontBillingRecord.setChannelName((String) params.get("channelName"));
            frontBillingRecord.setChannelNum((String) params.get("channelNum"));
            frontBillingRecord.setEmployeeNo((String) params.get("employeeNo"));
            frontBillingRecord.setSiteName((String) params.get("siteName"));
            frontBillingRecord.setAcquirerNo((String) params.get("acquirerNo"));
            frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            frontBillingRecord.setClientName(etcclientinfo.getClientName());
//            frontBillingRecord.setCertificateNumber(etcclientinfo.getCertificateNumber());
            frontBillingRecord.setCertificateNumber(etcclientinfo.getSpare());
            frontBillingRecord.setAccountSubject(2);
            /**1-20早 临时注释
             /*    * */
           /* frontBillingRecord.setVehicleLicense(etcvehicle.getVehicleLicense());
            frontBillingRecord.setVehicleType(etcvehicle.getVehicleType());*/
            frontBillingRecord.setAccountSubjectNo(etccardinfo.getCardId());
            frontBillingRecord.setAccountSubjectStatus(1);
            frontBillingRecord.setOperationType(1);
            frontBillingRecord.setRechargeType(Integer.valueOf(chargeType));
            frontBillingRecord.setRechargeNum(rechargeNum);
            frontBillingRecord.setSpecificRechargeType((String)params.get("specificRechargeType"));
            String otherCollectionField = params.get("collectField") == null ? "" : collectField(params);
            frontBillingRecord.setOtherCollectionField(otherCollectionField);

//        frontBillingRecord.setFillTransferStatus();
//        frontBillingRecord.setBankType();
//        frontBillingRecord.setClientAcount();
//        frontBillingRecord.setClientBalance();
//        frontBillingRecord.setBankAccountOfThings();
//        frontBillingRecord.setTransferType();
//        frontBillingRecord.setTransferMode();
            frontBillingRecord.setOperationMark(1);
            frontBillingRecord.setPreOperationBalance(preAccountBalance);
            frontBillingRecord.setOperationAmount(operationBalance);
            frontBillingRecord.setSufOperationBalance(sufAccountBalance);
            frontBillingRecord.setOperationUser((String) params.get("createBy"));
            frontBillingRecord.setOperationTime(date);
            frontBillingRecord.setCreateBy((String) params.get("createBy"));
            frontBillingRecord.setRemove(0);
            frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
            // endregion

        } catch (DuplicateKeyException e){
            logger.error("<==  唯一索引冲突,交易流水号重复 " + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ReturnResult.error("充值失败，不允许重复充值");
        } catch (Exception e) {
            logger.error("<==  充值失败，充值异常" + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ReturnResult.error("充值失败");
        }
        logger.info("<==  卡充值成功");
        return ReturnResult.success("卡账户充值成功");
    }

    /**
     * 格式化采集字段
     * @param param
     * @return
     */
    public static String collectField(Map<String, Object> param) {
        List<HashMap<String, Object>> fields = (List<HashMap<String, Object>>) param.get("collectField");
        JSONArray array = new JSONArray();
        if(fields.size() > 0){
            for (HashMap<String, Object> hashMap : fields) {
                JSONObject field = new JSONObject();
                field.put("fieldNo", hashMap.get("fieldNo"));
                field.put("fieIdValue", hashMap.get("fieIdValue"));
                array.add(field);
            }
        }
        return array.toString();
    }


}
