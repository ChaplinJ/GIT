package com.owinfo.service.core.service;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import com.owinfo.service.util.ValidateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月22日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class CardTransferService {

    private static final Logger logger = Logger.getLogger(CardTransferService.class);

    @Autowired
    private FrontCardTransferOperationService frontCardTransferOperationService;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private ReportFeign reportFeign;

    @Transactional(rollbackFor = {Exception.class})
    public Map<String,Object> cardTransfer(Map<String,Object> params){
        Map<String, Object> errorMap = new HashMap<>();
        Map<String, Object> successMap = new HashMap<>();
        try {
            Date date = new Date();

            // region 获取用户信息、转账金额
            Map<String,Object> userMap = (Map<String, Object>) params.get("userMap");
            if (ValidateUtils.isEmpty(userMap)){
                logger.error(" <-- 转账失败,获取用户信息失败");
                return ReturnResult.error("转账失败,返回的用户信息为空");
            }
            String transferBalances = getParams(params.get("transferBalance"));
            BigDecimal transferBalance = new BigDecimal(transferBalances);
            Double amount = transferBalance.doubleValue();
            int paidMoney = (int)(amount*100);
            int giftMoney = 0;
            int rechargeMoney = (int)(amount*100);
            // endregion

            // region 获取转出卡信息、账户余额
            String outCardId = (String) params.get("outCardId");
            Etccardinfo outCardInfo = cardMapper.getCard(outCardId);
            // 转出卡账户余额、账户余额必须大于转账金额
            BigDecimal outCardAccountBalance = outCardInfo.getCardAccountBalance();
            if (transferBalance.compareTo(outCardAccountBalance) == 1){
                logger.error(" <-- 转账失败,转账金额不能大于原ETC卡账户余额");
                return ReturnResult.error("转账失败,余额不足");
            }

            String spare = outCardInfo.getSpare();
            Etcclientinfo etcclientinfo = new Etcclientinfo();
            etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.error("<==  不存在唯一标识为[" + spare + "]的这个客户");
                return ReturnResult.errors("不存在这个用户信息");
            }
            String clientType = etcclientinfo.getClientType();
            logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());
            // endregion

            // region 转入卡信息、不可和转入卡相同
            Map<String,Object> cardList = (Map<String, Object>) params.get("cardList");
            String inputCardId = getParams(cardList.get("cardId"));
            if (outCardId.equals(inputCardId)){
                logger.error(" <-- 转账失败,转入卡账号和转出卡账号一致");
                return ReturnResult.error("转账失败,转入转出卡号不可一致");
            }
            // 转入卡状态
            Etccardinfo inCardInfo = cardMapper.getCard(inputCardId);
            // 转入卡账户余额
            BigDecimal inputCardAccountBalance = inCardInfo.getCardAccountBalance();
            if (!inCardInfo.getCardStatus().equals("600202101")){
                logger.error("<== 转入ETC卡账户不正常,不允许转账");
                return ReturnResult.error("转入ETC卡账户不正常,不允许转账");
            }
            if (!inCardInfo.getPayType().equals("1")){
                logger.error("<== 转入ETC卡账户为记账卡,不允许转账");
                return ReturnResult.error("记账卡不允许转账");
            }
            // endregion

            // region 金额计算
            logger.info("<==  卡转账前，转出卡账户[" + outCardId + "] 账户余额[" + outCardAccountBalance + "] " +
                    " 转入卡账户[" + inputCardId + "] 卡账户余额[" + inputCardAccountBalance + "]");
            // 转出后转出卡账户余额、转入卡账户余额
            outCardAccountBalance = outCardAccountBalance.subtract(transferBalance);
            inputCardAccountBalance = inputCardAccountBalance.add(transferBalance);
            logger.info("<==  卡转账后，转出卡账户[" + outCardId + "] 账户余额[" + outCardAccountBalance + "] " +
                    " 转入卡账户[" + inputCardId + "] 卡账户余额[" + inputCardAccountBalance + "]");
            // endregion

            // region 转出卡账户余额更新、新增转出卡账单记录
            Double outPreAmount = outCardInfo.getCardAccountBalance().doubleValue();
            Double outAmount = Double.parseDouble(transferBalances);
            int resultA = cardMapper.updateCardAccountBalance(BigDecimal.ZERO.subtract(transferBalance),outCardId);
            if (resultA != 1){
                logger.error("<==  卡转账失败 resultA=[" + resultA + "]");
                throw new RuntimeException("更新转出卡账户余额失败，卡转账失败");
            }
            // 转出卡账单
            FrontBillingRecord outFrontRecord = new FrontBillingRecord();
            outFrontRecord.setId(UUIDUtils.getUUID());
            outFrontRecord.setTradeNum(getParams(params.get("tradeNum")));
            outFrontRecord.setTransId(getParams(params.get("transId")));
            outFrontRecord.setChannelName(getParams(params.get("channelName")));
            outFrontRecord.setChannelNum(getParams(params.get("channelNum")));
            outFrontRecord.setChannelType(getParams(params.get("channelType")));
            outFrontRecord.setCreateBy(getParams(params.get("createBy")));
            outFrontRecord.setAcquirerNo(getParams(params.get("acquirerNo")));
            outFrontRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            outFrontRecord.setClientName(etcclientinfo.getClientName());
//            outFrontRecord.setCertificateNumber(outCardInfo.getCertificateNumber());
            outFrontRecord.setCertificateNumber(etcclientinfo.getSpare());
            outFrontRecord.setAccountSubject(2);
            outFrontRecord.setAccountSubjectNo(outCardId);
            outFrontRecord.setAccountSubjectStatus(1);
            outFrontRecord.setOperationType(6);
            outFrontRecord.setOperationMark(2);
            outFrontRecord.setVehicleLicense(outCardInfo.getVehicleLicense());
            outFrontRecord.setVehicleType(outCardInfo.getCardType());
            int outPreBalance = (int)(outPreAmount*100);
            int outBalance = (int)(outAmount*100);
            int outSufBalance = outPreBalance - outBalance;
            outFrontRecord.setPreOperationBalance(outPreBalance);
            outFrontRecord.setOperationAmount(outBalance);
            outFrontRecord.setSufOperationBalance(outSufBalance);
            outFrontRecord.setOperationTime(date);
            frontBillingRecordService.addBillingOperationRecord(outFrontRecord);
            // endregion

            // region 转入卡账户余额更新、新增转入卡账单记录
            Double inPreAmount = inCardInfo.getCardAccountBalance().doubleValue();
            Double inAmount = Double.parseDouble(transferBalances);
            int resultB = cardMapper.updateCardAccountBalance(transferBalance,inputCardId);
            if (resultB != 1){
                logger.error("<==  卡转账失败 resultB=[" + resultB + "]");
                throw new RuntimeException("更新转入卡账户余额失败，卡转账失败");
            }
            // 转入卡账单
            FrontBillingRecord inFrontRecord = new FrontBillingRecord();
            inFrontRecord.setId(UUIDUtils.getUUID());
            inFrontRecord.setTradeNum(getParams(params.get("tradeNum2")));
            inFrontRecord.setChannelName(getParams(params.get("channelName")));
            inFrontRecord.setChannelNum(getParams(params.get("channelNum")));
            inFrontRecord.setChannelType(getParams(params.get("channelType")));
            inFrontRecord.setCreateBy(getParams(params.get("createBy")));
            inFrontRecord.setAcquirerNo(getParams(params.get("acquirerNo")));
            inFrontRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
            inFrontRecord.setClientName(etcclientinfo.getClientName());
//            inFrontRecord.setCertificateNumber(inCardInfo.getCertificateNumber());
            inFrontRecord.setCertificateNumber(etcclientinfo.getSpare());
            inFrontRecord.setAccountSubject(2);
            inFrontRecord.setAccountSubjectNo(inputCardId);
            inFrontRecord.setAccountSubjectStatus(1);
            inFrontRecord.setOperationType(6);
            inFrontRecord.setOperationMark(1);
            inFrontRecord.setVehicleLicense(inCardInfo.getVehicleLicense());
            inFrontRecord.setVehicleType(inCardInfo.getCardType());
            int inPreBalance = (int)(inPreAmount*100);
            int inBalance = (int)(inAmount*100);
            int inSufBalance = inPreBalance + inBalance;
            inFrontRecord.setPreOperationBalance(inPreBalance);
            inFrontRecord.setOperationAmount(inBalance);
            inFrontRecord.setSufOperationBalance(inSufBalance);
            inFrontRecord.setOperationTime(date);
            frontBillingRecordService.addBillingOperationRecord(inFrontRecord);
            // endregion

            // region 转出卡营改增数据上报--退费
            Map<String,Object> sendOutTransferMap = new HashMap<>();
            logger.info("<==  卡转账，转出卡，营改增调用数据 paidMoney=[" + paidMoney + "] giftMoney=[" + giftMoney + "] rechargeMoney="
                    + rechargeMoney + "]");
            sendOutTransferMap.put("id", getParams(params.get("tradeNum")));
            sendOutTransferMap.put("fee",rechargeMoney+"");
            sendOutTransferMap.put("userId",etcclientinfo.getSpare());
            sendOutTransferMap.put("cardId", outCardId);
            try {
                logger.info("<==  转出卡调用营改增接口实现数据上报开始");
                reportFeign.sendReimburse(sendOutTransferMap);
                logger.info("<==  转出卡调用营改增接口实现数据上报结束");
            } catch (Exception e) {
                logger.error("<==  转出卡卡号[" + outCardId + "]" + e.getMessage());
            }
            // endregion

            // region 转入卡营改增数据上报--充值
            Map<String,Object> sendInTransferMap = new HashMap<>();
            logger.info("<==  卡转账，转入卡，营改增调用数据 fee=[" + paidMoney + "] giftMoney=[" + giftMoney + "] fee="
                    + rechargeMoney + "]");
            sendInTransferMap.put("id", getParams(params.get("tradeNum2")));
            sendInTransferMap.put("paidAmount",paidMoney+"");
            sendInTransferMap.put("giftAmount",giftMoney+"");
            sendInTransferMap.put("rechargeAmount",rechargeMoney+"");
            sendInTransferMap.put("cardId", inputCardId);
            try {
                logger.info("<==  转入卡调用营改增接口实现数据上报开始");
                reportFeign.sendRecharge(sendInTransferMap);
                logger.info("<==  转入卡调用营改增接口实现数据上报结束");
            } catch (Exception e) {
                logger.error("<==  转出卡卡号[" + outCardId + "]" + e.getMessage());
            }
            // endregion

        } catch (Exception e) {
            logger.error("<==  卡转账异常 " + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            errorMap.put("status",0);
            errorMap.put("msg","卡转账失败，服务异常");
            return errorMap;
        }
        logger.info("<==  卡转账成功");
        successMap.put("status",1);
        successMap.put("msg","卡转账成功");
        return successMap;
    }

}
