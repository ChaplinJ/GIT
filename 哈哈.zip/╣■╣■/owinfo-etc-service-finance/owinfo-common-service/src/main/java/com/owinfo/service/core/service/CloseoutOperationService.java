package com.owinfo.service.core.service;

import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.FrontBillingRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 清账、清户、退卡补款资金流向操作记录
 * 创建时间：2017年12月21日
 * <p>
 * 〈一句话功能简述〉清账、清户、退卡补款资金流向操作记录〈功能详细描述〉
 *
 * @author sun
 * @version [版本号, 2017年12月21日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Service
public class CloseoutOperationService {
    @Autowired
    private FrontBillingRecordMapper frontBillingRecordMapper;

    /**
     * 新增退卡补款记录
     * 新增清账记录
     * 新增清户记录
     * @param frontBillingRecord
     * @return
     */
    public int addOperation(FrontBillingRecord frontBillingRecord){
        return frontBillingRecordMapper.insertSelective(frontBillingRecord);
    }
}
