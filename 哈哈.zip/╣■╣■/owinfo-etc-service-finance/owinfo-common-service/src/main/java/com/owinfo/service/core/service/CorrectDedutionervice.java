package com.owinfo.service.core.service;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2018年01月30日
 *         github : https://github.com/rexlin600/
 * @Description  冲正
 */
@Service
public class CorrectDedutionervice {

    private static final Logger logger = Logger.getLogger(CorrectDedutionervice.class);

    @Autowired
    private TransferAccountsManageService transferAccountsManageService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private ReportFeign reportFeign;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Transactional(rollbackFor = {Exception.class})
    public Map<String, Object> correctDeduction(Map<String, Object> params){
        logger.info("<==  方法correctDeduction的参数::" + params + "   开始执行");

        int accountStatus = (int) params.get("accountStatus");
        Date date = new Date();

        // region 冲正金额
        int operationAmount = Integer.parseInt(ParamClassUtils.getParams(params.get("operationAmount")));
        Double correctAmount = Double.valueOf(operationAmount*0.01);
        BigDecimal correctBalance = new BigDecimal(String.valueOf(correctAmount));
        correctBalance = BigDecimal.ZERO.subtract(correctBalance);
        // endregion

        // region 根据不同的充值方式不同的处理方案：转账冲正
        Map<String,Object> tempTransferMap = new HashMap<>();
        Map<String,Object> transferResultMap = new HashMap<>();
        int rechargeType = Integer.parseInt(ParamClassUtils.getParams(params.get("rechargeType")));
        Double d = Double.valueOf(correctAmount);
        BigDecimal surplusRechargeAmount = new BigDecimal(String.valueOf(d));
        String rechargeNum = "";
        if (rechargeType == 2){
            // TODO 更新原转账金额
            rechargeNum = ParamClassUtils.getParams(params.get("rechargeNum"));
            tempTransferMap.put("random",rechargeNum);
            tempTransferMap.put("surplusRechargeAmount",surplusRechargeAmount);
            return ReturnResult.error("目前不支持转账冲正");
//            int result = transferAccountsManageService.effectiveTransfer(tempTransferMap);
//            if (result == 0){
//                logger.error("<== 冲正（转账）失败,服务返回结果为0");
//                return ReturnResult.error("冲正失败,请联系管理员");
//            } else {
//                logger.info("<==  冲正（转账）成功");
//
//            }
        }
        // endregion


        // region 获取用户信息、卡信息、冲正前余额
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        Etccardinfo etccardinfo = new Etccardinfo();
        // 冲正前余额
        Double preCardAccountBalance = null;
        Double preAccountBalance = null;
        if (accountStatus == 0){
            String certificateNumber = (String) params.get("certificateNumber");
            // 获取用户信息
            etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
            if (etcclientinfo == null){
                logger.info("<==  证件编号[" + certificateNumber + "]不是个人客户");
                etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<==  证件编号[" + certificateNumber + "]没有相应的客户信息");
                    return ReturnResult.errors("未找到相应的用户信息");
                }
            }
            preAccountBalance = etcclientinfo.getAccountBalance().doubleValue();
        }
        if (accountStatus == 1){
            String cardId = (String) params.get("accountSubjectNo");
            etccardinfo = cardMapper.getCard(cardId);
            if (etccardinfo == null){
                logger.error("<==  卡账户卡号[" + cardId + "]冲正，未找到对应的卡片信息");
                return ReturnResult.errors("未找到对应的卡片信息");
            }
            // 用户信息
            String spare = etccardinfo.getSpare();
            // 获取用户信息
            etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
            if (etcclientinfo == null){
                logger.info("<==  唯一标识[" + spare + "]冲正，未找到相应的用户信息");
                return ReturnResult.errors("未找到相应的用户信息");
            }
            preCardAccountBalance = etccardinfo.getCardAccountBalance().doubleValue();
        }
        // endregion

        // region 用户账户执行冲正
        if (accountStatus == 0){
            String spare = (String) params.get("spare");
            int clientType = Integer.valueOf(etcclientinfo.getClientType());
            spare = etcclientinfo.getSpare();
            // 用户账户冲正，直接传需冲正的金额（负数）即可，SQL计算
            Etcclientinfo etcclientinfo1 = new Etcclientinfo();
            etcclientinfo1.setSpare(spare);
            etcclientinfo1.setAccountBalance(correctBalance);
            int result = etcclientinfoMapper.updateByPrimaryKeySelective(etcclientinfo1);
            if (result != 1){
                logger.error("<==  唯一标识[" + spare + "]冲正失败");
                return ReturnResult.errors("冲正失败");
            }
        }
        // endregion

        // region 卡账户执行冲正
        if (accountStatus == 1){
            String cardId = (String) params.get("accountSubjectNo");
            int result = cardMapper.updateCardAccountBalance(correctBalance,cardId);
            if (result != 1){
                logger.error("<==  卡号[" + cardId + "]冲正失败");
                return ReturnResult.errors("冲正失败");
            }
        }
        // endregion

        // region 新增冲正记录
        FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
        frontBillingRecord.setId(UUIDUtils.getUUID());
        frontBillingRecord.setTransId((String) params.get("transId"));
        frontBillingRecord.setTradeNum((String) params.get("tradeNum"));
        frontBillingRecord.setChannelType((String) params.get("channelType"));
        frontBillingRecord.setChannelName((String) params.get("channelName"));
        frontBillingRecord.setChannelNum((String) params.get("channelNum"));
        frontBillingRecord.setEmployeeNo((String) params.get("employeeNo"));
        frontBillingRecord.setSiteName((String) params.get("siteName"));
        frontBillingRecord.setAcquirerNo((String) params.get("acquirerNo"));
        frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        frontBillingRecord.setClientName(etcclientinfo.getClientName());
        frontBillingRecord.setCertificateNumber(etcclientinfo.getSpare());
        if (accountStatus == 0){
            frontBillingRecord.setAccountSubject(1);
            frontBillingRecord.setAccountSubjectNo(etcclientinfo.getSpare());
            frontBillingRecord.setPreOperationBalance((int)(preAccountBalance*100));
            frontBillingRecord.setSufOperationBalance((int)(preAccountBalance*100) - operationAmount);
        }
        if (accountStatus == 1){
            frontBillingRecord.setAccountSubject(2);
            frontBillingRecord.setAccountSubjectNo(etccardinfo.getCardId());
            frontBillingRecord.setPreOperationBalance((int)(preCardAccountBalance*100));
            frontBillingRecord.setSufOperationBalance((int)(preCardAccountBalance*100) - operationAmount);
        }
        frontBillingRecord.setAccountSubjectStatus(1);
        frontBillingRecord.setOperationType(2);
        frontBillingRecord.setRechargeType(rechargeType);
        frontBillingRecord.setOperationAmount(operationAmount);
        frontBillingRecord.setRechargeNum(rechargeNum);
        frontBillingRecord.setOperationMark(2);
        frontBillingRecord.setOperationUser((String) params.get("createBy"));
        frontBillingRecord.setOperationTime(date);
        frontBillingRecord.setCreateBy((String) params.get("createBy"));
        frontBillingRecord.setRemove(0);
        frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
        // endregion

        // region 营改增数据上报
        if (accountStatus == 1){
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Map<String,Object> sendReversalMap = new HashMap<>();
            //交易流水号+ 1（冲正标志）
            sendReversalMap.put("id",ParamClassUtils.getParams(params.get("tradeNum") + "1"));
            sendReversalMap.put("effectiveTime",dateFormat.format(new Date()).replaceAll(" ","T"));
            sendReversalMap.put("cardId",ParamClassUtils.getParams(params.get("cardId")));
            try {
                reportFeign.sendReversal(sendReversalMap);
            } catch (Exception e) {
                logger.error("<==  卡号" + ParamClassUtils.getParams(params.get("cardId")) + " 冲正数据上报服务异常" + e.getMessage());
            }
        }
        // endregion

        logger.info("<==  方法correctDeduction执行结束");
        return ReturnResult.successs("冲正成功");
    }

}
