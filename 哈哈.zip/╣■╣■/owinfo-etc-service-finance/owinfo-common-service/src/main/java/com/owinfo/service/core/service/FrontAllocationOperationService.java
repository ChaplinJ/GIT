package com.owinfo.service.core.service;

import com.owinfo.object.entity.FrontAllocationOperation;
import com.owinfo.service.core.mapper.FrontAllocationOperationMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 资金分配操作
 */
@Service
public class FrontAllocationOperationService {

    @Autowired
    private FrontAllocationOperationMapper frontAllocationOperationMapper;

    /**
     * 新增资金分配操作记录
     * @param frontAllocationOperation
     * @return
     */
    public int addAllocationOperationRecord(FrontAllocationOperation frontAllocationOperation){
        return frontAllocationOperationMapper.insertSelective(frontAllocationOperation);
    }

}
