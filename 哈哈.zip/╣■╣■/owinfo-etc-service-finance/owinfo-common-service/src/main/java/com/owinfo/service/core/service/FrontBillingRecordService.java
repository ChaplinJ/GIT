package com.owinfo.service.core.service;

import com.owinfo.object.dto.AccountRechargeDTO;
import com.owinfo.object.dto.FinanceFlowDTO;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.FrontBillingRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 账单记录
 */
@Service
public class FrontBillingRecordService {

    @Autowired
    private FrontBillingRecordMapper frontBillingRecordMapper;

    /**
     * 新增账单记录
     * @param frontBillingRecord
     * @return
     */
    public int addBillingOperationRecord(FrontBillingRecord frontBillingRecord){
        return frontBillingRecordMapper.insertSelective(frontBillingRecord);
    }

    /**
     * ETC卡资金流动查询
     * @param params
     * @return
     */
    public List<FinanceFlowDTO> financeflowSearch(Map<String,Object> params) {
        return frontBillingRecordMapper.selectFinanceFlowList(params);
    }

    /**
     * ETC资金流动查询(包括卡和用户的资金)  --  此处查卡的资金流动
     * @param params
     * @return
     */
    public List<FinanceFlowDTO> etcCardFinanceFlowSearch(Map<String,Object> params) {
        return frontBillingRecordMapper.selectEtcCardFinanceFlowList(params);
    }

    /**
     * ETC资金流动查询(包括卡和用户的资金)  --  此处查用户本身已经用户名下所有卡的资金流动
     * @param params
     * @return
     */
    public List<FinanceFlowDTO> etcAccountFinanceFlowSearch(Map<String,Object> params) {
        return frontBillingRecordMapper.selectEtcAccountFinanceFlowList(params);
    }

    /**
     * 用户账户充值查询
     * @param params
     * @return
     */
    public List<AccountRechargeDTO> userAccountRechargeSearch(Map<String,Object> params){
        return frontBillingRecordMapper.selectUserAccountRechargeList(params);
    }

    /**
     * 获取用户账户的最新一条交易记录信息
     * @param params
     * @return
     */
    public FrontBillingRecord validateCorrectDedution(Map<String,Object> params){
        return frontBillingRecordMapper.selectUserTransactionDetail(params);
    }

    /**
     * 获取卡账户的最新一条交易记录信息
     * @param params
     * @return
     */
    public FrontBillingRecord validateCorrectDedutions(Map<String,Object> params){
        return frontBillingRecordMapper.selectUserTransactionDetails(params);
    }

    /**
     * 更新账单补圈存状态
     * @param map
     * @return
     */
    public int updateTransferRecord(Map<String,Object> map) {
        return frontBillingRecordMapper.updateTransferRecord(map);
    }

    /**
     * 补圈之后，更新圈存账单补圈存状态  chenxiaofeng   2018-03-21
     * @param map
     * @return
     */
    public int updateRepairTransferRecord(Map<String,Object> map) {
        return frontBillingRecordMapper.updateRepairTransferRecord(map);
    }

    /**
     * 获取最新一条银行充值记录信息
     * @param params
     * @return
     */
    public FrontBillingRecord getLastBankRechargeRecord(Map<String,Object> params){
        return frontBillingRecordMapper.getLastBankRechargeRecord(params);
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 查询用户账户、卡账户充值、转账、圈存操作记录
     * @Params:  * @param null
     * @Date: 2017/12/7 12:53
     */
    public List<FrontBillingRecord> financeSelect(Map<String, Object> map){
        return frontBillingRecordMapper.financeSelect(map);
    }

    /**
     * 银行充值渠道交易流水号验重
     * @param transId
     * @return
     */
    public Boolean TransIdValidate(String transId){
        return frontBillingRecordMapper.TransIdValidate(transId);
    }


}
