package com.owinfo.service.core.service;

import com.owinfo.object.entity.FrontPayBack;
import com.owinfo.service.core.mapper.FrontPayBackMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2018年01月04日
 *         github : https://github.com/rexlin600/
 * @Description  补交收款服务
 */
@Service
public class FrontPayBackService {

    @Autowired
    private FrontPayBackMapper frontPayBackMapper;

    public int addPayBackRecord(FrontPayBack frontPayBack){
        return frontPayBackMapper.insertSelective(frontPayBack);
    }

    public int delPayBackRecord(ArrayList<String> ids){
        return frontPayBackMapper.deleteByPrimaryKey(ids);
    }

    public List<FrontPayBack> getPayBackList(Map<String,Object> params){
        return frontPayBackMapper.getPayBackList(params);
    }

    public int updatePayBackStatus(Map<String,Object> params){
        return frontPayBackMapper.updatePayBackStatus(params);
    }

}
