package com.owinfo.service.core.service;

import com.owinfo.object.entity.FrontPaybackOperation;
import com.owinfo.service.core.mapper.FrontPaybackOperationMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 补交收款
 */
@Service
public class FrontPaybackOperationService {

    @Autowired
    private FrontPaybackOperationMapper frontPaybackOperationMapper;

    /**
     * 新增补交收款记录
     * @param frontPaybackOperation
     * @return
     */
    public int addPayBackOperationRecord(FrontPaybackOperation frontPaybackOperation){
        return frontPaybackOperationMapper.insertSelective(frontPaybackOperation);
    }

}
