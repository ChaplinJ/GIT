package com.owinfo.service.core.service;

import com.owinfo.object.entity.FrontRechargeOperation;
import com.owinfo.service.core.mapper.FrontRechargeOperationMapper;
import com.owinfo.service.util.DataValidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 充值冲正
 */
@Service
public class FrontRechargeOperationService {

    @Autowired
    private FrontRechargeOperationMapper frontRechargeOperationMapper;

    /**
     * 新增充值冲正记录
     * @param frontRechargeOperation
     * @return
     */
    public int addRechargeOperationRecord(FrontRechargeOperation frontRechargeOperation){
        return frontRechargeOperationMapper.insertSelective(frontRechargeOperation);
    }

    public int changeCard(Map<String, Object> params) {
        params.put("updateTime", DataValidate.validateDate());
        return frontRechargeOperationMapper.changeCard(params);
    }
}
