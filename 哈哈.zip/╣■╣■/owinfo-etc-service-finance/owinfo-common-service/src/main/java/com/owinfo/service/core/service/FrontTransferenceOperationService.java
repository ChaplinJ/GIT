package com.owinfo.service.core.service;

import com.owinfo.object.entity.*;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.FrontTransferenceOperationMapper;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.QuanCunVO;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月24日
 *         github : https://github.com/rexlin600/
 * @Description 圈存操作
 */
@Service
public class FrontTransferenceOperationService {

    private static final Logger logger = Logger.getLogger(FrontTransferenceOperationService.class);

    @Autowired
    private FrontTransferenceOperationMapper frontTransferenceOperationMapper;

    @Autowired
    private FrontTransferenceOperationService frontTransferenceOperationService;

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private FrontTransfrenceService frontTransfrenceService;

    /**
     * 新增圈存操作记录
     * @param frontTransferenceOperation
     * @return
     */
    public int addTransferOperationRecord(FrontTransferenceOperation frontTransferenceOperation){
        return frontTransferenceOperationMapper.insertSelective(frontTransferenceOperation);
    }

    /**
    * @description 卡账查询
    * @author hekunlin 2018/1/16 15:22 Version 1.0
    * @param
    * @return
    */
    @Transactional
    public Map<String,Object> cardAccountResearch(String cardNo,String cardInfo){
        logger.info("<==  方法cardAccountResearch的参数::" + cardNo + "  " + cardInfo + "   开始执行");

        int onlineSn = Integer.parseInt(cardInfo.substring(8,12),16);

        logger.info("<==  圈存卡账查询开始 onlineSn=[" + onlineSn + "]  cardNo=[" + cardNo +"]");

        // 获取数据库最新的圈存操作记录
        FrontTransferenceOperation frontTransferenceOperation =
                frontTransferenceOperationMapper.getLastTransferOperation(cardNo,onlineSn-1);

        logger.info("<==  最新的圈存操作记录onlineSn-1对应的圈存操作记录" + frontTransferenceOperation);

        if (frontTransferenceOperation != null){
            logger.info("<==  更新上次圈存完成记录 Start");
            String id = frontTransferenceOperation.getId();
            int result = frontTransferenceOperationMapper.updateTransferOperations(id);
            if (result == 0){
                logger.error("<==  卡号[" + cardNo + "] 更新上次圈存完成记录失败");
                throw new RuntimeException("更新上次圈存完成记录失败");
            }
            logger.info("<==  更新上次圈存完成记录 End");
            // 需要加一个更新上次圈存完成记录操作日志
            FrontTransfrenceLog frontTransfrenceLog = new FrontTransfrenceLog();
            frontTransfrenceLog.setId(UUIDUtils.getUUID());
            frontTransfrenceLog.setCardNo(cardNo);
            frontTransfrenceLog.setOnlineSn(onlineSn-1);
            frontTransfrenceLog.setOperationAmount(frontTransferenceOperation.getOperationMoney());
            frontTransfrenceLog.setPreOperationAmount(frontTransferenceOperation.getOperationPreMoney());
            frontTransfrenceLog.setSufOperationAmount(frontTransferenceOperation.getOperationSufMoney());
            frontTransfrenceLog.setCreateBy(null);
            frontTransfrenceLog.setCreateTime(new Date());
            frontTransfrenceLog.setContent("更新上一次圈存完成记录成功");
            int addLogResult = frontTransfrenceService.addTransfrenceLog(frontTransfrenceLog);
            if (addLogResult != 1){
                logger.info("<==   新增上一次圈存完成记录日志失败");
            }
            logger.info("<==  新增更新上一次圈存完成记录日志成功");
        }

        // 获取数据库最新的圈存操作记录
        FrontTransferenceOperation frontTransferenceOperations =
                frontTransferenceOperationMapper.getLastTransferOperation(cardNo,onlineSn);

        logger.info("<==  最新的圈存操作记录onlineSn" + frontTransferenceOperations);

        Map<String, Object> tempMap = new HashMap<>();
        tempMap.put("operationStatus",0);

        if (frontTransferenceOperations != null){
            logger.info("<==  设置补圈状态和补圈金额");
            String tradeNum = frontTransferenceOperations.getTradeNum();
            tempMap.put("operationStatus",1);
            tempMap.put("fillAmout",frontTransferenceOperations.getOperationMoney());
            // 更新账单表补圈存状态
            Map<String, Object> temp = new HashMap<>();
            temp.put("cardNo",cardNo);
            temp.put("tradeNum",tradeNum);
            int result = frontBillingRecordService.updateTransferRecord(temp);
            FrontTransfrenceLog frontTransfrenceLog = new FrontTransfrenceLog();
            frontTransfrenceLog.setId(UUIDUtils.getUUID());
            frontTransfrenceLog.setCardNo(cardNo);
            frontTransfrenceLog.setOnlineSn(onlineSn);
            frontTransfrenceLog.setOperationAmount(frontTransferenceOperations.getOperationMoney());
            frontTransfrenceLog.setPreOperationAmount(frontTransferenceOperations.getOperationPreMoney());
            frontTransfrenceLog.setSufOperationAmount(frontTransferenceOperations.getOperationSufMoney());
            frontTransfrenceLog.setCreateBy(null);
            frontTransfrenceLog.setCreateTime(new Date());
            frontTransfrenceLog.setContent("更新上一次圈存账单表状态成功");
            int addLogResult = frontTransfrenceService.addTransfrenceLog(frontTransfrenceLog);
            if (result != 1){
                logger.error("<==  更新账单表圈存状态失败");
            }
            logger.info("<==  更新账单表圈存状态成功");
        }

        // 卡账查询 补圈存状态、金额
        Etccardinfo etccardinfo = cardMapper.getCard(cardNo);
        if(etccardinfo == null){
            logger.info("<==  没有获取到该卡[" + cardNo + "]的卡信息" );
            throw new RuntimeException("没有获取到该卡的卡信息");
        }
        String spare = etccardinfo.getSpare();
        logger.info("<==  圈存用户唯一标识spare[" +  spare + "]");
        // 用户信息
        Etcclientinfo etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  卡号[" + cardNo + "]圈存获取用户账户信息失败");
            throw new RuntimeException("没有获取到[" + cardNo + "]的用户信息");
        }
        String clientType = etcclientinfo.getClientType();
        logger.info("<==  卡号[" + cardNo + "]圈存获取用户信息成功" + etcclientinfo.toString());
        // 设置客户名称、卡账户余额等信息
        if ("1".equals(clientType)){
            tempMap.put("clientName",etcclientinfo.getClientName());
        }
        if ("2".equals(clientType)){
            tempMap.put("clientName",etcclientinfo.getUnitName());
        }
        tempMap.put("cardAccountBalance",etccardinfo.getCardAccountBalance());
        tempMap.put("cardStatus",etccardinfo.getCardStatus());
        tempMap.put("payType",etccardinfo.getPayType());
        tempMap.put("clientType",etcclientinfo.getClientType());
        tempMap.put("carLicense",etccardinfo.getVehicleLicense());
//        tempMap.put("cardBalance",Integer.parseInt(cardInfo.substring(0,8),16));
        logger.info("<==  方法getLastTransferRecord执行结束,返回的参数 " + tempMap.toString());
        return tempMap;
    }

    /**
    * @description 圈存初始化
    * @author hekunlin 2018/1/16 14:18 Version 1.0
    * @param
    * @return
    */
    @Transactional
    public boolean quanCun(QuanCunVO quanCunVO){
        logger.info("<==  方法quanCun的参数::" + quanCunVO.toString() + "   开始执行");

        quanCunVO.setRandom(quanCunVO.getCardInfo().substring(16,24));
        String cardNo = quanCunVO.getCardNo();
        int onlineSn = Integer.parseInt(quanCunVO.getCardInfo().substring(8,12),16);
        int amount = quanCunVO.getOperationMoney();
        int cardAmount = Integer.parseInt(quanCunVO.getCardInfo().substring(0,8),16);

        // 获取数据库最新的圈存操作记录
        FrontTransferenceOperation frontTransferenceOperations =
                frontTransferenceOperationMapper.getLastTransferOperation(cardNo,onlineSn);

        if (frontTransferenceOperations != null){
            if ((amount > 0) && (amount - frontTransferenceOperations.getOperationMoney() != 0)){
                throw new RuntimeException("补圈金额与数据库金额不一致");
            }
            logger.error("<==  补圈存 " + frontTransferenceOperations.toString());
            // 加一个补圈存历史记录表
            FrontTransfrenceLog frontTransfrenceLog = new FrontTransfrenceLog(UUIDUtils.getUUID(),cardNo,
                    onlineSn,frontTransferenceOperations.getOperationPreMoney(),
                    frontTransferenceOperations.getOperationMoney(),frontTransferenceOperations.getOperationSufMoney()
                    ,new Date(),null,0,"新增补圈存记录");
            quanCunVO.setTradeNum(frontTransferenceOperations.getTradeNum());

            int addLogResult = frontTransfrenceService.addTransfrenceLog(frontTransfrenceLog);
            if (addLogResult != 1){
                logger.info("<==   新增补圈存记录日志失败");
                throw new RuntimeException("新增补圈存记录日志失败");
            }
            logger.info("<==  新增补圈存记录日志成功");
            logger.info("<==  补圈金额=[" + amount + "]  上次圈存金额[" +  frontTransferenceOperations.getOperationMoney() + "]");
            return amount - frontTransferenceOperations.getOperationMoney() == 0 ? true : false;
        }

        //本次交易金额 >z0


        // 1：验钱：卡账户钱 - 本次交易金额 >z0
        Etccardinfo etccardinfo = cardMapper.getCard(cardNo);
        String str = null;
        if(etccardinfo == null){
            logger.info("<==  没有获取到该卡的卡信息" );
            throw new RuntimeException("没有获取到该卡的卡信息");
//            return false;
        }
        // 获取用户信息
        String spare = etccardinfo.getSpare();
        Etcclientinfo etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  卡号[" + cardNo + "]圈存获取用户账户信息失败");
            throw new RuntimeException("没有获取到该卡的对应的用户信息");
        }
        logger.info("<==  获取卡号[" + cardNo + "]的用户信息成功");

        Map<String, Object> car = new HashMap<>();
        try {
            car.put("cardId", etccardinfo.getCardId());
            car = cardMapper.getcar(car);
        }catch(Exception e){
            logger.info("获取车辆信息异常");
//            car.put("vehicleType","");//有多个车
//            return false;
            car = null;
//            throw new RuntimeException("获取车辆信息异常");
        }
        if(car != null && car.get("vehicleType") != null && !"".equals(car.get("vehicleType"))){
            str =String.valueOf(car.get("vehicleType"));
//            car.put("vehicleType","111111111");//没有车
        }

        BigDecimal account = etccardinfo.getCardAccountBalance();
        int accountBalance = account.multiply(BigDecimal.valueOf(100L)).intValue();

        if(amount<=0){
            logger.error("<==  圈存金额不能小于等于0");
            throw new RuntimeException("圈存金额不能小于等于0");
        }

        if ( (accountBalance <= 0) || (accountBalance - amount < 0) ){
            logger.error("<==  卡账户余额不足以支撑本次圈存");
            // 加一个圈存历史记录表
            FrontTransfrenceLog frontTransfrenceLog = new FrontTransfrenceLog(UUIDUtils.getUUID(),cardNo,
                    onlineSn,frontTransferenceOperations.getOperationPreMoney(),
                    frontTransferenceOperations.getOperationMoney(),frontTransferenceOperations.getOperationSufMoney()
                    ,new Date(),null,0,"卡账户余额不足以支撑本次圈存");
            int addLogResult = frontTransfrenceService.addTransfrenceLog(frontTransfrenceLog);
            if (addLogResult != 1){
                logger.info("<==   新增圈存验钱记录日志失败");
            }
            logger.info("<==  新增圈存验钱记录日志成功");
            throw new RuntimeException("卡账户余额不足以支撑本次圈存");
        }

        // 2：卡账户扣钱：加账单表
        // 2.1：卡账户扣钱
        // 需要把钱转为元单位的BigDecimal
        int resultA = cardMapper.updateCardAccountBalance(BigDecimal.ZERO.subtract(new BigDecimal((amount*0.01)+"")),
                cardNo);
        if (resultA != 1){
            logger.error("<==  卡账户扣钱失败 resultA= " + resultA);
            throw new RuntimeException("卡账户扣钱失败 resultA= " + resultA);
        }

        // 2.2：新增卡账户账单记录
        Date date = new Date();
        FrontBillingRecord cardAccountRecord = new FrontBillingRecord();
        // FIXME 补全参数
        cardAccountRecord.setId(UUIDUtils.getUUID());
        cardAccountRecord.setTradeNum(quanCunVO.getTradeNum());
        cardAccountRecord.setChannelNum(quanCunVO.getChannelNum());
        cardAccountRecord.setChannelName(quanCunVO.getChannelName());
        cardAccountRecord.setChannelType(quanCunVO.getChannelType());
        cardAccountRecord.setAcquirerNo(quanCunVO.getAcquirerNo());
        cardAccountRecord.setSiteName(quanCunVO.getSiteName());
        cardAccountRecord.setEmployeeNo(quanCunVO.getEmployeeNo());
        cardAccountRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        cardAccountRecord.setClientName(etcclientinfo.getClientName());
        cardAccountRecord.setCertificateNumber(etcclientinfo.getSpare());
        cardAccountRecord.setVehicleLicense(etccardinfo.getVehicleLicense());
//        cardAccountRecord.setVehicleType(String.valueOf(car.get("vehicleType")));
        cardAccountRecord.setVehicleType(str);
        cardAccountRecord.setAccountSubject(2);
        cardAccountRecord.setAccountSubjectNo(quanCunVO.getCardNo());
        cardAccountRecord.setAccountSubjectStatus(1);
        cardAccountRecord.setOperationType(3); // 圈存
        cardAccountRecord.setOperationMark(2); // 卡账户-
        cardAccountRecord.setPreOperationBalance(accountBalance);
        cardAccountRecord.setOperationAmount(quanCunVO.getOperationMoney());
        cardAccountRecord.setSufOperationBalance(accountBalance - quanCunVO.getOperationMoney());
        cardAccountRecord.setOperationUser(quanCunVO.getOperationUser());
        cardAccountRecord.setOperationTime(date);
        cardAccountRecord.setCreateBy(quanCunVO.getOperationUser());
        frontBillingRecordService.addBillingOperationRecord(cardAccountRecord);

        //:3：新增圈存初始化记录
        // 3.1：圈存
        FrontTransferenceOperation frontTransferenceOperation = new FrontTransferenceOperation();
        frontTransferenceOperation.setOptTime(date);
        frontTransferenceOperation.setCreateTime(date);
        frontTransferenceOperation.setCardInfo(quanCunVO.getCardInfo());
        frontTransferenceOperation.setCardNo(cardNo);
        frontTransferenceOperation.setClientNo(etccardinfo.getClientNo());

        //更新id为卡号+onlineSn
//        frontTransferenceOperation.setId(UUIDUtils.getUUID());
        frontTransferenceOperation.setId(cardNo+onlineSn);

        frontTransferenceOperation.setOnlineSn(onlineSn);
        frontTransferenceOperation.setOperationPreMoney(Integer.parseInt(quanCunVO.getCardInfo().substring(0,8),16));
        frontTransferenceOperation.setOperationMoney(quanCunVO.getOperationMoney());
        frontTransferenceOperation.setOperationSufMoney(Integer.parseInt(quanCunVO.getCardInfo().substring(0,8),16)
                + quanCunVO.getOperationMoney());
        frontTransferenceOperation.setOperationStatus(0);
        frontTransferenceOperation.setRandom(quanCunVO.getRandom());
        frontTransferenceOperation.setTerminalNo(quanCunVO.getTerminal());
        frontTransferenceOperation.setTradeNum(quanCunVO.getTradeNum());
        frontTransferenceOperation.setSignData(quanCunVO.getSignData());
        frontTransferenceOperation.setCreateBy(quanCunVO.getEmployeeNo());
        frontTransferenceOperation.setUpdateTime(date);
        frontTransferenceOperation.setUpdateBy(quanCunVO.getEmployeeNo());
        frontTransferenceOperation.setEmployeeNo(quanCunVO.getEmployeeNo());
        frontTransferenceOperation.setSiteName(quanCunVO.getSiteName());
        frontTransferenceOperationMapper.insertSelective(frontTransferenceOperation);

        // 3.2：更新电子钱包金额：前台传读取到硬件卡片的离线金额 + 本次圈存的金额
        // FIXME 电子钱包金额计算
        int resultB = cardMapper.updateCardBalance(new BigDecimal(((amount+cardAmount)*0.01)+""),cardNo);

        // 3.3：新增电子钱包账单记录
        FrontBillingRecord cardRecord = new FrontBillingRecord();
        cardRecord.setId(UUIDUtils.getUUID());
        cardRecord.setTradeNum(quanCunVO.getTradeNum());
        cardRecord.setChannelNum(quanCunVO.getChannelNum());
        cardRecord.setChannelName(quanCunVO.getChannelName());
        cardRecord.setChannelType(quanCunVO.getChannelType());
        cardRecord.setAcquirerNo(quanCunVO.getAcquirerNo());
        cardRecord.setSiteName(quanCunVO.getSiteName());
        cardRecord.setEmployeeNo(quanCunVO.getEmployeeNo());
        cardRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        cardRecord.setClientName(etcclientinfo.getClientName());
        cardRecord.setCertificateNumber(etcclientinfo.getSpare());
        cardRecord.setVehicleLicense(etccardinfo.getVehicleLicense());
//        cardAccountRecord.setVehicleType(String.valueOf(car.get("vehicleType")));
        cardAccountRecord.setVehicleType(str);
        cardRecord.setAccountSubject(3);
        cardRecord.setAccountSubjectNo(quanCunVO.getCardNo());
        cardRecord.setAccountSubjectStatus(1);
        cardRecord.setOperationType(3); // 圈存
        cardRecord.setOperationMark(1); // 电子钱包账户+
        cardRecord.setPreOperationBalance(Integer.parseInt(quanCunVO.getCardInfo().substring(0,8),16));
        cardRecord.setOperationAmount(quanCunVO.getOperationMoney());
        cardRecord.setSufOperationBalance(Integer.parseInt(quanCunVO.getCardInfo().substring(0,8),16)
                + quanCunVO.getOperationMoney());
        cardRecord.setOperationUser(quanCunVO.getOperationUser());
        cardRecord.setOperationTime(date);
        cardRecord.setCreateBy(quanCunVO.getCreateBy());
        frontBillingRecordService.addBillingOperationRecord(cardRecord);

        //:4：验证：读取数据库卡账户金额 如果卡账户金额 < 0，则直接回滚
        Etccardinfo etccardinfos = cardMapper.getCard(cardNo);
        if(etccardinfo == null){
            logger.info("<==  没有获取到该卡的卡信息" );
            throw new RuntimeException("没有获取到该卡的卡信息");
        }
        int accountBalances = etccardinfo.getCardAccountBalance().multiply(BigDecimal.valueOf(100L)).intValue();

        if (accountBalances < 0){
            logger.error("<==  账户余额不足，不足以支撑本次圈存");
            throw new RuntimeException("账户余额不足，不足以支撑本次圈存");
        }

        logger.info("<==  方法quanCun执行结束");
        return true;
    }


    /**
     * 圈存完成
     * @param cardNo
     * @param onlineSn
     * @return
     */
    public int updateTransferOperation(String cardNo, int onlineSn){
        return frontTransferenceOperationMapper.updateTransferOperation(cardNo, onlineSn);
    }

    public int updateTransferOperationByTradeNumber(String cardNo, String tradeNum) {
        return frontTransferenceOperationMapper.updateTransferOperationByTradeNumber(cardNo,tradeNum);
    }

    @Transactional
    public void quancunWancheng(Map<String, Object> params) {
//        int a = 0;
        Map<String,Object> map1 = new HashMap<>();
        map1.put("cardNo",params.get("cardNo"));
        map1.put("tradeNum",params.get("tradeNum"));
//            map1.put("onlineSn",Integer.parseInt(String.valueOf(params.get("onlineSn")),16));
        Map<String,Object> map2 = new HashMap<>();
        map2.put("cardNo",params.get("cardNo"));
        map2.put("tradeNum",params.get("tradeNum"));


        String cardNo = ParamClassUtils.getParams(params.get("cardNo"));
        String tradeNum = ParamClassUtils.getParams(params.get("tradeNum"));
//            int onlineSn = Integer.parseInt(ParamClassUtils.getParams(params.get("onlineSn")));
        logger.info("<==  补圈存记录参数 cardNo=" + cardNo + " tradeNum=" + tradeNum);
//        Map<String,Object> map = new HashMap<>();
//        map.put("cardNo",cardNo);
//        map.put("onlineSn",onlineSn);
//            int operationResult = frontTransferenceOperationService.updateTransferOperation(cardNo,tradeNum);
        int operationResult = frontTransferenceOperationService.updateTransferOperationByTradeNumber(cardNo,tradeNum);

        if (operationResult <= 0){
            logger.error("新增补圈存操作记录失败");
            throw new RuntimeException("新增补圈存操作记录失败");
//            return a;
        }
//        a++;
        logger.info("新增补圈存操作记录成功");
//            return ReturnResult.success("补圈存操作记录成功");

//            String tradeNum = ParamClassUtils.getParams(params.get("tradeNum"));
        logger.info("<==  补圈存记录参数 cardNo=" + cardNo + " tradeNum=" + tradeNum);
        // 取出需要新增记录的参数
        Map<String,Object> map = new HashMap<>();
        map.put("cardNo",cardNo);
        map.put("tradeNum",tradeNum);
        int result = frontBillingRecordService.updateTransferRecord(map);
        if (result <= 0){
            logger.error("更新补圈存状态账单记录失败");
            throw new RuntimeException("更新补圈存状态账单记录失败");
//            return a;
        }
//        a++;
        logger.info("更新补圈存状态账单记录成功");
//            return ReturnResult.success("更新补圈存状态账单记录成功");
    }


}
