package com.owinfo.service.core.service;

import com.owinfo.object.entity.FrontTransfrenceLog;
import com.owinfo.service.core.mapper.FrontTransfrenceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Created by hekunlin on 2018年01月16日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class FrontTransfrenceService {

    @Autowired
    private FrontTransfrenceMapper frontTransfrenceMapper;

    public int addTransfrenceLog(FrontTransfrenceLog frontTransfrenceLog){
        return frontTransfrenceMapper.addTransfrenceLog(frontTransfrenceLog);
    }

}
