package com.owinfo.service.core.service;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.object.entity.MapOnline;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.core.mapper.MapOnlineMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2018年01月22日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class IncreRechargeService {

    private static final Logger logger = Logger.getLogger(IncreRechargeService.class);

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private FrontRechargeOperationService frontRechargeOperationService;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private MapOnlineMapper mapOnlineMapper;

    @Autowired
    private ReportFeign reportFeign;

    @Autowired
    private CardMapper cardMapper;

    @Transactional(rollbackFor = {Exception.class})
    public Map<String, Object> increRecharge(Map<String, Object> params){
        logger.info("<==  方法increRecharge的参数::" + params + "   开始执行");

        Map<String, Object> errorMap = new HashMap<>();
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        try {
            // region 金额
            String totalBalance = ParamClassUtils.getParams(params.get("totalAmount"));
            String giftBalacne = ParamClassUtils.getParams(params.get("giftAmount"));
            String etcBalance = ParamClassUtils.getParams(params.get("etcAmount"));
            // endregion

            // region 获取充值类型、银行编号、卡号并传入校验(去掉多余的0)
            String accountType = String.valueOf(params.get("accountType")).replaceFirst("^0*","");
            int rechargeType = Integer.valueOf(accountType);
            String channelCode = String.valueOf(params.get("channelCode"));
            String channelTransId = String.valueOf(params.get("channelTransId"));
            String channelFinTime = String.valueOf(params.get("channelFinTime"));
            // 充值金额
            int etcAmount = Integer.valueOf(etcBalance);
            int giftAmount = Integer.valueOf(giftBalacne);
            // 相当于amount
            int totalAmount = Integer.valueOf(totalBalance);
            // endregion

            // region 渠道网点认证：平安、邮政储蓄
            MapOnline mapOnline = mapOnlineMapper.selectByPrimaryKey(channelCode);
            if (mapOnline == null){
                logger.error("<==  未获取到[" + channelCode + "]对应的渠道相关信息");
                errorMap.put("stateCode","2222");
                errorMap.put("field","未获取到[" + channelCode + "]对应的渠道相关信息");
                return errorMap;
            }
            String dotContactName = null;
            String dotName = null;
            String dotNo = mapOnline.getId();
            String channelName = mapOnline.getName();
//            String channelId = mapOnline.getId().substring(0,10);
            String channelId = dotNo;
            if (dotNo.equals("410101020150201")){
                dotContactName = "平安银行";
                dotName = "平安银行郑州市分行";
            }
            if (dotNo.equals("410101020060201")){
                dotContactName = "邮政储蓄";
                dotName = "邮储银行郑州众意西路支行";
            }
            // endregion

            // region 获取交易流水号
            String tradeNumber = (String) params.get("tradeNumber");
            logger.info("<==  本次交易交易流水号为tradeNumber= " + tradeNumber);
            // endregion

            // region 如果是卡充值
            if (rechargeType == 1){
                // 卡ID
                String cardId = (String) params.get("etcCardId");
                // 校验卡号是否存在
                if (StringUtils.isEmpty(cardId)){
                    logger.error("<== 卡号不能为空");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","卡号不能为空");
                    return errorMap;
                }

                Map<String, Object> tempCardMap = new HashMap<>();
                tempCardMap.put("cardId",cardId);
                // 获取卡信息
                Etccardinfo etccardinfo = cardMapper.getCard(cardId);
                if (etccardinfo == null){
                    logger.error("<==  获取卡信息为空，不允许充值");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","未查到该卡片信息");
                    return errorMap;
                }
                if (etccardinfo.getCardAccountBalance().compareTo(BigDecimal.ZERO) == -1){
                    logger.error("<==  卡账户余额[" + etccardinfo.getCardAccountBalance() + "]为负数，不允许充值");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","卡账户余额为负数，不允许充值");
                    return errorMap;
                }
                logger.info("<==  获取卡信息成功 " + etccardinfo.toString());

                // 判断卡状态
                String cardStatus = etccardinfo.getCardStatus();
//                String certificateNumber = etccardinfo.getCertificateNumber();
                String spare = etccardinfo.getSpare();
                if (!cardStatus.equals("600202101")){
                    logger.error("<== 卡状态不正常，不允许充值");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","ETC卡状态不正常");
                    return errorMap;
                }
                // 验证卡类型
                String payType = etccardinfo.getPayType();
                if (payType.equals("2")){
                    logger.error("<== 记账卡不允许充值");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","记账卡不允许充值");
                    return errorMap;
                }

                // 金额转换：电子钱包、卡账户余额
                BigDecimal cardBalance = etccardinfo.getCardBalance();
                BigDecimal cardAccountBalance = etccardinfo.getCardAccountBalance();
                double d1 = cardBalance.doubleValue();
                double d2 = cardAccountBalance.doubleValue();
                int cardAmount = (int)(d1 * 100);
                int cardAccountAmount = (int)(d2 * 100);

                // 获取卡对应的用户信息
                Etcclientinfo etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
                if (etcclientinfo == null){
                    logger.info("<==  唯一标识[" + spare + "]未找到对应的用户信息");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","未找到对应的用户信息");
                    return errorMap;
                }
                logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());

                // 充值后卡余额
                int cardAcountBalance = cardAccountAmount + totalAmount;
                BigDecimal cardAccountBalances = new BigDecimal((double)(cardAcountBalance * 0.01));
                // 充值金额
                BigDecimal rechargeAmount = new BigDecimal(Double.valueOf(totalAmount*0.01));
                logger.info("<==  充值后[" + etccardinfo.getCardId() + "]卡余额 " + cardAccountBalances);

                int result = cardMapper.updateCardAccountBalance(rechargeAmount,cardId);
                if (result == 0){
                    logger.error("<==  卡账户充值失败");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","卡账户充值失败");
                    return errorMap;
                }
                logger.info("<==  卡[" + cardId + "]充值成功");

                // 新增账单记录
                FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
                frontBillingRecord.setId(UUIDUtils.getUUID());
                // 银行发送的流水号、清分时间
                frontBillingRecord.setTransId(channelTransId);
                try {
                    frontBillingRecord.setClearingTime(dateFormat.parse(channelFinTime));
                } catch (ParseException e) {
                    logger.error("<==  清分时间转换异常");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","清分时间转换异常");
                    return errorMap;
                }
                frontBillingRecord.setTradeNum(tradeNumber);
                frontBillingRecord.setChannelName(channelName);
                frontBillingRecord.setChannelNum(channelId);
                frontBillingRecord.setChannelType("3");
                frontBillingRecord.setAcquirerNo(dotNo);
                frontBillingRecord.setSiteName(dotName);
                frontBillingRecord.setEmployeeNo(dotContactName);
                if ("1".equals(etcclientinfo.getClientType())){
                    frontBillingRecord.setClientName(etcclientinfo.getClientName());
                }
                if ("2".equals(etcclientinfo.getClientType())){
                    frontBillingRecord.setClientName(etcclientinfo.getUnitName());
                }
                frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
                frontBillingRecord.setCertificateNumber(etccardinfo.getSpare());
                frontBillingRecord.setVehicleLicense(etccardinfo.getVehicleLicense());
                frontBillingRecord.setVehicleType(etccardinfo.getCardType());
                frontBillingRecord.setAccountSubject(2);
                frontBillingRecord.setAccountSubjectNo(cardId);
                frontBillingRecord.setAccountSubjectStatus(1);
                frontBillingRecord.setOperationType(15);
                frontBillingRecord.setOperationMark(1);
                frontBillingRecord.setPreOperationBalance(cardAccountAmount);
                frontBillingRecord.setOperationAmount(totalAmount);
                frontBillingRecord.setSufOperationBalance(cardAcountBalance);
                frontBillingRecord.setOperationTime(date);
                frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
                logger.info("<==  新增卡充值账单记录成功");

                // region FIXME 营改增数据上报
                Map<String, Object> sendRechargeMap = new HashMap<>();
                sendRechargeMap.put("id",tradeNumber);
                sendRechargeMap.put("paidAmount",String.valueOf(etcBalance));
                sendRechargeMap.put("giftAmount",String.valueOf(giftBalacne));
                sendRechargeMap.put("rechargeAmount",String.valueOf(totalBalance));
                sendRechargeMap.put("cardId",cardId);
                try {
                    reportFeign.sendRecharge(sendRechargeMap);
                }catch (Exception e) {
                    logger.error("<==  线上渠道上报异常，上报渠道编号 " + channelCode);
                }
                // endregion

                // 返回相关结果
                Map<String, Object> successMap = new HashMap<>();
                successMap.put("stateCode","0000");
                successMap.put("etcTransId",tradeNumber);
                successMap.put("channelTransId",channelTransId);
                successMap.put("etcCardId",cardId);
                successMap.put("totalAmount",totalBalance);
                successMap.put("giftAmount",giftBalacne);
                successMap.put("etcAmount",etcBalance);
                successMap.put("cardBalance",cardAmount);
                successMap.put("cardAcountBalance",cardAcountBalance);
                successMap.put("successTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
                successMap.put("channelFinTime",channelFinTime);
                logger.info("<==  卡充值成功");
                return successMap;
            }
            // endregion

            // region 如果是用户账户充值
            if (rechargeType == 2){
                // 证件编号
                String certificateNumber = ParamClassUtils.getParams(params.get("etcCertNum"));
                // 校验证件编号是否存在
                if (StringUtils.isEmpty(certificateNumber)){
                    logger.error("<== 证件编号不能为空");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","证件编号不能为空");
                    return errorMap;
                }

                Etcclientinfo etcclientinfo = new Etcclientinfo();
                etcclientinfo = etcclientinfoMapper.selectByPrimaryKey(certificateNumber);
                if (etcclientinfo == null){
                    logger.error("<==  不是个人客户充值，集团客户充值");
                    etcclientinfo = etcclientinfoMapper.selectByUnitNo(certificateNumber);
                    if (etcclientinfo == null){
                        logger.error("<== 不存在这个用户信息");
                        errorMap.put("stateCode","1111");
                        errorMap.put("field","未查到该用户信息");
                        return errorMap;
                    }
                }
                logger.info("<==  获取用户信息成功 " + etcclientinfo.toString());

                // 获取用户账户余额、用户证件类型（区别个人和集团）
                String accountBalance = etcclientinfo.getAccountBalance().toString();
    //            String accountBalance = String.valueOf(userMap.get("accountBalance"));
                double d3 = Double.valueOf(accountBalance);
                // 计算充值后的账户余额
                int userAccountBalance = (int)(d3*100);
                int laccountnum = userAccountBalance + totalAmount;
                // 根据客户类型区分证件号
                String clientType = etcclientinfo.getClientType();
    //            String clientType = String.valueOf(userMap.get("clientType"));

                String etcCertNum = certificateNumber;
    //            frontRechargeOperation.setCertificateNumber(certificateNumber);
                if (clientType.equals("2")){
                    etcCertNum = etcclientinfo.getUnitCertificateNo();
    //                frontRechargeOperation.setCertificateNumber(etcCertNum);
                }

                // 充值账户余额
                Map<String, Object> tempUserMap = new HashMap<>();
                BigDecimal userAcountBalance = new BigDecimal(Double.valueOf((totalAmount*0.01)));
                Etcclientinfo tempUser = new Etcclientinfo();
                tempUser.setSpare(etcclientinfo.getSpare());
                tempUser.setAccountBalance(userAcountBalance);
                int result = etcclientinfoMapper.updateByPrimaryKeySelective(tempUser);
                if (result == 0){
                    logger.error("<==  更新用户账户余额失败");
                    errorMap.put("stateCode","1111");
                    errorMap.put("field","用户账户充值失败");
                    return errorMap;
                }

                // region 新增账单记录
                Map<String, Object> rechargeMap = new HashMap<>();
                FrontBillingRecord frontBillingRecord = new FrontBillingRecord();
                frontBillingRecord.setId(UUIDUtils.getUUID());
                frontBillingRecord.setTransId(channelTransId);
                frontBillingRecord.setTradeNum(tradeNumber);
                frontBillingRecord.setChannelName(channelName);
                frontBillingRecord.setChannelType("3");
                frontBillingRecord.setChannelNum(channelId);
                frontBillingRecord.setAcquirerNo(dotNo);
                frontBillingRecord.setSiteName(dotName);
                frontBillingRecord.setEmployeeNo(dotContactName);
                if ("1".equals(etcclientinfo.getClientType())){
                    frontBillingRecord.setClientName(etcclientinfo.getClientName());
                }
                if ("2".equals(etcclientinfo.getClientType())){
                    frontBillingRecord.setClientName(etcclientinfo.getUnitName());
                }
                frontBillingRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
                frontBillingRecord.setCertificateNumber(etcclientinfo.getSpare());
                frontBillingRecord.setAccountSubject(1);
                frontBillingRecord.setAccountSubjectNo(etcclientinfo.getSpare());
                frontBillingRecord.setAccountSubjectStatus(1);
                frontBillingRecord.setOperationType(16);
                frontBillingRecord.setOperationMark(1);
                frontBillingRecord.setPreOperationBalance(userAccountBalance);
                frontBillingRecord.setOperationAmount(totalAmount);
                frontBillingRecord.setSufOperationBalance(laccountnum);
                frontBillingRecord.setOperationTime(date);
                frontBillingRecordService.addBillingOperationRecord(frontBillingRecord);
                logger.info("<==  新增用户充值账单记录成功");

                // 返回相关结果
                Map<String, Object> successMap = new HashMap<>();
                successMap.put("stateCode","0000");
                successMap.put("etcTransId",tradeNumber);
                successMap.put("totalAmount",totalBalance);
                successMap.put("giftAmount",giftBalacne);
                successMap.put("etcAmount",etcBalance);
                successMap.put("channelTransId",channelTransId);
                successMap.put("etcCertNum",etcCertNum);
                successMap.put("acountBalance",laccountnum);
                successMap.put("successTime",LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
                successMap.put("channelFinTime",channelFinTime);
                logger.info("<==  用户账户充值成功");
                return successMap;

            }
            // endregion

        }catch (DuplicateKeyException e){
            logger.error("<==  执行线上充值SQL异常,交易流水号重复 " + e.getMessage());
            errorMap.put("stateCode","1111");
            errorMap.put("field","唯一索引冲突,交易流水号重复");
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return errorMap;
        }catch (Exception e) {
            logger.error("<==  充值异常 " + e.getMessage());
            errorMap.put("stateCode","1111");
            errorMap.put("field","充值异常");
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return errorMap;
        }

        errorMap.put("stateCode","1111");
        errorMap.put("field","充值类型有误");
        logger.error("<== 充值类型有误");
        logger.info("<==  方法increRecharge执行结束");
        return errorMap;
    }


}
