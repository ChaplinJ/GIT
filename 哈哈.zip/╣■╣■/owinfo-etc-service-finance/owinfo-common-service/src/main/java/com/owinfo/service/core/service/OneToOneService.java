package com.owinfo.service.core.service;

import com.owinfo.object.entity.Etccardinfo;
import com.owinfo.object.entity.Etcclientinfo;
import com.owinfo.object.entity.FrontBillingRecord;
import com.owinfo.service.core.mapper.CardMapper;
import com.owinfo.service.core.mapper.EtcclientinfoMapper;
import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ParamClassUtils;
import com.owinfo.service.util.ReturnResult;
import com.owinfo.service.util.UUIDUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import javax.smartcardio.Card;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.owinfo.service.util.ParamClassUtils.getParams;

/**
 * @author Created by hekunlin on 2018年01月25日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Service
public class OneToOneService {

    private static final Logger logger = Logger.getLogger(OneToOneService.class);

    @Autowired
    private CardMapper cardMapper;

    @Autowired
    private EtcclientinfoMapper etcclientinfoMapper;

    @Autowired
    private FrontBillingRecordService frontBillingRecordService;

    @Autowired
    private ReportFeign reportFeign;

    @Transactional(rollbackFor = {Exception.class})
    public Map<String,Object> pointTransfer(@RequestBody Map<String, Object> params){
        logger.info("<==  方法pointTransfer的参数::" + params + "   开始执行");

        Date date = new Date();

        // region 获取卡信息、账户信息
        String cardId = (String) params.get("cardId");
        Etccardinfo etccardinfo = cardMapper.getCard(cardId);
        if (etccardinfo == null){
            logger.error("<==  未找到[" + cardId + "]对应的卡片信息");
            return ReturnResult.errors("未找到对应的卡片信息");
        }

        // 20180129修正证件编号
        String spare = etccardinfo.getSpare();
        Etcclientinfo etcclientinfo = new Etcclientinfo();
        etcclientinfo = etcclientinfoMapper.getUserBySpare(spare);
        if (etcclientinfo == null){
            logger.error("<==  唯一标识[" + spare + "]未找到对应的用户信息");
            return ReturnResult.errors("未找到对应的用户信息");
        }
        String clientType = etcclientinfo.getClientType();
        String certificateNumber = null;
        if ("1".equals(clientType)){
            certificateNumber = etcclientinfo.getCertificateNumber();
        }
        if ("2".equals(clientType)){
            certificateNumber = etcclientinfo.getUnitCertificateNo();
        }

        String distributionBalance = getParams(params.get("distributionBalance"));
        BigDecimal distributionBalances = new BigDecimal(distributionBalance);
        // endregion

        // region 用户账户余额扣钱
        BigDecimal accountBalance = etcclientinfo.getAccountBalance();
        logger.info("<==  用户账户余额[" + accountBalance + "]分配金额[" + distributionBalances + "]");

        Etcclientinfo etcclientinfo1 = new Etcclientinfo();
        etcclientinfo1.setAccountBalance(BigDecimal.ZERO.subtract(distributionBalances));
        etcclientinfo1.setSpare(spare);
        int resultA = etcclientinfoMapper.updateByPrimaryKeySelective(etcclientinfo1);
        if (resultA != 1){
            logger.error("<==  卡号[" + cardId + "]点对点分配失败");
            throw new RuntimeException("更新用户账户余额失败，点对点分配失败！");
        }
        // endregion

        // region 用户账单
        FrontBillingRecord accountRecord = new FrontBillingRecord();
        accountRecord.setId(UUIDUtils.getUUID());
        accountRecord.setTradeNum((String) params.get("tradeNumber"));
        // 只在用户账户加一个trans_id，防止重试
        accountRecord.setTransId((String) params.get("transId"));
        accountRecord.setChannelName((String) params.get("channelName"));
        accountRecord.setChannelNum((String) params.get("channelNum"));
        accountRecord.setChannelType((String) params.get("channelType"));
        accountRecord.setEmployeeNo((String) params.get("employeeNo"));
        accountRecord.setSiteName((String) params.get("siteName"));
        accountRecord.setAcquirerNo((String) params.get("acquirerNo"));
        accountRecord.setCreateBy((String) params.get("createBy"));
        accountRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        accountRecord.setClientName(etcclientinfo.getClientName());
//        accountRecord.setCertificateNumber(etcclientinfo.getCertificateNumber());
        accountRecord.setCertificateNumber(etcclientinfo.getSpare());
        accountRecord.setAccountSubject(1);
        accountRecord.setAccountSubjectNo(etcclientinfo.getSpare());
        accountRecord.setAccountSubjectStatus(1);
        accountRecord.setOperationType(4);
        accountRecord.setOperationMark(2);
        Double x = accountBalance.doubleValue();
        Double y = distributionBalances.doubleValue();
        accountRecord.setPreOperationBalance((int)(x*100));
        accountRecord.setOperationAmount((int)(y*100));
        accountRecord.setSufOperationBalance((int)(x*100) - (int)(y*100));
        accountRecord.setOperationTime(date);
        frontBillingRecordService.addBillingOperationRecord(accountRecord);
        // endregion

        // region 卡账户加钱
        BigDecimal cardAccountBalance = etccardinfo.getCardAccountBalance();
        logger.info("<==  卡账户余额[" + cardAccountBalance + "]分配金额[" + distributionBalances + "]");

        int resultB = cardMapper.updateCardAccountBalance(distributionBalances,cardId);
        if (resultB != 1){
            logger.error("<==  卡号[" + cardId + "]点对点分配失败");
            throw new RuntimeException("更新卡账户余额失败，点对点分配失败！");
        }
        // endregion

        // region 卡账单
        FrontBillingRecord cardAccountRecord = new FrontBillingRecord();
        cardAccountRecord.setId(UUIDUtils.getUUID());
        cardAccountRecord.setTradeNum((String) params.get("tradeNumber"));
        cardAccountRecord.setChannelName((String) params.get("channelName"));
        cardAccountRecord.setChannelNum((String) params.get("channelNum"));
        cardAccountRecord.setChannelType((String) params.get("channelType"));
        cardAccountRecord.setEmployeeNo((String) params.get("employeeNo"));
        cardAccountRecord.setSiteName((String) params.get("siteName"));
        cardAccountRecord.setAcquirerNo((String) params.get("acquirerNo"));
        cardAccountRecord.setCreateBy((String) params.get("createBy"));
        cardAccountRecord.setClientType(Integer.valueOf(etcclientinfo.getClientType()));
        cardAccountRecord.setClientName(etcclientinfo.getClientName());
//        cardAccountRecord.setCertificateNumber(etcclientinfo.getCertificateNumber());
        cardAccountRecord.setCertificateNumber(etcclientinfo.getSpare());
        cardAccountRecord.setAccountSubject(2);
        cardAccountRecord.setAccountSubjectNo(cardId);
        cardAccountRecord.setAccountSubjectStatus(1);
        cardAccountRecord.setOperationType(4);
        cardAccountRecord.setOperationMark(1);
        Double m = cardAccountBalance.doubleValue();
        cardAccountRecord.setPreOperationBalance((int)(m*100));
        cardAccountRecord.setOperationAmount((int)(y*100));
        cardAccountRecord.setSufOperationBalance((int)(m*100) + (int)(y*100));
        cardAccountRecord.setOperationTime(date);
        frontBillingRecordService.addBillingOperationRecord(cardAccountRecord);
        // endregion

        // region 数据上报
        try {
            /**
             * FIXME 调用营改增接口实现数据上报
             */
            Map<String,Object> sendRechargeMap = new HashMap<>();
            sendRechargeMap.put("id", ParamClassUtils.getParams(params.get("tradeNumber")));
            sendRechargeMap.put("paidAmount",String.valueOf((int)(y*100)));
            sendRechargeMap.put("giftAmount",String.valueOf(0L));
            sendRechargeMap.put("rechargeAmount",String.valueOf((int)(y*100)));
            sendRechargeMap.put("cardId",cardId);
            reportFeign.sendRecharge(sendRechargeMap);
        } catch (Exception e) {
            logger.error("<==  [" + cardId + "]点对点分配数据上报异常");
        }
        // endregion

        logger.info("<==  方法pointTransfer执行结束");
        return ReturnResult.successs("分配成功");
    }

}
