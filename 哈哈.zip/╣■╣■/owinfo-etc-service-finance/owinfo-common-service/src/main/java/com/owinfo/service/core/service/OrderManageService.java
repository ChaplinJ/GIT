package com.owinfo.service.core.service;

import com.owinfo.object.entity.OrderManage;
import com.owinfo.service.core.mapper.OrderManageMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Created by gongchengping on 2018/03/08
 * @Description 订单
 */
@Service
public class OrderManageService {

    /**
     * OrderManageService日志打印
     */
    private static Logger logger = Logger.getLogger(OrderManageService.class);

    @Autowired
    private OrderManageMapper orderManageMapper;

    /**
     * 获取订单分页数据--首页、分页查询
     * @param params
     * @return
     */
    public List<OrderManage> getOrderList(Map<String,Object> params){
        List<OrderManage> orderManageList =  orderManageMapper.selectOrderList(params);
        return orderManageList;
    }

    /**
     * 导入订单/商家
     * @param orderManage
     * @return
     */
    public int addOrder(OrderManage orderManage){
        return orderManageMapper.insertSelective(orderManage);
    }

    /**
     * 批量删除订单  逻辑删除
     * @param orderNos
     * @return
     */
    public int deleteOrders(ArrayList<String> orderNos){
        return orderManageMapper.deleteByOrderNos(orderNos);
    }

    /**
     * 验证订单号
     */
    public OrderManage validateOrder(String orderNo){
        OrderManage orderManage = orderManageMapper.validateOrder(orderNo);
        return orderManage;
    }

    /**
     * 获取订单信息
     */
    public OrderManage getOrderDetail(String orderNo){
        return orderManageMapper.getOrderDetail(orderNo);
    }

    /**
     * 获取订单信息
     */
    public OrderManage getOrderManage(String id){
        return orderManageMapper.getOrderManage(id);
    }

    /**
     * 更新余量
     * @param params
     * @return
     */
    public int updateOrderSurplys(Map<String,Object> params){
        return orderManageMapper.updateOrderSurplys(params);
    }

    /**
     * 更新订单状态
     */

    public int updateOrderSaleStatus(OrderManage orderManage) {
        return orderManageMapper.updateOrderSaleStatus(orderManage);
    }

    /**
     * 更新订单
     *
     */
    public int updateOrderByOrderNo(OrderManage orderManage) {
        return orderManageMapper.updateByOrderNo(orderManage);
    }
}
