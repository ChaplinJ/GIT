package com.owinfo.service.core.service;

import com.owinfo.object.entity.TicketManage;
import com.owinfo.service.core.mapper.TicketManageMapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月17日
 *         github : https://github.com/rexlin600/
 * @Description 卡券管理业务处理
 */
@Service
public class TicketManageService {

    private static Logger logger = Logger.getLogger(TicketManageService.class);

    @Autowired
    private TicketManageMapper ticketManageMapper;

    /**
     * 获取卡券分页数据--首页、分页查询
     * @param params
     * @return
     */
    public List<TicketManage> getTicketList(Map<String,Object> params){
        List<TicketManage> ticketManageList =  ticketManageMapper.selectTicketList(params);
        return ticketManageList;
    }

    /**
     * 导入卡券
     * @param list
     * @return
     */
    public int addTicket(List<TicketManage> list){
        return ticketManageMapper.insertSelective(list);
    }

    /**
     * 更改卡券状态：启用、变更、回收
     * @param params
     * @return
     */
    public int changeTicketStatus(Map<String,Object> params){
        return ticketManageMapper.changeTicketStatus(params);
    }

    /**
     * 验证卡券和密码
     * @param params
     * @return
     */
    public TicketManage validateTicket(Map<String,Object> params){
        return ticketManageMapper.validateTicket(params);
    }

    /**
     * 获取卡券信息
     * @param params
     * @return
     */
    public TicketManage getTicket(Map<String,Object> params){
        return ticketManageMapper.getTicket(params);
    }

    /**
     * 回收卡券
     */
    public int recoveryTicket(Map<String,Object> params){
        return ticketManageMapper.recoveryTicket(params);
    }

    /**
     * 查询是否存在这个卡券,导入卡券时使用
     */
    public TicketManage validateExitTicket(String ticketNo){
        return ticketManageMapper.validateExitTicket(ticketNo);
    }

    /**
     * 查询是否存在这个卡券，回收卡券时使用
     * @param ticketNo
     * @return
     */
    public TicketManage validateExitTickets(String ticketNo) {
        return ticketManageMapper.validateExitTickets(ticketNo);
    }

}
