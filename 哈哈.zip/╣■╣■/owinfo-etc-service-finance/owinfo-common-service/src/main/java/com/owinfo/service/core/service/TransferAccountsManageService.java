package com.owinfo.service.core.service;

import com.owinfo.object.entity.TransferAccountsManage;
import com.owinfo.service.core.mapper.TransferAccountsManageMapper;
import com.owinfo.service.util.TransferAccountsManageDto;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月17日
 *         github : https://github.com/rexlin600/
 * @Description 转账管理业务处理
 */
@Service
public class TransferAccountsManageService {

    private static Logger logger = Logger.getLogger(TransferAccountsManageService.class);

    @Autowired
    private TransferAccountsManageMapper transferAccountsManageMapper;

    /**
     * 验证随机码是否存在
     * @param random
     * @return
     */
    public TransferAccountsManage haveRandom(String random) {
        return transferAccountsManageMapper.haveRandom(random);
    }

    /**
     * 导入转账信息
     * @param transferAccountsManage
     * @return
     */
    public int insertTransfer(TransferAccountsManage transferAccountsManage) {
        return transferAccountsManageMapper.insertSelective(transferAccountsManage);
    }

    /**
     * 根据条件进行模糊查询
     * @param map
     * @return
     */
    public List<TransferAccountsManage> getTransferList(Map<String, Object> map) {
        return transferAccountsManageMapper.getTransferList(map);
    }

    /**
     * 通过订单号查询交易记录
     * @param transId
     * @return
     */
    public TransferAccountsManage getTransAccountManage(String transId) {
        return transferAccountsManageMapper.selectByPrimaryKey(transId);
    }

    /**
     * 通过订单号，删除转账记录
     * @param transId
     * @return
     */
    public int deleteTransAccount(String transId) {
        return transferAccountsManageMapper.deleteByPrimaryKey(transId);
    }

    /**
     * 逻辑删除，将remove标识改成1
     * @param transferAccountsManage
     * @return
     */
    public int updateTransAccount(TransferAccountsManage transferAccountsManage) {
        return transferAccountsManageMapper.updateByPrimaryKeySelective(transferAccountsManage);
    }
}
