package com.owinfo.service.feign;

import com.owinfo.service.feign.feignImpl.ReportFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 权限服务获取所有站点
 * 创建时间：2017年10月19日 *
 * @author sun
 * @version [版本号, 2017年10月19日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@FeignClient(value = "owinfo-etc-service-report",fallbackFactory = ReportFeignImpl.class)
@Component
public interface ReportFeign {
    /***
     *推送发行商变动信息
     */
    @RequestMapping("/sendService/sendIssuer")
    void sendIssuer(@RequestBody Map<String, Object> maps);

    /***
     *sendAgency推送合作机构、渠道变动信息
     */
    @RequestMapping("/sendService/sendAgency")
    void sendAgency(@RequestBody Map<String, Object> maps);

    /***
     *推送服务网点变动信息
     */
    @RequestMapping("/sendService/sendDot")
    void sendDot(@RequestBody Map<String, Object> maps);

    /***
     *sendMobile推送移动网点变动信息
     */
    @RequestMapping("/sendService/sendMobile")
    void sendMobile(@RequestBody Map<String, Object> maps);

    /***
     *sendTerminal推送终端网点信息
     */
    @RequestMapping("/sendService/sendTerminal")
    void sendTerminal(@RequestBody Map<String, Object> maps);

    /***
     *sendOnline推送线上网点信息
     */
    @RequestMapping("/sendService/sendOnline")
    void sendOnline(@RequestBody Map<String, Object> maps);

    /***
     *sendUser推送客户变动信息
     */
    @RequestMapping("/sendService/sendUser")
    void sendUser(@RequestBody Map<String, Object> maps);

    /***
     *sendVehicle推送车辆变动信息
     */
    @RequestMapping("/sendService/sendVehicle")
    void sendVehicle(@RequestBody Map<String, Object> maps);

    /***
     *sendCard推送卡变动信息
     */
    @RequestMapping("/sendService/sendCard")
    void sendCard(@RequestBody Map<String, Object> maps);

    /***
     *sendObu推送Obu变动信息
     */
    @RequestMapping("/sendService/sendObu")
    void sendObu(@RequestBody Map<String, Object> maps);

    /***
     *sendCardBlack推送卡黑名单信息
     */
    @RequestMapping("/sendService/sendCardBlack")
    void sendCardBlack(@RequestBody Map<String, Object> maps);

    /***
     * sendObuBlack推送Obu黑名单信息
     */
    @RequestMapping("/sendService/sendObuBlack")
    void sendObuBlack(@RequestBody Map<String, Object> maps);

    /***
     * sendRecharge推送充值交易信息
     */
    @RequestMapping("/sendService/sendRecharge")
    void sendRecharge(@RequestBody Map<String, Object> maps);

    /**
     * sendReversal发送冲正交易信息
     */
    @RequestMapping("/sendService/sendReversal")
    void sendReversal(@RequestBody Map<String, Object> maps);

    /***
     * sendReimburse推送退款交易信息
     */
    @RequestMapping("/sendService/sendReimburse")
    void sendReimburse(@RequestBody Map<String, Object> maps);

    /**
     * 全国车牌唯一性验证
     */
    @RequestMapping("/vehicleService/plateCheck")
    Map<String, Object> plateCheck(Map<String, Object> map);

}

