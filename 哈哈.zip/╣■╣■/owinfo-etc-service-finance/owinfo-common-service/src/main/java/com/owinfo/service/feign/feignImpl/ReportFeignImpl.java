package com.owinfo.service.feign.feignImpl;

import com.owinfo.service.feign.ReportFeign;
import com.owinfo.service.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;


/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 权限服务获取所有站点
 * 创建时间：2017年10月19日 *
 * @author sun
 * @version [版本号, 2017年10月19日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component
public class ReportFeignImpl implements FallbackFactory<ReportFeign> {

    private Logger logger = LoggerFactory.getLogger(ReportFeignImpl.class);

    @Override
    public ReportFeign create(Throwable throwable) {
        return new ReportFeign() {
            @Override
            public void sendIssuer(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendAgency(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendDot(Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendMobile(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendTerminal(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendOnline(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendUser(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendVehicle(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendCard(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendObu(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendCardBlack(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendObuBlack(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendRecharge(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendReversal(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public void sendReimburse(@RequestBody Map<String, Object> maps) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
            }

            @Override
            public Map<String, Object> plateCheck(Map<String, Object> map) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("车牌唯一性接口调用失败");
            }
        };
    }
}
