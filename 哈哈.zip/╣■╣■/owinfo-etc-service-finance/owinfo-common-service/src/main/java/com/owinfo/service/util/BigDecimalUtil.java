/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月13日
 */
package com.owinfo.service.util;

import java.math.BigDecimal;

/**
 * @Description Bigcimal工具类
 * @author gongchengping
 * @version [1.0, 2018/03/13]
 */
public class BigDecimalUtil {

    /**
     * a multi b
     * @param a
     * @param b
     * @return
     */
    public static Integer getMultiply(String a,String b) {
        BigDecimal m = new BigDecimal(a).multiply(new BigDecimal(b));
        return m.intValue();
    }
}
