package com.owinfo.service.util;

/**
 * @author Created by hekunlin on 2018年01月18日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class CardRechargeVO {




}
