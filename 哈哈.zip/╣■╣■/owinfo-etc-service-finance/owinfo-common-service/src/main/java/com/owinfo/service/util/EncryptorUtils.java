package com.owinfo.service.util;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.DatatypeConverter;

import static com.owinfo.service.util.XgsReadUtils.readHexString;


/**
* @description: 加密机工具类
* @author hekunlin on 2017/11/7 9:24
*/
public class EncryptorUtils {

    private static final Logger logger = LoggerFactory.getLogger(EncryptorUtils.class);

    // Socket地址、端口
//    private static final String SOCKET_IP = "10.0.254.201";
    private static final String SOCKET_IP = "10.0.253.75"; // 10.0.254.75  10.248.8.12
//    private static final int SOCKET_PORT = 6666;
    private static final int SOCKET_PORT = 40005;
    // 命令类型（a14、a015）
	private static final String COMMOND_TYPE = "A0";
    // 命令类型2（a016）
	private static final String COMMOND_TYPE2 = "B0";

	// 次主密钥索引
	public static final String SECOND_KEY = "0002";
    // 次主密钥索引（b061）
	public static final String SECOND_KEY2 = "0001";
	public static final String SECOND_KEY3 = "0012";
    // 次主秘钥索引（a014、a015） 测试环境做A015
	public static final String SECOND_KEY4 = "0021";

    // 分散次数（a014、a015）
	private static final String HASH_NUMBER = "01";
    // 分散次数（b061）
	private static final String HASH_NUMBER2 = "02";
    // 固定值
	private static final String PROCESS_KEY = "8000";
    // 固定
	private static final String DATA_PLACEHOLDER = "02";

	public static void main(String[] args) {

        // 正式环境必须用正式环境的数据；反之用测试环境数据

//        boolean flag = a014("410163722010207",1,"0000000000000200FF730E21B090D3EC","000000000001");
//		System.out.println(flag);
		boolean flag = a014("41011637220102056122",1,"00000000000002008C4D11EA01B8669A","000000000001");
//		String mac2 = a015("41011543220102084070",1,"0000000000000200FF730E21B090D3EC","000000000001","20171102094146");
//		System.out.println(mac2);
		System.out.println(flag);

//
//        String mac = b061("41011543220102084070",14);
//        System.out.println(mac);

	}

    /**
     * 加密机验证A014
     * @param cardNo 卡号
     * @param amount 交易金额
     * @param cardInfo 卡信息
     * @param terminalNo  设备号
     * @return
     */


    public static boolean a014(String cardNo, Integer amount, String cardInfo, String terminalNo) {
        logger.info("请求A014参数为 cardNo=" + cardNo + " amount=" + amount + " cardInfo=" + cardInfo + " terminalNo="
				+ terminalNo);
        // 卡号截后16位
        if (cardNo.length() > 16) {
            cardNo = cardNo.substring(cardNo.length() - 16);
        }
        logger.info("处理后的卡号 cardNo=" + cardNo);

        // 终端机号截后12位
        if (terminalNo.length() > 12) {
            terminalNo = terminalNo.substring(terminalNo.length() - 12);
        }
        logger.info("处理后的终端机编号 terminalNo=" + terminalNo);

        // 获取验证的 HEX 信息
        StringBuffer buffer = getA014SendMsg(cardNo, amount, cardInfo, terminalNo);

		// 添加密管监控信息
//        StringBuffer addNew = buffer;
		StringBuffer addNew = addNew(buffer, amount, 1);

        // 发送
        String receiveMsg = send(addNew.toString());
        logger.info("验证返回的验证结果 receiveMsg=" + receiveMsg);

        StringBuffer receiveMsgSb = new StringBuffer(receiveMsg);

		// 效验直接跳过了
		readHexString(10, receiveMsgSb);

        String successStr = readHexString(1, receiveMsgSb);
        logger.info("A014返回的密钥 " + successStr);

        char success = (char) Integer.parseInt(successStr, 16);
        if (success == 'A') {
            logger.info("验证成功 " + success);
            return true;
        }
        logger.info("验证失败 " + success);
        return false;
    }

    /**
     * 拼接待发送验证的数据
     * @param cardNo
     * @param amount
     * @param cardInfo
     * @param terminalNo
     * @return
     */
    private static StringBuffer getA014SendMsg(String cardNo, Integer amount, String cardInfo, String terminalNo) {
        // 解析卡信息
        String preBalance = cardInfo.substring(0, 8); // 卡余额
        String onlineSn = cardInfo.substring(8, 12); // 交易序列号
        onlineSn = onlineSn.toUpperCase();
        String random = cardInfo.substring(16, 24); // 随机数
        String mac1 = cardInfo.substring(24, 32); // mac1

        StringBuffer buffer = new StringBuffer();
        XgsWriteUtils.writeHexString(COMMOND_TYPE, 1, buffer);// 命令类型
        XgsWriteUtils.writeHexString("14", 1, buffer);// 命令
        XgsWriteUtils.writeHexString(SECOND_KEY, 2, buffer);// 次主密钥索引 0021
        XgsWriteUtils.writeHexString(HASH_NUMBER, 1, buffer);// 分散次数 01

        // 这两行是写出分散数据 24字节
        XgsWriteUtils.writeHexString(cardNo, 8, buffer);//卡号
        XgsWriteUtils.writeHexString(0, 16, buffer);

        // 写出过程密钥数据 8字节
        XgsWriteUtils.writeHexString(random, 4, buffer);// 随机数（给设备发指令取。四字节）
        XgsWriteUtils.writeHexString(onlineSn, 2, buffer);// 交易流水号
        XgsWriteUtils.writeHexString(PROCESS_KEY, 2, buffer);// 固定值

        XgsWriteUtils.writeHexString(0, 8, buffer);// mac初始数据

        XgsWriteUtils.writeHexString(mac1, 4, buffer);// mac1（设备取出的mac，从cardInfo中截取）

        // 写出MAC数据和数据长度
        XgsWriteUtils.writeHexString(4 + 4 + 1 + 6, 2, buffer);
        XgsWriteUtils.writeHexString(preBalance, 4, buffer);// 写出余额
        XgsWriteUtils.writeHexString(amount, 4, buffer);// 写出交易金额
        XgsWriteUtils.writeHexString(DATA_PLACEHOLDER, 1, buffer);// 写出02 固定
        XgsWriteUtils.writeHexString(terminalNo, 6, buffer);// 写出终端机号

        return buffer;
    }


    /**
     * 申请Mac A015
     * @param cardNo 卡号
     * @param amount 账户余额
     * @param cardInfo 卡信息
     * @param terminalNo 终端编号
     * @param optDateTime 交易时间
     * @return
     */
	public static String a015(String cardNo, Integer amount, String cardInfo, String terminalNo, String optDateTime) {
        logger.info("请求A015参数为 cardNo=" + cardNo + " amount=" + amount + " cardInfo=" + cardInfo + " terminalNo="
                + terminalNo + " optDateTime=" + optDateTime);
        // 卡号截后16位
		if (cardNo.length() > 16) {
			cardNo = cardNo.substring(cardNo.length() - 16);
		}
        logger.info("处理后的卡号 cardNo=" + cardNo);

		// 终端机号截后12位
		if (terminalNo.length() > 12) {
			terminalNo = terminalNo.substring(terminalNo.length() - 12);
		}
        logger.info("处理后的终端机编号 terminalNo=" + terminalNo);

		// 分散次主密钥产生MAC
		StringBuffer buffer = getA015SendMsg(cardNo, amount, cardInfo, terminalNo, optDateTime);

		// 添加密管监控信息
//		 StringBuffer addNew = buffer;
		StringBuffer addNew = addNew(buffer, amount, 1);

		// 发送
		String receiveMsg = send(addNew.toString());
        logger.info("验证返回的验证结果 receiveMsg=" + receiveMsg);

		StringBuffer receiveMsgSb = new StringBuffer(receiveMsg);
		readHexString(10, receiveMsgSb);// 效验直接跳过了

		String successStr = readHexString(1, receiveMsgSb);
        logger.info("A015返回的密钥 " + successStr);

		char success = (char) Integer.parseInt(successStr, 16);
		if (success != 'A') {
            logger.info("验证成功 " + success);
			return null;
		}
//		// mac2，返回给web端的mac2：截取获取到的密钥的前8位
//		receiveMsg = receiveMsg.substring(2,receiveMsg.length()-8);
//		System.out.println("mac2 " + receiveMsg);

		// 注：测试10.0.254.201:6666，返回的时间不用转换成16进制的 "805200000B" + optDateTime + receiveMsg + "04"
		return readHexString(4, receiveMsgSb);
	}

    /**
     * 拼接连接加密机获取MAC的数据
     * @param cardNo
     * @param amount
     * @param cardInfo
     * @param terminalNo
     * @param optDateTime
     * @return
     */
	private static StringBuffer getA015SendMsg(String cardNo, Integer amount, String cardInfo, String terminalNo, String optDateTime) {
		// 解析卡信息
		String onlineSn = cardInfo.substring(8, 12);
		onlineSn = onlineSn.toUpperCase();
		String random = cardInfo.substring(16, 24);

		StringBuffer buffer = new StringBuffer();
		XgsWriteUtils.writeHexString(COMMOND_TYPE, 1, buffer);// 命令类型
		XgsWriteUtils.writeHexString("15", 1, buffer);// 命令
		XgsWriteUtils.writeHexString(SECOND_KEY, 2, buffer);// 次主密钥索引，圈存为33,16进制0021
		XgsWriteUtils.writeHexString(HASH_NUMBER, 1, buffer);// 分散次数，01

		// 这两行是写出分散数据 24字节
		XgsWriteUtils.writeHexString(cardNo, 8, buffer);// 卡号
		XgsWriteUtils.writeHexString(0, 16, buffer); // 补0

		// 写出过程密钥数据 8字节
		XgsWriteUtils.writeHexString(random, 4, buffer);// 设备取的随机数
		XgsWriteUtils.writeHexString(onlineSn, 2, buffer);// 交易流水号，卡信息中截取
		XgsWriteUtils.writeHexString(PROCESS_KEY, 2, buffer);// 固定值

        // MAC初始数据
		XgsWriteUtils.writeHexString(0, 8, buffer);// mac初始数据

		// MAC数据长度
		XgsWriteUtils.writeHexString(4 + 1 + 6 + 7, 2, buffer); // MAC数据长度=（写出金额+固定+设备交易时间）长度

        // 写出MAC数据
        XgsWriteUtils.writeHexString(amount, 4, buffer);// 写出支付金额
		XgsWriteUtils.writeHexString(DATA_PLACEHOLDER, 1, buffer);// 固定
		XgsWriteUtils.writeHexString(terminalNo, 6, buffer);// 设备号
		XgsWriteUtils.writeHexString(optDateTime, 7, buffer);// 交易时间

		return buffer;
	}

    /**
     * B061
     * @param cardNo
     * @param index
     * @return
     */
    public static String b061(String cardNo,Integer index) {
        logger.info("请求B061参数为 cardNo=" + cardNo + " index=" + index);

        // 卡号截后16位
        if (cardNo.length() > 16) {
            cardNo = cardNo.substring(cardNo.length() - 16);
        }

        Integer type = null;
        if (index == 13 || index == 14) { //
            type = 2;
        } else if (index == 11 || index == 12) { //
            type = 3;
        } else {
            throw new RuntimeException("未知的异常");
        }

        // 获取验证的 HEX 信息
        StringBuffer buffer = getB061SendMsg(cardNo, index);

        // 添加密管监控信息
        StringBuffer addNew = addNew(buffer, 0, type);
        // StringBuffer addNew = buffer;

        // 发送
        String receiveMsg = send(addNew.toString());

        StringBuffer receiveMsgSb = new StringBuffer(receiveMsg);

        readHexString(10, receiveMsgSb);// 效验直接跳过了

        String successStr = readHexString(1, receiveMsgSb);

        logger.info("B061返回的密钥 " + successStr);

        char success = (char) Integer.parseInt(successStr, 16);
        if (success != 'A') {
            logger.info("验证成功 " + success);
            return null;
        }

        String mac = readHexString(28, receiveMsgSb);

		mac = mac.substring(16); // 去掉保留字
		mac = mac.substring(0,32); // 去掉校验码

//        return XgsReadUtils.readHexString(28, receiveMsgSb);
    	return mac;
    }


    /**
     * B061
     * @param cardNo
     * @param index
     * @return
     */
    private static StringBuffer getB061SendMsg(String cardNo, Integer index) {
        StringBuffer buffer = new StringBuffer();
        XgsWriteUtils.writeHexString("B0", 1, buffer);// 命令类型
        XgsWriteUtils.writeHexString("61", 1, buffer);// 命令
        XgsWriteUtils.writeHexString(0, 8, buffer);// 用户保留字
        XgsWriteUtils.writeHexString(index, 2, buffer);// 次主密钥索引
        XgsWriteUtils.writeHexString(01, 1, buffer);// 分散次数
        XgsWriteUtils.writeHexString(cardNo, 8, buffer);// 分散数据 卡号
        return buffer;
    }


	/**
	 * 添加统计
	 * @param buffer
	 * @param amount
	 * @param type
	 * @return
	 */
	private static StringBuffer addNew(StringBuffer buffer, int amount, int type) {
		// 指令头
		StringBuffer sb = new StringBuffer();
		sb.append(buffer);
		sb.insert(0, XgsWriteUtils.getHexString(0, 8));

		String comLen = XgsWriteUtils.getHexString(sb.length() / 2, 2);
		sb.insert(0, comLen);

		String pAppIP = "1234567890123456712345678901234567";
		String pSysLabel = "1234512345";
		String pAuthCode = "1234567890123456712345678901234567";
		// String pFunName =
		// "68656E616E2065746320413031350000000000000000000000000000000000";
		String pFunName = XgsWriteUtils.getHexString(amount, 4) + "6E206574632041303135000000000000000000000000"
				+ XgsWriteUtils.getHexString(amount, 4) + XgsWriteUtils.getHexString(type, 1);

		sb.insert(0, pAppIP + pSysLabel + pAuthCode + pFunName);
		sb.insert(0, XgsWriteUtils.getHexString(sb.length() / 2, 2));
		return sb;
	}

/*********************************************** 发送报文 **************************************************************/
	/**
	 * 发送报文
	 * @param sendMsg
	 * @return
	 */
	private static String send(String sendMsg) {
		EventLoopGroup workerGroup = new NioEventLoopGroup();
		try {
			EncryptChannelInitialize ifChannelInitialize = new EncryptChannelInitialize();

			EncryptHandler tranderHandler = new EncryptHandler();
			tranderHandler.setSendMsg(sendMsg);

			ifChannelInitialize.setHandle(tranderHandler);

			Bootstrap bootstrap = new Bootstrap();
			bootstrap.group(workerGroup).channel(NioSocketChannel.class).handler(ifChannelInitialize);
			ChannelFuture f = bootstrap.connect(SOCKET_IP,SOCKET_PORT).sync();
			f.channel().closeFuture().sync();
			return tranderHandler.getReceiveMsg();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			workerGroup.shutdownGracefully();
		}
		return null;
	}
}

/*********************************************** Channel **************************************************************/
class EncryptChannelInitialize extends ChannelInitializer<SocketChannel> {

	private EncryptHandler handle = null;

	@Override
	protected void initChannel(SocketChannel channel) throws Exception {
		channel.pipeline().addLast("encHandler", handle);
	}

	public EncryptHandler getHandle() {
		return handle;
	}

	public void setHandle(EncryptHandler handle) {
		this.handle = handle;
	}

}

class EncryptHandler extends ChannelInboundHandlerAdapter {

	private static final Logger logger = LoggerFactory.getLogger(ChannelInboundHandlerAdapter .class);

    /**
     * 发送消息
     */
	private String sendMsg;

    /**
     * 接收消息
     */
	private String receiveMsg;

    /**
     * 功能：发送消息
     * @param ctx
     * @throws Exception
     */
	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		try {
			logger.info("MAC-发送的消息:" + sendMsg);
			ByteBuf buf = Unpooled.buffer();
			buf.writeBytes(DatatypeConverter.parseHexBinary(sendMsg));
			ctx.writeAndFlush(buf);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 功能：读取返回数据
	 * @param ctx
	 * @param msg
	 * @throws Exception
	 */
	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		ByteBuf buf = (ByteBuf) msg;
		String upperCase = ByteBufUtil.hexDump(buf).toUpperCase();
		logger.info("MAC-返回的消息:" + upperCase);
		receiveMsg = upperCase;
		ctx.close();
	}

	public String getSendMsg() {
		return sendMsg;
	}

	public void setSendMsg(String sendMsg) {
		this.sendMsg = sendMsg;
	}

	public String getReceiveMsg() {
		return receiveMsg;
	}

	public void setReceiveMsg(String receiveMsg) {
		this.receiveMsg = receiveMsg;
	}

}
