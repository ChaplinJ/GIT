package com.owinfo.service.util;

/**
 * Created by admin on 2017/12/5.
 */
public class GetWriteCardCertCmdDto {

    private String encData;

    private boolean success;

    private String message;

    public String getEncData() {
        return encData;
    }

    public void setEncData(String encData) {
        this.encData = encData;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
