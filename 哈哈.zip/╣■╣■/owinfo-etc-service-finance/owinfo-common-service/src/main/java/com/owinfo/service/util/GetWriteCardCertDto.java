package com.owinfo.service.util;

/**
 * Created by admin on 2017/12/5.
 */
public class GetWriteCardCertDto {
    private String cert;

    public String getCert() {
        return cert;
    }

    public void setCert(String cert) {
        this.cert = cert;
    }

    @Override
    public String toString() {
        return "GetWriteCardCertDto{" +
                "cert='" + cert + '\'' +
                '}';
    }
}
