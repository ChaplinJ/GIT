package com.owinfo.service.util;

public class GetWriteCardMfMacResDto {
	
	private String mac;

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}
	
	

}
