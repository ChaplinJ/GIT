/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月12日
 */
package com.owinfo.service.util;

import com.owinfo.service.config.annotation.AddOrderCheck;
import com.owinfo.service.config.annotation.OrderCheckGroups;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;

import javax.validation.GroupSequence;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;

/**
 * @Description 服务接收校验DTO
 * @author gongchengping
 * @version [版本号, 2018/03/12]
 */

@GroupSequence({OrderCheckGroups.Base.class, OrderCheckGroups.AddOrderCheck.class, OrderManageDTO.class})
@AddOrderCheck(groups = {OrderCheckGroups.AddOrderCheck.class})
public class OrderManageDTO {

    //订单渠道
    @Range(min = 0, groups = {OrderCheckGroups.Base.class})
    @NotNull(message = "订单渠道不能为空", groups = {OrderCheckGroups.Base.class})
    private Integer orderChannel;


    @NotBlank(message = "订单用途不能为空", groups = {OrderCheckGroups.UpdateOrderSurplysCheck.class})
    @Pattern(message = "订单类型格式错误｛data1,data2,data3....｝", regexp = "(^\\d$)|(^\\d+(,\\d+)+$)", groups = {OrderCheckGroups.UpdateOrderSurplysCheck.class, OrderCheckGroups.validateOrderNo.class})
    private String orderType;  //订单类型

    //订单编号
    @NotBlank(message = "订单编号不能为空", groups = {OrderCheckGroups.Base.class, OrderCheckGroups.UpdateOrderSurplysCheck.class, OrderCheckGroups.validateOrderNo.class})
    private String orderNo;

    //用户名
    @NotBlank(message = "用户名称不能为空", groups = {OrderCheckGroups.Base.class})
    private String customerName;

    //实收金额
    @NotNull(message = "订单金额不能为空", groups = {OrderCheckGroups.Base.class})
    @DecimalMin(value = "0.00", message = "订单金额不能小于0.00元", groups = {OrderCheckGroups.Base.class})
    private BigDecimal realMoney;

    @NotNull(message = "充值状态不能为空", groups = {OrderCheckGroups.Base.class})
    private Boolean rechargeStatus;

    //充值金额
    @DecimalMin(value = "0.00", message = "充值不能小于0.00元", groups = {OrderCheckGroups.Base.class})
    private BigDecimal rechargeMoney;


    //蓝牙标签状态
    @NotNull(message = "蓝牙电子标签状态不能为空", groups = {OrderCheckGroups.Base.class})
    private Boolean obuStatus;

    //蓝牙电子标签名字
    private String obuName;

    //蓝牙电子标签数量
    @Min(value = 1,message = "蓝牙电子标签数量不能小于0", groups = {OrderCheckGroups.Base.class})
    private Integer obuNum;

    //蓝牙电子标签单价
    @DecimalMin(value = "0.0", message = "蓝牙电子标签单价不能低于0.00", groups = {OrderCheckGroups.Base.class})
    private BigDecimal obuUnitPrice;

    //充值宝状态
    @NotNull(message = "充值宝状态不能为空", groups = {OrderCheckGroups.Base.class})
    private Boolean treasureStatus;

    //充值宝名
    private String treasureName;

    //充值宝数量
    @Min(value = 0, message = "充值宝数量不能小于0", groups = {OrderCheckGroups.Base.class})
    private Integer treasureNum;

    //充值宝单价
    @DecimalMin(value = "0.00", message = "充值宝单价不能低于00", groups = {OrderCheckGroups.Base.class})
    private BigDecimal treasureUnitPrice;

    //中石油状态
    @NotNull(message = "中石油状态不能为空", groups = {OrderCheckGroups.Base.class})
    private Boolean oilStatus;

    //中石油金额
    @DecimalMin(value = "0.00", message = "中石油金额不能地域0.00", groups = {OrderCheckGroups.Base.class})
    private BigDecimal oilAmount;


    private String inputPerson;

    private String updateBy;

    public OrderManageDTO() {
    }

    @Override
    public String toString() {
        return "OrderManageDTO{" +
                "orderChannel=" + orderChannel +
                ", orderNo='" + orderNo + '\'' +
                ", orderType='" + orderType + '\'' +
                ", customerName='" + customerName + '\'' +
                ", inputPerson='" + inputPerson + '\'' +
                ", realMoney=" + realMoney +
                ", rechargeStatus=" + rechargeStatus +
                ", rechargeMoney=" + rechargeMoney +
                ", obuStatus=" + obuStatus +
                ", obuName='" + obuName + '\'' +
                ", obuNum=" + obuNum +
                ", obuUnitPrice=" + obuUnitPrice +
                ", treasureStatus=" + treasureStatus +
                ", treasureName='" + treasureName + '\'' +
                ", treasureNum=" + treasureNum +
                ", treasureUnitPrice=" + treasureUnitPrice +
                ", oilStatus=" + oilStatus +
                ", oilAmount=" + oilAmount +
                ", updateBy=" + updateBy +
                '}';
    }

    public OrderManageDTO(Integer orderChannel, String orderNo, String orderType, String customerName, String inputPerson, BigDecimal realMoney, Boolean rechargeStatus, BigDecimal rechargeMoney, Boolean obuStatus, String obuName, Integer obuNum, BigDecimal obuUnitPrice, Boolean treasureStatus, String treasureName, Integer treasureNum, BigDecimal treasureUnitPrice, Boolean oilStatus, BigDecimal oilAmount) {
        this.orderChannel = orderChannel;
        this.orderNo = orderNo;
        this.orderType = orderType;
        this.customerName = customerName;
        this.inputPerson = inputPerson;
        this.realMoney = realMoney;
        this.rechargeStatus = rechargeStatus;
        this.rechargeMoney = rechargeMoney;
        this.obuStatus = obuStatus;
        this.obuName = obuName;
        this.obuNum = obuNum;
        this.obuUnitPrice = obuUnitPrice;
        this.treasureStatus = treasureStatus;
        this.treasureName = treasureName;
        this.treasureNum = treasureNum;
        this.treasureUnitPrice = treasureUnitPrice;
        this.oilStatus = oilStatus;
        this.oilAmount = oilAmount;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getOrderChannel() {
        return orderChannel;
    }

    public void setOrderChannel(Integer orderChannel) {
        this.orderChannel = orderChannel;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getInputPerson() {
        return inputPerson;
    }

    public void setInputPerson(String inputPerson) {
        this.inputPerson = inputPerson;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public BigDecimal getRealMoney() {
        return realMoney;
    }

    public void setRealMoney(BigDecimal realMoney) {
        this.realMoney = realMoney;
    }

    public Boolean getRechargeStatus() {
        return rechargeStatus;
    }

    public void setRechargeStatus(Boolean rechargeStatus) {
        this.rechargeStatus = rechargeStatus;
    }

    public BigDecimal getRechargeMoney() {
        return rechargeMoney;
    }

    public void setRechargeMoney(BigDecimal rechargeMoney) {
        this.rechargeMoney = rechargeMoney;
    }

    public Boolean getObuStatus() {
        return obuStatus;
    }

    public void setObuStatus(Boolean obuStatus) {
        this.obuStatus = obuStatus;
    }

    public String getObuName() {
        return obuName;
    }

    public void setObuName(String obuName) {
        this.obuName = obuName;
    }

    public Integer getObuNum() {
        return obuNum;
    }

    public void setObuNum(Integer obuNum) {
        this.obuNum = obuNum;
    }

    public BigDecimal getObuUnitPrice() {
        return obuUnitPrice;
    }

    public void setObuUnitPrice(BigDecimal obuUnitPrice) {
        this.obuUnitPrice = obuUnitPrice;
    }

    public Boolean getTreasureStatus() {
        return treasureStatus;
    }

    public void setTreasureStatus(Boolean treasureStatus) {
        this.treasureStatus = treasureStatus;
    }

    public String getTreasureName() {
        return treasureName;
    }

    public void setTreasureName(String treasureName) {
        this.treasureName = treasureName;
    }

    public Integer getTreasureNum() {
        return treasureNum;
    }

    public void setTreasureNum(Integer treasureNum) {
        this.treasureNum = treasureNum;
    }

    public BigDecimal getTreasureUnitPrice() {
        return treasureUnitPrice;
    }

    public void setTreasureUnitPrice(BigDecimal treasureUnitPrice) {
        this.treasureUnitPrice = treasureUnitPrice;
    }

    public Boolean getOilStatus() {
        return oilStatus;
    }

    public void setOilStatus(Boolean oilStatus) {
        this.oilStatus = oilStatus;
    }

    public BigDecimal getOilAmount() {
        return oilAmount;
    }

    public void setOilAmount(BigDecimal oilAmount) {
        this.oilAmount = oilAmount;
    }
}
