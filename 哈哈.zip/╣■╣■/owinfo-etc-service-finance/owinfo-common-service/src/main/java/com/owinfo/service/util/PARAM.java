package com.owinfo.service.util;

/**
 * Created by liyue on 2017/11/4.
 * <p>
 * <p>
 * excel表格需要的参数
 */
public enum PARAM {

    FINANCEFIOW_SHEET(new String[]{"ETC资金流动查询"}),

    FINANCEFIOW_COLUMS(new String[]{"流动时间", "客户证件号", "客户名称", "ETC卡号", "操作类型"
            , "充值方式", "ETC卡状态", "操作对象", "补圈存状态", "操作前金额", "操作符号",
            "操作金额", "操作后金额"}),

    FINANCEFIOW_FIELDS(new String[]{"operationTime", "certificateNumber", "clientName", "accountSubjectNo",
            "operationType", "rechargeType", "cardStatus", "accountSubject", "fillTransferStatus",
            "preOperationBalance", "operationMark", "operationAmount", "sufOperationBalance"});

    private String[] params;

    PARAM(String[] params) {
        this.params = params;
    }

    public String[] getParams() {
        return params;
    }
}
