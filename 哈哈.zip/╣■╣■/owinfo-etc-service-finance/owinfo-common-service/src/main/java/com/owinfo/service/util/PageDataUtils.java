package com.owinfo.service.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月17日
 *         github : https://github.com/rexlin600/
 * @Description 返回分页数据
 */
public class PageDataUtils {

    /**
     * 封装分页数据返回结果集
     * @param total 总记录数
     * @param pageSize 页数
     * @param isFirstPage 是否第一页
     * @param isLastPage 是否最后一页
     * @param pageNum 页码
     * @return
     */
    public static Map<String,Object> pagePut(Long total, int pageSize, boolean isFirstPage, boolean isLastPage, int pageNum){
        // 这里只初始化了Map大小为10，多留几个以提供拓展
        Map<String,Object> data = new HashMap<>(10);
        data.put("total",total);
        data.put("pageSize",pageSize);
        data.put("isFirstPage",isFirstPage);
        data.put("isLastPage",isLastPage);
        data.put("page",pageNum);
        return data;
    }
}
