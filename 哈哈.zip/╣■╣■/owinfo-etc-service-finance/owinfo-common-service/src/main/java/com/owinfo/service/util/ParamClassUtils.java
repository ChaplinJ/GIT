package com.owinfo.service.util;

/**
 * @author Created by hekunlin on 2017年11月04日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class ParamClassUtils {

    public static String getParams(Object str){
        /**
         * 数字转字符串
         */
        if (str instanceof Integer){
            return new String(String.valueOf(str));
        }
        /**
         * Double转字符串
         */
        if (str instanceof Double){
            return new String(String.valueOf(str));
        }
        /**
         * String转字符串
         */
        if (str instanceof String){
            return (String) str;
        }
        return null;
    }


}
