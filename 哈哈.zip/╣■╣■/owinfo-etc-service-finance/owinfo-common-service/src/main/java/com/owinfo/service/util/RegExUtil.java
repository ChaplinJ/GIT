/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述：
 * 创建时间：2018年03月13日
 */
package com.owinfo.service.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description 正则表达式工具
 * @author gongchengping
 * @version [版本号, 2018/03/13]
 */
public class RegExUtil {

    public static String getString(String str,String regx) {
        Pattern pattern = Pattern.compile(regx);
        //2.将字符串和正则表达式相关联
        Matcher matcher = pattern.matcher(str);
        //3.String 对象中的matches 方法就是通过这个Matcher和pattern来实现的。

       if(matcher.find()) {
           return matcher.group();
       }else
           return null;


    }

    public static void main(String[] args) {
        String s = RegExUtil.getString("37,39,30","()");
        System.out.println(s);
    }
}

