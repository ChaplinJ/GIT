package com.owinfo.service.util;

/**
 * Created by liyue on 2017/11/4.
 * <p>
 * excel标题
 */
public enum TITLE {

    FINANCEFIOW_TITLE("ETC资金流动查询");

    private String title;

    TITLE(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
