package com.owinfo.service.util;

import java.util.UUID;

/**
 * @author Created by hekunlin on 2017年10月16日
 *         github : https://github.com/rexlin600/
 * @Description 生成UUID
 */
public class UUIDUtils {

    /**
     * 生成一个32位的UUID
     * @return
     */
    public static String getUUID(){
        return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * 生成一个随机的6位数
     * @return
     */
    public static String getSixRandom(){
        int code = (int)((Math.random()*9+1)*100000);
        return Integer.toString(code);
    }
}
