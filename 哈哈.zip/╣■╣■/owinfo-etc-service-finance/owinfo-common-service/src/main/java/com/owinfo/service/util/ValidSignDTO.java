package com.owinfo.service.util;

/**
 * @author Created by hekunlin on 2018年01月17日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class ValidSignDTO {

    private String message;

    private boolean success;

    private boolean valid;

    public ValidSignDTO() {
    }

    public ValidSignDTO(String message, boolean success, boolean valid) {
        this.message = message;
        this.success = success;
        this.valid = valid;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }
}
