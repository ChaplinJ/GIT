package com.owinfo.service.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月16日
 *         github : https://github.com/rexlin600/
 * @Description 校验对象是否为空的工具类
 */
@SuppressWarnings("rawtypes")
public class ValidateUtils {

    /**
     * @description 传入对象进行统一参数验证,上层接口通过code标识判断
     * @param object
     * @param param
     * @return
     */
    public static Map<String, Object> validateBean(Object object, int param) {
        Map<String, Object> map = new HashMap<>();
        String moneyRegex = "(^[1-9]([0-9]+)?(\\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\\.[0-9]([0-9])?$)";
        //录入转账接口参数验证
        if(object instanceof TransferAccountsManageDto && param == 1) {
            TransferAccountsManageDto transferDto = (TransferAccountsManageDto) object;

            if (transferDto.getInputPerson() == null || "".equals(transferDto.getInputPerson())) {
                map.put("code",ReturnResult.ERROR);
                map.put("msg","录入人员不能为空");
                return map;
            }
            //接口基本数据非空校验
            if (transferDto.getCustomerName() == null || "".equals(transferDto.getCustomerName())) {
                map.put("code", ReturnResult.ERROR);
                map.put("msg", "客户名称不能为空");
                return map;
            }
            if (transferDto.getTransferTime() == null || "".equals(transferDto.getTransferTime())) {
                map.put("code", ReturnResult.ERROR);
                map.put("msg", "转账日期不能为空");
                return map;
            }
            if (!transferDto.getTransferAmount().matches(moneyRegex)) {
                map.put("code", ReturnResult.ERROR);
                map.put("msg", "转账金额格式不正确");
                return map;
            }
            if (!transferDto.isCharge() && !transferDto.isObu() && !transferDto.isTreasure()) {
                map.put("code", ReturnResult.ERROR);
                map.put("msg", "请选择使用用途");
                return map;
            }
            //充值判断充值金额格式
            if(transferDto.isCharge() && transferDto.getRechargeAmount() == null) {
                map.put("code", ReturnResult.ERROR);
                map.put("msg", "请输入充值金额");
                return map;
            }
            if(transferDto.isCharge() && !transferDto.getRechargeAmount().matches(moneyRegex)) {
                map.put("code", ReturnResult.ERROR);
                map.put("msg", "充值金额格式不正确");
                return map;
            }
            //选择电子标签，判断名称，数量和单价
            if(transferDto.isObu()) {
                if (transferDto.getObuName() == null || "".equals(transferDto.getObuName())) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "请输入电子标签名称");
                    return map;
                }
                if(transferDto.getObuNum() == null) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "请输入电子标签数量");
                    return map;
                }
                if(!transferDto.getObuNum().matches("\\d+")) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "电子标签数量格式不正确");
                    return map;
                }
                if (transferDto.getObuPrice() == null) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "请输入电子标签单价");
                    return map;
                }
                if (!transferDto.getObuPrice().matches(moneyRegex)) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "电子标签单价格式不正确");
                    return map;
                }
            }
            //选择充值宝，充值宝数据校验
            if (transferDto.isTreasure()) {
                if (transferDto.getTreasureName() == null || "".equals(transferDto.getTreasureName())) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "请输入充值宝名称");
                    return map;
                }
                if(transferDto.getTreasureNum() == null) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "请输入充值宝数量");
                    return map;
                }
                if(!transferDto.getTreasureNum().matches("\\d+")) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "充值宝数量格式不正确");
                    return map;
                }
                if(transferDto.getTreasurePrice() == null) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "请输入充值宝单价");
                    return map;
                }
                if(!transferDto.getTreasurePrice().matches(moneyRegex)) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "充值宝单价格式不正确");
                    return map;
                }
            }

            //所有数据正确的情况下，进行数据逻辑判定
            String transAmount = MoneyUtil.format(transferDto.getTransferAmount(), 2);
            if(transferDto.isCharge() && !transferDto.isTreasure() && !transferDto.isObu()) { //1、充值
                if(!transAmount.equals(MoneyUtil.format(transferDto.getRechargeAmount(),2))){
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                }else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","1"); //1、充值
                    return map;
                }
            } else if (transferDto.isObu() && !transferDto.isCharge() && !transferDto.isTreasure()) {
                if (!transAmount.equals(MoneyUtil.mul(transferDto.getObuPrice(),transferDto.getObuNum(),2))) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                } else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","2"); //2、电子标签
                    return map;
                }
            } else if (transferDto.isTreasure() && !transferDto.isCharge() && !transferDto.isObu()) {
                if (!transAmount.equals(MoneyUtil.mul(transferDto.getTreasureNum(), transferDto.getTreasurePrice(), 2))) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                } else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","3"); //3、充值宝
                    return map;
                }
            } else if (transferDto.isCharge() && transferDto.isObu() && !transferDto.isTreasure()) {
                if(!transAmount.equals(MoneyUtil.add(MoneyUtil.mul(transferDto.getObuPrice(),
                        transferDto.getObuNum(), 2), transferDto.getRechargeAmount(), 2))) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                } else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","4"); // 4、充值+电子标签
                    return map;
                }
            } else if (transferDto.isCharge() && transferDto.isTreasure() && !transferDto.isObu()) {
                if (!transAmount.equals(MoneyUtil.add(MoneyUtil.mul(transferDto.getTreasureNum(),
                        transferDto.getTreasurePrice(),2), transferDto.getRechargeAmount(),2))) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                } else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","5"); //5、充值+充值宝
                    return map;
                }
            } else if (transferDto.isObu() && transferDto.isTreasure() && !transferDto.isCharge()) {
                if (!transAmount.equals(MoneyUtil.add(MoneyUtil.mul(
                        transferDto.getTreasureNum(), transferDto.getTreasurePrice(),2),
                        MoneyUtil.mul(transferDto.getObuPrice(), transferDto.getObuNum(),2),2))) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                } else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","6");//6、电子标签+充值宝
                    return map;
                }
            } else if (transferDto.isCharge() && transferDto.isTreasure() && transferDto.isObu()) {
                if (!transAmount.equals(MoneyUtil.add(transferDto.getRechargeAmount(),MoneyUtil.add(MoneyUtil.mul(
                        transferDto.getTreasureNum(), transferDto.getTreasurePrice(),2),
                        MoneyUtil.mul(transferDto.getObuPrice(), transferDto.getObuNum(),2),2),2))) {
                    map.put("code", ReturnResult.ERROR);
                    map.put("msg", "转账金额和计算出的金额不相等");
                    return map;
                } else {
                    map.put("code",ReturnResult.SUCCESS);
                    map.put("transferUse","7"); //7充值+电子标签+充值宝
                    return map;
                }
            }
        }
        map.put("code",ReturnResult.ERROR);
        map.put("msg", "传入数据异常");
        return map;
    }

    /**
     * 验证对象是否为空并返回字符串
     * @param object
     * @return
     */
    public static String toString(Object object) {
        return object == null ? "" : object.toString();
    }

    /**
     * 验证集合是否为空或null
     * @param collection
     * @return
     */
    public static boolean isEmpty(Collection collection) {
        return collection == null || collection.isEmpty();
    }

    /**
     * 验证Map是否为null或空
     * @param map
     * @return
     */
    public static boolean isEmpty(Map map) {
        return map == null || map.isEmpty();
    }

    /**
     * 验证字符串是否为空
     * @param string
     * @return
     */
    public static boolean isEmpty(String string) {
        return toString(string).isEmpty();
    }

    /**
     * 验证去掉前后空格后的字符串是否为空
     * @param string
     * @return
     */
    public static boolean isEmptyTrim(String string) {
        return toString(string).trim().isEmpty();
    }

    /**
     * 验证对象是否为空
     * @param object
     * @return
     */
    public static boolean isEmpty(Object object) {
        return toString(object).isEmpty();
    }

    /**
     * 验证对象去掉空格后是否为空
     * @param object
     * @return
     */
    public static boolean isEmptyTrim(Object object) {
        return toString(object).trim().isEmpty();
    }

    /**
     * 验证数组是否为null或数组为空
     * @param array
     * @param <T>
     * @return
     */
    public static <T> boolean isEmpty(T[] array) {
        return array == null || array.length == 0;
    }
}
