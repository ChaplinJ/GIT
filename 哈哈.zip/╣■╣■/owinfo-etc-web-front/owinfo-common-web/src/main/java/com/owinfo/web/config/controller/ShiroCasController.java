package com.owinfo.web.config.controller;

import com.owinfo.web.config.exception.UserInitException;
import com.owinfo.web.config.util.UserSessionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by liyue on 2017/10/17.
 */
@Controller
public class ShiroCasController {

    private static Logger logger = LoggerFactory.getLogger(ShiroCasController.class);

//    @Value("${shiro.cas.loginUrl}")
//    private String loginUrl;
//
//    @Value("${shiro.cas.logoutUrl}")
//    private String logoutUrl;
//
//    @Value("${owinfo.web.addressUrl}")
//    private String addressUrl;

    @RequestMapping("/login")
    public String login() throws UserInitException {
        throw new UserInitException("需要从4A系统进行登陆，请检查yml文件配置");
//        return "redirect:" + loginUrl;
    }

    @RequestMapping("/logout")
    public String loginout() throws UserInitException {
//        logger.info("user logout ----->"+ UserSessionUtil.getUserName());
//        UserSessionUtil.logout();
//        return "redirect:" + logoutUrl;
        throw new UserInitException("需要从4A系统进行注销，请检查yml文件配置");
    }

    @RequestMapping("/index")
    public String index() throws UserInitException {
        throw new UserInitException("需要从4A系统进行登陆，请检查yml文件配置");
//        String userName = URLEncoder.encode(UserSessionUtil.getUserName(), "UTF-8");
//        String userNo = URLEncoder.encode(UserSessionUtil.getUserNo(), "UTF-8");
//        logger.info("user login ----->"+ UserSessionUtil.getUserName());
//        return "redirect:" + addressUrl + "?userName=" + userName + "&userNo=" + userNo
//                + "&userId=" + UserSessionUtil.getUserId();
    }

    @RequestMapping("/403")
    public String auth() {
        logger.info("user unauthorized ----->"+ UserSessionUtil.getUserName());
        return "403";
    }
}
