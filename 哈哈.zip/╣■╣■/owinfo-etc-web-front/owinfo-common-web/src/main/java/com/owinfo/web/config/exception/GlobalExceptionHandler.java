package com.owinfo.web.config.exception;

import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by liyue on 2017/9/20.
 *
 *    处理shiro注解
 *
 *   v1  liyue
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    @Value("${shiro.cas.unauthorizedUrl}")
    private String unauthorizedUrl;

    /**
     * 使用shiro注解  实现filter的方式就不适用了
     * @param request
     * @param response
     */
    @ExceptionHandler(UnauthorizedException.class)
    public void UnauthorizedExceptionHandler(HttpServletRequest request, HttpServletResponse response) {
        String requestedWith = request.getHeader("X-Requested-With");
        if(requestedWith != null && "XMLHttpRequest".equals(requestedWith)){
            response.setHeader("SESSIONSTATUS", "UNAUTHORIZED");
            response.setHeader("CONTEXTPATH", unauthorizedUrl);
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        }else {
            try {
                response.sendRedirect(unauthorizedUrl);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
