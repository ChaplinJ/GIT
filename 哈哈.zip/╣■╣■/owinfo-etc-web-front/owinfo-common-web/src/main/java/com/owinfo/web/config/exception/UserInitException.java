package com.owinfo.web.config.exception;

/**
 * Created by liyue on 2017/10/28.
 */
public class UserInitException extends Exception {

    public UserInitException(String msg) {
        super(msg);
    }
}
