package com.owinfo.web.config.filter;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.session.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by liyue on 2017/10/25.
 *
 *
 *    验证用户是否登陆
 *
 *      因为cas和shiro的filter优先于自定义的filter
 *      所以需要设置自定义的filter优先级为最高 但是这时还没有初始化shiro和cas的配置类
 *      就造成了现在获取的session不是shiro包装之后的session
 *      就算在登陆的时候设置用户的登陆状态 在这里也是获取不到的
 *      实现方法：
 *
 *          设置过滤器为最先执行 去验证用户是否登陆 如果用户已登陆 redis中必定会有一个session缓存
 *          根据redis中的session缓存是否过期来判断用户是否过期
 *
 *       I'm so clever
 *
 *       liyue v1
 */
public class UserValidateFilter implements Filter {

    private static Logger logger = LoggerFactory.getLogger(UserValidateFilter.class);

    private String loginUrl;

    @Autowired
    private RedisTemplate redisTemplate;

    @Value("${shiro.cas.casFilterUrlPattern}")
    private String casFilterUrlPattern;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.loginUrl = filterConfig.getInitParameter("loginUrl");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String uri = request.getRequestURI();
        Cookie[] cookies = request.getCookies();
        if(cookies != null){
            for (Cookie cookie : cookies) {
                if("SHIROSESSIONID".equals(cookie.getName())){
                    Session session = (Session) redisTemplate.opsForValue().get(cookie.getValue());
                    if(session == null){
                        if(!StringUtils.equals(uri, casFilterUrlPattern)){
                            String requestedWith = request.getHeader("X-Requested-With");
                            if(requestedWith != null && "XMLHttpRequest".equals(requestedWith)){
                                response.setHeader("SESSIONSTATUS", "TIMEOUT");
                                response.setHeader("CONTEXTPATH", loginUrl);
                                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                                logger.info("session timeout ajax request and contains cookie----->" + uri);
                                return;
                            }else {
                                logger.info("session timeout no ajax request and contains cookie ----->" + uri);
                                response.sendRedirect(loginUrl);
                                return;
                            }
                        }
                    }
                }
            }
        }else{
            if(!StringUtils.equals(uri, casFilterUrlPattern)){
                String requestedWith = request.getHeader("X-Requested-With");
                if(requestedWith != null && "XMLHttpRequest".equals(requestedWith)){
                    response.setHeader("SESSIONSTATUS", "TIMEOUT");
                    response.setHeader("CONTEXTPATH", loginUrl);
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    logger.info("session timeout ajax request and cookie empty----->" + uri);
                    return;
                }else {
                    logger.info("session timeout no ajax request and cookie empty----->" + uri);
                    response.sendRedirect(loginUrl);
                    return;
                }
            }
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }
}
