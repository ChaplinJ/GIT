package com.owinfo.web.config.session;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.session.mgt.eis.CachingSessionDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

/**
 * Created by liyue on 2017/10/26.
 *
 *
 *         实现session共享
 *
 *         添加了ehcache做内存缓存  减少大量查询redis的次数
 *
 *         liyue v2
 */
@Service
public class ShiroSessionDao extends CachingSessionDAO {

    private static final Logger logger = LoggerFactory.getLogger(ShiroSessionDao.class);

    @Value("${shiro.cas.sessionTimeout}")
    private long sessionTimeout;

    @Autowired
    private RedisTemplate redisTemplate;

    public ShiroSessionDao() {
        super();
    }

    /**
     *  创建session时  把session写入redis
     * @param session
     * @return
     */
    @Override
    protected Serializable doCreate(Session session) {
        Serializable sessionId = this.generateSessionId(session);
        this.assignSessionId(session, sessionId);
        logger.info("create session sessionId-->"+session.getId());
        redisTemplate.opsForValue().set(session.getId(), session, sessionTimeout, TimeUnit.MILLISECONDS);
        return sessionId;
    }

    /**
     * 从redis中读取session
     * @param sessionId
     * @return
     */
    @Override
    protected Session doReadSession(Serializable sessionId) {
        logger.info("session read ----->" + sessionId);
        if (sessionId == null) {
            logger.error("read session error session is null");
            return null;
        }
        Session session = (Session) redisTemplate.opsForValue().get(sessionId);
        super.cache(session, sessionId);
        return session;
    }

    /**
     * 更新session的信息
     * @param session
     * @throws UnknownSessionException
     */
    @Override
    public void doUpdate(Session session) throws UnknownSessionException {
        if (session == null || session.getId() == null) {
            logger.error("update session error session is null");
            return;
        }
        session.setTimeout(sessionTimeout);
        redisTemplate.opsForValue().set(session.getId(), session, sessionTimeout, TimeUnit.MILLISECONDS);
    }

    /**
     * 删除session
     * @param session
     */
    @Override
    public void doDelete(Session session) {
        if (session == null || session.getId() == null) {
            logger.error("delete session error session is null");
            return;
        }
        redisTemplate.opsForValue().getOperations().delete(session.getId());
    }

    /**
     * 获取活跃的session集合
     *
     *     用不到 不实现
     *
     * @return
     */
    @Override
    public Collection<Session> getActiveSessions() {
        return null;
    }
}
