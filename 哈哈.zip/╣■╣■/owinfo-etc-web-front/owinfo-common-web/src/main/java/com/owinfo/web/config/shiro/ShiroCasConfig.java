package com.owinfo.web.config.shiro;

import com.owinfo.web.config.filter.UserValidateFilter;
import com.owinfo.web.config.session.ShiroSessionDao;
import org.apache.shiro.cache.ehcache.EhCacheManager;
import org.apache.shiro.cas.CasFilter;
import org.apache.shiro.cas.CasSubjectFactory;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.mgt.eis.SessionDAO;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.servlet.Cookie;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.jasig.cas.client.session.SingleSignOutFilter;
import org.jasig.cas.client.session.SingleSignOutHttpSessionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.DelegatingFilterProxy;

import javax.servlet.Filter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by liyue on 2017/10/14.
 *
 *
 *
 *      shiro和cas的配置
 *
 *
 *      liyue v2
 *
 */
@Configuration
public class ShiroCasConfig {

    private static final Logger logger = LoggerFactory.getLogger(ShiroCasConfig.class);

    @Value("${shiro.cas.serverUrl}")
    private String serverUrl;

    @Value("${shiro.cas.casLoginUrl}")
    private String casLoginUrl;

    @Value("${shiro.cas.casLogoutUrl}")
    private String casLogoutUrl;

    @Value("${shiro.cas.casFilterUrlPattern}")
    private String casFilterUrlPattern;

    @Value("${shiro.cas.shiroServerUrlPrefix}")
    private String shiroServerUrlPrefix;

    @Value("${shiro.cas.loginUrl}")
    private String loginUrl;

    @Value("${shiro.cas.logoutUrl}")
    private String logoutUrl;

    @Value("${shiro.cas.successUrl}")
    private String successUrl;

    @Value("${shiro.cas.unauthorizedUrl}")
    private String unauthorizedUrl;

    @Value("${shiro.cas.sessionTimeout}")
    private long sessionTimeout;

    @Value(("${shiro.cas.sessionValidation}"))
    private long sessionValidation;

    @Bean
    public DefaultWebSecurityManager securityManager() {
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        securityManager.setRealm(myShiroCasRealm());
        securityManager.setCacheManager(ehCacheManager());
        securityManager.setSessionManager(sessionManager());
        securityManager.setSubjectFactory(new CasSubjectFactory());
        return securityManager;
    }

    @Bean
    public ShiroCasRealm myShiroCasRealm() {
        ShiroCasRealm shiroRealm = new ShiroCasRealm();
        shiroRealm.setCachingEnabled(true);
        shiroRealm.setAuthorizationCachingEnabled(true);
        shiroRealm.setAuthorizationCacheName("authorizationCache");
        return shiroRealm;
    }

    @Bean
    public EhCacheManager ehCacheManager() {
        EhCacheManager cacheManager = new EhCacheManager();
        cacheManager.setCacheManagerConfigFile("classpath:ehcache/ehcache.xml");
        return cacheManager;
    }

    @Bean
    public ServletListenerRegistrationBean singleSignOutHttpSessionListener(){
        ServletListenerRegistrationBean bean = new ServletListenerRegistrationBean();
        bean.setListener(new SingleSignOutHttpSessionListener());
        bean.setEnabled(true);
        return bean;
    }

    @Bean
    public FilterRegistrationBean delegatingFilterProxy() {
        FilterRegistrationBean filterRegistration = new FilterRegistrationBean();
        filterRegistration.setFilter(new DelegatingFilterProxy("shiroFilter"));
        filterRegistration.addInitParameter("targetFilterLifecycle", "true");
        filterRegistration.setEnabled(true);
        filterRegistration.addUrlPatterns("/*");
        return filterRegistration;
    }

    @Bean
    public Filter userFilter() {
        return new UserValidateFilter();
    }

    @Bean
    public FilterRegistrationBean userValidateFilter() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        registrationBean.setFilter(userFilter());
        registrationBean.setName("userValidateFilter");
        registrationBean.addUrlPatterns("/*");
        registrationBean.addInitParameter("loginUrl", loginUrl);
        /**
         * 就是这么一句代码  没参与搭建的
         * 永远体会不到这句代码对我的意义  解决了一个大难题
         */
        registrationBean.setOrder(0);
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean singleSignOutFilter(){
        FilterRegistrationBean bean = new FilterRegistrationBean();
        bean.setName("singleSignOutFilter");
        bean.setFilter(new SingleSignOutFilter());
        bean.addUrlPatterns("/*");
        bean.setEnabled(true);
        return bean;
    }

    @Bean
    public Cookie cookie(){
        Cookie cookie = new SimpleCookie("SHIROSESSIONID");
        cookie.setHttpOnly(true);
        return cookie;
    }

    @Bean
    public SessionDAO sessionDAO() {
        return new ShiroSessionDao();
    }

    @Bean
    public DefaultWebSessionManager sessionManager(){
        DefaultWebSessionManager sessionManager = new DefaultWebSessionManager();
        sessionManager.setCacheManager(ehCacheManager());
        sessionManager.setSessionIdCookie(cookie());
        sessionManager.setSessionDAO(sessionDAO());
        sessionManager.setDeleteInvalidSessions(true);
        sessionManager.setGlobalSessionTimeout(sessionTimeout);
        sessionManager.setSessionValidationInterval(sessionValidation);
        return sessionManager;
    }

    @Bean("lifecycleBeanPostProcessor")
    public static LifecycleBeanPostProcessor lifecycleBeanPostProcessor() {
        return new LifecycleBeanPostProcessor();
    }

    @Bean
    public DefaultAdvisorAutoProxyCreator advisorAutoProxyCreator() {
        DefaultAdvisorAutoProxyCreator advisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
        advisorAutoProxyCreator.setProxyTargetClass(true);
        return advisorAutoProxyCreator;
    }

    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager) {
        AuthorizationAttributeSourceAdvisor attributeSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
        attributeSourceAdvisor.setSecurityManager(securityManager);
        return attributeSourceAdvisor;
    }

    @Bean
    public CasFilter casFilter() {
        ShiroCasFilter casFilter = new ShiroCasFilter();
        casFilter.setName("casFilter");
        casFilter.setEnabled(true);
        /**
         * 登录失败后跳转的URL
         */
        casFilter.setFailureUrl(loginUrl);
        return casFilter;
    }

    @Bean
    public ShiroFilterFactoryBean shiroFilter(SecurityManager securityManager, CasFilter casFilter) {
        logger.info("org.apache.shiro.spring.web.shiroFilter  initialization  start");
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        shiroFilterFactoryBean.setSecurityManager(securityManager);
        shiroFilterFactoryBean.setLoginUrl(loginUrl);
        shiroFilterFactoryBean.setSuccessUrl(successUrl);
        shiroFilterFactoryBean.setUnauthorizedUrl(unauthorizedUrl);
        Map<String, Filter> filters = new HashMap<>();
        filters.put("casFilter", casFilter);
        shiroFilterFactoryBean.setFilters(filters);
        Map<String, String> filterChain = new LinkedHashMap<String, String>();
        //cas过滤请求
        filterChain.put(casFilterUrlPattern, "casFilter");
        //不拦截的请求
        filterChain.put("/login", "anon");
        filterChain.put("/logout","anon");
        filterChain.put("/error","anon");
        //拦截的请求
        filterChain.put("/**", "authc");
        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChain);
        logger.info("org.apache.shiro.spring.web.shiroFilter  initialization  end");
        return shiroFilterFactoryBean;
    }
}
