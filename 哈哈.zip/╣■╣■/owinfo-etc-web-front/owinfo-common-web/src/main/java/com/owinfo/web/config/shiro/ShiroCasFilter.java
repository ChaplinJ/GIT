package com.owinfo.web.config.shiro;

import com.owinfo.web.config.exception.UserInitException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.cas.CasFilter;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Created by liyue on 2017/10/21.
 *
 *
 *    因为shiro默认会记住上一次访问的路径进行跳转  造成了一些问题
 *
 *      在这里重写CasFilter  进行处理
 *
 *      liyue v1
 */
public class ShiroCasFilter extends CasFilter {

    private static Logger logger = LoggerFactory.getLogger(ShiroCasFilter.class);

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) throws Exception {
        return super.createToken(request, response);
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        return super.onAccessDenied(request, response);
    }

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        return super.isAccessAllowed(request, response, mappedValue);
    }

    @Override
    protected boolean onLoginSuccess(AuthenticationToken token, Subject subject, ServletRequest request, ServletResponse response) throws Exception {
        throw new UserInitException("需要从4A系统进行登陆，请检查yml文件配置");
//        List<Object> principalsList = subject.getPrincipals().asList();
//        HashMap<String, String> principals = (HashMap<String, String>) principalsList.get(1);
//        String userId = principals.get("id");
//        String userNo = principals.get("userNo");
//        String userName = principals.get("userName");
//        if(userId == null || userNo == null || userName == null ||
//                "".equals(userId) || "".equals(userNo) || "".equals(userName)){
//            logger.error("initialization userInfo error userId userNo userName is null");
//            throw new UserInitException("initialization userInfo error userId userNo userName is null");
//        }
//        Session session = subject.getSession();
//        session.setAttribute("userId", userId);
//        session.setAttribute("userNo", userNo);
//        session.setAttribute("userName", userName);
//        WebUtils.getAndClearSavedRequest(request);
//        return super.onLoginSuccess(token, subject, request, response);
    }

    @Override
    protected boolean onLoginFailure(AuthenticationToken token, AuthenticationException ae, ServletRequest request, ServletResponse response) {
        WebUtils.getAndClearSavedRequest(request);
        return super.onLoginFailure(token, ae, request, response);
    }

    @Override
    public void setFailureUrl(String loginUrl) {
        super.setFailureUrl(loginUrl);
    }
}
