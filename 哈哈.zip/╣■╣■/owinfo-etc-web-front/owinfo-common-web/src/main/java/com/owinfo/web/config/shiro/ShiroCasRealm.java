package com.owinfo.web.config.shiro;

import com.owinfo.web.service.UserService;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cas.CasRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.Set;

/**
 * Created by liyue on 2017/9/19.
 *
 *    用户认证
 *
 *    v3  liyue
 *
 *    update 17.10.14
 */
public class ShiroCasRealm extends CasRealm {

    private Logger logger = LoggerFactory.getLogger(ShiroCasRealm.class);

    @Value("${shiro.cas.serverUrl}")
    private String serverUrl;

    @Value("${shiro.cas.casFilterUrlPattern}")
    private String casFilterUrlPattern;

    @Value("${shiro.cas.shiroServerUrlPrefix}")
    private String shiroServerUrlPrefix;

    @Autowired
    private UserService userService;

    @PostConstruct
    public void initProperty(){
        setCasServerUrlPrefix(serverUrl);
        setCasService(shiroServerUrlPrefix + casFilterUrlPattern);
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        String userName = (String)super.getAvailablePrincipal(principalCollection);
        Map<String, String> map = (Map<String, String>) principalCollection.asList().get(1);
        String userId = map.get("id");
        /**
         * 加载用户的权限
         *   未避免多次调用  配置了cache  当查询一次后 在超时时间内
         *   都不会再去调用服务
         */
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        Set<String> roles = userService.roleNames(userId);
        if(roles == null || roles.size() < 1){
            logger.error("initialization user authentic error-----> role empty-->" + userName);
            return info;
        }
        Set<String> auths = userService.authUrls(userId);
        if(auths == null || auths.size() < 1){
            logger.error("initialization user authentic error-----> auths empty-->" + userName);
        }
        info.setRoles(roles);
        info.setStringPermissions(auths);
        logger.info("initialization user authentic success----->" + userName);
        return info;
    }
}
