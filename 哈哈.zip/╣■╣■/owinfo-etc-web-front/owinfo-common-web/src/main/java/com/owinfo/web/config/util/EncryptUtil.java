package com.owinfo.web.config.util;

import org.apache.shiro.codec.Base64;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by liyue on 2017/9/19.
 *
 *    shiro提供的加密进行封装
 *
 *      对关键数据都需要进行加密处理
 *      v1  liyue
 */
public class EncryptUtil {

    private static Logger logger = LoggerFactory.getLogger(EncryptUtil.class);

    private static String salt;

    static{
        Properties properties = new Properties();
        InputStream inputStream = EncryptUtil.class.getClassLoader().getResourceAsStream("config/system.properties");
        try {
            properties.load(inputStream);
            salt = properties.getProperty("salt");
            inputStream.close();
            if(salt == null){
                logger.error("properties  initialization  error:----->salt is null");
            }else{
                logger.info("properties  initialization  success");
            }
        } catch (IOException e) {
            logger.error("properties  initialization  error:", e);
        }
    }

    /**
     *  shiro base64加密
     * @param str
     * @return
     */
    public static String encBase64(String str){
        return Base64.encodeToString(str.getBytes());
    }

    /**
     * shiro base64解密
     * @param str
     * @return
     */
    public static String decBase64(String str){
        return Base64.decodeToString(str);
    }

    /**
     * shiro MD5加密
     * @param str
     * @return
     */
    public static String md5(String str){
        return new Md5Hash(str, salt).toString();
    }

//    public static void main(String[] args) {
//        System.out.println(UUID.randomUUID().toString().replaceAll("-", ""));
//        String str = "12345";
//        System.out.println(EncryptUtil.encBase64(str));
//        System.out.println(EncryptUtil.decBase64(EncryptUtil.encBase64(str)));
//        System.out.println(new Md5Hash(str, "owinfo").toString());
//    }

}
