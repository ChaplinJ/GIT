package com.owinfo.web.config.util;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by liyue on 2017/11/1.
 *
 *
 *    构建日志服务需要的参数
 *
 */
public class LoggerParameter {

    private LoggerParameter(){}

    /**
     * 构建操作日志需要的参数
     * @param operationThing
     * @param description
     * @param requestParam  适用于请求参数是一个Map对象的情况下
     * @param result
     * @param request
     * @return
     */
    public static Map<String, Object> OperationLoggerParam(String operationThing, String description,
                                                           Map<String, Object> requestParam, Map<String, Object> result, HttpServletRequest request) {
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("userId", UserSessionUtil.getUserId());
        param.put("userName", UserSessionUtil.getUserName());
        param.put("operationThing", operationThing);
        param.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        param.put("ip", LoggerParameter.getIpAddress(request));
        /**
         * 如果系统中服务返回值不是JSONObject 可自行更改
         * 只需要把操作结果取出来就行
         */
        String message = (String) result.get("msg");
        param.put("description", description + "<br/>参数为：<br/>" + LoggerParameter.paramToString(requestParam)
                + "<br/>操作结果为：<br/>" + message);
        return param;
    }

    /**
     * 如果请求参数不是Map对象 且 不止一个参数 需自行把参数拼接为一个字符串
     * @param operationThing
     * @param description
     * @param requestParam  适用于请求参数只有一个的情况下
     * @param result
     * @param request
     * @return
     */
    public static Map<String, Object> OperationLoggerParam(String operationThing, String description,
                                                           String requestParam, Map<String, Object> result, HttpServletRequest request) {
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("userId", UserSessionUtil.getUserId());
        param.put("userName", UserSessionUtil.getUserName());
        param.put("operationThing", operationThing);
        param.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        param.put("ip", LoggerParameter.getIpAddress(request));
        /**
         * 如果系统中服务返回值不是JSONObject 可自行更改
         * 只需要把操作结果取出来就行
         */
        String message = (String) result.get("msg");
        param.put("description", description + "<br/>参数为：<br/>" + requestParam
                + "<br/>操作结果为：<br/>" +  message);
        return param;
    }

    public static String paramToString(Map<String, Object> param) {
        StringBuffer sb = new StringBuffer();
        for (String key : param.keySet()) {
            String value;
            try {
                value = (String) param.get(key);
            } catch (Exception e){
                value = e.getMessage();
            }
            sb.append("key--" + key + "<===>value--" + value + "<br/>");
        }
        return sb.toString();
    }

    public static String getIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if(ip != null && !"".equals(ip) && ip.contains(",")){
            ip = ip.substring(0, (ip.indexOf(",")));
        }
        return ip;
    }
}
