package com.owinfo.web.config.util;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liyue on 2017/9/21.
 *
 *      封装一些session和subject的方法
 *
 *          Control中使用此类获取session和user
 *
 *      v1  liyue
 */
public class UserSessionUtil {

    private static Logger logger = LoggerFactory.getLogger(UserSessionUtil.class);

    private UserSessionUtil(){}

    /**
     * 获取session
     *     项目中的session会话是shiro提供的session会话
     *     即使用HttpServletRequest获取HttpSession
     *     此HttpSession也不是Servlet中的HttpSession
     * @return
     */
    public static Session getSession(){
        Subject subject = SecurityUtils.getSubject();
        if(subject != null){
            return subject.getSession();
        }
        logger.error("get session error subject is null");
        return null;
    }

    /**
     * 获取UserName
     * @return
     */
    public static String getUserName(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("userName");
        }
        logger.error("get userName error subject is null or isAuthenticated is false");
        return null;
    }

    /**
     * 获取UserId
     * @return
     */
    public static String getUserId(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("userId");
        }
        logger.error("get userId error session is null");
        return null;
    }

    /**
     * 获取User工号
     * @return
     */
    public static String getUserNo(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("userNo");
        }
        logger.error("get userNo error session is null");
        return null;
    }

    /**
     * 获取当前网点编号
     * @return
     */
    public static String getDotNo(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("dotNo");
        }
        logger.error("get dotNo error session is null");
        return null;
    }

    /**
     * 获取当前网点名称
     * @return
     */
    public static String getUserDotName(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("dotName");
        }
        logger.error("get dotName error session is null");
        return null;
    }

    /**
     * 获取当前渠道编号
     * @return
     */
    public static String getChannelNo(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("channelNo");
        }
        logger.error("get channelNo error session is null");
        return null;
    }

    /**
     * 获取当前网点名称
     * @return
     */
    public static String getChannelName(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("channelName");
        }
        logger.error("get channelName error session is null");
        return null;
    }

    /**
     * 获取当前网点所属渠道类型
     * @return
     */
    public static String getChannelType(){
        Session session = SecurityUtils.getSubject().getSession();
        if(session != null){
            return (String) session.getAttribute("channelType");
        }
        logger.error("get channelType error session is null");
        return null;
    }

    public static void logout() {
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
    }
}
