package com.owinfo.web.controller;

import com.alibaba.fastjson.JSONObject;
import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.AccountMergeService;
import com.owinfo.web.util.JSONResultUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by liyue on 2018/2/2.
 */
@RestController
@RequestMapping("/accountMerge")
public class AccountMergeController {

    @Autowired
    private AccountMergeService accountMergeService;

    /**
     * 查询证件号下的户
     * @param certificateNumber
     * @return
     */
    @RequestMapping(value = "/queryAccount", method = RequestMethod.POST)
    public JSONObject queryAccount(@RequestParam("certificateNumber") String certificateNumber) {
        if(certificateNumber == null || "".equals(certificateNumber)){
            return JSONResultUtil.errorResult(null, "获取参数为空");
        }
        return accountMergeService.queryAccount(certificateNumber);
    }

    /**
     * 查询账户下的明细
     * @param spare
     * @return
     */
    @RequestMapping(value = "/queryAccountDetail", method = RequestMethod.POST)
    public JSONObject queryAccountDetail(@RequestParam("spare") String spare) {
        if(spare == null || "".equals(spare)){
            return JSONResultUtil.errorResult(null, "获取参数为空");
        }
        return accountMergeService.queryAccountDetail(spare);
    }

    /**
     * 统一账户
     * @param param
     * @return
     */
    @RequestMapping(value = "/accountUnified", method = RequestMethod.POST)
    public JSONObject accountUnified(@RequestBody Map<String, Object> param, HttpServletRequest request){
        if(param == null || param.get("spare") == null || param.get("certificateNumber") == null){
            return JSONResultUtil.errorResult(null, "获取参数为空");
        }
        if(UserSessionUtil.getUserId() == null || UserSessionUtil.getUserName() == null){
            return JSONResultUtil.errorResult(null, "获取参数为空");
        }
        param.put("userId", UserSessionUtil.getUserId());
        param.put("userName", UserSessionUtil.getUserName());
        param.put("ip", LoggerParameter.getIpAddress(request));
        return accountMergeService.accountUnified(param);
    }
}
