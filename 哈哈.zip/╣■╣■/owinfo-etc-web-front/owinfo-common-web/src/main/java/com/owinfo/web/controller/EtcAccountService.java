package com.owinfo.web.controller;

import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.AccountFeign;
import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.LoggerService;
import com.owinfo.web.util.FileUtil;
import com.owinfo.web.util.Json;
import com.owinfo.web.util.ReturnResult;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

/**
 * Created by admin on 2017/10/26.
 */
@RestController
@RequestMapping("/etcUserService")
public class EtcAccountService {

    @Autowired
    private AccountFeign accountFeign;

    @Autowired
    private BizFeign bizFeign;

    @Autowired
    private LoggerService loggerService;

    /**
     * 查看客户信息
     *
     * @param param
     * @return
     */   //68  //180
    @RequiresPermissions(value = {"car:query", "tabtransform:query", "card:query", "etab:query", "cardchangpwd:query", "accountrecharge:query", "accountWithdraw:query", "treeToOne:query", "ltcarsinfo:query", "ltcorrection:query", "cardlost:query", "cardsolution:queryCard", "cardchangpwd:query", "carddetail:query", "ltcarscheck:verify", "accountrecharge:query", "printreceipt:query", "account:add", "accountchange:query", "idEdit:query"}, logical = Logical.OR)
    @RequestMapping(value = "/findByNumber", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findByNumber(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findByNumber(param);
        return resultMap;
    }

    /**
     * 查看车辆（列表）
     *
     * @param param
     * @return
     */  //69
    @RequiresPermissions(value = {"car:list", "ltcarsinfo:list", "ltcorrection:list", "cardsolution:queryCard", "cardlost:query", "cardreplace:query", "cardtransform:queryCard", "cardextend:queryCard", "cardhangup:queryCard", "cardhangoff:queryCard", "cardwithdraw:queryCard", "cardbreakdown:query", "ltcarscheck:verify"}, logical = Logical.OR)
    @RequestMapping(value = "/findVehicleByCertificateNumber", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findVehicleByCertificateNumber(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findVehicleByCertificateNumber(param);
        return resultMap;
    }

    /**
     * 查看车辆详情
     *
     * @param param
     * @return
     */   //691
    @RequiresPermissions(value = {"car:detil", "ltcarsinfo:query", "ltcarsinfo:detil", "ltcarscheck:verify","carsAccount:list"}, logical = Logical.OR)
    @RequestMapping(value = "/findVehicleDetil", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findVehicleDetil(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findVehicleDetil(param);
        return resultMap;
    }

    /**
     * 查看车辆详情
     *
     * @param param
     * @return
     */   //691

    @RequestMapping(value = "/findVehicleDetilTwo", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findVehicleDetilTwo(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findVehicleDetilTwo(param);
        return resultMap;
    }

    /**
     * 查看客户操作记录
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/findAccountOperationDetail", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findAccountOperationDetail(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findAccountOperationDetail(param);
        return resultMap;
    }

    /**
     * 开户
     *
     * @param param
     * @return
     */   //66
    @RequiresPermissions(value = {"account:add"})
    @RequestMapping(value = "/insertAccount", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> insertAccount(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        String stationId = UserSessionUtil.getDotNo();
        if (stationId==null){
           return ReturnResult.error("获取站点信息失败,请重试或重新登录");
        }
        param.put("stationId", stationId);//获取网点信息
        param.put("operatorId", UserSessionUtil.getUserNo());//操作员工号
        param.put("createBy", UserSessionUtil.getUserNo());//操作员姓名
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员姓名
        resultMap = bizFeign.insertAccount(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "开户", param, resultMap, request));
        return resultMap;
    }

    /**
     * 修改用户
     *
     * @param param
     * @return
     */   //699
    @RequiresPermissions(value = {"accountQuery:update"})
    @RequestMapping(value = "/updateAccount", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> updateAccount(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员姓名
        resultMap = bizFeign.updateAccount(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "修改用户", param, resultMap, request));
        return resultMap;
    }

    /**
     * 添加车辆
     *
     * @param param
     * @return
     */   //70
    @RequiresPermissions(value = {"car:add"})
    @RequestMapping(value = "/insertVehicle", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> insertVehicle(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        System.out.println("添加车辆-----------------");
        String stationId = UserSessionUtil.getDotNo();
        if (stationId==null){
            return ReturnResult.error("获取站点信息失败,请重试或重新登录");
        }
        Map<String, Object> resultMap = new HashMap<>();
        param.put("createBy", UserSessionUtil.getUserNo());//操作员姓名
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员姓名
        param.put("stationId", stationId);//获取网点信息4101010200201010142
//        param.put("createBy", "17110002");//操作员姓名
//        param.put("updateBy", "17110002");//操作员姓名
//        param.put("stationId", "4101010200201010142");//获取网点信息
//        System.out.println("获取------------站点" + stationId);
        resultMap = bizFeign.insertVehicle(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "添加车辆", param, resultMap, request));
        return resultMap;
    }

    /**
     * 更新车辆
     *
     * @param param
     * @return
     */    //72
    @RequiresPermissions(value = {"car:update"})
    @RequestMapping(value = "/updateVehicle", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> updateVehicle(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        System.out.println("修改车辆-----------------");
        Map<String, Object> resultMap = new HashMap<>();
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员姓名
        System.out.println("获取------------站点" + UserSessionUtil.getDotNo().toString());
        resultMap = bizFeign.updateVehicle(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "更新车辆", param, resultMap, request));
        return resultMap;
    }

    /**
     * 用户注销
     *
     * @param param
     * @return
     */    //297
    @RequiresPermissions(value = {"accountWithdraw:logout"})
    @RequestMapping(value = "/deleteAccount", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> deleteAccount(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        resultMap = bizFeign.deleteAccount(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("3", "用户注销", param, resultMap, request));
        return resultMap;
    }

    /**
     * 多证合一
     *
     * @param param
     * @return
     */    //308
    @RequiresPermissions(value = {"treeToOne:register"})
    @RequestMapping(value = "/groupTransferAccount", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> groupTransferAccount(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        param.put("cretaeBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        resultMap = bizFeign.groupTransferAccount(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "多证合一", param, resultMap, request));
        return resultMap;
    }

    /**
     * 修改账户密码
     */
    @RequiresPermissions(value = {"cardchangpwd:update"})
    @RequestMapping(value = "/updateAccountPass", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> updateAccountPass(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        param.put("updateBy", UserSessionUtil.getUserNo());//获取修改人
        resultMap = bizFeign.updateAccountPass(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "修改账户密码", param, resultMap, request));
        return resultMap;
    }

    /**
     * 重置账户密码
     */
    @RequiresPermissions(value = {"cardchangpwd:reset"})
    @RequestMapping(value = "/resetAccountPass", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> resetAccountPass(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        param.put("updateBy", UserSessionUtil.getUserNo());//获取修改人
        resultMap = bizFeign.resetAccountPass(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "重置账户密码", param, resultMap, request));
        return resultMap;
    }

    /**
     * 账户密码校验
     */
    @RequiresPermissions(value = {"cardchangpwd:verify", "cardlost:queryPass", "cardreplace:queryPass", "cardtransform:queryPass", "cardwithdraw:queryPass", "onetoone:queryPass"}, logical = Logical.OR)
    @RequestMapping(value = "/verifyAccountPass", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> verifyAccountPass(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.verifyAccountPass(param);
        return resultMap;
    }

    /**
     * 添加黑名单
     */
    @RequiresPermissions(value = {"lthitlist:add"})
    @RequestMapping(value = "/insertBlackList")
    public Map<String, Object> insertBlackList(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("cretaeBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        resultMap = bizFeign.insertBlackList(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "添加黑名单", param, resultMap, request));
        return resultMap;
    }

    /**
     * 黑名单---分页、组合查询
     */
    @RequiresPermissions(value = {"lthitlist:list"})
    @RequestMapping(value = "/blackList", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> blackList(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = bizFeign.blackList(param);
        return resultMap;
    }

    /**
     * 黑名单---更新、修改
     */
    @RequiresPermissions(value = {"lthitlist:update"})
    @RequestMapping(value = "/blackUpdate", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> blackUpdate(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        resultMap = bizFeign.blackUpdate(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "黑名单修改", param, resultMap, request));
        return resultMap;
    }

    /**
     * 黑名单单条查询
     */
    @RequiresPermissions(value = {"lthitlist:query"})
    @RequestMapping(value = "/findByKeyBlackList", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findByKeyBlackList(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findByKeyBlackList(param);
        return resultMap;
    }

    /**
     * 黑转白
     */
    @RequiresPermissions(value = {"lthitlist:white"})
    @RequestMapping(value = "/blackToWhite", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> blackToWhite(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("cretaeBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        resultMap = bizFeign.blackToWhite(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "黑转白", param, resultMap, request));
        return resultMap;
    }

    /**
     * 黑名单重新上报  2018-02-02
     *
     * @param
     * @return
     */
    @RequestMapping(value = "/reportBlackAgain", method = RequestMethod.POST)
    public Json findDictByCode(@RequestBody Map<String, Object> param) {
        return accountFeign.reportBlackAgain(param);
    }



    /**
     * 查看历史黑名单信息  2018-02-02
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/findBlackLog", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findBlackLog(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findBlackLog(param);
        return resultMap;
    }

    /**
     * 黑名单导出
     *
     * @param param
     * @param response
     */
    @RequiresPermissions(value = {"lthitlist:export"})
    @RequestMapping(value = "/blackListExport")
    public void blackListExport(@RequestParam Map<String, Object> param, HttpServletResponse response) {
        byte[] bytes = accountFeign.blackListExport(param);
        FileUtil fileUtil = new FileUtil();
        if (bytes != null) {
            String fileName = "黑名单列表";
            try {
                fileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 密码校验
     */
    @ResponseBody
    @RequestMapping("/verifyAccountPass")
    public Map<String, Object> verifyAccountPass(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        return accountFeign.verifyAccountPass(param);
    }

    /**
     * 停车场消费查询导出
     */
    @RequiresPermissions(value = {"ltparkexpense:export"})
    @RequestMapping("/findPrkListExport")
    public void findPrkListExport(@RequestParam Map<String, Object> param, HttpServletResponse response) {
        try {
            FileUtil.fileOutput(response, "停车场消费导出", accountFeign.findPrkListExport(param));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 停车场消费查询
     */
    @RequiresPermissions(value = {"ltparkexpense:list","ltparkexpense:export"}, logical = Logical.OR)
    @RequestMapping("/findPrkList")
    public Map<String, Object> findPrkList(@RequestBody Map<String, Object> param, HttpServletResponse response) {
        return accountFeign.findPrkList(param);
    }

    //修改用户重要信息
    @RequiresPermissions(value = {"accountchange:update"})
    @RequestMapping("/upUserMsg")
    public Map<String, Object> upUserMsg(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("cretaeBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        resultMap = bizFeign.upUserMsg(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "修改用户重要信息", param, resultMap, request));
        return resultMap;
    }

    /**
     * 查看车辆（列表）
     *
     * @param param
     * @return
     */  //69
    @RequiresPermissions(value = {"car:list", "ltcarsinfo:list", "ltcorrection:list","cardsolution:queryCard","cardlost:query","cardreplace:query","cardtransform:queryCard","cardextend:queryCard","cardhangup:queryCard","cardhangoff:queryCard","cardwithdraw:queryCard","cardbreakdown:query","ltcarscheck:verify","carsAccount:list"}, logical = Logical.OR)
    @RequestMapping(value = "/findAllCar", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findAllCar(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findAllCarTwo(param);
        return resultMap;
    }

    /**
     * 账户查看（模糊）
     *
     * @param param
     * @return
     */  //69

    @RequestMapping(value = "/likeFind", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> likeFind(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.likeFind(param);
        return resultMap;
    }

    /**
     * 账户查看（证件号,卡号,客户名称,车牌）
     *
     * @param param
     * @return
     */  //69
    @RequiresPermissions(value = {"carsAccount:query"}, logical = Logical.OR)
    @RequestMapping(value = "/likeFindTwo", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> likeFindTwo(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.likeFindTwo(param);
        return resultMap;
    }

    //国库记录
    @RequestMapping(value = "/nationalSoleCar", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> nationalSoleCar(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.nationalSoleCar(param);
        return resultMap;
    }

    //车辆删除
    @RequestMapping(value = "/deleteVehicle", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> deleteVehicle(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        resultMap = accountFeign.deleteVehicle(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("3", "车辆删除", param, resultMap, request));
        return resultMap;
    }

    //证件号修改（不一样的号码，修改成一样的）
    @RequiresPermissions(value = {"idEdit:update"}, logical = Logical.OR)
    @RequestMapping(value = "/updateCerNo", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> updateCerNo(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("operatorId", UserSessionUtil.getUserNo());//操作员工号
        param.put("stationId", UserSessionUtil.getDotNo());//获取网点信息
        resultMap = accountFeign.updateCerNo(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "用户证件修改（合户）", param, resultMap, request));
        return resultMap;
    }

    /**
     * 纸质材料设置
     */
    @RequiresPermissions(value = {"carsAudit:query"}, logical = Logical.OR)
    @RequestMapping(value = "/pageSet", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> pageSet(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        resultMap = accountFeign.pageSet(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "纸质材料设置", param, resultMap, request));
        return resultMap;
    }

    /**
     * 车辆信息审核
     */
    @RequiresPermissions(value = {"carsAudit:query"}, logical = Logical.OR)
    @RequestMapping(value = "/reviseReject", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> reviseReject(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("updateBy", UserSessionUtil.getUserNo());//操作员工号
        param.put("auditMan", UserSessionUtil.getUserNo());//审核人
//        param.put("updateBy", "16050005");//操作员工号
//        param.put("auditMan", "16050005");//审核人
        resultMap = accountFeign.reviseReject(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "车辆信息审核", param, resultMap, request));
        return resultMap;
    }

    /**
     * 校正审核通过
     */
    @RequestMapping(value = "/passRevise", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> passRevise(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("auditMan",UserSessionUtil.getUserNo());
        resultMap = accountFeign.passRevise(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "车辆校正流程通过", param, resultMap, request));
        return resultMap;
    }

    /**
     * 校正记录查询（分页list）
     */
    @RequiresPermissions(value = {"ltcarscheck:list", "caredit:list"}, logical = Logical.OR)
    @RequestMapping(value = "/findReviseList", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findReviseList(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        param.put("stationId",UserSessionUtil.getDotNo());
        resultMap = accountFeign.findReviseList(param);
        return resultMap;
    }

    /**
     * 查看校正记录（单条）
     */
    @RequiresPermissions(value = {"caredit:query", "ltcarscheck:query", "ltcorrection:verify"}, logical = Logical.OR)
    @RequestMapping(value = "/findOneRevise", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findOneRevise(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findOneRevise(param);
        return resultMap;
    }


    /**
     * 创建校正流程校验
     */   //692
    @RequestMapping(value = "/registerRevise", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> registerRevise(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.registerRevise(param);
        return resultMap;
    }

    /**
     * 创建校正流程记录
     */   //700
    @RequestMapping(value = "/insertRevise", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> insertRevise(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        String sender = UserSessionUtil.getUserNo();//校正发起人
//        String sender = "665544";//校正发起人
        if (sender == null) {
            return ReturnResult.error("获取发起人失败");
        }
        param.put("sender", sender);
        param.put("index","1");//标志页面调用
        resultMap = accountFeign.insertRevise(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "创建车辆校正流程", param, resultMap, request));
        return resultMap;
    }

    /**
     * 审核不通过
     */

    @RequestMapping(value = "/errorRevise", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> errorRevise(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.errorRevise(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "车辆校正流程不通过", param, resultMap, request));
        return resultMap;
    }

    /**
     * 校正确认按钮
     */
    @RequiresPermissions(value = {"caredit:revise"})
    @RequestMapping(value = "/goRevise", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> goRevise(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        String reviser = UserSessionUtil.getUserNo();//获取校正人
//        String reviser = "123";
        if (reviser == null) {
            return ReturnResult.error("获取校正人失败");
        }
        param.put("reviser", reviser);
        resultMap = accountFeign.goRevise(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "车辆校正确认", param, resultMap, request));
        return resultMap;
    }

    /**
     * 校正详情查询
     */
    @RequiresPermissions(value = {"caredit:query", "ltcarscheck:query", "ltcarscheck:revise"}, logical = Logical.OR)
    @RequestMapping(value = "/findReviseDetil", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findReviseDetil(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findReviseDetil(param);
        return resultMap;
    }

    /**
     * 车辆审核(list)
     */
    @RequiresPermissions(value = {"carsAudit:query"}, logical = Logical.OR)
    @RequestMapping(value = "/auditList", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> auditList(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.auditList(param);
        return resultMap;
    }

    /**
     * 车辆审核(list) 导出
     */
    @RequiresPermissions(value = {"carsAudit:export"})
    @RequestMapping(value = "/auditExport")
    public void auditExport(@RequestParam Map<String, Object> param,HttpServletResponse response) {
        try {
            FileUtil.fileOutput(response, "车辆审核列表导出", accountFeign.auditExport(param));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}