package com.owinfo.web.controller;


import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.CardFeign;
import com.owinfo.web.service.LoggerService;
import com.owinfo.web.util.CnCode;
import com.owinfo.web.util.FileUtil;
import com.owinfo.web.util.ReturnResult;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by admin on 2017/10/16.
 */
@RestController
@RequestMapping("/etcCardService")
public class EtcCardService {

    @Autowired
    private CardFeign cardFeign;

    @Autowired
    private BizFeign bizFeign;

    @Autowired
    private LoggerService loggerService;

    @RequestMapping(value="/insertCard",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> insertCard(@RequestBody Map<String, Object> data) {
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.insertCard(data);
        return map;
    }


    @RequiresPermissions(value = {"cardsolution:queryCard","cardreplace:query","cardreplace:queryCard","cardtransform:queryCard","cardtransform:addNewCard","cardextend:queryCard","cardhangup:queryCard","cardhangoff:queryCard","cardwithdraw:queryCard","cardbreakdown:query","debitactivate:queryCard","ltetcaccount:query","cardrecharge:query","deposit:query","carsAccount:list"}, logical = Logical.OR)
    @RequestMapping(value="/getCard",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCard(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.getCard(data);
        return map;
    }

    @RequestMapping(value="/getCardDetail",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCardDetail(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.getCard(data);
        return map;
    }

    @RequiresPermissions(value = {"ltetcaccount:list"}, logical = Logical.OR)
    @RequestMapping(value="/getCards",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCards(@RequestBody Map<String, Object> data) {
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.getCards(data);
        return map;
    }

    @RequiresPermissions(value = {"ltetcchangelist:list","ltetcchangeinfo:list"}, logical = Logical.OR)
    @RequestMapping(value="/getCardlogs",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCardlogs(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.getCardlogs(data);
        return map;
    }

    @RequestMapping(value="/changeCard",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> changeCard(@RequestBody Map<String, Object> data, HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.changeCard(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "更改卡信息", data, map, request));

        return map;
    }

    @RequestMapping(value="/saveLog",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> saveLog(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.saveLog(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "插入卡操作记录", data, map, request));

        return map;
    }

    @RequestMapping(value = "/gbkToHex", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> gbkToHex(@RequestBody Map<String, Object> data) {
        int a = data.size();
        try {
            Map<String, Object> map = new HashMap<>();
            if (data.size() > 0) {
                for (String i : data.keySet()) {
                    if (data.get(i) != null) {
                        String j = null;
                       j = URLDecoder.decode((String) data.get(i));
                        j = CnCode.StrToHex(j);
                        map.put(i,j.replaceAll(" ",""));
                    }
                }
            }
            return ReturnResult.successResult("转换成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return ReturnResult.error("转换失败");
        }
    }

    @RequestMapping("/CardInfoExport")
    @RequiresPermissions(value = {"ltetcaccount:export"})
    public void CardInfoExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        if(map.get("vehicleLicense")!=null && map.get("vehicleLicense") != ""){
            map.put("vehicleLicense",URLDecoder.decode(String.valueOf(map.get("vehicleLicense"))));
        }
        byte[] bytes = bizFeign.CardInfoExport(map);
        if(bytes!=null){
            String fileName = "卡账户列表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @RequestMapping("/CardDetailExport")
    @RequiresPermissions(value = {"ltetcchangeinfo:export"})
    public void CardDetailExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.CardDetailExport(map);
        if(bytes!=null){
            String fileName = "卡操作明细表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @RequestMapping("/CardListExport")
    @RequiresPermissions(value = {"ltetcchangelist:export"})
    public void CardListExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.CardListExport(map);
        if(bytes!=null){
            String fileName = "卡操作记录表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @RequestMapping("/CardRevokeListExport")
    public void CardRevokeListExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.CardRevokeListExport(map);
        if(bytes!=null){
            String fileName = "卡注销记录表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @RequestMapping("/CardUpExport")
    @RequiresPermissions(value = {"ltetcup:export"})
    public void CardUpExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.CardUpExport(map);
        if(bytes!=null){
            String fileName = "卡挂起记录表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


   @RequestMapping(value="/pcBind",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> PcBindCard(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
       data.put("stationId", UserSessionUtil.getDotNo());
       data.put("operatorId",UserSessionUtil.getUserNo());
       //入口改为大写
       if( data.get("certificateNumber")!=null &&  !"".equals(data.get("certificateNumber")) ){
           data.put("certificateNumber",data.get("certificateNumber").toString().toUpperCase());
       }
        map = cardFeign.pcBind(data);

       //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
       loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡初始化绑定", data, map, request));

        return map;
    }

    @RequestMapping(value="/pcWrite0016",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> pcWrite0016(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        if( data.get("certificateNumber")!=null &&  !"".equals(data.get("certificateNumber")) ){
            data.put("certificateNumber",data.get("certificateNumber").toString().toUpperCase());
        }
        map = cardFeign.pcWrite0016(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "pc开卡写客户信息", data, map, request));

        return map;
    }

    @RequestMapping(value="/pcWrite0015",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> pcWrite0015(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        if( data.get("certificateNumber")!=null &&  !"".equals(data.get("certificateNumber")) ){
            data.put("certificateNumber",data.get("certificateNumber").toString().toUpperCase());
        }
        map = cardFeign.pcWrite0015(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "pc开卡写车辆信息", data, map, request));

        return map;
    }

    //pc开卡完成
    @RequestMapping(value="/pcFinish1516",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> pcFinish1516(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        data.put("channelNum", UserSessionUtil.getChannelNo());
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("operatorName",UserSessionUtil.getUserName());
        if( data.get("certificateNumber")!=null &&  !"".equals(data.get("certificateNumber")) ){
            data.put("certificateNumber",data.get("certificateNumber").toString().toUpperCase());
        }
        map = cardFeign.pcFinish1516(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "pc开卡完成", data, map, request));

        return map;
    }

    @RequestMapping(value="/renewCardCmd",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> renewCardCmd(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.renewCardCmd(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡续期获取指令", data, map, request));

        return map;
    }

    @RequestMapping(value="/hangCardCmd",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> hangCardCmd(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.hangCardCmd(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡挂起获取指令", data, map, request));

        return map;
    }

    @RequestMapping(value="/hangOffCardCmd",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> hangOffCardCmd(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.hangOffCardCmd(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡挂起解除获取指令", data, map, request));

        return map;
    }

    @RequestMapping(value="/reissueCardCmd0015",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> reissueCardCmd0015(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        if( data.get("certificateNumber")!=null &&  !"".equals(data.get("certificateNumber")) ){
            data.put("certificateNumber",data.get("certificateNumber").toString().toUpperCase());
        }
        map = cardFeign.reissueCardCmd0015(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "补卡写车辆信息指令", data, map, request));

        return map;
    }

    @RequestMapping(value="/reissueCardCmd0016",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> reissueCardCmd0016(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        if( data.get("certificateNumber")!=null &&  !"".equals(data.get("certificateNumber")) ){
            data.put("certificateNumber",data.get("certificateNumber").toString().toUpperCase());
        }
        map = cardFeign.reissueCardCmd0016(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "补卡写客户信息指令", data, map, request));

        return map;
    }

    @RequestMapping(value="/activeCardCmd",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> activeCardCmd(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.activeCardCmd(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "记账卡激活获取写钱指令", data, map, request));

        return map;
    }

    @RequestMapping(value="/activeCardTimeCmd",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> activeCardTimeCmd(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.activeCardTimeCmd(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "记账卡激活获取写时间指令", data, map, request));

        return map;
    }


    @RequestMapping(value="/HexToGbk",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> HexToGbk(@RequestBody Map<String, Object> data){

        int a = data.size();
        try {
            Map<String, Object> map = new HashMap<>();
            if (data.size() > 0) {
                for (String i : data.keySet()) {
                    if (data.get(i) != null) {
                        String j = null;
                        j = URLDecoder.decode((String) data.get(i));
                        j = CnCode.hexStringToString(j);
                        map.put(i,j.replaceAll(" ",""));
                    }
                }
            }
            return ReturnResult.successResult("转换成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return ReturnResult.error("转换失败");
        }

    }


    //传入卡号和随机数
    @RequestMapping(value="/ReWriteCard0015",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> ReWriteCard0015(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.ReWriteCard0015(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡片信息校正写车辆信息指令", data, map, request));

        return map;
    }

    //传入卡号和随机数
    @RequestMapping(value="/ReWriteCard0016",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> ReWriteCard0016(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.ReWriteCard0016(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡片信息校正写客户信息指令", data, map, request));

        return map;
    }

    @RequestMapping(value = "/getCardBind", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCardBind(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.getCardBind(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "查看车卡绑定记录", data, map, request));

        return map;
    }

    @RequestMapping(value = "/writeDeviceLog", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String,Object> writeDeviceLog(@RequestBody Map<String, Object> data){
        data.put("stationId",UserSessionUtil.getDotNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        return  ReturnResult.success(String.valueOf(cardFeign.writeDeviceLog(data)));
    }

    @RequestMapping(value = "/queryForKaika", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> queryForKaika(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForKaika(data);
        return map;
    }

    @RequestMapping(value = "/queryForGuashi", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> queryForGuashi(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForGuashi(data);
        return map;
    }

    @RequestMapping(value = "/queryForAllByCardId", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> queryForAllByCardId(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForAllByCardId(data);
        return map;
    }

    @RequestMapping(value = "/queryForNoCar", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> queryForNoCar(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForNoCar(data);
        return map;
    }


    @RequestMapping(value = "/queryForNoSingleCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> queryForNoSingleCard(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForNoSingleCard(data);
        return map;
    }

    @RequestMapping(value = "/upgrade", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> upgrade(@RequestBody Map<String, Object> data,HttpServletRequest request){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.upgrade(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡片升级", data, map, request));

        return map;
    }

}
