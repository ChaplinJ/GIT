package com.owinfo.web.controller;

import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.CardFeign;
import com.owinfo.web.service.LoggerService;
import com.owinfo.web.service.RedisService;
import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@RestController
@RequestMapping("/cardService")
public class EtcCardServiceBiz {

    @Autowired
    private BizFeign bizFeign;

    @Autowired
    private LoggerService loggerService;

    @Autowired
    private CardFeign cardFeign;

    @Autowired
    private RedisService redisService;

    // 发行方渠道类型默认为 1
    private static final String CHANNEL_TYPE = "1";

    private static final Logger logger = Logger.getLogger(EtcCardServiceBiz.class);


    //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字

    @RequiresPermissions(value = {"card:add"}, logical = Logical.OR)
    @RequestMapping(value = "/initCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> insertCard(@RequestBody Map<String, Object> data) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("afterToSite",UserSessionUtil.getDotNo());
        map = bizFeign.insertCard(data);
        return map;
    }

    @RequiresPermissions(value = {"cardlost:add"}, logical = Logical.OR)
    @RequestMapping(value = "/loseCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> loseCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.loseCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡挂失", data, map, request));

        return map;
    }
    @RequiresPermissions(value = {"cardsolution:add"}, logical = Logical.OR)
    @RequestMapping(value = "/loseReleaseCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> loseReleaseCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.loseReleaseCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡挂失解除", data, map, request));

        return map;
    }

    @RequiresPermissions(value = {"cardreplace:add"}, logical = Logical.OR)
    @RequestMapping(value = "/reissueCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> reissueCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();

        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("operatorName",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
//
        // region 生成交易流水号等信息
        String acquirerNo = "4101018802401050635";
        String siteName = "经三路网点";
        String employeeNo = "00000000";
        String createByName = "00000000";
        String channelType = "0";
        String channelNum = "00000000";
        String channelNumBYXX = "00000000";
        String channelName = "00000000";
        try {
            acquirerNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
            siteName = UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName();
            employeeNo = UserSessionUtil.getUserNo() == null ? "00000000" : UserSessionUtil.getUserNo();
            createByName = UserSessionUtil.getUserName() == null ? "00000000" : UserSessionUtil.getUserName();
            channelType = UserSessionUtil.getChannelType() == null ? "0" : UserSessionUtil.getChannelType();
            channelNum = UserSessionUtil.getDotNo() == null ? "00000000" : UserSessionUtil.getDotNo();
            channelNumBYXX = UserSessionUtil.getChannelNo() == null ? "00000000" : UserSessionUtil.getChannelNo();
            channelName = UserSessionUtil.getChannelName() == null ? "00000000" : UserSessionUtil.getChannelName();
        } catch (Exception e) {
            logger.error("<==  获取渠道信息异常");
        }

        data.put("acquirerNo",acquirerNo);
        data.put("siteName",siteName);
        data.put("employeeNo",employeeNo);
        data.put("createByName",createByName);
        data.put("channelType",channelType);
        data.put("channelNum",channelNum);
        data.put("channelName",channelName);
        data.put("channelNumBYXX",channelNumBYXX);

        LocalDateTime localDateTime = LocalDateTime.now();

        // region 交易流水号
        String tradeNumber = getTradeNumber(channelNum,localDateTime);
        logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
        data.put("tradeNumber",tradeNumber);

        map = cardFeign.reissueCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "补卡", data, map, request));

        return map;
    }

    @RequestMapping(value = "/reissueOilCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> reissueOilCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();

        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("operatorName",UserSessionUtil.getUserName());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
//
        // region 生成交易流水号等信息
        String acquirerNo = "4101018802401050635";
        String siteName = "经三路网点";
        String employeeNo = "00000000";
        String createByName = "00000000";
        String channelType = "0";
        String channelNum = "00000000";
        String channelNumBYXX = "00000000";
        String channelName = "00000000";
        try {
            acquirerNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
            siteName = UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName();
            employeeNo = UserSessionUtil.getUserNo() == null ? "00000000" : UserSessionUtil.getUserNo();
            createByName = UserSessionUtil.getUserName() == null ? "00000000" : UserSessionUtil.getUserName();
            channelType = UserSessionUtil.getChannelType() == null ? "0" : UserSessionUtil.getChannelType();
            channelNum = UserSessionUtil.getDotNo() == null ? "00000000" : UserSessionUtil.getDotNo();
            channelNumBYXX = UserSessionUtil.getChannelNo() == null ? "00000000" : UserSessionUtil.getChannelNo();
            channelName = UserSessionUtil.getChannelName() == null ? "00000000" : UserSessionUtil.getChannelName();
        } catch (Exception e) {
            logger.error("<==  获取渠道信息异常");
        }

        data.put("acquirerNo",acquirerNo);
        data.put("siteName",siteName);
        data.put("employeeNo",employeeNo);
        data.put("createByName",createByName);
        data.put("channelType",channelType);
        data.put("channelNum",channelNum);
        data.put("channelNumBYXX",channelNumBYXX);
        data.put("channelName",channelName);

        LocalDateTime localDateTime = LocalDateTime.now();

        // region 交易流水号
        String tradeNumber = getTradeNumber(channelNum,localDateTime);
        logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
        data.put("tradeNumber",tradeNumber);

        map = cardFeign.reissueOilCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "更换联名卡", data, map, request));
        return map;
    }

    @RequiresPermissions(value = {"cardextend:add"}, logical = Logical.OR)
    @RequestMapping(value = "/renewCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> renewCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.renewCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡续期", data, map, request));

        return map;
    }

    @RequiresPermissions(value = {"cardhangup:add"}, logical = Logical.OR)
    @RequestMapping(value = "/hangCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> hangCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.hangCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡挂起", data, map, request));
        return map;
    }

    @RequiresPermissions(value = {"cardhangoff:add"}, logical = Logical.OR)
    @RequestMapping(value = "/hangReleaseCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> hangReleaseCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.hangReleaseCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡挂起解除", data, map, request));

        return map;
    }

    @RequiresPermissions(value = {"cardwithdraw:add"}, logical = Logical.OR)
    @RequestMapping(value = "/logOffCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> logOffCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("channelNum", UserSessionUtil.getChannelNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());

        map = cardFeign.logOffCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡注销", data, map, request));
        return map;
    }


    @RequiresPermissions(value = {"cardbreakdown:add"}, logical = Logical.OR)
    @RequestMapping(value = "/breakCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> breakCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.breakCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡损坏", data, map, request));

        return map;
    }


    @RequiresPermissions(value = {"cardchangpwd:update"}, logical = Logical.OR)
    @RequestMapping(value = "/changePass", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> changePass(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.changePass(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "修改卡密码", data, map, request));
        return map;
    }

    @RequiresPermissions(value = {"debitactivate:add"}, logical = Logical.OR)
    @RequestMapping(value = "/activeCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> activeCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        data.put("stationId", UserSessionUtil.getDotNo());
        data.put("operatorId",UserSessionUtil.getUserNo());
        data.put("createBy",UserSessionUtil.getUserNo());
        data.put("updateBy",UserSessionUtil.getUserNo());
        map = bizFeign.activeCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "记账卡激活", data, map, request));
        return map;
    }



    @RequestMapping(value = "/seeCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> seeCard(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        map = bizFeign.seeCard(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "卡片信息查看", data, map, request));
        return map;
    }


    @RequiresPermissions(value = {"ltetcup:list"}, logical = Logical.OR)
    @RequestMapping(value = "/gethangCardLog", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> gethangCardLog(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        map = bizFeign.gethangCardLog(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "查看卡挂起操作记录", data, map, request));

        return map;
    }


    @RequestMapping(value = "/gethangRCardLog", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> gethangRCardLog(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        map = bizFeign.gethangRCardLog(data);

        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "查看卡挂起解除记录", data, map, request));

        return map;
    }

    @RequestMapping(value = "/getCardLog", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCardLog(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        map = bizFeign.getCardLog(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "查看卡操作记录", data, map, request));
        return map;
    }


    @RequestMapping(value = "/queryForReplace", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> queryForReplace(@RequestBody Map<String, Object> data,HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForReplace(data);
        //0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "查看补换卡明细记录", data, map, request));
        return map;
    }


    @RequestMapping(value = "/getUserByCard", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> getUserByCard(@RequestBody Map<String, Object> data) {
        Map<String,Object> map = new HashMap<>();
        map = bizFeign.getUserByCard(data);
        return map;
    }

    @RequestMapping(value = "/getCardDetail", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCardDetail(@RequestBody Map<String, Object> data) {
        Map<String,Object> map = new HashMap<>();
        map = bizFeign.getCardDetail(data);
        return map;
    }

    @RequestMapping(value="/readDeviceLog",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String,Object> readDeviceLog(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.readDeviceLog(data);
        return map;
    }

    @RequestMapping(value="/queryForRevoke",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String,Object> queryForRevoke(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.queryForRevoke(data);
        return map;
    }

    @RequestMapping(value="/updateRevokebackInfo",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String,Object> updateRevokebackInfo(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.updateRevokebackInfo(data);
        return map;
    }

    @RequestMapping(value="/updateRevokeStatus",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String,Object> updateRevokeStatus(@RequestBody Map<String, Object> data){
        Map<String,Object> map = new HashMap<>();
        map = cardFeign.updateRevokeStatus(data);
        return map;
    }


    /************************************ 获取交易流水号、Token ******************************************************************/

    /**
     * @description 获取交易流水号
     * @author hekunlin 2018/1/23 17:08 Version 1.2
     * @param
     * @return
     */
    public String getTradeNumber(String channelNum,LocalDateTime local){
        LocalDateTime localDateTime = local.now();
        String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        Long incr = redisService.getIncr(formatDate,60L);
        String tradeNum = "";
        if (incr < 99){
            tradeNum = String.format("%02d", incr);
        }
        if (incr > 99){
            localDateTime = localDateTime.plusSeconds(1);
            formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            incr = redisService.getIncr(formatDate,60L);
            tradeNum = String.format("%02d", incr);
        }
        String tradeNumber = CHANNEL_TYPE + channelNum + formatDate + tradeNum;
        return tradeNumber;
    }

}
