package com.owinfo.web.controller;

import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.*;
import com.owinfo.web.util.FileUtil;
import com.owinfo.web.util.ParamClassUtils;
import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by weich on 2017/10/31.
 */
@RestController
@RequestMapping("/closeOutService")
public class EtcCloseOutService {
    @Autowired
    private CloseOutFeign closeOutFeign;
    @Autowired
    private LoggerService loggerService;
    @Autowired
    private AccountFeign accountFeign;
    @Autowired
    private RedisService redisService;
    @Autowired
    private OtherFeign otherFeign;
    @Autowired
    private CardFeign cardFeign;

    private static final Logger logger = Logger.getLogger(EtcCloseOutService.class);

    /**
     * 发行方渠道类型默认为 1
     */
    private static final String CHANNEL_TYPE = "1";

    //清账、清户查询  flag=1:清账 cStartTime cEndTime flag=2:清户 startTime endTime
    @PostMapping("/selectSelective")
    @RequiresPermissions(value = {"ltclearaccount:list", "ltclearcustomer:list"}, logical = Logical.OR)
    public Map<String, Object> selectSelective(@RequestBody Map<String, Object> map){
        Map<String, Object> map1 = closeOutFeign.selectSelective(map);
        return map1;
    }
    //清账、清户确认 flag=1:清账  flag=2:清户
    @PostMapping("/update")
    @RequiresPermissions(value = {"ltclearaccount:updateList", "ltclearaccount:update", "ltclearcustomer:clean", "ltclearcustomer:batch"}, logical = Logical.OR)
    public Map<String, Object> update(@RequestBody Map<String, Object> params, HttpServletRequest request){
        /**
         * 日期 清账时间
         */
        LocalDateTime localDateTime = LocalDateTime.now();
        String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String formatTime = "";
        if("2".equals(params.get("flag").toString())){
            LocalDateTime localTime = LocalDateTime.now();
            formatTime = localTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        }
        /**
         * 获取网点信息 网点编号 网点名称 操作员工号 操作员姓名
         */
        params.put("acquirerNo",UserSessionUtil.getDotNo());
        params.put("siteName",UserSessionUtil.getUserDotName());
        params.put("employeeNo",UserSessionUtil.getUserNo());
        params.put("createBy",UserSessionUtil.getUserName());
        params.put("operatorName",UserSessionUtil.getUserName());

        /**
         * 将渠道数据存入：渠道类型、渠道编号(合作机构编号)、渠道名称
         */
        params.put("channelType",ParamClassUtils.getParams(UserSessionUtil.getChannelType()));
        params.put("channelNum",ParamClassUtils.getParams(UserSessionUtil.getChannelNo()));
        params.put("channelName",ParamClassUtils.getParams(UserSessionUtil.getChannelName()));

        /**
         * 从redis获取流水号
         */
        // 渠道编号，本系统中实际上是站点编号
        String channelNum = ParamClassUtils.getParams(UserSessionUtil.getDotNo());
        // 流水号
        Long incr = 0L;
        if("2".equals(params.get("flag").toString())){
            incr = redisService.getIncr(formatTime,60L);
        }else{
            incr = redisService.getIncr(formatDate,60L);
        }
        String tradeNum = "";
        if (incr < 99){
            tradeNum = String.format("%02d", incr);
        }
        if (incr > 99){
            localDateTime = localDateTime.plusSeconds(1);
            formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            incr = redisService.getIncr(formatDate,60L);
            tradeNum = String.format("%02d", incr);
        }
        String tradeNumber = CHANNEL_TYPE + channelNum + formatDate + tradeNum;
        logger.info("<==  当前交易流水号 tradeNum=" + tradeNum);
        params.put("tradeNum",tradeNumber);
        Map<String, Object> update = closeOutFeign.update(params);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "清账或清户", params, update, request));
        return update;
    }

    //退卡补款--查询
    @RequiresPermissions(value = {"ltcleartuibu:list"})
    @PostMapping("/cardFillMoney/cardFillMoney")
    public Map<String, Object> cardFillMoney(@RequestBody Map<String, Object> param){
        Map<String, Object> map = closeOutFeign.findCardFillMoney(param);
        return map;
    }
    /**退卡补款--通过
     * 新卡卡号:newCardId
     * ETC卡号:cardId
     * 补款金额:fillAmount
     * 旧卡钱包金额:cardBalance
     * 新卡卡账户余额:cardAccountBalance
     * */
    @RequiresPermissions(value = {"ltcleartuibu:agree"})
    @PostMapping("/cardFillMoney/agree")
    public Map<String, Object> agree(@RequestBody Map<String, Object> params, HttpServletRequest request){
        /**
         * 日期
         */
        LocalDateTime localDateTime = LocalDateTime.now();
        String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        /**
         * 获取网点信息 网点编号 网点名称 操作员工号 操作员姓名
         */
        params.put("acquirerNo",UserSessionUtil.getDotNo());
        params.put("siteName",UserSessionUtil.getUserDotName());
        params.put("employeeNo",UserSessionUtil.getUserNo());
        params.put("createBy",UserSessionUtil.getUserName());
        params.put("operatorName",UserSessionUtil.getUserName());
        /**
         * 将渠道数据存入：渠道类型、渠道编号(合作机构编号)、渠道名称
         */
        params.put("channelType",ParamClassUtils.getParams(UserSessionUtil.getChannelType()));
        params.put("channelNum",ParamClassUtils.getParams(UserSessionUtil.getChannelNo()));
        params.put("channelName",ParamClassUtils.getParams(UserSessionUtil.getChannelName()));

        /**
         * 从redis获取流水号
         */
        // 渠道编号，本系统中实际上是站点编号
        String channelNum = ParamClassUtils.getParams(UserSessionUtil.getDotNo());
        // 流水号
        Long incr = redisService.getIncr(formatDate,60L);
        String tradeNum = "";
        if (incr < 99){
            tradeNum = String.format("%02d", incr);
        }
        if (incr > 99){
            localDateTime = localDateTime.plusSeconds(1);
            formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            incr = redisService.getIncr(formatDate,60L);
            tradeNum = String.format("%02d", incr);
        }
        String tradeNumber = CHANNEL_TYPE + channelNum + formatDate + tradeNum;
        logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
        params.put("tradeNum",tradeNumber);
        Map<String, Object> map = closeOutFeign.agree(params);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "修改一条退卡补款信息", params, map, request));
        return map;
    }

    /**
     * 清账、清户数据导出
     * @param param
     * @param response
     */
    @RequiresPermissions(value = {"ltclearcustomer:export", "ltclearcustomer:export"}, logical = Logical.OR)
    @RequestMapping(value = "/cleanAccountExport")
    public void cleanAccountExport(@RequestParam Map<String, Object> param, HttpServletResponse response){
        String fileName = "";
        FileUtil fileUtil = new FileUtil();
        byte[] bytes = {};
        if("1".equals(param.get("flag").toString())){
            bytes = accountFeign.closeoutExport(param);
            fileName = "清账列表";
        }else if("2".equals(param.get("flag").toString())){
            fileName = "清户列表";
            bytes = accountFeign.cleanAccountExport(param);
        }
        if(bytes!=null){
            try {
                fileUtil.fileOutput(response,fileName,bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*************************************************************************************************/
    /**
     * 清户表查询（单条）
     */
    @RequiresPermissions(value = {"ltclearcustomer:query"})
    @RequestMapping(value = "/findByCertificateNumber", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findByCertificateNumber(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findByCertificateNumber(param);
        return resultMap;
    }

    /**
     * 清户数据查询（列表）
     *
     * @param param
     * @return
     */
    @RequiresPermissions(value = {"ltclearcustomer:list"})
    @RequestMapping(value = "/findCleanAccountList", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> findCleanAccountList(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.findCleanAccountList(param);
        return resultMap;
    }

    /**
     * 修改清户数据
     */
    @ResponseBody
    @RequestMapping(value = "/updateCleanAccount", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> updateCleanAccount(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = accountFeign.updateCleanAccount(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "清户数据修改", param, resultMap, request));
        return resultMap;
    }

    /**
     * 清户
     */
    @RequiresPermissions(value = {"ltclearcustomer:clean"})
    @RequestMapping(value = "/cleanAccount", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> cleanAccount(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = closeOutFeign.cleanAccount(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "清户", param, resultMap, request));
        return resultMap;
    }

    /**
     * 清户批处理
     */
    @RequiresPermissions(value = {"ltclearcustomer:batch"})
    @RequestMapping(value = "/cleanAccountList", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> cleanAccountList(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = closeOutFeign.cleanAccountList(param);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "清户批处理", param, resultMap, request));
        return resultMap;
    }


    /**
     * 充正补款--查询  新增 ltpayforbu:add
     */
    @RequiresPermissions(value = {"ltpayforbu:list"})
    @RequestMapping(value = "/fullComplement", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> fullComplement(@RequestBody Map<String, Object> param) {
        return accountFeign.fullComplement(param);
    }

    /**
     * 充正补款--导出   新增 ltpayforbu:add
     */
    @RequiresPermissions(value = {"ltpayforbu:export"})
    @RequestMapping(value = "/fullComplExport")
    public void fullComplExport(@RequestParam Map<String, Object> param, HttpServletResponse response) {
        FileUtil fileUtil = new FileUtil();
        byte[] bytes = {};
        bytes = accountFeign.fullComplExport(param);
        String fileName = "充正补款列表";
        if(bytes!=null){
            try {
                fileUtil.fileOutput(response,fileName,bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 充正补款--新增--查询卡信息  导出 ltpayforbu:export  新增
     */
    @RequestMapping(value = "/getCardInfoToFull", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCardInfoToFull(@RequestBody Map<String, Object> param) {
        return cardFeign.getCard(param);
    }

    /**
     * 充正补款--新增  导出 ltpayforbu:export  新增
     * 卡号 cardId  卡内余额 cardBalance  卡账户余额 cardAccountBalance 补款金额(元) addMoney
     */
    @RequiresPermissions(value = {"ltpayforbu:add"})
    @RequestMapping(value = "/addFullComplement", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> addFullComplement(@RequestBody Map<String, Object> param, HttpServletRequest request) {
        return otherFeign.addFullComplement(param);
    }


}
