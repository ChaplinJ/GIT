package com.owinfo.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.AccountFeign;
import com.owinfo.web.service.CardFeign;
import com.owinfo.web.service.FinanceFeign;
import com.owinfo.web.service.RedisService;
import com.owinfo.web.util.*;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.*;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.*;

import static org.bouncycastle.asn1.ua.DSTU4145NamedCurves.params;

/**
* @description: 资金管理服务
* @author hekunlin on 2017/10/26 11:16
*/
@RestController
@CrossOrigin(maxAge = 3600,origins = "*")
@RequestMapping("/finance/back")
public class EtcFinance {

    private static final Logger logger = Logger.getLogger(EtcFinance.class);

    private static final String CHANNEL_TYPE = "1";

    @Autowired
    private FinanceFeign financeFeign;

    @Autowired
    private CardFeign cardFeign;

    @Autowired
    private AccountFeign accountFeign;

    @Autowired
    private RedisService redisService;

    /************************************************* 卡券管理 *********************************************************/

    /**
     * 验证卡券编号和密码
     * ticketNo password
     * @param params
     * @return
     */
    @PostMapping("/business/validateTicket")
    @RequiresPermissions(value = {"etab:checkTicket","accountrecharge:ticketQuery","cardrecharge:ticketQuery"},logical = Logical.OR)//注册电子标签时校验
    public Map<String,Object> validateTicket(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validateTicket的参数::" + params);
        return financeFeign.validateTicket(params);
    }

    /**
     * 获取卡券列表
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"ltcouponadmin:list"})
    @PostMapping("/business/getTicketList")
    Map<String,Object> getTicketList(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法getTicketList的参数::" + params);
        return financeFeign.getTicketList(params);
    }

    /**
     * 导入卡券，上传EXCEL方式
     * @param file
     * @return
     */
    @RequiresPermissions(value = {"ltcouponadmin:import"})
    @PostMapping("/business/uploadTickets")
    Map<String,Object> uploadTickets(@RequestParam(value = "file") MultipartFile file){
        logger.info(" --> 方法uploadTickets的参数::" + file.getOriginalFilename());
        logger.info(" <-- 上传Excel的大小 file=" + file.getSize());
        /**
         * 限制上传EXCEL文件大小
         * 接收传输的Excel文件
         */
        if (file.getSize() < 0 || file.getSize() > 1048576){
            logger.error(" <-- 上传EXCEL文件不可大于1M，请拆分后上传");
            return ReturnResult.error("在线上传EXCEL文件不可大于1M");
        }
        /**
         * 截取文件后缀
         */
        String fileType = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        logger.info(" <-- 文件名后缀=" + fileType);
        if (!fileType.equals(".xls")){
            logger.info(" <-- 不支持的文件格式,目前仅支持excel2003及以下");
            return ReturnResult.error("请使用系统提供的模板上传");
        }
        /**
         * 定义需要转换的Excel表头 数据库对应字段
         */
        Map<String,String> map = new HashMap<>(3);
        map.put("卡券编号","ticketNo");
        map.put("卡券名称","ticketName");
        map.put("卡券类型","ticketType");
        map.put("卡券面值","ticketFaceValue");
        map.put("卡券密码","password");
        map.put("录入人","inputPerson");
        map.put("创建人","createBy");
        /**
         * 新建一个Excel的导入类excelImport，日期格式化
         */
        ExcelImport excelImport = new ExcelImport(map);
        /**
         * 实例化一个List<T>来接收Excel的数据 T 实体类
         */
        List<TicketManageDTO> ticketManageDTOList = null;
        List<TicketManage> ticketManageList = new ArrayList<>();
        try {
            /**
             * 初始化文件流、文件名称
             * 读取文件流并绑定到实体类
             */
            excelImport.init(file.getInputStream(),file.getOriginalFilename());
            ticketManageDTOList = excelImport.bindToModels(TicketManageDTO.class,true);
        } catch (Exception e) {
            logger.error(" <-- 实例化Excel导入失败");
            return ReturnResult.error("导入Excel失败");
        }
        /**
         * 遍历ticketManageList补全剩余参数：id、saleStatus(0)、inputTime、createTime
         */
        logger.info(" <-- 开始补全参数");
        for (TicketManageDTO temp : ticketManageDTOList){
            TicketManage ticketManage = new TicketManage();
            /**
             * 补齐参数
             */
            ticketManage.setId(UUIDUtils.getUUID());
            ticketManage.setInputTime(new Date());
            ticketManage.setCreateTime(new Date());
            //
            /**
             * Excel参数验证非空校验
             */
            if (ValidateUtils.isEmptyTrim(temp.getCreateBy()) || ValidateUtils.isEmptyTrim(temp.getInputPerson())
                    || ValidateUtils.isEmptyTrim(temp.getPassword()) || ValidateUtils.isEmptyTrim(temp.getTicketName())
                    || ValidateUtils.isEmptyTrim(temp.getTicketNo()) || ValidateUtils.isEmptyTrim(temp.getTicketFaceValue())){
                logger.error(" <-- 请补全EXCEL所需的数据");
                return ReturnResult.error("表数据不全或存在空行,请检查");
            }
            ticketManage.setCreateBy(temp.getCreateBy());
            ticketManage.setInputPerson(temp.getInputPerson());
            ticketManage.setPassword(temp.getPassword());
            ticketManage.setTicketName(temp.getTicketName());
            ticketManage.setTicketNo(temp.getTicketNo());
            //ticketManage.setTicketType(temp.getTicketType());
            ticketManage.setRemove("0");
            ticketManage.setSaleStatus("0");
            ticketManage.setSaleMoney(0);
            /**
             * 判断是充值券还是设备券
             * 卡卷类型 1电子标签、2充值宝、3中原通卡、4充值卷、5加油卷
             */
            if ("电子标签".equals(temp.getTicketType())){
                ticketManage.setTicketType("1");
            } else if ("充值宝".equals(temp.getTicketType())){
                ticketManage.setTicketType("2");
            } else if ("中原通卡".equals(temp.getTicketType())){
                ticketManage.setTicketType("3");
            } else if ("充值卷".equals(temp.getTicketType())){
                ticketManage.setTicketType("4");
            } else if ("加油卷".equals(temp.getTicketType())){
                ticketManage.setTicketType("5");
            } else{
                logger.error(" <-- 没有这个卡券类型" + temp.getTicketType());
                return ReturnResult.error("请参照模板修改卡券类型");
            }
            /**
             * 卡券面值
             */
            String faceValue = temp.getTicketFaceValue();
            int ticketFaceValue = 0;
            if (faceValue.equals("赠送")){
                ticketFaceValue = 0;
            } else{
                ticketFaceValue = Integer.parseInt(faceValue);
            }
            ticketManage.setTicketFaceValue(ticketFaceValue*100);
            // 放入list中
            ticketManageList.add(ticketManage);
        }
        logger.info(" <-- 参数校验、Excel表数据转换为对象成功");
        /**
         * Excel文件验重
         */
        int countResult = 0;
        HashSet<String> set = new HashSet<>();
        logger.info(" <-- 开始验证Excel文件本身是否存在重复数据");
        for(TicketManage temp : ticketManageList) {
            countResult++;
            String ticketNo = temp.getTicketNo();
            // 如果能将数据放入则说明ticketNo不重复
            boolean flag = set.add(ticketNo);
            if (!flag) {
                logger.info(" <-- EXCEL文件中第 " + countResult + " 个卡券编号重复");
                return ReturnResult.error("EXCEL文件中第 " + countResult + " 个卡券编号重复");
            }
        }
        logger.info(" <-- 验证Excel自身文件通过,不存在重复数据");
        /**
         * 数据库验重
         * 初始化计数器
         */
        logger.info(" <-- 开始数据库验证Excel文件是否存在重复卡券编号");
        countResult = 0;
        for (TicketManage temp : ticketManageList){
            countResult++;
            String ticketNo = temp.getTicketNo();
            Map<String,Object> tempTicketMap = new HashMap<>(1);
            tempTicketMap.put("ticketNo",ticketNo);
            boolean validateResult = true;
            try {
                /**
                 * false: 不存在这个卡券，可以导入
                 */
                validateResult = financeFeign.validateExitTicket(tempTicketMap);
            } catch (Exception e) {
                logger.error(" <-- 验证失败,网络超时（熔断）,验证数据库是否存在重复卡券失败" + e.getMessage());
                return ReturnResult.error("验证失败,网络超时");
            }
            if (validateResult){
                logger.error("数据库已存在这个卡券编号(第" + countResult + "条): " + ticketNo);
                return ReturnResult.error("导入卡券失败，已存在卡券编号：" + ticketNo);
            }
//            logger.info("卡券 " +  ticketNo + " 允许导入");
        }
        logger.info(" <-- 数据库验重通过,不存在重复数据");
        /**
         * 调取接口导入ticketManageList所有数据
         */
        int count = 0;
        long startTime = System.currentTimeMillis();
        logger.info(" <-- 批量导入卡券开始 " + System.currentTimeMillis());
        try {
            count = financeFeign.addTicket(ticketManageList);
        } catch (Exception e) {
            logger.error(" <-- 导入失败,网络超时（熔断）,批量导入卡券失败" + e.getMessage());
            return ReturnResult.error("导入失败,网络超时");
        }
        long endTime = System.currentTimeMillis();
        logger.info(" <-- 批量导入卡券结束 " + System.currentTimeMillis());
        double custTime = endTime-startTime;
        logger.info(" <-- 批量导入 " + count + " 条卡券结束,共计耗时耗时 " + custTime + " 毫秒");
        if (count == 0){
            logger.error(" <-- 批量导入失败");
            return ReturnResult.error("批量导入失败");
        }
        logger.info(" <-- 批量导入成功,共计导入 "+ count + " 张卡券");
        return ReturnResult.success("批量导入成功,共计导入 "+ count +" 张卡券");
    }

    /**
     * 卡券模板下载
     * @param request
     * @param response
     * @return
     */
    @RequiresPermissions(value = {"ltcouponadmin:download"})
    @GetMapping("/downLoadExcelTemplate")
    public Map<String, Object> downLoadExcelTemplate(HttpServletRequest request, HttpServletResponse response){
        logger.info(" --> 方法downLoadExcelTemplate的参数::" + " 文件下载，无参数");
        OutputStream out = null;
        try {
            response.setHeader("Content-Disposition","attachment; filename="
                    + new String(("卡券上传模板").getBytes("gb2312"),"ISO-8859-1")+".xls");
            out = response.getOutputStream();
            // 调用写出流方法
            this.exportMatrixLeaderSheet(out);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            logger.error("==> Download Excel Failed,UnsupportedEncodingException");
            return ReturnResult.error("Download Excel Failed");
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("==> Download Excel Failed,IO Exception");
            return ReturnResult.error("Download Excel Failed");
        }
        // 关闭流
        try {
            out.close();
        } catch (IOException e){
            e.printStackTrace();
            logger.error("==> Download Excel Failed,IO Exception");
            return ReturnResult.error("Download Excel Failed");
        }
        // 写出成功
        logger.info("==> Download Excel Success");
        return ReturnResult.success("Download Excel Success");
    }

    /**
     * 导出Excel模板写出流
     * @param out
     */
    public void exportMatrixLeaderSheet(OutputStream out){
        HSSFWorkbook workbook = new HSSFWorkbook(); // 声明一个工作薄
        HSSFSheet sheet = workbook.createSheet("卡券上传模板");  // 生成一个表格
        HSSFCellStyle cStyle = workbook.createCellStyle(); // 创建一个格式
        sheet.setDefaultColumnWidth(20);// 设置表格默认列宽度为20个字节

        // 第一行头
        HSSFRow row = sheet.createRow(0); // 创建单元格行
        row.setHeight((short)(17*20)); // 设置单元格高度
        HSSFCell cell = row.createCell(0);
        cell.setCellStyle(cStyle);
        cell.setCellValue("卡券编号");

        cell = row.createCell(1);
        cell.setCellStyle(cStyle);
        cell.setCellValue("卡券名称");

        cell = row.createCell(2);
        cell.setCellStyle(cStyle);
        cell.setCellValue("卡券类型");

        cell = row.createCell(3);
        cell.setCellStyle(cStyle);
        cell.setCellValue("卡券面值");

        cell = row.createCell(4);
        cell.setCellStyle(cStyle);
        cell.setCellValue("卡券密码");

        cell = row.createCell(5);
        cell.setCellStyle(cStyle);
        cell.setCellValue("录入人");

        cell = row.createCell(6);
        cell.setCellStyle(cStyle);
        cell.setCellValue("创建人");

        // 第二行数据示例
        HSSFRow rows = sheet.createRow(1); // 创建单元格行
        row.setHeight((short)(17*20)); // 设置单元格高度
        HSSFCell cells = rows.createCell(0);
        cells.setCellStyle(cStyle);
        cells.setCellValue("200710110001");

        cells = rows.createCell(1);
        cells.setCellStyle(cStyle);
        cells.setCellValue("充值券-XXX/设备券-XXX");

        cells = rows.createCell(2);
        cells.setCellStyle(cStyle);
        cells.setCellValue("中原通卡/电子标签/充值卷/充值宝/加油卷");

        cells = rows.createCell(3);
        cells.setCellStyle(cStyle);
        cells.setCellValue("298.00");

        cells = rows.createCell(4);
        cells.setCellStyle(cStyle);
        cells.setCellValue("123456");

        cells = rows.createCell(5);
        cells.setCellStyle(cStyle);
        cells.setCellValue("张三");

        cells = rows.createCell(6);
        cells.setCellStyle(cStyle);
        cells.setCellValue("李四");

        HSSFCellStyle style = workbook.createCellStyle();
        style.setWrapText(true);
        try {
            workbook.write(out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 变更卡券状态
     * @param params
     * @return
     */
    @PostMapping("/business/changeTicketStatus")
    Map<String,Object> changeTicketStatus(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法changeTicketStatus的参数::" + params);
        params.put("startPerson",ParamClassUtils.getParams(UserSessionUtil.getUserName()));
        //params.put("startPerson","小张");
        return financeFeign.changeTicketStatus(params);
    }

    /************************************************* 电商/订单管理 *****************************************************/

    /**
     * 验证订单单号--充值时需要用
     * @param params
     * @return
     */
    @PostMapping("/order/validateOrderNo")
    @RequiresPermissions(value = {"etab:checkOrder","accountrecharge:orderQuery","cardrecharge:orderQuery"},logical = Logical.OR)//注册电子标签时校验
    public Map<String,Object> validateOrderNo(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validateOrderNo的参数::" + params);
        return financeFeign.validateOrderNo(params);
    }

    @PostMapping("/order/updateOrder")
    Map<String, Object> updateOrder(@RequestBody Map<String,Object> params) {
        logger.info(" --> 方法updateOrder的参数::" + params);
        return financeFeign.updateOrder(params);
    }

    /**
     * 校验随机码
     * @param params
     * @return
     */
    @PostMapping("/transfer/validateRandom")
    @RequiresPermissions(value = {"etab:checkTransfer","accountrecharge:transferQuery"},logical = Logical.OR)//注册电子标签时校验
    public Map<String,Object> validateRandom(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validateRandom的参数::" + params);
        return financeFeign.validateRandom(params);
    }

    /**
     * 获取订单数据
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"ltbusinadmin:list"})
    @PostMapping("/order/getOrderList")
    Map<String,Object> getOrderList(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法getOrderList的参数::" + params);
        return financeFeign.getOrderList(params);
    }

    /**
     * 新增订单
     * @param params
     * @returns
     */
    @RequiresPermissions(value = {"ltbusinadmin:import"})
    @PostMapping("/order/addOrder")
    Map<String,Object> addOrder(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法addOrder的参数::" + params);
        return financeFeign.addOrder(params);
    }

    /**
     * 批量删除订单
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"ltbusinadmin:delete"})
    @PostMapping(value = "/order/deleteOrders")
    Map<String,Object>  deleteOrders(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法deleteOrders的参数::" + params);
        return financeFeign.deleteOrders(params);
    }

    /************************************************* 转账管理 *********************************************************/

    /**
     * 获取转账数据列表
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"ltrechargeadmin:list"})
    @PostMapping("/transfer/getTransferList")
    Map<String,Object> getTransferList(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法getTransferList的参数::" + params);
        return financeFeign.getTransferList(params);
    }

    /**
     * 录入转账
     * @param transferAccountManageDto
     * @return
     */
    @RequiresPermissions(value = {"ltrechargeadmin:import"})
    @PostMapping("/transfer/addTransfer")
    Map<String,Object> addTransfer(@RequestBody TransferAccountManageDto transferAccountManageDto){
        logger.info(" --> 方法addTransfer的参数::" + transferAccountManageDto);
        return financeFeign.addTransfer(transferAccountManageDto);
    }

    /**
     * 修改转账
     * @param transferAccountManageDto
     * @return
     */
    @RequiresPermissions(value = {"ltrechargeadmin:import"})
    @PostMapping("/transfer/updateTransfer")
    Map<String,Object> updateTransfer(@RequestBody TransferAccountManageDto transferAccountManageDto){
        logger.info(" --> 方法addTransfer的参数::" + transferAccountManageDto);
        return financeFeign.updateTransfer(transferAccountManageDto);
    }

    /**
     * 批量删除转账
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"ltrechargeadmin:delete"})
    @PostMapping("/transfer/deleteTransfers")
    Map<String,Object>  deleteTransfers(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法deleteTransfers的参数::" + params);
        return financeFeign.deleteTransfers(params);
    }


    /************************************************* 补交收款 *********************************************************/

    @GetMapping("/payBack/payBackInfo")
    /**
    * @description 补交收款新增第一步：根据ETC卡号查询相关信息
    * @author hekunlin 2018/1/3 20:46 Version 1.0
    * @param [params]
    * @return java.util.Map<java.lang.String,java.lang.Object>
    */
    public Map<String,Object> payBackInfo(@RequestParam(value = "cardId") String cardId){
        logger.info("<==  方法payBackInfo的参数::" + params + "   开始执行");

        if (StringUtils.isEmpty(cardId)){
            logger.error("<== 卡号为空,无法新增补交收款记录");
            return ReturnResult.error("卡号为空,无法新增补交收款记录");
        }

        Map<String, Object> cardMap = new HashMap<>();
        Map<String, Object> userMap = new HashMap<>();
        Map<String, Object> vehicleMap = new HashMap<>();
        Map<String, Object> payBackMap = new HashMap<>();

        Map<String, Object> tempMap = new HashMap<>();

        // 获取卡信息
        tempMap.put("cardId",cardId);
        try {
            cardMap = cardFeign.getCard(tempMap);
        } catch (Exception e) {
            logger.error("<== 获取卡信息异常");
            return ReturnResult.error("获取卡信息异常");
        }
        cardMap = (Map<String, Object>) cardMap.get("data");
        if (cardMap == null){
            logger.error("<== 未查到相应的卡信息");
            // 前台校验、此处不能改为返回status的状态码
            Map<String, Object> errorMap = new HashMap<>();
            errorMap.put("code",0);
            errorMap.put("msg","未查到相应的卡信息");
            return errorMap;
        }

        // 现在最准确的是根据spare去查询用户、卡信息
        String vehicleLicense = (String) cardMap.get("vehicleLicense");
        String spare = (String) cardMap.get("spare");
        tempMap.clear();

        // 获取用户信息
        tempMap.put("spare",spare);
        try {
            userMap = accountFeign.findByNumber(tempMap);
        } catch (Exception e) {
            logger.error("<== 获取用户信息异常");
            return ReturnResult.error("获取用户信息异常");
        }
        int userResult = 0;
        userResult = (int) userMap.get("status");
        if (userResult == 0){
            logger.error("<== 未查到相应的用户信息");
            return ReturnResult.error("未查到相应的用户信息");
        }
        userMap = (Map<String, Object>) userMap.get("data");

        tempMap.clear();
        tempMap.put("vehicleLicense",vehicleLicense);
        tempMap.put("vehicleColor",ParamClassUtils.getParams(cardMap.get("favorRate")));
        try {
            vehicleMap = accountFeign.findVehicleDetil(tempMap);
        } catch (Exception e) {
            logger.error("<== 获取车辆信息异常");
            return ReturnResult.error("获取车辆信息异常");
        }
        int vehicleResult = 0;
        vehicleResult = (int) vehicleMap.get("status");
        if (vehicleResult == 0){
            logger.error("<== 未查到相应的车辆信息");
            return ReturnResult.error("未查到相应的车辆信息");
        }
        vehicleMap = (Map<String, Object>) vehicleMap.get("data");

        // 车型
        String vehicleType = (String) vehicleMap.get("vehicleType");

        // 不同用户类型参数处理 ...
        payBackMap.put("cardId",cardId);
        int userStatus = Integer.valueOf((String) userMap.get("clientType"));
        if (userStatus == 1){
            payBackMap.put("clientName",userMap.get("clientName"));
            payBackMap.put("certificateNumber",userMap.get("certificateNumber"));
        }
        if (userStatus == 2){
            payBackMap.put("clientName",userMap.get("unitName"));
            payBackMap.put("certificateNumber",userMap.get("unitCertificateNo"));
        }
        payBackMap.put("clientNo",userMap.get("clientNo"));
        payBackMap.put("vehicleLicense",vehicleLicense);
        payBackMap.put("vehicleType",vehicleType);
        // 个人客户证件号
        String clientType = (String) userMap.get("clientType");
        String type = clientType.equals("1") ? "个人" : clientType.equals("2") ? "集团" : "未知";
        logger.info("<==  获取到的客户类型为 " + type + " ,证件号为 " + userMap.get("certificateNumber") + " 的相关信息 " + payBackMap);

        payBackMap.put("code",1);
        payBackMap.put("msg","检索客户信息成功");
        logger.info("<==  方法payBackInfo执行结束");
        return payBackMap;
    }


    @PostMapping("/payBack/addPayBack")
    /**
    * @description 补交收款新增第二部：确认新增一条补交收款记录
    * @author hekunlin 2018/1/3 20:45 Version 1.0
    * @param [params]
    * @return java.util.Map<java.lang.String,java.lang.Object>
    */
    public Map<String,Object> addPayBack(@RequestBody FrontPayBackVO frontPayBackVO){
        logger.info("<==  方法addPayBack的参数::" + frontPayBackVO + "   开始执行");

        // 将金额转换为分
        int money = (int) (frontPayBackVO.getPayMoney()*100);
        Integer payMoney = Integer.valueOf(money);

        FrontPayBack frontPayBack = new FrontPayBack();
        frontPayBack.setId(UUIDUtils.getUUID());
        frontPayBack.setCardId(frontPayBackVO.getCardId());
        frontPayBack.setCertificateNumber(frontPayBackVO.getCertificateNumber());
        frontPayBack.setClientName(frontPayBackVO.getClientName());
        frontPayBack.setClientNo(frontPayBackVO.getClientNo());
        frontPayBack.setCreateBy(UserSessionUtil.getUserName());
//        frontPayBack.setCreateBy("后台接口测试");
        frontPayBack.setCreateTime(new Date());
        frontPayBack.setPayMoney(payMoney);
        frontPayBack.setPayReason(frontPayBackVO.getPayReason());
        frontPayBack.setVehicleType(frontPayBackVO.getVehicleType());
        frontPayBack.setVehicleLicense(frontPayBackVO.getVehicleLicense());

        int result = 0;
        try {
            result = financeFeign.addPayBackRecord(frontPayBack);
        } catch (Exception e) {
            logger.error("<== 新增补交收款记录异常");
            return ReturnResult.error("新增补交收款记录异常");
        }
        if (result == 0){
            logger.error("<== 新增补交收款记录失败");
            return ReturnResult.error("新增补交收款记录失败");
        }

        logger.info("<==  方法addPayBack执行结束");
        return ReturnResult.success("新增补交收款记录成功");
    }


    @PostMapping("/payBack/payBackDetail")
    /**
     * 后台补交收款记录查询
     * @param params
     * @return
     */
    public Map<String,Object> payBackDetail(@RequestBody Map<String,Object> params){
        logger.info("<==  方法payBackDetail的参数::" + params + "   开始执行");

        Map<String, Object> payBackMap = new HashMap<>();

        int page = (int) params.get("page");
        int pageSize = (int) params.get("pageSize");

        PageHelper.startPage(page, pageSize);

        List<FrontPayBack> frontPayBackList = null;
        try {
            frontPayBackList = financeFeign.getPayBackList(params);
        } catch (Exception e) {
            logger.error("<== 获取补交收款列表异常");
            return ReturnResult.error("获取补交收款列表异常");
        }

        PageInfo<FrontPayBack> pageInfo = new PageInfo<FrontPayBack>(frontPayBackList);

        logger.info("<==  获取到的payBack对象数据为 " + pageInfo.getList().toString());

        payBackMap.put("code",1);
        payBackMap.put("msg","获取补交收款信息成功");
        payBackMap.put("frontPayBackList",pageInfo.getList());
        payBackMap.put("total",pageInfo.getTotal());

        logger.info("<==  方法payBackDetail执行结束");
        return payBackMap;
    }


    @PostMapping("/payBack/delPayBack")
    /**
    * @description 补交收款删除
    * @author hekunlin 2018/1/3 20:45 Version 1.0
    * @param [params]
    * @return java.util.Map<java.lang.String,java.lang.Object>
    */
    public Map<String,Object> delPayBack(@RequestBody Map<String,Object> params){
        logger.info("<==  方法delPayBack的参数::" + params + "   开始执行");

        ArrayList<String> ids = (ArrayList) params.get("ids");

        int result = 0;
        try {
            result = financeFeign.delPayBackRecord(ids);
        } catch (Exception e) {
            logger.error("<== 删除补交收款记录异常");
            return ReturnResult.error("删除补交收款记录异常");
        }

        if (result == 0){
            logger.error("<== 删除补交收款记录失败");
            return ReturnResult.error("删除补交收款记录失败");
        }
        logger.info("<==  删除 " + result + " 条记录 ： " + ids.toString());

        logger.info("<==  方法delPayBack执行结束");
        return ReturnResult.success("删除补交收款记录成功");
    }


    @PostMapping("/payBack/exportPayBack")
    /**
    * @description 补交收款导出
    * @author hekunlin 2018/1/3 20:45 Version 1.0
    * @param [params]
    * @return java.util.Map<java.lang.String,java.lang.Object>
    */
    public Map<String,Object> exportPayBack(@RequestBody Map<String,Object> params){
        logger.info("<==  方法exportPayBack的参数::" + params + "   开始执行");

        return null;
    }


    /************************************************* 交易管理查询 ******************************************************/

    /**
     * ETC卡资金流动查询（三合一查询）
     * @param params
     * @return
     */
    @PostMapping("/recharge/financeFlowSearch")
    @RequiresPermissions(value = {"ltetccashflow:list"})
    public Map<String,Object> financeFlowSearch(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法financeFlowSearch的参数::" + params);
        return financeFeign.financeFlowSearch(params);
    }

    /**
     * ETC资金流动查询（充圈转三合一查询） --  ETC资金流动页面
     * @param params
     * @return
     */
    @PostMapping("/recharge/etcFinanceFlowSearch")
    @RequiresPermissions(value = {"ltetccashflow:list"})
    public Map<String,Object> etcFinanceFlowSearch(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法etcFinanceFlowSearch的参数::" + params);
        return financeFeign.etcFinanceFlowSearch(params);
    }

    /**
     * 用户账户充值查询
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"ltusersrecharge:list"})
    @PostMapping("/recharge/userAccountRechargeSearch")
    public Map<String,Object> userAccountRechargeSearch(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法userAccountRechargeSearch的参数::" + params);
        return financeFeign.userAccountRechargeSearch(params);
    }

    /******************************************* 交易管理查询-导出ETC资金流动查询 *****************************************/

    /**
     * ETC卡资金流动查询导出（三合一查询）
     * @param params
     * @return
     */
    @RequestMapping("/recharge/exportUnitSearch")
    //@RequiresPermissions(value = {"ltetccashflow:list"})
    public void exportUnitSearch(@RequestParam Map<String,Object> params, HttpServletResponse response){
        logger.info(" --> 方法exportUnitSearch的参数::" + params);
        byte[] bytes = financeFeign.exportUnitSearch(params);
        if (bytes != null) {
            try {
                FileUtil.fileOutput(response, "ETC资金流动查询", bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
