package com.owinfo.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.*;
import com.owinfo.web.util.*;
import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.owinfo.web.util.ParamClassUtils.getParams;
import static org.bouncycastle.asn1.ua.DSTU4145NamedCurves.params;

/**
 * @description: 前台资金管理服务
 * @author hekunlin on 2017/10/26 11:16
 */
@RestController
@RequestMapping("/frontFinanceService")
@CrossOrigin(maxAge = 3600,origins = "*")
public class EtcFinanceBiz {
    
    private static final Logger logger = Logger.getLogger(EtcFinanceBiz.class);

    private static final String FIRST = "1";
    private static final String SECOND = "2";
    // 发行方渠道类型默认为 1
    private static final String CHANNEL_TYPE = "1";

    @Autowired
    private BizFeign bizFeign;

    @Autowired
    private CardFeign cardFeign;

    @Autowired
    private AccountFeign accountFeign;

    @Autowired
    private FinanceFeign financeFeign;

    @Autowired
    private RedisService redisService;

    @Autowired
    private LoggerService loggerService;

    /************************************ 用户账户充值 ******************************************************************/

    /**
    * @description 用户账户充值查询
    * @author hekunlin 2018/1/29 14:42 Version 1.2
    * @param
    * @return
    */
    @PostMapping("/userAccountRearch")
    public Map<String,Object> userAccountRearch(@RequestBody Map<String,Object> params){
        logger.info("<==  方法userAccountRearch的参数::" + params + "   开始执行");

        String certificateNumber = (String) params.get("certificateNumber");
        if (StringUtils.isEmpty(certificateNumber)){
            logger.error("<==  用户证件编号不能为空");
            return ReturnResult.error("用户证件编号不能为空");
        }

        logger.info("<==  方法userAccountRearch执行结束");
        return financeFeign.accountRearch(params);
    }

    /**
     * 用户账户充值
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"accountrecharge:add"})
    @PostMapping("/userAccountRecharge")
    public Map<String,Object> userAccountRecharge(@RequestBody Map<String,Object> params,HttpServletRequest request){
        logger.info("<==  方法userAccountRecharge的参数::" + params + "   开始执行");
        Map<String, Object> map = null;

        LocalDateTime localDateTime = LocalDateTime.now();
        String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        try {
            // 去掉map中的空值
            MapRemoveNullUtil.removeNullEntry(params);

            map = new HashMap<>();

            params.put("recoveryPerson", getParams(UserSessionUtil.getUserName()));
//            params.put("recoveryPerson", "hkl");

            // region 设置唯一token，防止重试、重复批量分配
            String token = (String) params.get("token");
            if (StringUtils.isEmpty(token)){
                logger.error("<==  本笔用户账户充值的token=[" + token + "]，未获取到用户账户充值唯一流水号");
                return ReturnResult.error("请查询重试，如无法充值请联系管理员");
            }
            String redisToken = null;
            try {
                // 获取token之后将其清除
                redisToken = (String) redisService.get(token);
                logger.info("<==  本笔用户账户充值唯一token[" + token + "]，内存中的redisToken[" + redisToken + "]");
                if (StringUtils.isEmpty(redisToken)){
                    logger.error("<==  本笔用户账户充值的token=[" + token + "]与缓存中获取的[" + redisToken + "]不一致，请重新查询后充值");
                    return ReturnResult.error("充值请求(有效期10分钟)已失效，请点击查询后重试");
                }
            } catch (Exception e) {
                logger.error("<==  从redis读取本次用户账户充值交易token[" + redisToken + "]异常");
                return ReturnResult.error("token验证异常，不允许充值");
            }
            params.put("transId",token);
            // endregion

            // region 渠道数据验证
            String dotNo = "4101018802401050635";
            try {
                dotNo = "4101018802401050635";
                dotNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                params.put("acquirerNo",UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo());
                params.put("siteName",UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName());
                params.put("employeeNo",UserSessionUtil.getUserNo());
                params.put("createBy",UserSessionUtil.getUserName());
                params.put("channelType", getParams(UserSessionUtil.getChannelType()));
                params.put("channelNum", getParams(UserSessionUtil.getChannelNo()));
                params.put("channelName", getParams(UserSessionUtil.getChannelName()));
//                params.put("acquirerNo","4101018802401050635");
//                params.put("siteName","经三路网点");
//                params.put("employeeNo","19950401");
//                params.put("createBy","0000");
//                params.put("channelType", "01");
//                params.put("channelNum", "4101018802401050635");
//                params.put("channelName", "0000");
                if (StringUtils.isEmpty(UserSessionUtil.getDotNo())){
                    logger.error("<==  获取渠道编号[" + UserSessionUtil.getDotNo() + "]失败，不允许充值");
                    return ReturnResult.errors("获取渠道编号失败，不允许充值");
                }
            } catch (Exception e) {
                logger.error("<==  获取渠道数据异常，不允许充值");
                return ReturnResult.errors("获取渠道数据异常，不允许充值");
            }
            // endregion

            // region 交易流水号
            String tradeNumber = getTradeNumber(dotNo,localDateTime);
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
            params.put("tradeNum",tradeNumber);
            // endregion

            // 执行充值
            map = financeFeign.userAccountRecharge(params);

            // 打日志
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方用户账户充值",params,map,request));
        } catch (Exception e) {
            logger.error("<==  充值异常，充值失败 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("充值失败");
        }
        logger.info(" --> 方法userAccountRecharge的参数::" + params);
        return map;
    }


    /************************************ 卡账户充值 ******************************************************************/

    /**
    * @description 卡充值查询
    * @author hekunlin 2018/1/26 18:15 Version 1.2
    * @param
    * @return
    */
    @RequiresPermissions(value = {"cardsolution:queryCard","cardreplace:query","cardreplace:queryCard","cardtransform:queryCard","cardtransform:addNewCard","cardextend:queryCard","cardhangup:queryCard","cardhangoff:queryCard","cardwithdraw:queryCard","cardbreakdown:query","debitactivate:queryCard","ltetcaccount:query","cardrecharge:query","deposit:query"}, logical = Logical.OR)
    @PostMapping("/getCardInfo")
    public Map<String, Object> getCardInfo(@RequestBody Map<String,Object> params){
        logger.info("<==  方法getCardInfo的参数::" + params + "   开始执行");

        String cardId = (String) params.get("cardId");
        if (StringUtils.isEmpty(cardId)){
            logger.error("<==  卡号不能为空");
            return ReturnResult.error("卡号不能为空");
        }

        logger.info("<==  方法getCardInfo执行结束");
        return financeFeign.getCardInfo(cardId);
    }

    /**
     * 卡账户充值
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"cardrecharge:add"})
    @PostMapping("/userCardRecharge")
    public Map<String,Object> userCardRecharge(@RequestBody Map<String,Object> params,HttpServletRequest request){
        logger.info("<==  方法userCardRecharge的参数::" + params + "   开始执行");
        Map<String, Object> map = null;
        try {
            // 去掉map中的空值
            MapRemoveNullUtil.removeNullEntry(params);

            map = new HashMap<>();
            String cardStatus = getParams(params.get("cardStatus"));
            if (!cardStatus.equals("600202101")){
                logger.error("<== 卡状态不正常，不允许充值");
                return ReturnResult.error("ETC卡状态不正常");
            }
            params.put("recoveryPerson", getParams(UserSessionUtil.getUserName()));
//            params.put("recoveryPerson", "hkl");

            // region 设置唯一token，防止重试、重复批量分配
            String token = (String) params.get("token");
            if (StringUtils.isEmpty(token)){
                logger.error("<==  本笔卡充值的token=[" + token + "]，未获取到卡充值唯一流水号");
                return ReturnResult.error("请查询重试，如无法充值请联系管理员");
            }
            String redisToken = null;
            try {
                // 获取token之后将其清除
                redisToken = (String) redisService.get(token);
                logger.info("<==  本笔卡充值唯一token[" + token + "]，内存中的redisToken[" + redisToken + "]");
                if (StringUtils.isEmpty(redisToken)){
                    logger.error("<==  本笔卡充值的token=[" + token + "]与缓存中获取的[" + redisToken + "]不一致，请重新查询后充值");
                    return ReturnResult.error("充值请求(有效期10分钟)已失效，请点击查询后重试");
                }
            } catch (Exception e) {
                logger.error("<==  从redis读取本次充值交易token[" + redisToken + "]异常");
                return ReturnResult.error("token验证异常，不允许充值");
            }
            params.put("transId",token);
            // endregion

            LocalDateTime localDateTime = LocalDateTime.now();
            String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

            // region 渠道数据验证
            String dotNo = "4101018802401050635";
            try {
                dotNo = "4101018802401050635";
                dotNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                params.put("acquirerNo",UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo());
                params.put("siteName",UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName());
                params.put("employeeNo",UserSessionUtil.getUserNo());
                params.put("createBy",UserSessionUtil.getUserName());
                params.put("channelType", getParams(UserSessionUtil.getChannelType()));
                params.put("channelNum", getParams(UserSessionUtil.getChannelNo()));
                params.put("channelName", getParams(UserSessionUtil.getChannelName()));
//                params.put("acquirerNo","4101018802401050635");
//                params.put("siteName","经三路网点");
//                params.put("employeeNo","19950401");
//                params.put("createBy","0000");
//                params.put("channelType", "01");
//                params.put("channelNum", "4101018802401050635");
//                params.put("channelName", "0000");
                if (StringUtils.isEmpty(UserSessionUtil.getDotNo())){
                    logger.error("<==  获取渠道编号[" + UserSessionUtil.getDotNo() + "]失败，不允许充值");
                    return ReturnResult.errors("获取渠道编号失败，不允许充值");
                }
            } catch (Exception e) {
                logger.error("<==  获取渠道数据异常，不允许充值");
                return ReturnResult.errors("获取渠道数据异常，不允许充值");
            }
            // endregion

            // region 交易流水号
            String tradeNumber = getTradeNumber(dotNo,localDateTime);
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);

             params.put("tradeNum",tradeNumber);
            // endregion

            // 执行充值
            map = financeFeign.cardRecharge(params);

            // 打日志
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方卡账户充值",params,map,request));
        } catch (Exception e) {
            logger.error("<==  充值异常，充值失败 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("充值失败");
        }
        logger.info(" --> 方法userCardRecharge的参数::" + params);
        return map;
    }


    /************************************ 冲正扣款 ******************************************************************/

    /**
     * 冲正扣款验证
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"dedutmoney:userQuery","dedutmoney:cardQuery"},logical = Logical.OR)
    @PostMapping("/validateCorrectDedution")
    Map<String,Object> validateCorrectDedution(@RequestBody Map<String,Object> params){
        // 网点名称
        params.put("siteName",UserSessionUtil.getUserDotName());
//        params.put("siteName","经三路网点");
        logger.info(" --> 方法validateCorrectDedution的参数::" + params);
        return financeFeign.validateCorrectDedution(params);
    }

    /**
     * 冲正
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"dedutmoney:add"})
    @PostMapping("/correctDeduction")
    public Map<String,Object> correctDeduction(@RequestBody Map<String,Object> params,HttpServletRequest request){
        logger.info("<==  方法correctDeduction的参数::" + params + "   开始执行");
        Map<String, Object> map = null;

        try {

            // 去掉map中的空值
            MapRemoveNullUtil.removeNullEntry(params);

            // region 渠道数据验证
            String dotNo = "4101018802401050635";
            try {
                dotNo = "4101018802401050635";
                dotNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                params.put("acquirerNo",UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo());
                params.put("siteName",UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName());
                params.put("employeeNo",UserSessionUtil.getUserNo());
                params.put("createBy",UserSessionUtil.getUserName());
                params.put("channelType", getParams(UserSessionUtil.getChannelType()));
                params.put("channelNum", getParams(UserSessionUtil.getChannelNo()));
                params.put("channelName", getParams(UserSessionUtil.getChannelName()));
//                params.put("acquirerNo","4101018802401050635");
//                params.put("siteName","经三路网点");
//                params.put("employeeNo","19950401");
//                params.put("createBy","0000");
//                params.put("channelType", "01");
//                params.put("channelNum", "4101018802401050635");
//                params.put("channelName", "0000");
                if (StringUtils.isEmpty(UserSessionUtil.getDotNo())){
                    logger.error("<==  获取渠道编号[" + UserSessionUtil.getDotNo() + "]失败，不允许充值");
                    return ReturnResult.errors("获取渠道编号失败，不允许充值");
                }
            } catch (Exception e) {
                logger.error("<==  获取渠道数据异常，不允许充值");
                return ReturnResult.errors("获取渠道数据异常，不允许充值");
            }
            // endregion

            // region 交易流水号
            String tradeNumber = getParams(params.get("tradeNum"));
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
            params.put("tradeNum",tradeNumber);
            // endregion

            map = financeFeign.correctDeduction(params);

            // 打日志
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方冲正",params,map,request));
        } catch (Exception e) {
            logger.error("<==  冲正异常，冲正失败 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("冲正失败");
        }
        logger.info(" --> 方法correctDeduction的参数::" + params);
        return map;
    }


    /************************************ 补交收款 ******************************************************************/

    @GetMapping("/payBackDetail")
    /**
     * @description 根据证件编号查询用户补交信息
     * @author hekunlin 2018/1/3 20:23 Version 1.2
     * @param [certificateNumber]
     * @return java.util.Map<java.lang.String,java.lang.Object>
     */
    public Map<String,Object> searchPayBack(@RequestParam(value = "certificateNumber",required = true) String certificateNumber,
                                            @RequestParam(value = "page",required = true) Integer page,
                                            @RequestParam(value = "pageSize",required = true) Integer pageSize){
        logger.info("<==  方法searchPayBack的参数::" + certificateNumber + "   开始执行");

        if (StringUtils.isEmpty(certificateNumber)){
            logger.error("<== 查询证件编号为空");
            return ReturnResult.error("查询证件编号为空");
        }

        Map<String, Object> userMap = new HashMap<>();
        Map<String, Object> payBackMap = new HashMap<>();
        List<FrontPayBack> frontPayBackList = new ArrayList<>();

        Map<String, Object> tempMap = new HashMap<>();
        tempMap.put("certificateNumber",certificateNumber);

        // 根据用户证件编号获取用户信息
        try {
            userMap = accountFeign.findByNumber(tempMap);
        } catch (Exception e) {
            logger.error("<== 获取用户信息异常");
            return ReturnResult.error("获取用户信息异常");
        }
        int results = (int) userMap.get("status");
        if (results != 1){
            logger.error(" <-- 未查到这个用户");
            return ReturnResult.error("未找到该用户");
        }
        userMap = (Map<String, Object>) userMap.get("data");
        logger.info("<==  获取到的用户信息 " + userMap);

        PageHelper.startPage(page,pageSize);
        PageInfo<FrontPayBack> pageInfo = null;
        try {
            frontPayBackList = financeFeign.getPayBackList(tempMap);
            pageInfo = new PageInfo<>(frontPayBackList);
        } catch (Exception e) {
            logger.error("<== 获取待补交列表数据异常");
            return ReturnResult.error("获取待补交列表数据异常");
        }
        logger.info("<==  获取到的待补交数据 " + frontPayBackList);

        payBackMap.put("code",1);
        payBackMap.put("total",pageInfo.getTotal());
        payBackMap.put("msg","获取待补交列表数据成功");
        payBackMap.put("frontPayBackList",pageInfo.getList());
        payBackMap.put("userDetail",userMap);

        logger.info("<==  方法searchPayBack执行结束");
        return payBackMap;
    }

    @PostMapping("/payBack")
    /**
     * 补交收款
     * @param params
     * @return
     */
    public Map<String,Object> payBack(@RequestBody PayBackVO payBackVO){
        logger.info(" --> 方法payBack的参数::" + params);

        LocalDateTime localDateTime = LocalDateTime.now();
        String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        // 前台办理业务时才会有获取交易流水号、以及新增渠道信息
//        String channelNum = "4101018802401050635";
        String channelNum = getParams(UserSessionUtil.getDotNo()) == null ? "4101018802401050635" :
                getParams(UserSessionUtil.getDotNo());
        if (StringUtils.isEmpty(channelNum)){
            logger.error("<== 站点编号为空，不允许补交");
            Map<String, Object> tempMap = new HashMap<>();
            tempMap.put("status",0);
            tempMap.put("msg","未正确获取到站点编号，不允许补交");
            return tempMap;
        }
//        String channelNum = "4101010200101010024";
        // 流水号
        Long incr = redisService.getIncr(formatDate,60L);
        String tradeNum = "";
        if (incr < 99){
            tradeNum = String.format("%02d", incr);
        }
        if (incr > 99){
            localDateTime = localDateTime.plusSeconds(1);
            formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            incr = redisService.getIncr(formatDate,60L);
            tradeNum = String.format("%02d", incr);
        }
        String tradeNumber = CHANNEL_TYPE + channelNum + formatDate + tradeNum;
        logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);

        // 金额处理
        int money = (int) (payBackVO.getPaidMoney()*100);
        Integer payMoney = Integer.valueOf(money);

        Map<String, Object> tempMap = new HashMap<>();
        tempMap.put("id",payBackVO.getId());
        tempMap.put("payType",payBackVO.getPayType());
        tempMap.put("paidMoney",payMoney);
        if (payBackVO.getPayNum() != null && !"".equals(payBackVO.getPayNum())){
            tempMap.put("payNum",payBackVO.getPayNum());
        }
        tempMap.put("tradeNum",tradeNumber);
        tempMap.put("updateBy",UserSessionUtil.getUserName());
        tempMap.put("channelNum",UserSessionUtil.getChannelNo());
        tempMap.put("channelName",UserSessionUtil.getChannelName());
        tempMap.put("siteName",UserSessionUtil.getUserDotName());
        tempMap.put("acquirerNo",UserSessionUtil.getDotNo());
        tempMap.put("updateBy",UserSessionUtil.getUserName());
//        tempMap.put("channelNum","00000000");
//        tempMap.put("channelName","00000000");
//        tempMap.put("siteName","经三路");
//        tempMap.put("acquirerNo","00000000");
//        tempMap.put("updateBy","00000000");
        tempMap.put("payTime",new Date());

        int result = 0;
        try {
            result = financeFeign.updatePayBackStatus(tempMap);
        } catch (Exception e) {
            logger.error("<== 更新补交收款状态异常");
            return ReturnResult.error("更新补交收款状态异常");
        }

        if (result == 0){
            logger.error("<== 更新补交收款状态失败");
            return ReturnResult.error("更新补交收款状态失败");
        }

        logger.info("<==  方法payBack执行结束");
        return ReturnResult.success("更新补交收款状态成功");
    }


    /************************************ 圈存 ******************************************************************/

    /**
     * 圈存：卡账查询接口
     * @param params
     * @return
     */
    @PostMapping("/cardAccountSearch")
    public Map<String,Object> cardAccountSearch(@RequestBody CardAccountSearchVO cardAccountSearchVO){
        logger.info("<==  方法cardAccountSearch的参数::" + cardAccountSearchVO + "   开始执行");
        logger.info("<==  方法cardAccountSearch执行结束");
        return financeFeign.cardAccountSearch(cardAccountSearchVO);
    }

    /**
     * 圈存：调用服务执行数据库圈存+调用加密机返回密钥
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"deposit:add"})
    @PostMapping("/transference")
    public Map<String,Object> transference(@RequestBody QuanCunVO quanCunVO,HttpServletRequest request){
        logger.info("<==  方法transference的参数::" + quanCunVO + "   开始执行");

        Map<String, Object> map = null;
        try {
            LocalDateTime localDateTime = LocalDateTime.now();
            String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

            // region 生成交易流水号等信息
            String acquirerNo = "4101018802401050635";
            String siteName = "经三路网点";
            String employeeNo = "00000000";
            String createBy = "00000000";
            String channelType = "0";
            String channelNum = "00000000";
            String channelName = "00000000";
            try {
                acquirerNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                siteName = UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName();
                employeeNo = UserSessionUtil.getUserNo() == null ? "00000000" : UserSessionUtil.getUserNo();
                createBy = UserSessionUtil.getUserName() == null ? "00000000" : UserSessionUtil.getUserName();
                channelType = UserSessionUtil.getChannelType() == null ? "0" : UserSessionUtil.getChannelType();
                channelNum = UserSessionUtil.getDotNo() == null ? "00000000" : UserSessionUtil.getDotNo();
                channelName = UserSessionUtil.getChannelName() == null ? "00000000" : UserSessionUtil.getChannelName();
            } catch (Exception e) {
                logger.error("<==  获取渠道信息异常");
            }
            // endregion

            // region流水号
            String tradeNumber = getTradeNumber(channelNum,localDateTime);
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
            // endregion

            // region 组装DTO参数
            QuanCunDTO quanCunDTO = null;
            try {
                quanCunDTO = new QuanCunDTO();
                quanCunDTO.setCardInfo(quanCunVO.getCardInfo());
                quanCunDTO.setCardNo(quanCunVO.getCardNo());
                quanCunDTO.setRandom(quanCunVO.getRandom());
                quanCunDTO.setTerminal(quanCunVO.getTerminal());
                quanCunDTO.setOperationMoney(quanCunVO.getOperationMoney());
                quanCunDTO.setOptTime(quanCunVO.getOptTime());
                quanCunDTO.setChannelType(channelType);
                quanCunDTO.setChannelNum(channelNum);
                quanCunDTO.setChannelName(channelName);
                quanCunDTO.setAcquirerNo(acquirerNo);
                quanCunDTO.setSiteName(siteName);
                quanCunDTO.setEmployeeNo(employeeNo);
                quanCunDTO.setCreateBy(createBy);
                quanCunDTO.setOperationUser(createBy);
                quanCunDTO.setTradeNum(tradeNumber);
            } catch (Exception e) {
                logger.error("<==  获取卡信息失败");
                throw new RuntimeException("获取卡信息失败，不允许圈存");
            }
            // endregion

            // region 圈存金额验证
            if (quanCunVO.getOperationMoney() <= 0){
                logger.error("<==  卡号[" + quanCunVO.getCardNo() + "]，圈存金额[" + quanCunVO.getOperationMoney() + "]必须大于0");
                return ReturnResult.error("圈存金额必须大于0");
            }
            // endregion

            // region 交易序列号、A014
            String onlineSn = quanCunVO.getCardInfo().substring(8,12);

            logger.info("<==  A014请求随机次主密钥");
            boolean a014Flag = EncryptorUtils.a014(quanCunVO.getCardNo(),quanCunVO.getOperationMoney(),quanCunVO.getCardInfo(),
                    quanCunVO.getTerminal());
            if (!a014Flag){
                logger.error("<==  卡号[" + quanCunVO.getCardNo() +  "]A014验证未通过，不允许圈存");
                return ReturnResult.error("A014验证失败，不允许圈存");
            }
            // endregion

            // region 调用圈存服务
            boolean flag = false;
            try {
                flag = financeFeign.quanCun(quanCunDTO);
                logger.info("<==  圈存调用状态 " + flag);
            } catch (Exception e) {
                logger.error("<==  调用圈存服务失败，接口熔断");
                flag = false;
            }

            if (!flag){
                logger.error("<==  调用圈存服务失败");
                throw new RuntimeException("调用圈存服务失败");
            }
            // endregion

            // region AO15、shsmk
            logger.info("<==  A015申请圈存MAC");
            String mac = EncryptorUtils.a015(quanCunVO.getCardNo(),quanCunVO.getOperationMoney(),quanCunVO.getCardInfo(),
                    quanCunVO.getTerminal(),quanCunVO.getOptTime());

            String shsmk = "805200000B" + quanCunVO.getOptTime() + mac + "04";
            logger.info("<==  卡号[" + quanCunVO.getCardNo() + "]圈存指令为[" + shsmk + "]");
            // endregion

            // region 返回数据
            map = new HashMap<>();
            map.put("shsmk",shsmk);
            map.put("tradeNumber",tradeNumber);
            map.put("onlineSn",onlineSn);
            // endregion

            // 打日志
            Map<String, Object> tempMap = new HashMap<>();
            tempMap.put("quanCunDTO+quancunVO",quanCunDTO.toString() + quanCunVO.toString());
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方PC圈存",tempMap,map,request));

        } catch (RuntimeException e) {
            logger.error("<==  圈存错误，请联系管理员 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("圈存错误，请联系管理员");
        }

        logger.info("<==  方法transference执行结束");
        return map;
    }

    /**
     * 圈存回调-->更新圈存状态、更新圈存账单补圈存状态
     * @param params
     * @return
     */
    @PostMapping("/transferReturn")
    public Map<String,Object> transferReturn(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法transferReturn的参数::" + params);
        /**
         * 修改圈存操作表和账单表圈存状态、补圈存状态
         */
        try {
            Map<String,Object> map1 = new HashMap<>();
            map1.put("cardNo",params.get("cardNo"));
            map1.put("onlineSn",Integer.parseInt(String.valueOf(params.get("onlineSn")),16));
            Map<String,Object> map2 = new HashMap<>();
            map2.put("cardNo",params.get("cardNo"));
            map2.put("tradeNum",params.get("tradeNum"));
            financeFeign.updateTransferOperation(map1);
            financeFeign.updateTransferRecord(map2);
        } catch (Exception e) {
            logger.error("<==  圈存回调,更新物理圈存状态失败" + e.getMessage());
            return ReturnResult.error("圈存失败,请联系管理员");
        }
        logger.info("<==  圈存回调,更新物理圈存状态成功");
        return ReturnResult.success("圈存成功");
    }


    /************************************ 资金点对点分配 ******************************************************************/

    /**
     * 资金点对点分配验证
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"onetoone:query"})
    @PostMapping("/validatePointTransfer")
    public Map<String,Object> validatePointTransfer(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validatePointTransfer的参数::" + params);

        String cardId = (String) params.get("cardId");
        if (StringUtils.isEmpty(cardId)){
            logger.error("<==  卡号[" + cardId + "]不能为空");
            return ReturnResult.errors("卡号不能为空");
        }

        Map<String,Object> map = new HashMap<>(3);
        map = financeFeign.validatePointTransfer(params);
        logger.info("<==  方法validatePointTransfer执行结束");
        return map;
    }

    /**
     * 资金点对点分配
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"onetoone:add"})
    @PostMapping("/pointTransfer")
    public Map<String,Object> pointTransfer(@RequestBody Map<String,Object> params,HttpServletRequest request){
        logger.info(" --> 方法pointTransfer的参数::" + params);
        Map<String,Object> map = null;

        try {

            MapRemoveNullUtil.removeNullEntry(params);

            // region 卡、证件编号、卡状态初步校验、分配金额、localDateTime
            String cardId = (String) params.get("cardId");
            if (StringUtils.isEmpty(cardId)){
                logger.error("<==   想要进行分配的卡号[" + cardId + "]不能为空");
                return ReturnResult.error("卡号不能为空");
            }

            String certificateNumber = (String) params.get("certificateNumber");
            if (StringUtils.isEmpty(certificateNumber)){
                logger.error("<==   想要进行分配的卡号对应的用户证件编号[" + certificateNumber + "]不能为空");
                return ReturnResult.error("证件编号不能为空");
            }

            String cardStatus = getParams(params.get("cardStatus"));
            if (!cardStatus.equals("600202101")){
                logger.error("<== 待分配的ETC卡状态不正常");
                return ReturnResult.error("待分配的ETC卡状态不正常");
            }

            String distributionBalance = getParams(params.get("distributionBalance"));
            Double x = Double.parseDouble(distributionBalance);
            if (StringUtils.isEmpty(distributionBalance) || x <= 0D){
                logger.error("<== 待分配的金额[" +  distributionBalance+ "]不能为空且必须大于0");
                return ReturnResult.error("分配金额不正确");
            }

            LocalDateTime localDateTime = LocalDateTime.now();
            String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            logger.info("<==  待分配ETC卡状态正常,允许分配");
            // endregion

            // region 设置唯一token，防止重试、重复批量分配
            String token = (String) params.get("token");
            if (StringUtils.isEmpty(token.toString())){
                logger.error("<==  本笔点对点分配的token=[" + token + "]，未获取到点对点分配唯一流水号");
                return ReturnResult.error("请查询重试，如无法分配请联系管理员");
            }
            String redisToken = null;
            try {
                // 获取token之后将其清除
                redisToken = (String) redisService.get(token);
                logger.info("<==  本笔点对点分配唯一token[" + token + "]，内存中的redisToken[" + redisToken + "]");
                if (StringUtils.isEmpty(redisToken)){
                    logger.error("<==  本笔点对点分配的token=[" + token + "]与缓存中获取的[" + redisToken + "]不一致，请重新查询后分配");
                    return ReturnResult.error("分配请求(有效期10分钟)已失效，请点击查询后重试");
                }
            } catch (Exception e) {
                logger.error("<==  从redis读取本次点对点分配交易token[" + redisToken + "]异常");
                return ReturnResult.error("token验证异常，不允许分配");
            }
            params.put("transId",token);
            // endregion

            // region 渠道数据验证
            String dotNo = "4101018802401050635";
            try {
                dotNo = "4101018802401050635";
                dotNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                params.put("acquirerNo",UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo());
                params.put("siteName",UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName());
                params.put("employeeNo",UserSessionUtil.getUserNo());
                params.put("createBy",UserSessionUtil.getUserName());
                params.put("channelType", getParams(UserSessionUtil.getChannelType()));
                params.put("channelNum", getParams(UserSessionUtil.getChannelNo()));
                params.put("channelName", getParams(UserSessionUtil.getChannelName()));
//                params.put("acquirerNo","4101018802401050635");
//                params.put("siteName","经三路网点");
//                params.put("employeeNo","19950401");
//                params.put("createBy","0000");
//                params.put("channelType", "01");
//                params.put("channelNum", "4101018802401050635");
//                params.put("channelName", "0000");
                if (StringUtils.isEmpty(UserSessionUtil.getDotNo())){
                    logger.error("<==  获取渠道编号[" + UserSessionUtil.getDotNo() + "]失败，不允许点对点分配");
                    return ReturnResult.errors("获取渠道编号失败，不允许点对点分配");
                }
            } catch (Exception e) {
                logger.error("<==  获取渠道数据异常，不允许点对点分配");
                return ReturnResult.errors("获取渠道数据异常，不允许点对点分配");
            }
            // endregion

            // region 交易流水号
            String tradeNumber = getTradeNumber(dotNo,localDateTime);

            params.put("tradeNumber",tradeNumber);
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
            // endregion

            map = new HashMap<>(3);
            map = financeFeign.pointTransfer(params);

            // 打日志
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方点对点分配",params,map,request));
        } catch (Exception e) {
            logger.error("<==  点对点分配错误，请联系管理员 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("点对点分配错误，请联系管理员");
        }

        logger.info("<==  方法pointTransfer执行结束");
        return map;
    }


    /************************************ 资金批量分配 ******************************************************************/

    /**
     * 资金批量分配验证
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"batch:query"})
    @PostMapping("/validateBatchPoint")
    public Map<String,Object> validateBatchPoint(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法validateBatchPoint的参数::" + params);
        Map<String,Object> map = new HashMap<>(3);
        map = financeFeign.validateBatchPoint(params);
        return map;
    }

    /**
     * 资金批量分配
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"batch:add"})
    @PostMapping("/batchTransfer")
    Map<String,Object> batchTransfer(@RequestBody Map<String,Object> params,HttpServletRequest request){
        logger.info(" --> 方法batchTransfer的参数::" + params);

        LocalDateTime localDateTime = LocalDateTime.now();
        Map<String,Object> map = null;
        try {

            MapRemoveNullUtil.removeNullEntry(params);

            // region 设置唯一token，防止重试、重复批量分配
            String token = (String) params.get("token");
            if (StringUtils.isEmpty(token.toString())){
                logger.error("<==  本笔批量分配的token=[" + token + "]，未获取到批量分配唯一流水号");
                return ReturnResult.error("请查询重试，如无法分配请联系管理员");
            }
            String redisToken = null;
            try {
                // 获取token之后将其清除
                redisToken = (String) redisService.get(token);
                logger.info("<==  本笔批量分配唯一token[" + token + "]，内存中的redisToken[" + redisToken + "]");
                if (StringUtils.isEmpty(redisToken)){
                    logger.error("<==  本笔批量分配的token=[" + token + "]与缓存中获取的[" + redisToken + "]不一致，请重新查询后分配");
                    return ReturnResult.error("分配请求(有效期10分钟)已失效，请点击查询后重试");
                }
            } catch (Exception e) {
                logger.error("<==  从redis读取本次批量分配交易token[" + redisToken + "]异常");
                return ReturnResult.error("token验证异常，不允许分配");
            }
            params.put("transId",token);
            // endregion

            // region 渠道数据验证
            String dotNo = "4101018802401050635";
            try {
                dotNo = "4101018802401050635";
                dotNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                params.put("acquirerNo",UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo());
                params.put("siteName",UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName());
                params.put("employeeNo",UserSessionUtil.getUserNo());
                params.put("createBy",UserSessionUtil.getUserName());
                params.put("channelType", getParams(UserSessionUtil.getChannelType()));
                params.put("channelNum", getParams(UserSessionUtil.getChannelNo()));
                params.put("channelName", getParams(UserSessionUtil.getChannelName()));
//                params.put("acquirerNo","4101018802401050635");
//                params.put("siteName","经三路网点");
//                params.put("employeeNo","19950401");
//                params.put("createBy","0000");
//                params.put("channelType", "01");
//                params.put("channelNum", "4101018802401050635");
//                params.put("channelName", "0000");
                if (StringUtils.isEmpty(UserSessionUtil.getDotNo())){
                    logger.error("<==  获取渠道编号[" + UserSessionUtil.getDotNo() + "]失败，不允许批量分配");
                    return ReturnResult.errors("获取渠道编号失败，不允许批量分配");
                }
            } catch (Exception e) {
                logger.error("<==  获取渠道数据异常，不允许批量分配");
                return ReturnResult.errors("获取渠道数据异常，不允许批量分配");
            }
            // endregion

            // region 用户账户分配流水号
            String tradeNumber = getTradeNumber(dotNo,localDateTime);
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);
            params.put("tradeNum",tradeNumber);
            map = new HashMap<>(3);
            // endregion

            // region 卡分配流水号
            List tempCardList = (List) params.get("tempCardList");
            Map<String, Object> userMap = (Map<String, Object>) params.get("userMap");
            if (userMap == null){
                logger.error("<==  前端没有传输本次需要分配的用户数据[" + userMap + "]");
                return ReturnResult.error("未传输用户信息，分配失败");
            }
            Double accountBalance = Double.parseDouble(ParamClassUtils.getParams(userMap.get("accountBalance")));
            if (accountBalance <= 0){
                logger.error("<==  用户账户余额[" + accountBalance + "]不足，不允许批量分配");
                return ReturnResult.error("余额不足，分配失败");
            }
            if (tempCardList.size() <= 0){
                logger.error("<==  用户[" + ParamClassUtils.getParams(userMap.get("certificateNumber")) + "]没有给名下的卡分配金额");
                return ReturnResult.error("未给卡分配金额，分配失败");
            }
            for (int i = 0; i < tempCardList.size();i++){
                String tradeNum = getTradeNumber(dotNo,localDateTime.plusSeconds(1L));
                Map<String,Object> temp = (Map<String, Object>) tempCardList.get(i);
                temp.put("tradeNum",tradeNum);
            }
            logger.info("<==  每张卡生成资金批量分配交易流水号成功");
            // endregion

            map = financeFeign.batchTransfer(params);

            // 打日志
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方批量分配",params,map,request));
        } catch (Exception e) {
            logger.error("<==  批量分配错误，请联系管理员 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("批量分配错误，请联系管理员");
        }
        logger.info("<==  方法batchTransfer执行结束");
        return map;
    }


    /************************************ 卡转账 ******************************************************************/

    /**
     * 卡转账验证
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"carryover:query"})
    @PostMapping("/getTransferCards")
    public Map<String,Object> getTransferCards(@RequestBody Map<String,Object> params){
        logger.info(" --> 方法getTransferCards的参数::" + params);
        Map<String,Object> map = new HashMap<>(3);

        // region 参数校验
        String cardId = getParams(params.get("cardId"));
        if (StringUtils.isEmpty(cardId)){
            logger.error("<==  卡号为空");
            return ReturnResult.error("卡号为空");
        }
        // endregion

        map = financeFeign.getTransferCards(params);
        return map;
    }

    /**
     * 卡转账
     * @param params
     * @return
     */
    @RequiresPermissions(value = {"carryover:add"})
    @PostMapping("/cardTransfer")
    public Map<String,Object> cardTransfer(@RequestBody Map<String,Object> params,HttpServletRequest request){
        logger.info("<==  方法cardTransfer的参数::" + params + "   开始执行");
        Map<String,Object> map = null;
        try {
            // region 卡状态、卡号验证
            String cardOutStatus = getParams(params.get("cardStatus"));
            if (!cardOutStatus.equals("600202101")){
                logger.error("<== 转出的ETC卡状态不正常，不允许转账");
                return ReturnResult.error("转出ETC卡状态不正常");
            }
            logger.info("<==  转出ETC卡号状态正常");
            Map<String,Object> transferInCardMap = (Map<String, Object>) params.get("cardList");
            String cardInStatus = getParams(transferInCardMap.get("cardStatus"));
            if (!cardInStatus.equals("600202101")){
                logger.error("<== 转入的ETC卡状态不正常，不允许转账");
                return ReturnResult.error("转入ETC卡状态不正常");
            }
            logger.info("<==  转入ETC卡号状态正常");
            LocalDateTime localDateTime = LocalDateTime.now();
            String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            // endregion

            // region 设置唯一token，防止重试、重复批量分配
            String token = (String) params.get("token");
            if (StringUtils.isEmpty(token.toString())){
                logger.error("<==  本笔卡转账的token=[" + token + "]，未获取到卡转账唯一流水号");
                return ReturnResult.error("请查询重试，如无法转账请联系管理员");
            }
            String redisToken = null;
            try {
                // 获取token之后将其清除
                redisToken = (String) redisService.get(token);
                logger.info("<==  本笔卡转账唯一token[" + token + "]，内存中的redisToken[" + redisToken + "]");
                if (StringUtils.isEmpty(redisToken)){
                    logger.error("<==  本笔卡转账的token=[" + token + "]与缓存中获取的[" + redisToken + "]不一致，请重新查询后转账");
                    return ReturnResult.error("转账请求(有效期10分钟)已失效，请点击查询后重试");
                }
            } catch (Exception e) {
                logger.error("<==  从redis读取本次卡转账交易token[" + redisToken + "]异常");
                return ReturnResult.error("token验证异常，不允许转账");
            }
            params.put("transId",token);
            // endregion

            // region 渠道数据验证
            String dotNo = "4101018802401050635";
            try {
                dotNo = "4101018802401050635";
                dotNo = UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo();
                params.put("acquirerNo",UserSessionUtil.getDotNo() == null ? "4101018802401050635" : UserSessionUtil.getDotNo());
                params.put("siteName",UserSessionUtil.getUserDotName() == null ? "经三路网点" : UserSessionUtil.getUserDotName());
                params.put("employeeNo",UserSessionUtil.getUserNo());
                params.put("createBy",UserSessionUtil.getUserName());
                params.put("channelType", getParams(UserSessionUtil.getChannelType()));
                params.put("channelNum", getParams(UserSessionUtil.getChannelNo()));
                params.put("channelName", getParams(UserSessionUtil.getChannelName()));
//                params.put("acquirerNo","4101018802401050635");
//                params.put("siteName","经三路网点");
//                params.put("employeeNo","19950401");
//                params.put("createBy","0000");
//                params.put("channelType", "01");
//                params.put("channelNum", "4101018802401050635");
//                params.put("channelName", "0000");
                if (StringUtils.isEmpty(UserSessionUtil.getDotNo())){
                    logger.error("<==  获取渠道编号[" + UserSessionUtil.getDotNo() + "]失败，不允许卡转账");
                    return ReturnResult.errors("获取渠道编号失败，不允许卡转账");
                }
            } catch (Exception e) {
                logger.error("<==  获取渠道数据异常，不允许卡转账");
                return ReturnResult.errors("获取渠道数据异常，不允许卡转账");
            }
            // endregion

            // region 交易流水号：转出卡、转入卡流水号
            String tradeNumber = getTradeNumber(dotNo,localDateTime);
            String tradeNumber2 = getTradeNumber(dotNo,localDateTime.plusSeconds(1L));
            logger.info("<==  当前交易流水号 tradeNumber=" + tradeNumber);

            params.put("tradeNum",tradeNumber);
            params.put("tradeNum2",tradeNumber2);
            logger.info("<==  本笔卡转账，转出卡交易流水号[" + tradeNumber + "],转入卡交易流水号[" + tradeNumber2 + "]");
            // endregion

            map = new HashMap<>(3);
            map = financeFeign.cardTransfer(params);

            // 打日志
            loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1","发行方卡转账",params,map,request));
        } catch (Exception e) {
            logger.error("<==  卡转账错误，请联系管理员 " + e.getMessage());
            e.printStackTrace();
            return ReturnResult.error("卡转账错误，请联系管理员");
        }

        logger.info("<==  方法cardTransfer执行结束");
        return map;
    }


    /************************************ 获取交易流水号、Token ******************************************************************/

    /**
    * @description 获取交易流水号
    * @author hekunlin 2018/1/23 17:08 Version 1.2
    * @param
    * @return
    */
    public String getTradeNumber(String channelNum,LocalDateTime local){
        LocalDateTime localDateTime = local.now();
        String formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        Long incr = redisService.getIncr(formatDate,60L);
        String tradeNum = "";
        if (incr < 99){
            tradeNum = String.format("%02d", incr);
        }
        if (incr > 99){
            localDateTime = localDateTime.plusSeconds(1);
            formatDate = localDateTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            incr = redisService.getIncr(formatDate,60L);
            tradeNum = String.format("%02d", incr);
        }
        String tradeNumber = CHANNEL_TYPE + channelNum + formatDate + tradeNum;
        return tradeNumber;
    }

    /**
     * 获取token
     * @return
     */
    @GetMapping("/getOnlyToken")
    public String getOnlyToken(){
        String uuid = UUIDUtils.getUUID();
        redisService.set(uuid,uuid,600L);
        return uuid;
    }

}
