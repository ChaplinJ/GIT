package com.owinfo.web.controller;

import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.ObuFeign;
import com.owinfo.web.util.FileUtil;
import com.owinfo.web.util.ObuRead;
import com.owinfo.web.util.ReturnResult;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@RestController
@RequestMapping("/etcObu")
public class EtcObuService {
    @Autowired
    private ObuFeign obuFeign;
    @Autowired
    private BizFeign bizFeign;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * @Author: Wei Chunlai
     * @Description: 查询电子标签操作记录
     * @Params:
     * @MothedName:
     * @Date: 2017/10/26 12:14
     */
    @RequestMapping("/selectBusinessSelective")
    @RequiresPermissions(value = {"lttagup:list", "lttagchangelist:list", "lttagchangeinfo:list"}, logical = Logical.OR)
    public Map<String, Object> selectBusinessSelective(@RequestBody Map<String, Object> map) throws IOException {
        Map<String, Object> map1 = obuFeign.selectBusinessSelective(map);
        return map1;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 查询电子标签信息
     * @Params:
     * @MothedName:
     * @Date: 2017/10/26 12:15
     */
    @RequestMapping("/selectSelective")
    @RequiresPermissions(value = {"lttaginfo:list"})
    Map<String, Object> selectSelective(@RequestBody Map<String, Object> map){
        return obuFeign.selectSelective(map);
    }

    @RequestMapping("/selectByPrimaryKey")
    @RequiresPermissions(value = {"ltcarsinfo:list", "ltcorrection:list","carsAccount:list"}, logical = Logical.OR)
    Map<String, Object> selectByPrimaryKey(@RequestBody Map<String, Object> map){
        Map<String, Object> stringObjectMap = obuFeign.selectByPrimaryKey(map);
        Map<String, Object> data = (Map<String, Object>) stringObjectMap.get("data");
        if (data != null){
            try {
                Date date = sdf.parse(String.valueOf(data.get("tradeTime")));
                Date time = addYear(date);
                data.put("time", time);
            } catch (ParseException e) {
                e.printStackTrace();
                return ReturnResult.error("查询电子标签异常");
            }
        }
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("status", "1");
        result.put("data", data);
        result.put("msg", "查询成功");
        return result;
    }

    //在原有时间上加上10年
    private Date addYear(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, 10);
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        return calendar.getTime();
    }

    @RequestMapping("/obuInfoExport")
    @RequiresPermissions(value = {"lttaginfo:export"})
    public void obuInfoExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.obuInfoExport(map);
        if(bytes!=null){
            String fileName = "电子标签信息列表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @RequestMapping("/obuBusinessExport")
    @RequiresPermissions(value = {"lttagup:export", "lttagchangelist:export", "lttagchangeinfo:export"}, logical = Logical.OR)
    public void obuBusinessExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.obuBusinessExport(map);
        if(bytes!=null){
            String fileName = "";
            if ("1".equals(String.valueOf(map.get("flag")))){
                fileName = "电子标签挂起列表";
            }else if ("2".equals(String.valueOf(map.get("flag")))){
                fileName = "电子标签操作记录列表";
            }else if ("3".equals(String.valueOf(map.get("flag")))){
                fileName = "电子标签操作明细列表";
            }

            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @RequestMapping("/closeOutExport")
    @RequiresPermissions(value = {"ltclearaccount:export"})
    public void closeOutExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.closeOutExport(map);
        if(bytes!=null){
            String fileName = "清账列表列表";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @RequestMapping("/selectTradeDetail")
    public Map<String, Object> selectTradeDetail(@RequestBody Map<String, Object> map){
        Map<String, Object> objectMap = bizFeign.selectTradeDetail(map);
        return objectMap;
    }

    @RequestMapping("/selectObuStatus")
    public String selectObuStatus(@RequestBody Map<String, Object> map){
        String obuId = String.valueOf(map.get("obuId"));
        if (obuId == null || "".equals(obuId)){
            return null;
        }
        String obuStatus = obuFeign.selectObuStatus(map);
        return obuStatus;
    }

    @RequestMapping(value = "/ObuRead", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public ObuRead ObuRead(@RequestBody Map<String, Object> data){
        return obuFeign.ObuRead(data);
    }

}
