package com.owinfo.web.controller;

import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.LoggerService;
import com.owinfo.web.util.ReturnResult;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@RestController
@RequestMapping("/etcObuService")
public class EtcObuServiceBiz {
    @Autowired
    private BizFeign bizFeign;
    @Autowired
    private LoggerService loggerService;

    /**
     * @Author: Wei Chunlai
     * @Description: 重新安装激活
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:37
     */
    
    @RequestMapping("/install")
    @RequiresPermissions(value = {"reinstall:add"})
    public Map<String, Object> install(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> install = bizFeign.install(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "电子标签重新安装激活", map, install, request));
        return install;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签挂失
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/reportLoss")
    @RequiresPermissions(value = {"tablost:add"})
    public Map<String, Object> reportLoss(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> map1 = bizFeign.reportLoss(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "电子标签挂失", map, map1, request));
        return map1;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签解挂
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/relieve")
    @RequiresPermissions(value = {"tabsolution:add"})
    public Map<String, Object> relieve(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> relieve = bizFeign.relieve(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "电子标签解挂", map, relieve, request));
        return relieve;
    }


    /**
     * @Author: Wei Chunlai
     * @Description: 标签续期
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/renewal")
    @RequiresPermissions(value = {"tabextend:add"})
    public Map<String, Object> renewal(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> renewal = bizFeign.renewal(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "标签续期", map, renewal, request));
        return renewal;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签挂起
     * @Params:
     * 电子标签编号:obuid
     * 挂起类型: hangtype 0主动挂起，1被动挂起
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/hang")
    @RequiresPermissions(value = {"taghangup:add"})
    public Map<String, Object> hang(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> hang = bizFeign.hang(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "标签挂起", map, hang, request));
        return hang;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签挂起解除
     * @Params:
     * 电子标签编号:obuid
     * 新车辆号码: vehicleLicense
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/suspendRelease")
    @RequiresPermissions(value = {"tabhangoff:query"})
    public Map<String, Object> suspendRelease(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> map1 = bizFeign.suspendRelease(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "标签挂起解除", map, map1, request));
        return map1;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签过户
     * @Params:
     * 原电子标签编号:obuId
     * 原车辆号码:vehicleLicense
     * 新证件号码:newCertificateNumber
     * 新车辆号码:newVehicleLicense
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/transfer")
    @RequiresPermissions(value = {"tabtransform:add"})
    public Map<String, Object> transfer(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> transfer = bizFeign.transfer(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "标签过户", map, transfer, request));
        return transfer;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签注销
     * @Params:
     * 电子标签编号:obuId
     * 注销原因（编号或字符串）:revokeReason
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/cancel")
    @RequiresPermissions(value = {"tabwithdraw:add"})
    public Map<String, Object> cancel(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> cancel = bizFeign.cancel(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "标签注销", map, cancel, request));
        return cancel;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签损坏登记
     * @Params:
     * 电子标签编号:obuId
     * 损坏原因（编号或字符串）:damageReason
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/damage")
    @RequiresPermissions(value = {"tabbreakdown:add"})
    public Map<String, Object> damage(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> damage = bizFeign.damage(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "标签损坏登记", map, damage, request));
        return damage;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 体验标签回收
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/recovery")
    @RequiresPermissions(value = {"tabtaste:add"})
    public Map<String, Object> recovery(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        Map<String, Object> recovery = bizFeign.recovery(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "体验标签回收", map, recovery, request));
        return recovery;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 标签信息查看
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/serch")
    @RequiresPermissions(value = {"reinstall:query", "tablost:query", "tabsolution:query", "tabextend:query",
    "taghangup:query", "tabtransform:queryObu", "tabwithdraw:queryObu", "tabbreakdown:queryObu",
    "tabtaste:queryObu"}, logical = Logical.OR)
    public Map<String, Object> serch(@RequestBody Map<String, Object> map) throws ParseException {
        return bizFeign.serch(map);
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 注册电子标签
     * @Params:
     * @MothedName:
     * @Date: 2017/10/26 12:12
     */
    @RequestMapping("/register")
    @RequiresPermissions(value = {"etab:add"})
    public Map<String, Object> register(@RequestBody Map<String, Object> map, HttpServletRequest request){
        //获取操作员
        String userNo = UserSessionUtil.getUserNo();
        if (userNo == null){
            return ReturnResult.error("获取操作人员信息为空");
        }
        map.put("updateBy", userNo);
        map.put("operatorId", userNo);
        map.put("createBy", userNo);
        map.put("idAndName", userNo+"-"+UserSessionUtil.getUserName());
        map.put("recoveryPerson", UserSessionUtil.getUserName());
        if (UserSessionUtil.getDotNo() == null){
            return ReturnResult.error("获取站点信息为空");
        }
        if (UserSessionUtil.getChannelNo() == null){
            return ReturnResult.error("获取渠道信息为空");
        }
        map.put("dotName", UserSessionUtil.getUserDotName());
        map.put("stationId", UserSessionUtil.getDotNo());
        map.put("channelNo", UserSessionUtil.getChannelNo());
        Map<String, Object> register = bizFeign.register(map);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("2", "注册电子标签", map, register, request));
        return register;
    }
}
