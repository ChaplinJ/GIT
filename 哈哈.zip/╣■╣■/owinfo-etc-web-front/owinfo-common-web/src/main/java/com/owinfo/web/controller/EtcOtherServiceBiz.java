package com.owinfo.web.controller;

import com.owinfo.web.config.util.LoggerParameter;
import com.owinfo.web.config.util.UserSessionUtil;
import com.owinfo.web.service.AccountFeign;
import com.owinfo.web.service.LoggerService;
import com.owinfo.web.service.OtherFeign;
import com.owinfo.web.util.CollectFieldUtil;
import com.owinfo.web.util.FileUtil;
import com.owinfo.web.util.ReturnResult;
import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 物品售出、以旧换新、账户查看、交易统计
 * 创建时间：2017年10月26日
 * <p>
 * 〈一句话功能简述〉物品售出、以旧换新、账户查看、交易统计〈功能详细描述〉
 *
 * @author sun
 * @version [版本号, 2017年10月26日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@RestController
@RequestMapping("/otherService")
public class EtcOtherServiceBiz {

    @Autowired
    private OtherFeign otherFeign;

    @Autowired
    private LoggerService loggerService;

    @Autowired
    private AccountFeign accountFeign;

    private static Logger logger = Logger.getLogger(EtcOtherServiceBiz.class);
    /***
     * 物品售出--查询物品
     *  物品编号:goodsNo
     *  当前站点:siteName
     */
    @RequiresPermissions(value = {"sellnew:query","change:query"}, logical = Logical.OR)
    @RequestMapping(value="/getGoods",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getGoods(@RequestBody Map<String, Object> params){
        String siteName = UserSessionUtil.getUserDotName();
        String siteNo = UserSessionUtil.getDotNo();
        params.put("siteName", siteName);
        params.put("siteNo", UserSessionUtil.getDotNo());
        params.put("inSite", siteNo);
        return otherFeign.getGoods(params);
    }

    /***
     * 物品售出--售出
     * 物品编号:goodsNo
     * 物品名称:goodsName
     * 物品厂商:goodsManufacturer
     * 客户姓名:clientName
     * 电话号码:telNo
     */
    @RequiresPermissions(value = {"sellnew:add"})
    @RequestMapping(value="/saleGoods",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> saleGoods(@RequestBody Map<String, Object> params, HttpServletRequest request){
        logger.info("充值宝售出 params = " +params);
        if(params.get("payType") == null || "".equals(params.get("payType").toString())){
            logger.info("收款方式为空");
            return ReturnResult.error("收款方式为空");
        }
        if(params.get("saleType") == null || "".equals(params.get("saleType").toString())){
            logger.info("销售类型为空");
            return ReturnResult.error("销售类型为空");
        }
        if("5".equals(params.get("saleType").toString())){
            if(params.get("activityId") == null || "".equals(params.get("activityId").toString())){
                logger.info("营销活动为空");
                return ReturnResult.error("营销活动为空");
            }
        }
        switch (String.valueOf(params.get("payType"))){
            case "1":
                if (params.get("posOrderNo") == null || "".equals(params.get("posOrderNo").toString())){
                    logger.info("pos单号为空");
                    return ReturnResult.error("pos单号为空");
                }else{
                    params.put("rechargeNum",params.get("posOrderNo").toString());
                    break;
                }
            case "2":
                if (params.get("random") == null || "".equals(params.get("random").toString())){
                    logger.info("转账随机码为空");
                    return ReturnResult.error("转账随机码为空");
                }
                if(params.get("unitPrice") == null || "".equals(params.get("unitPrice").toString())){
                    logger.info("转账实收金额为空");
                    return ReturnResult.error("转账实收金额为空");
                }
                params.put("rechargeNum",params.get("random").toString());
                params.put("saleMoney",params.get("unitPrice").toString());
                break;
            case "3":
                if (params.get("orderNo") == null || "".equals(params.get("orderNo").toString())){
                    logger.info("订单号为空");
                    return ReturnResult.error("订单号为空");
                }
                if(params.get("unitPrice") == null || "".equals(params.get("unitPrice").toString())){
                    logger.info("电商实收金额为空");
                    return ReturnResult.error("电商实收金额为空");
                }
                params.put("rechargeNum",params.get("orderNo").toString());
                params.put("saleMoney",params.get("unitPrice").toString());
                break;
            case "4":
                if (params.get("ticketNo") == null || "".equals(params.get("ticketNo").toString())){
                    logger.info("卡券号为空");
                    return ReturnResult.error("卡券号为空");
                }else{
                    params.put("rechargeNum",params.get("ticketNo").toString());
                    params.put("saleMoney",0);
                    break;
                }
            case "5":
                if (params.get("payId") == null || "".equals(params.get("payId").toString())){
                    logger.info("其它付款方式编号为空");
                    return ReturnResult.error("其它付款方式编号为空");
                }else{
                    params.put("specificRechargeType",params.get("payId").toString());
                    params.put("otherCollectionField",CollectFieldUtil.collectField(params));
                    break;
                }
        }
        //deviceSaleType 0正常销售 1营销活动 2收取押金 3以旧换新 4免费发出
        params.put("createBy", UserSessionUtil.getUserNo());
        params.put("siteName", UserSessionUtil.getDotNo());
        params.put("siteNo", UserSessionUtil.getDotNo());
        params.put("channelNum", UserSessionUtil.getChannelNo());
        params.put("operatorName", UserSessionUtil.getUserName());
        Double var1 = Double.parseDouble(params.get("saleMoney").toString());
        params.put("deviceSaleReceipts",(int) Math.round(var1 * 100));
        if(params.get("activityId") != null && !"".equals(params.get("activityId").toString())){
            params.put("deviceSaleType",1);
            params.put("activityPrice",(int) Math.round(var1 * 100));
            params.put("activityType",params.get("activityId").toString());
        }

        Map<String, Object> map = otherFeign.saleGoods(params);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "新增一条物品售出信息", params, map, request));
        return map;
    }

    /***
     * 物品售出--售出记录
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * 商品名称:goodsName
     * 商品编号:goodsNo
     * 站点名称:siteName
     *
     */
    @RequiresPermissions(value = {"selllist:list"})
    @RequestMapping(value="/saleRecord",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> saleRecord(@RequestBody Map<String, Object> params){
        return otherFeign.saleRecord(params);
    }

    /***
     * 物品售出--以旧换新--检索物品信息
     *  物品编号:goodsNo
     */
    @RequiresPermissions(value = {"change:queryOld"})
    @RequestMapping(value="/getChangeInfo",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getChangeInfo(@RequestBody Map<String, Object> params) {
        return otherFeign.getChangeInfo(params);
    }

    /***
     * 物品售出--以旧换新保存
     * 站点名称:siteName
     * 新品编号:newGoodsNo
     * 当前旧品编号:goodsNo
     * 物品名称:newGoodsName
     * 物品厂商:newGoodsFact
     */
    @RequiresPermissions(value = {"change:add"})
    @RequestMapping(value="/saveChangeGoods",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> saveChangeGoods(@RequestBody Map<String, Object> params, HttpServletRequest request){
        logger.info("充值宝换新 params = " +params);
        if(params.get("payType") != null && !"".equals(params.get("payType").toString())){
            switch (String.valueOf(params.get("payType"))) {
                case "1":
                    if (params.get("posOrderNo") == null || "".equals(params.get("posOrderNo").toString())) {
                        logger.info("pos单号为空");
                        return ReturnResult.error("pos单号为空");
                    } else {
                        params.put("rechargeNum", params.get("posOrderNo").toString());
                        break;
                    }
                case "4":
                    if (params.get("ticketNo") == null || "".equals(params.get("ticketNo").toString())){
                        logger.info("卡券号为空");
                        return ReturnResult.error("卡券号为空");
                    }else{
                        params.put("rechargeNum",params.get("ticketNo").toString());
                        params.put("saleMoney",0);
                        break;
                    }
                case "5":
                    if (params.get("payId") == null || "".equals(params.get("payId").toString())){
                        logger.info("其它付款方式编号为空");
                        return ReturnResult.error("其它付款方式编号为空");
                    }else{
                        params.put("specificRechargeType",params.get("payId").toString());
                        params.put("otherCollectionField",CollectFieldUtil.collectField(params));
                        break;
                    }
            }
        }else{
            params.put("saleMoney",0);
        }
        params.put("createBy", UserSessionUtil.getUserNo());
        params.put("operatorName", UserSessionUtil.getUserName());
        params.put("siteName", UserSessionUtil.getDotNo());
        params.put("siteNo", UserSessionUtil.getDotNo());
        params.put("channelNum", UserSessionUtil.getChannelNo());
        Double var1 = Double.parseDouble(params.get("saleMoney").toString());
        params.put("deviceSaleReceipts",(int) Math.round(var1 * 100));
        Map<String, Object> map = otherFeign.saveChangeGoods(params);
        loggerService.saveOperationLog(LoggerParameter.OperationLoggerParam("1", "新增一条以旧换新信息", params, map, request));
        return map;
    }

    /***
     * 物品售出--以旧换新分页查询
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * 站点名称:siteName
     * 新品编号:newGoodsNo
     * 最初旧品编号:goodsNo
     * 新品名称：newGoodsName
     */
    @RequiresPermissions(value = {"changelist:list"})
    @RequestMapping(value="/changeGoods",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> changeGoods(@RequestBody Map<String, Object> params){
        return otherFeign.changeGoods(params);
    }

    /***
     * 查询统计--客户交易流水号查询
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * ETC卡号:cardId
     * 交易类型:operationType
     * 查询老卡:flag(true--选中老卡)
     */
    @RequiresPermissions(value = {"record:list"})
    @RequestMapping(value="/getCount",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getCount(@RequestBody Map<String, Object> params){
        return otherFeign.getCount(params);
    }

    /**
     *  查询客户信息
     *  证件编号:certificateNumber
     *  原证件编号:oldUnitCertificateNo
     * */
    @RequiresPermissions(value = {"goodsinfo:list","goodsfirm:list","goodsstatus:list"}, logical = Logical.OR)
    @RequestMapping(value = "/getUserInfo" ,method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getUserInfo(@RequestBody Map<String, Object> params){
        return otherFeign.getUserInfo(params);
    }

    /**
     * 查看账户
     *  证件编号:certificateNumber
     *  ETC卡号:cardId
     *  车牌号查询卡:vehicleLicense
     *  用户类型:clientType:1(个人)
     * */
    @RequiresPermissions(value = {"accountQuery:query","ltcustominfo:query","carsAccount:list"}, logical = Logical.OR)
    @RequestMapping(value = "/getAllInfo",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public Map<String, Object> getAllInfo(@RequestBody Map<String, Object> params){
        return otherFeign.getAllInfo(params);
    }

    /***
     * 以旧换新记录Excel导出
     * 开始时间:startTime
     * 结束时间:endTime
     * 站点名称:siteName
     * 新品编号:newGoodsNo
     * 最初旧品编号:goodsNo
     * 新品名称：newGoodsName
     */
    @RequiresPermissions(value = {"changelist:export"})
    @RequestMapping(value = "/changeGoodsExport")
    public void changeGoodsExport(@RequestParam Map<String, Object> param, HttpServletResponse response) throws IOException {
        byte[] bytes = accountFeign.changeGoodsExport(param);
        if(bytes != null){
            FileUtil fileUtil = new FileUtil();
            String fileName = "以旧换新记录列表";
            try {
                fileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /***
     * 售出记录Excel导出
     * 商品名称:goodsName
     * 商品编号:goodsNo
     * 站点名称:siteName
     * 开始时间:startTime
     * 结束时间:endTime
     */
    @RequiresPermissions(value = {"selllist:export"})
    @RequestMapping(value = "/saleRecordExport")
    public void saleRecordExport(@RequestParam Map<String, Object> param, HttpServletResponse response) throws IOException {
        byte[] bytes = accountFeign.saleRecordExport(param);
        if(bytes != null){
            FileUtil fileUtil = new FileUtil();
            String fileName = "售出记录列表";
            try {
                fileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /***
     * 客户交易流水查询Excel导出
     * 商品名称:goodsName
     * 商品编号:goodsNo
     * 站点名称:siteName
     * 开始时间:startTime
     * 结束时间:endTime
     */
    @RequiresPermissions(value = {"record:export"})
    @RequestMapping(value = "/transDetailExport")
    public void transDetailExport(@RequestParam Map<String, Object> param, HttpServletResponse response) throws IOException {
        byte[] bytes = {};
        bytes = otherFeign.transDetailExport(param);
        if(bytes != null){
            FileUtil fileUtil = new FileUtil();
            String fileName = "客户交易流水列表";
            try {
                fileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
