package com.owinfo.web.controller;

import com.owinfo.web.service.PhotoFeign;
import com.owinfo.web.util.ReturnResult;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by weich on 2017/10/30.
 */
@RestController
@RequestMapping("/photoService")
public class EtcPhotoService {
    @Autowired
    private PhotoFeign photoFeign;

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    /**
     * @Author: Wei Chunlai
     * @Description: 保存照片
     * @Params:  * @param null
     * 照片编号（取证件编号）: photoNumber
     * 照片类型: photoType
     * 创建人（取网点操作人）:createBy
     * 客户号:clientNo
     * 业务类型:businessType
     * @Date: 2017/10/26 18:20
     */
    @RequestMapping(value="/savePhoto", method = RequestMethod.POST)
    public Map<String, Object> savePhoto(@RequestParam Map<String, Object> params, HttpServletRequest request) {
        StringBuffer sb = getStringBuffer(request);
        Map<String, Object> map = photoFeign.savePhoto(sb.toString());
        if (!"1".equals(String.valueOf(map.get("status")))){
            return ReturnResult.error("证件照保存失败");
        }
        return ReturnResult.success("保存证件照完成");

    }

    @RequestMapping(value = "/selectPhoto", method = RequestMethod.POST)
    @RequiresPermissions(value = {"ltaccountcards:list"})
    public Map<String, Object> selectSelective(@RequestBody Map<String, Object> map){
        Map<String, Object> objectMap = photoFeign.selectSelective(map);
        return objectMap;
    }

    /**
     * @Author: Wei Chunlai
     * @Description: 车辆信息校正更改证件照
     * @Params:  * @param null
     * @Date: 2017/11/26 21:23
     */
    @RequestMapping("/updatePhoto")
    public Map<String, Object> updatePhoto(@RequestBody HttpServletRequest request){
        StringBuffer sb = getStringBuffer(request);
        Map<String, Object> objectMap = photoFeign.updatePhoto(sb.toString());
        if (!"1".equals(String.valueOf(objectMap.get("status")))){
            return ReturnResult.error("证件照更新失败");
        }
        return ReturnResult.success("更新证件照完成");
    }

    private StringBuffer getStringBuffer(HttpServletRequest request){
        StringBuffer sb = new StringBuffer();
        try {
            request.setCharacterEncoding("UTF-8");
            BufferedReader reader = request.getReader();
            char[] buff = new char[1024];
            int len;
            while((len = reader.read(buff)) != -1) {
                sb.append(buff,0, len);
            }
            reader.close();
        }catch (IOException e) {
            e.printStackTrace();
        }
        return sb;
    }
}
