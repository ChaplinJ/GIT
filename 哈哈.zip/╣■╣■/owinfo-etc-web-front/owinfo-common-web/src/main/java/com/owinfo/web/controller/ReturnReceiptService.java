package com.owinfo.web.controller;

import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.LoggerService;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 描述:
 * 打印回执
 *
 * @outhor 江攀
 * @create 2018-01-03 20:49
 */
@RestController
@RequestMapping("/returnReceiptService")
public class ReturnReceiptService {
    @Autowired
    private BizFeign bizFeign;
    /**
     * 查看客户信息
     *
     * @param param
     * @return
     */   //68  //180
    @RequiresPermissions(value = {"printreceipt:queryPrint"})
    @RequestMapping(value = "/printReceipt", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public Map<String, Object> printReceipt(@RequestBody Map<String, Object> param) {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap = bizFeign.printReceipt(param);
        return resultMap;
    }
}
