package com.owinfo.web.controller;

import com.owinfo.web.service.BizFeign;
import com.owinfo.web.service.SiteFeign;
import com.owinfo.web.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by admin on 2017/11/30.
 */
@RestController
@RequestMapping("/siteService")
public class StatisticsService {

    @Autowired
    private SiteFeign siteFeign;

    @Autowired
    private BizFeign bizFeign;

    @RequestMapping(value="/statistics", method = RequestMethod.POST)
    public Map<String, Object> statistics(@RequestBody Map<String, Object> params, HttpServletRequest request) {
        Map<String,Object> map = new HashMap<>();
        map = siteFeign.statistics(params);
        return map;
    }

    @RequestMapping("/SiteTotalExport")
    public void SiteTotalExport(@RequestParam Map<String, Object> map, HttpServletResponse response){
        byte[] bytes = bizFeign.SiteTotalExport(map);
        if(bytes!=null){
            String fileName = "站点交易统计";
            try {
                FileUtil.fileOutput(response, fileName, bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
