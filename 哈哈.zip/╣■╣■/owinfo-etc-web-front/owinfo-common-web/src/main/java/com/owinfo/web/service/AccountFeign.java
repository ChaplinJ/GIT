package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.AccountImpl;
import com.owinfo.web.util.Json;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@FeignClient(value = "owinfo-etc-service-account",fallbackFactory = AccountImpl.class)
@Component
public interface AccountFeign {
    /*
        * 新建用户
        * */
    @PostMapping(value="/etcUserService/insertAccount")
    Map<String, Object> insertAccount(@RequestBody Map<String, Object> param);

    /*
    * 查询客户信息（证件）
    * */
    @RequestMapping(value="/etcUserService/findByNumber")
    Map<String, Object> findByNumber(@RequestBody Map<String, Object> param);
    /*
    * 修改用户
    * */
    @RequestMapping(value="/etcUserService/updateAccount")
    Map<String, Object> updateAccount(@RequestBody Map<String, Object> param);
    /*
    * 删除用户（逻辑）
    * */
    @RequestMapping(value="/etcUserService/deleteAccount")
    Map<String, Object> deleteAccount(@RequestBody Map<String, Object> param);
    /*
    * 查询车辆信息(列表)
    * */
    @RequestMapping(value="/etcUserService/findVehicleByCertificateNumber")
    Map<String, Object> findVehicleByCertificateNumber(@RequestBody Map<String, Object> param);
    /*
    * 查询车辆详情
    * */
    @RequestMapping(value="/etcUserService/findVehicleDetil")
    Map<String, Object> findVehicleDetil(@RequestBody Map<String, Object> param);
        /*
    * 查询车辆详情
    * */
    @RequestMapping(value="/etcUserService/findVehicleDetilTwo")
    Map<String, Object> findVehicleDetilTwo(@RequestBody Map<String, Object> param);
    /*
    * 添加车辆
    * */
    @RequestMapping(value="/etcUserService/insertVehicle")
    Map<String, Object> insertVehicle(@RequestBody Map<String, Object> param);
    /*
    * 修改车辆信息
    * */
    @RequestMapping(value="/etcUserService/updateVehicle")
    Map<String, Object> updateVehicle(@RequestBody Map<String, Object> param);
    /*
    * 车辆删除
    * */
    @RequestMapping(value="/etcUserService/deleteVehicle")
    Map<String, Object> deleteVehicle(@RequestBody Map<String,Object> param);
    /*
    * 新增客户业务
    * */
    @RequestMapping(value="/etcUserService/insertAccountOperation")
    Map<String, Object> insertAccountOperation(@RequestBody Map<String, Object> param);
    /*
    * 查看客户业务
    * */
    @RequestMapping(value="/etcUserService/findAccountOperationDetail")
    Map<String, Object> findAccountOperationDetail(@RequestBody Map<String,Object> param);
    /**
     *账号充值
     */
    @RequestMapping(value="/etcUserService/updateAccountBalance")
    Map<String, Object> updateAccountBalance(@RequestBody Map<String,Object> param);
    /**
     * 企业证件更换登记
     */
    @RequestMapping(value="/etcUserService/insertEtcGroupIdChange")
    Map<String, Object> insertEtcGroupIdChange(@RequestBody Map<String,Object> param);

    /**
     *查看校正列表
     */
    @RequestMapping(value="/carRegisterService/findReviseList")
    Map<String, Object> findReviseList(@RequestBody Map<String,Object> param);

    /**
     *查看校正详情
     */
    @RequestMapping(value="/carRegisterService/findReviseDetil")
    Map<String, Object> findReviseDetil(@RequestBody Map<String,Object> param);

    /**
     *添加校正流程记录
     */
    @RequestMapping(value="/carRegisterService/insertRevise")
    Map<String, Object> insertRevise(@RequestBody Map<String,Object> param);

    /**
     * 添加校正详情
     */
    @RequestMapping(value="/carRegisterService/insertReviseDetil")
    Map<String, Object> insertReviseDetil(@RequestBody Map<String,Object> param);

    /**
     * 修改流程记录
     */
    @RequestMapping(value="/carRegisterService/updateRevise")
    Map<String, Object> updateRevise(@RequestBody Map<String,Object> param);

    /**
     *查询流程单条信息
     */
    @RequestMapping(value="/carRegisterService/findOneRevise")
    Map<String, Object> findOneRevise(@RequestBody Map<String,Object> param);

    /**
     *编辑校正详情
     */
    @RequestMapping(value="/carRegisterService/updateReviseDetil")
    Map<String, Object> updateReviseDetil(@RequestBody Map<String,Object> param);

    /**
     * 清户表查询（单条）
     */
    @RequestMapping(value="/etcUserService/findByCertificateNumber")
    Map<String, Object> findByCertificateNumber(@RequestBody Map<String,Object> param);
    /**
     * 清户数据查询（列表）
     */
    @RequestMapping(value="/etcUserService/findCleanAccountList")
    Map<String, Object> findCleanAccountList(@RequestBody Map<String,Object> param);
    /**
     * 插入清户数据
     */
    @RequestMapping(value="/etcUserService/insertCleanAccount")
    Map<String, Object> insertCleanAccount(@RequestBody Map<String,Object> param);
    /**
     * 修改清户数据
     */
    @RequestMapping(value="/etcUserService/updateCleanAccount")
    Map<String, Object> updateCleanAccount(@RequestBody Map<String,Object> param);

    /**
     * 修改账户密码
     */
    @RequestMapping(value="/etcUserService/updateAccountPass")
    Map<String, Object> updateAccountPass(@RequestBody Map<String,Object> param);

    /**
     * 账户密码校验
     */
    @RequestMapping(value="/etcUserService/verifyAccountPass")
    Map<String, Object> verifyAccountPass(@RequestBody Map<String,Object> param);
    /**
     *添加黑名单
     */
    @RequestMapping(value="/etcUserService/insertBlackList")
    Map<String, Object> insertBlackList(@RequestBody Map<String,Object> param);
    /**
     * 黑名单单条查询
     */
    @RequestMapping(value="/etcUserService/findByKeyBlackList")
    Map<String, Object> findByKeyBlackList(@RequestBody Map<String,Object> param);

    /**
     * 黑名单单条查询   代码标识sign  currentType=0
     */
    @RequestMapping(value="/etcUserService/findByVBlackList")
    Map<String, Object> findByVBlackList(@RequestBody Map<String,Object> param);

    /**
     * 黑转白
     */
    @RequestMapping(value="/etcUserService/blackToWhite")
    Map<String, Object> blackToWhite(@RequestBody Map<String,Object> param);

    //退卡补款查询
    @RequestMapping("/cardFillMoneyService/findCardFillMoney")
    Map<String, Object> findCardFillMoney(@RequestBody Map<String, Object> param);

    //售出记录导出
    @RequestMapping("/etcsaleAndChange/saleRecordExport")
    byte[] saleRecordExport(@RequestBody Map<String, Object> param);

    //以旧换新记录导出
    @RequestMapping("/etcsaleAndChange/changeGoodsExport")
    byte[] changeGoodsExport(@RequestBody Map<String, Object> param);

    //清户导出
    @RequestMapping("/etcCloseOutService/cleanAccountExport")
    byte[] cleanAccountExport(@RequestBody Map<String, Object> param);

    //清账导出
    @RequestMapping("/etcCloseOutService/closeoutExport")
    byte[] closeoutExport(@RequestBody Map<String, Object> param);

    //黑名单导出
    @RequestMapping("/etcUserService/blackListExport")
    byte[] blackListExport(@RequestBody Map<String, Object> param);

    //停车场消费
    @RequestMapping(value="/etcUserService/findPrkList")
    Map<String, Object> findPrkList(@RequestBody Map<String,Object> param);

    //停车场消费-导出excel
    @RequestMapping(value = "/etcUserService/findPrkListExport")
    byte[] findPrkListExport(@RequestBody Map<String, Object> param);

    //充正补款--查询 addFullComplement
    @RequestMapping(value="/cardFillMoneyService/fullComplement")
    Map<String, Object> fullComplement(@RequestBody Map<String,Object> param);

    //充正补款导出
    @RequestMapping("/cardFillMoneyService/fullComplExport")
    byte[] fullComplExport(@RequestBody Map<String, Object> param);


    @RequestMapping(value = "/etcUserService/reportBlackAgain", method = RequestMethod.POST)
    Json reportBlackAgain(@RequestBody Map<String, Object> map);

    //用户名下车辆卡签统计
    @RequestMapping(value="/etcUserService/findAllCarTwo")
    Map<String, Object> findAllCarTwo(@RequestBody Map<String, Object> param);

    //黑名单历史
    @RequestMapping(value="/etcUserService/findBlackLog")
    Map<String, Object> findBlackLog(@RequestBody Map<String,Object> param);

    //账户查看模糊
    @RequestMapping(value="/etcUserService/likeFind")
    Map<String, Object> likeFind(@RequestBody Map<String,Object> param);

    //账户查看列表（证件号,卡号,客户名称,车牌）
    @RequestMapping(value="/etcUserService/likeFindTwo")
    Map<String, Object> likeFindTwo(@RequestBody Map<String,Object> param);

    //全国车牌验证
    @RequestMapping(value="/etcUserService/nationalSoleCar")
    Map<String, Object> nationalSoleCar(@RequestBody Map<String,Object> param);

    //证件号修改（不一样的号码，修改成一样的）
    @RequestMapping(value="/etcUserService/updateCerNo")
    Map<String, Object> updateCerNo(@RequestBody Map<String,Object> param);

    //纸质材料设置
    @RequestMapping(value="/carRegisterService/pageSet")
    Map<String, Object> pageSet(@RequestBody Map<String,Object> param);

    //车辆信息审核
    @RequestMapping(value="/carRegisterService/reviseReject")
    Map<String, Object> reviseReject(@RequestBody Map<String,Object> param);

    /**
     * 校正流程校验
     */
    @RequestMapping(value="/carRegisterService/registerRevise")
    Map<String, Object> registerRevise(@RequestBody Map<String, Object> param);

    /**
     * 校正审核通过
     */
    @RequestMapping(value="/carRegisterService/passRevise")
    Map<String, Object> passRevise(@RequestBody Map<String, Object> param);
    /**
     * 审核不通过
     */
    @RequestMapping(value="/carRegisterService/errorRevise")
    Map<String, Object> errorRevise(@RequestBody Map<String, Object> param);

    /**
     * 校正确认按钮
     */
    @RequestMapping(value="/carRegisterService/goRevise")
    Map<String, Object> goRevise(@RequestBody Map<String, Object> param);

    /**
     * 车辆审核(list)
     */
    @RequestMapping(value="/carRegisterService/auditList")
    Map<String, Object> auditList(@RequestBody Map<String, Object> param);

    /**
     * 车辆审核(list) 导出
     */
    @RequestMapping(value="/carRegisterService/auditExport")
    byte[] auditExport(@RequestBody Map<String, Object> param);


}
