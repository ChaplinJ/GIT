package com.owinfo.web.service;

import com.alibaba.fastjson.JSONObject;
import com.owinfo.web.service.hystrix.AccountImpl;
import com.owinfo.web.service.hystrix.AccountMergeHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;


/**
 * Created by liyue on 2018/2/2.
 */
@FeignClient(value = "owinfo-etc-service-account", fallbackFactory = AccountMergeHystrix.class)
public interface AccountMergeService {

    @RequestMapping(value = "/accountMerge/queryAccount", method = RequestMethod.POST)
    JSONObject queryAccount(@RequestParam("certificateNumber") String certificateNumber);

    @RequestMapping(value = "/accountMerge/queryAccountDetail", method = RequestMethod.POST)
    JSONObject queryAccountDetail(@RequestParam("spare") String spare);

    @RequestMapping(value = "/accountMerge/accountUnified", method = RequestMethod.POST)
    JSONObject accountUnified(@RequestBody Map<String, Object> param);
}
