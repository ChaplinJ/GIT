package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.BizFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.ParseException;
import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@FeignClient(value = "owinfo-etc-service-font-biz",fallbackFactory = BizFeignImpl.class)
@Component
public interface BizFeign {
    /**
     * 开户
     * @param param
     * @return
     */
    @PostMapping(value="/etcUserService/insertAccount")
    Map<String, Object> insertAccount(@RequestBody Map<String, Object> param);

    /**
     * @Author: Wei Chunlai
     * @Description: 重新安装激活
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/etcObuService/install")
    Map<String, Object> install(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签挂失
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/etcObuService/reportLoss")
    Map<String, Object> reportLoss(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签解挂
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/relieve")
    Map<String, Object> relieve(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签续期
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/renewal")
    Map<String, Object> renewal(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签挂起
     * @Params:
     * 电子标签编号:obuid
     * 挂起类型: hangtype 0主动挂起，1被动挂起
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/hang")
    Map<String, Object> hang(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签挂起解除
     * @Params:
     * 电子标签编号:obuid
     * 新车辆号码: vehicleLicense
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/suspendRelease")
    Map<String, Object> suspendRelease(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签过户
     * @Params:
     * 原电子标签编号:obuId
     * 原车辆号码:vehicleLicense
     * 新证件号码:newCertificateNumber
     * 新车辆号码:newVehicleLicense
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/transfer")
    Map<String, Object> transfer(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签注销
     * @Params:
     * 电子标签编号:obuId
     * 注销原因（编号或字符串）:revokeReason
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/cancel")
    Map<String, Object> cancel(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签损坏登记
     * @Params:
     * 电子标签编号:obuId
     * 损坏原因（编号或字符串）:damageReason
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/damage")
    Map<String, Object> damage(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 体验标签回收
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/recovery")
    Map<String, Object> recovery(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 标签信息查看
     * @Params:
     * 电子标签编号:obuid
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuService/serch")
    Map<String, Object> serch(@RequestBody Map<String, Object> map) throws ParseException;

    /**
     * @Author: Wei Chunlai
     * @Description: 注册电子标签
     * @Params:
     * @MothedName:
     * @Date: 2017/10/26 11:52
     */
    @RequestMapping("/etcObuService/register")
    Map<String, Object> register(@RequestBody Map<String, Object> map);
    @RequestMapping(value = "/cardService/initCard")
    Map<String,Object> insertCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/loseCard")
    Map<String,Object> loseCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/loseReleaseCard")
    Map<String,Object> loseReleaseCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/reissueCard")
    Map<String,Object> reissueCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/reissueOilCard")
    Map<String,Object> reissueOilCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/renewCard")
    Map<String,Object> renewCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/hangCard")
    Map<String,Object> hangCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/hangReleaseCard")
    Map<String,Object> hangReleaseCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/logOffCard")
    Map<String,Object> logOffCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/breakCard")
    Map<String,Object> breakCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/changePass")
    Map<String,Object> changePass(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/activeCard")
    Map<String,Object> activeCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/seeCard")
    Map<String,Object> seeCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/gethangCardLog")
    Map<String,Object> gethangCardLog(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/gethangRCardLog")
    Map<String,Object> gethangRCardLog(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/getCardLog")
    Map<String,Object> getCardLog(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/getUserByCard")
    Map<String,Object> getUserByCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/cardService/getCardDetail")
    Map<String,Object> getCardDetail(@RequestBody Map<String,Object> data);

    /**
     * 修改用户
     * @param param
     * @return
     */
    @RequestMapping(value="/etcUserService/updateAccount")
    Map<String, Object> updateAccount(@RequestBody Map<String, Object> param);

    /**
     * 添加车辆
     * @param param
     * @return
     */
    @RequestMapping(value="/etcUserService/insertVehicle")
    Map<String, Object> insertVehicle(@RequestBody Map<String, Object> param);

    /**
     * 更新车辆
     * @param param
     * @return
     */
    @RequestMapping(value="/etcUserService/updateVehicle")
    Map<String, Object> updateVehicle(@RequestBody Map<String, Object> param);
    /*
      * 车辆电子标签置空
      * */
    @RequestMapping(value="/etcUserService/vehicleObuCardSetZero")
    Map<String, Object> vehicleObuCardSetZero(@RequestBody Map<String, Object> param);
    /**
     * 用户注销
     * @param param
     * @return
     */
    @RequestMapping(value="/etcUserService/deleteAccount")
    Map<String, Object> deleteAccount(@RequestBody Map<String, Object> param);

    /**
     * 多证合一
     * @param param
     * @return
     */
    @RequestMapping(value="/etcUserService/groupTransferAccount")
    Map<String, Object> groupTransferAccount(@RequestBody Map<String, Object> param);

    /**
     * 修改账户密码
     */
    @RequestMapping(value="/etcUserService/updateAccountPass")
    Map<String, Object> updateAccountPass(@RequestBody Map<String,Object> param);
    /**
     * 重置账户密码
     */
    @RequestMapping(value="/etcUserService/resetAccountPass")
    Map<String, Object> resetAccountPass(@RequestBody Map<String,Object> param);

    //修改用户重要信息
    @RequestMapping("/etcUserService/upUserMsg")
    Map<String, Object> upUserMsg(@RequestBody Map<String, Object> param);



/****************************** 发行前台资金管理服务接口 Start ********************************************************/

    /**
     * 冲正扣款（用户账户/ETC卡账户）
     * @param params
     * @return
     */
    @PostMapping("/frontFinanceService/correctDeduction")
    Map<String,Object> correctDeduction(@RequestBody Map<String,Object> params);

    /**
     * 补交收款
     * @param params
     * @return
     */
    @PostMapping("/frontFinanceService/payBack")
    Map<String,Object> payBack(@RequestBody Map<String,Object> params);


/****************************** 发行前台资金管理服务接口 End **********************************************************/
    /**
     * 黑名单---分页、组合查询
     * */
    @RequestMapping(value="/etcUserService/blackList")
    Map<String, Object> blackList(@RequestBody Map<String,Object> param);

    /**
     * 黑名单---更新、修改
     * */
    @RequestMapping(value="/etcUserService/blackUpdate")
    Map<String, Object> blackUpdate(@RequestBody Map<String,Object> param);

    /**
     * 添加黑名单
     */
    @RequestMapping(value="/etcUserService/insertBlackList")
    Map<String, Object> insertBlackList(Map<String, Object> param);

    /**
     * 黑转白
     */
    @RequestMapping(value="/etcUserService/blackToWhite")
    Map<String, Object> blackToWhite(@RequestBody Map<String,Object> param);

    /**
     * @Author: Wei Chunlai
     * @Description: 电子标签信息导出
     * @Params:  * @param null
     * @Date: 2017/11/14 14:06
     */
    @RequestMapping("/etcObuBusinessService/obuInfoExport")
    byte[] obuInfoExport(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 电子标签操作记录导出
     * @Params:  * @param null
     * @Date: 2017/11/14 14:56
     */
    @RequestMapping("/etcObuBusinessService/obuBusinessExport")
    byte[] obuBusinessExport(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 清账列表导出
     * @Params:  * @param null
     * @Date: 2017/11/14 15:12
     */
    @RequestMapping("/etcObuBusinessService/closeOutExport")
    byte[] closeOutExport(@RequestBody Map<String, Object> map);

    /**
     * @Author: zjx
     * @Description: 卡账户信息导出
     * @Params:  * @param null
     * @Date: 2017/11/14 14:06
     */
    @RequestMapping("/cardService/CardInfoExport")
    byte[] CardInfoExport(@RequestBody Map<String, Object> map);

    @RequestMapping("/cardService/CardDetailExport")
    byte[] CardDetailExport(@RequestBody Map<String, Object> map);

    @RequestMapping("/cardService/CardListExport")
    byte[] CardListExport(@RequestBody Map<String, Object> map);

    @RequestMapping("/cardService/CardUpExport")
    byte[] CardUpExport(@RequestBody Map<String, Object> map);

    @RequestMapping("/siteService/SiteTotalExport")
    byte[] SiteTotalExport(@RequestBody Map<String, Object> map);

    @RequestMapping("/cardService/CardRevokeListExport")
    byte[] CardRevokeListExport(Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 查询站点交易明细
     * @Params:  * @param null
     * @Date: 2017/12/6 18:49
     */
    @RequestMapping("/etcObuBusinessService/selectTradeDetail")
    Map<String, Object> selectTradeDetail(@RequestBody Map<String, Object> map);


    @RequestMapping("/returnReceiptService/printReceipt")
    Map<String, Object> printReceipt(@RequestBody Map<String, Object> map);
}
