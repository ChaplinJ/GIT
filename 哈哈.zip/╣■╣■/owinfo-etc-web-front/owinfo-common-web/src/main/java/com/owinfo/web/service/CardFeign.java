package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.CardFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

/**
 * Created by admin on 2017/10/25.
 */
@FeignClient(value = "owinfo-etc-service-card",fallbackFactory = CardFeignImpl.class)
@Component
public interface CardFeign {

    @RequestMapping(value = "/etcCardService/getCard")
    Map<String,Object> getCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/getCards")
    Map<String,Object> getCards(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/insertCard")
    Map<String,Object> insertCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/changeCard")
    Map<String,Object> changeCard(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/getCardlogs")
    Map<String,Object> getCardlogs(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/saveLog")
    Map<String,Object> saveLog(@RequestBody Map<String,Object> data);

    //pc写卡调卡服务
    @RequestMapping(value = "/card/pcvalidate1516")
    Map<String,Object> pcBind(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/pcwrite0016")
    Map<String,Object> pcWrite0016(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/pcwrite0015")
    Map<String,Object> pcWrite0015(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/pcfinish1516")
    Map<String,Object> pcFinish1516(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/renewCardCmd")
    Map<String,Object> renewCardCmd(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/hangCardCmd")
    Map<String,Object> hangCardCmd(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/hangOffCardCmd")
    Map<String,Object> hangOffCardCmd(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/reissueCardCmd0015")
    Map<String,Object> reissueCardCmd0015(@RequestBody  Map<String, Object> data);

    @RequestMapping(value = "/card/reissueCardCmd0016")
    Map<String,Object> reissueCardCmd0016(@RequestBody  Map<String, Object> data);

    @RequestMapping(value = "/card/activeCardCmd")
    Map<String,Object> activeCardCmd(@RequestBody  Map<String, Object> data);

    @RequestMapping(value = "/card/activeCardTimeCmd")
    Map<String,Object> activeCardTimeCmd(@RequestBody  Map<String, Object> data);

    @RequestMapping(value = "/card/ReWriteCard0015")
    Map<String,Object> ReWriteCard0015(@RequestBody  Map<String, Object> data);

    @RequestMapping(value = "/card/ReWriteCard0016")
    Map<String,Object> ReWriteCard0016(@RequestBody  Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/getCardBind")
    Map<String,Object> getCardBind(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/writeDeviceLog")
    Integer writeDeviceLog(@RequestBody Map<String,Object> data);

    @RequestMapping(value = "/etcCardService/queryForKaika")
    Map<String,Object> queryForKaika(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/queryForGuashi")
    Map<String,Object> queryForGuashi(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/queryForAllByCardId")
    Map<String,Object> queryForAllByCardId(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/queryForNoCar")
    Map<String,Object> queryForNoCar(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/queryForNoSingleCard")
    Map<String,Object> queryForNoSingleCard(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/card/upgrade")
    Map<String,Object> upgrade(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/logOffCard")
    Map<String,Object> logOffCard(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/reissueCard")
    Map<String,Object> reissueCard(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/reissueOilCard")
    Map<String,Object> reissueOilCard(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/queryForReplace")
    Map<String,Object> queryForReplace(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/readDeviceLog")
    Map<String,Object> readDeviceLog(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/queryForRevoke")
    Map<String,Object> queryForRevoke(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/updateRevokebackInfo")
    Map<String,Object> updateRevokebackInfo(@RequestBody Map<String, Object> data);

    @RequestMapping(value = "/etcCardService/updateRevokeStatus")
    Map<String,Object> updateRevokeStatus(@RequestBody Map<String, Object> data);

}
