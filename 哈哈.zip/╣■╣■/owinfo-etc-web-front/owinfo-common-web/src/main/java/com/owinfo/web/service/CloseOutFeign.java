package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.CloseOutFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

/**
 * Created by weich on 2017/10/31.
 */
@FeignClient(value = "owinfo-etc-service-font-biz",fallbackFactory = CloseOutFeignImpl.class)
@Component
public interface CloseOutFeign {

    @PostMapping("/etcCloseOutService/closeOut/selectSelective")
    Map<String, Object> selectSelective(@RequestBody Map<String, Object> map);
    //清账确认
    @PostMapping("/etcCloseOutService/closeOut/update")
    Map<String, Object> update(@RequestBody Map<String, Object> map);

    @PostMapping("/etcCloseOutService/cardFillMoney/findCardFillMoney")
    Map<String, Object> findCardFillMoney(@RequestBody Map<String, Object> map);
    //退卡补款--通过
    @PostMapping("/etcCloseOutService/cardFillMoney/agree")
    Map<String, Object> agree(@RequestBody Map<String, Object> map);

    /**
     * 清户通过
     */
    @RequestMapping(value="/etcUserService/cleanAccount")
    Map<String, Object> cleanAccount(@RequestBody Map<String, Object> param);

    /**
     *清户批处理
     */
    @RequestMapping(value="/etcUserService/cleanAccountList")
    Map<String, Object> cleanAccountList(@RequestBody Map<String, Object> param);

}
