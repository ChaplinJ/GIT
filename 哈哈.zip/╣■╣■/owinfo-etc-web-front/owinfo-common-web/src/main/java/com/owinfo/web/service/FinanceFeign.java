package com.owinfo.web.service;


import com.owinfo.web.service.hystrix.FinanceFeignImpl;
import com.owinfo.web.util.*;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
* @description:
* @author hekunlin on 2017/10/26 11:05
*/
@Component
@FeignClient(value = "owinfo-etc-service-finance",fallbackFactory = FinanceFeignImpl.class)
public interface FinanceFeign {

    /**
     * 校验订单编号
     * @param params
     * @return
     */
    @PostMapping("/finance/back/order/validateOrderNo")
    Map<String,Object> validateOrderNo(@RequestBody Map<String,Object> params);

    /**
     * 校验卡券编号和卡券密码
     * @param params
     * @return
     */
    @PostMapping("/finance/back/business/validateTicket")
    Map<String,Object> validateTicket(@RequestBody Map<String,Object> params);

    /**
     * 校验转账随机码
     * @param params
     * @return
     */
    @PostMapping("/finance/back/transfer/validateRandom")
    Map<String,Object> validateRandom(@RequestBody Map<String,Object> params);

    /**
     * 获取订单数据
     * @param params
     * @return
     */
    @PostMapping("/finance/back/order/getOrderList")
    Map<String,Object> getOrderList(@RequestBody Map<String,Object> params);

    /**
     * 更新订单数据
     * @param params
     * @return
     */
    @PostMapping("/finance/back/order/updateOrder")
    Map<String,Object> updateOrder(@RequestBody Map<String,Object> params);
    /**
     * 新增订单
     * @param params
     * @returns
     */
    @PostMapping("/finance/back/order/addOrder")
    Map<String,Object> addOrder(@RequestBody Map<String,Object> params);

    /**
     * 批量删除订单订单
     * @param params
     * @return
     */
    @PostMapping(value = "/finance/back/order/deleteOrders")
    Map<String,Object> deleteOrders(@RequestBody Map<String,Object> params);

    /**
     * 获取卡券数据
     * @return
     */
    @PostMapping("/finance/back/business/getTicketList")
    Map<String,Object> getTicketList(@RequestBody Map<String,Object> params);

    /**
     * 导入卡券，上传EXCEL方式（仅支持EXCEL2003）
     * @param file
     * @return
     */
    @RequestMapping("/finance/back/business/uploadTickets")
    Map<String,Object> uploadTickets(@RequestParam(value = "file")MultipartFile file);

    /**
     * 变更卡券状态（启用、变更<销售、赠送>）
     * @param params
     * @return
     */
    @PostMapping("/finance/back/business/changeTicketStatus")
    Map<String,Object> changeTicketStatus(@RequestBody Map<String,Object> params);

    /**
     * 新增一条卡券
     * @param list
     * @return
     */
    @PostMapping("/finance/back/business/addTicket")
    int addTicket(@RequestBody List<TicketManage> list);

    /**
     * 验证卡券是否存在
     * @param params
     * @return
     */
    @PostMapping("/finance/back/business/validateExitTicket")
    boolean validateExitTicket(@RequestBody Map<String,Object> params);

    /**
     * 获取转账管理数据
     * @param params
     * @return
     */
    @PostMapping("/finance/back/transfer/getTransferList")
    Map<String,Object> getTransferList(@RequestBody Map<String,Object> params);

    /**
     * 新增转账
     * @param transferAccountManageDto
     * @return
     */
    @PostMapping("/finance/back/transfer/addTransfer")
    Map<String,Object> addTransfer(@RequestBody TransferAccountManageDto transferAccountManageDto);

    /**
     * 修改转账
     * @param transferAccountManageDto
     * @return
     */
    @PostMapping("/finance/back/transfer/updateTransfer")
    Map<String,Object> updateTransfer(@RequestBody TransferAccountManageDto transferAccountManageDto);


    /**
     * 批量删除转账
     * @param params
     * @return
     */
    @PostMapping("/finance/back/transfer/deleteTransfers")
    Map<String,Object>  deleteTransfers(@RequestBody Map<String,Object> params);

    /**
     * ETC卡资金流动查询导出（充圈转三合一查询）
     * @param params
     * @return
     */
    @PostMapping("/finance/back/recharge/exportUnitSearch")
    byte[] exportUnitSearch(@RequestBody Map<String,Object> params);

    /**
     * ETC卡资金流动查询（充圈转三合一查询）
     * @param params
     * @return
     */
    @PostMapping("/finance/back/recharge/financeFlowSearch")
    Map<String,Object> financeFlowSearch(@RequestBody Map<String,Object> params);

    /**
     * ETC资金流动查询（充圈转三合一查询） --  ETC资金流动页面
     * @param params
     * @return
     */
    @PostMapping("/finance/back/recharge/etcFinanceFlowSearch")
    Map<String,Object> etcFinanceFlowSearch(@RequestBody Map<String,Object> params);

    /**
     * 用户账户充值查询
     * @param params
     * @return
     */
    @PostMapping("/finance/back/recharge/userAccountRechargeSearch")
    Map<String,Object> userAccountRechargeSearch(@RequestBody Map<String,Object> params);

    /**
     * 获取最新的圈存记录
     * @param params
     * @return
     */
    @PostMapping("/finance/back/transfer/operation/getLastTransferOperation")
    Map<String,Object> getLastTransferOperation(@RequestBody Map<String,Object> params);

    /**
     * 新增圈存操作记录
     * @param params
     * @return
     */
    @PostMapping("/finance/back/transfer/operation/addTransferOperationRecord")
    int addTransferOperationRecord(@RequestBody Map<String,Object> params);

    /**
     * 补圈存记录
     * @param params
     * @return
     */
    @PostMapping("/finance/back/transfer/operation/updateTransferOperation")
    Map<String,Object> updateTransferOperation(@RequestBody Map<String,Object> params);

    /**
     * 更新账单补圈存状态
     * @param params
     * @return
     */
    @PostMapping("/finance/back/recharge/updateTransferRecord")
    Map<String,Object> updateTransferRecord(@RequestBody Map<String,Object> params);

    /**
     * 新增账单记录
     * @param params
     * @return
     */
    @PostMapping("/finance/front/business/addAccountRecord")
    int addAccountRecord(@RequestBody Map<String, Object> params);


    /******************************************  补交收款  **********************************************/

    /**
     * 前台/后台根据用户证件编号获取待补交列表数据
     * @param params
     * @return
     */
    @PostMapping("/payback/getPayBackList")
    List<FrontPayBack> getPayBackList(@RequestBody Map<String,Object> params);

    /**
     * 新增补交收款记录
     * @param frontPayBack
     * @return
     */
    @PostMapping("/payback/addPayBackRecord")
    int addPayBackRecord(@RequestBody FrontPayBack frontPayBack);

    /**
     * 删除补交收款记录
     * @param ids
     * @return
     */
    @PostMapping("/payback/delPayBackRecord")
    int delPayBackRecord(@RequestParam(value = "ids") ArrayList<String> ids);

    /**
     * 更新补交状态
     * @param params
     * @return
     */
    @PostMapping("/payback/updatePayBackStatus")
    int updatePayBackStatus(@RequestBody Map<String,Object> params);


    /**
    * @description 重构圈存---卡账查询
    * @author hekunlin 2018/1/16 19:20 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/quanCun/cardAccountSearch")
    Map<String,Object> cardAccountSearch(@RequestBody CardAccountSearchVO cardAccountSearchVO);

    /**
    * @description 重构圈存---圈存初始化
    * @author hekunlin 2018/1/16 19:20 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/quanCun/quanCun")
    Boolean quanCun(@RequestBody QuanCunDTO quanCunDTO);

    /**
    * @description 重构卡充值查询
    * @author hekunlin 2018/1/26 17:59 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/cardRecharge/getCardInfo")
    Map<String, Object> getCardInfo(@RequestParam(value = "cardId",required = true) String cardId);

    /**
    * @description 重构卡充值
    * @author hekunlin 2018/1/18 22:56 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/cardRecharge/cardRecharge")
    Map<String,Object> cardRecharge(@RequestBody Map<String, Object> params);


    /**
    * @description 重构卡转账查询
    * @author hekunlin 2018/1/22 21:07 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/cardTransference/getTransferCards")
    Map<String,Object> getTransferCards(@RequestBody Map<String,Object> params);

    /**
    * @description 重构卡转账
    * @author hekunlin 2018/1/22 22:31 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/cardTransference/cardTransfer")
    Map<String,Object> cardTransfer(@RequestBody Map<String,Object> params);

    /**
    * @description 重构批量分配查询
    * @author hekunlin 2018/1/23 17:05 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/allocation/validateBatchPoint")
    Map<String,Object> validateBatchPoint(Map<String,Object> params);

    /**
    * @description 重构批量分配
    * @author hekunlin 2018/1/23 17:06 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/allocation/batchTransfer")
    Map<String,Object> batchTransfer(Map<String,Object> params);

    /**
    * @description 重构点对点分配验证
    * @author hekunlin 2018/1/25 17:31 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/oneToOne/validatePointTransfer")
    Map<String,Object> validatePointTransfer(@RequestBody Map<String, Object> params);


    /**
    * @description 重构点对点分配
    * @author hekunlin 2018/1/25 18:59 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/oneToOne/pointTransfer")
    Map<String,Object> pointTransfer(@RequestBody Map<String, Object> params);

    /**
    * @description 重构用户账户充值查询
    * @author hekunlin 2018/1/29 15:01 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/accountRecharge/accountRearch")
    Map<String, Object> accountRearch(@RequestBody Map<String,Object> params);

    /**
    * @description 重构用户账户充值
    * @author hekunlin 2018/1/29 18:08 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/accountRecharge/userAccountRecharge")
    Map<String, Object> userAccountRecharge(@RequestBody Map<String,Object> params);

    /**
    * @description 重构冲正查询
    * @author hekunlin 2018/1/30 22:23 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/correctDedution/validateCorrectDedution")
    Map<String,Object> validateCorrectDedution(@RequestBody Map<String,Object> params);

    /**
    * @description 重构冲正
    * @author hekunlin 2018/1/30 23:27 Version 1.0
    * @param
    * @return
    */
    @PostMapping("/correctDedution/correctDeduction")
    Map<String,Object> correctDeduction(@RequestBody Map<String,Object> params);

}
