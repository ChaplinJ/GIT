package com.owinfo.web.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

/**
 * Created by liyue on 2017/10/21.
 *
 *      日志服务
 *
 *          不需要熔断
 *
 *         liyue  v1
 */
@FeignClient("owinfo-etc-service-4A")
@Component
public interface LoggerService {

    /**
     * 新增操作日志   不涉及查询
     *
     *   异步方法  不会影响业务的执行效率
     *
     *   调用config中的LoggerParameter构建参数
     *
     *    param
     *      key
     *          userId          用户Id    必选
     *          userName        用户名    必选
     *          operationThing  操作事件  必选      0：登陆  1：新增  2：修改  3：删除 字符串类型 不要直接写数字
     *          description     操作描述  必选      新增一条xx数据
     *          time            操作时间  必选      new Date
     *          ip              ip地址    必选
     *
     * @param param
     */
    @RequestMapping(value = "/operlog/saveLog", method = RequestMethod.POST)
    void saveOperationLog(@RequestBody Map<String, Object> param);


    /**
     * 新增异常日志
     *
     *   异步方法  不会影响业务的执行效率
     *
     *    param
     *      key
     *          userId          用户id        必选
     *          userName        用户名        必选
     *          ip              ip地址        必选
     *          classMethod     类方法        必选
     *          message         异常信息      必选
     * @param param
     */
    @RequestMapping(value = "/exptlog/saveLog", method = RequestMethod.POST)
    void saveExceptionLog(@RequestBody Map<String, Object> param);
}
