package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.ObuFeignImpl;
import com.owinfo.web.util.ObuRead;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@FeignClient(value = "owinfo-etc-service-obu",fallbackFactory = ObuFeignImpl.class)
@Component
public interface ObuFeign {
    @RequestMapping("/etcObu/selectObuStatus")
    public String selectObuStatus(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 新增电子标签信息
     * @Params:  * @param map 内含电子标签编号
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/etcObu/insertSelective")
    Map<String, Object> insertSelective(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 更新电子标签信息
     * @Params:  * @param map 内含电子标签编号
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/etcObu/updateByPrimaryKeySelective")
    Map<String, Object> updateByPrimaryKeySelective(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 查询单个电子标签信息
     * @Params:  * @param map 内含电子标签编号
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObu/selectByPrimaryKey")
    Map<String, Object> selectByPrimaryKey(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 通过不同的参数查询对应电子标签信息
     * @Params:
     * 查询参数: map
     * @Date: 2017/10/19 10:08
     */
    @RequestMapping("/etcObu/selectSelective")
    Map<String, Object> selectSelective(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description:多表联查（暂不用）
     * @Params:
     * 查询参数:map
     * 客户号:clientNo
     * 电子标签编号:obuId
     * @Date: 2017/10/19 15:01
     */
    @RequestMapping("/etcObu/select4Selective")
    Map<String, Object> select4Selective(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 新增电子标签业务信息
     * @Params:  * @param map 内含电子标签编号
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/etcObuBusiness/insertSelective")
    Map<String, Object> insertBusinessSelective(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 更新电子标签业务信息
     * @Params:  * @param map 内含电子标签编号
     * @Date: 2017/10/16 19:37
     */
    @RequestMapping("/etcObuBusiness/updateByPrimaryKeySelective")
    Map<String, Object> updateBusinessByPrimaryKeySelective(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 查询单个电子标签业务信息
     * @Params:  * @param map 内含电子标签编号
     * @Date: 2017/10/16 19:38
     */
    @RequestMapping("/etcObuBusiness/selectByPrimaryKey")
    Map<String, Object> selectBusinessByPrimaryKey(@RequestBody Map<String, Object> map);

    /**
     * @Author: Wei Chunlai
     * @Description: 查询电子标签操作记录
     * @Params:  * @param null
     * @Date: 2017/10/21 9:34
     */
    @RequestMapping("/etcObuBusiness/selectSelective")
    Map<String, Object> selectBusinessSelective(@RequestBody Map<String, Object> map);

    @RequestMapping("/etcObu/ObuRead")
    ObuRead ObuRead(@RequestBody Map<String, Object> data);
}
