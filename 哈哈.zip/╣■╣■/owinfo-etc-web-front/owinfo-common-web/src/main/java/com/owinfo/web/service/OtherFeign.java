package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.OtherFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 物品售出、以旧换新、账户查看、客户交易查询
 * 创建时间：2017年10月26日
 * <p>
 * 〈一句话功能简述〉物品售出、以旧换新、账户查看、客户交易查询〈功能详细描述〉
 *
 * @author sun
 * @version [版本号, 2017年10月26日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */

@FeignClient(value = "owinfo-etc-service-font-biz",fallbackFactory = OtherFeignImpl.class)
@Component
public interface OtherFeign {
    /***
     * 物品售出--查询物品
     *  物品编号:goodsNo
     */
    @RequestMapping(value="/otherService/getGoods")
    Map<String, Object> getGoods(@RequestBody Map<String, Object> params);

    /***
     * 物品售出--售出
     * 物品编号:goodsNo
     * 物品名称:goodsName
     * 物品厂商:goodsManufacturer
     * 客户姓名:clientName
     * 电话号码:telNo
     */
    @RequestMapping(value="/otherService/saleGoods")
    Map<String, Object> saleGoods(@RequestBody Map<String, Object> params);
    /***
     * 物品售出--售出记录
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * 商品名称:goodsName
     * 商品编号:goodsNo
     * 站点名称:siteName
     *
     */
    @RequestMapping(value="/otherService/saleRecord")
    Map<String, Object> saleRecord(@RequestBody Map<String, Object> params);

    /***
     * 物品售出--以旧换新--检索物品信息
     *  物品编号:goodsNo
     */
    @RequestMapping(value="/otherService/getChangeInfo")
    Map<String, Object> getChangeInfo(@RequestBody Map<String, Object> params);


    /***
     * 物品售出--以旧换新保存
     * 站点名称:siteName
     * 新品编号:newGoodsNo
     * 当前旧品编号:goodsNo
     * 物品名称:newGoodsName
     * 物品厂商:newGoodsFact
     */
    @RequestMapping(value="/otherService/saveChangeGoods")
    Map<String, Object> saveChangeGoods(@RequestBody Map<String, Object> params);

    /***
     * 物品售出--以旧换新分页查询
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * 站点名称:siteName
     * 新品编号:newGoodsNo
     * 最初旧品编号:goodsNo
     */
    @RequestMapping(value="/otherService/changeGoods")
    Map<String, Object> changeGoods(@RequestBody Map<String, Object> params);

    /***
     * 查询统计--客户交易流水号查询
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * ETC卡号:cardId
     * 交易类型:operationType
     * 查询老卡:flag(true--选中老卡)
     *
     */
    @RequestMapping(value="/otherService/getCount")
    Map<String, Object> getCount(@RequestBody Map<String, Object> params);

    /**
     * 查询客户信息
     证件编号:certificateNumber
     原证件编号:oldUnitCertificateNo
     * */
    @RequestMapping(value="/otherService/getUserInfo")
    Map<String, Object> getUserInfo(@RequestBody Map<String, Object> params);

    //查看账户
    /**
     *  证件编号:certificateNumber
     *  ETC卡号:cardId
     *  车牌号查询卡:vehicleLicense
     *  用户类型:clientType:1(个人)
     * */
    @RequestMapping(value="/otherService/getAllInfo")
    Map<String, Object> getAllInfo(@RequestBody Map<String, Object> params);

    /***
     * 查询统计--客户交易流水导出Excel
     * 分页：page  pageSize
     * 开始时间:startTime
     * 结束时间:endTime
     * ETC卡号:cardId
     * 交易类型:operationType
     * 查询老卡:flag(true--选中老卡)
     *
     */
    @RequestMapping(value="/otherService/transDetailExport")
    byte[] transDetailExport(@RequestBody Map<String, Object> params);

    //充正补款--新增
    @RequestMapping(value="/otherService/addFullComplement")
    Map<String, Object> addFullComplement(@RequestBody Map<String,Object> param);
}
