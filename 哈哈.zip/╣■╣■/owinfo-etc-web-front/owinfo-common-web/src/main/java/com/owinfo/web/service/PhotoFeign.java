package com.owinfo.web.service;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.owinfo.web.service.hystrix.PhotoFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

/**
 * Created by weich on 2017/10/26.
 */
@FeignClient(value = "owinfo-etc-service-font-biz",fallbackFactory = PhotoFeignImpl.class)
public interface PhotoFeign {
    /**
     * @Author: Wei Chunlai
     * @Description: 保存照片
     * @Params:  * @param null
     * 照片编号（取证件编号）: photoNumber
     * 照片类型: photoType
     * 创建人（取网点操作人）:createBy
     * 客户号:clientNo
     * 业务类型:businessType
     * @Date: 2017/10/26 18:20
     */
    @PostMapping("/etcPhotoService/savePhoto")
    Map<String, Object> savePhoto(@RequestBody String s);

    @PostMapping("/etcPhotoService/selectPhoto")
    Map<String, Object> selectSelective(@RequestBody Map<String, Object> map);

    @RequestMapping("/etcPhotoService/updatePhoto")
    Map<String, Object> updatePhoto(@RequestBody String str);
}
