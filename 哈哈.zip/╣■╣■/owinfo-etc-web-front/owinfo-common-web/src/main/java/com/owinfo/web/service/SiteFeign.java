package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.SiteFeignImpl;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Created by weich on 2017/10/26.
 */
@FeignClient(value = "owinfo-etc-service-font-biz",fallbackFactory = SiteFeignImpl.class)
@Component
public interface SiteFeign {
    @PostMapping("/siteService/statistics")
    Map<String, Object> statistics(@RequestBody Map<String, Object> params);
}
