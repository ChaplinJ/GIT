package com.owinfo.web.service;

import com.owinfo.web.service.hystrix.UserServiceHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Set;

/**
 * Created by liyue on 2017/10/17.
 */
@FeignClient(value = "owinfo-etc-service-4A", fallbackFactory = UserServiceHystrix.class)
public interface UserService {

    /**
     * 获取全部的权限url  shiro
     * @param userId
     * @return
     */
    @RequestMapping(value = "/user/authUrls", method = RequestMethod.POST)
    Set<String> authUrls(@RequestParam("userId") String userId);

    /**
     * 获取角色名 shiro
     * @param userId
     * @return
     */
    @RequestMapping(value = "/user/roleNames", method = RequestMethod.POST)
    Set<String> roleNames(@RequestParam("userId") String userId);
}
