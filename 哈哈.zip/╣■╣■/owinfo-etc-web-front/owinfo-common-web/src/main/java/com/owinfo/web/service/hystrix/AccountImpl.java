package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.AccountFeign;
import com.owinfo.web.util.Json;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@Component
public class AccountImpl implements FallbackFactory<AccountFeign> {
    private static Logger logger = LoggerFactory.getLogger(AccountImpl.class);

    @Override
    public AccountFeign create(Throwable throwable) {
        return new AccountFeign() {
            @Override
            public Map<String, Object> insertAccount(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }
            @Override
            public Map<String, Object> findByNumber(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateAccount(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> deleteAccount(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findVehicleByCertificateNumber(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findVehicleDetil(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findVehicleDetilTwo(Map<String, Object> param) {
                logger.error("findVehicleDetilTwo is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertVehicle(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateVehicle(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> deleteVehicle(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertAccountOperation(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findAccountOperationDetail(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateAccountBalance(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertEtcGroupIdChange(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findReviseList(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findReviseDetil(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());

                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertRevise(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertReviseDetil(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateRevise(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findOneRevise(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateReviseDetil(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findByCertificateNumber(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findCleanAccountList(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertCleanAccount(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateCleanAccount(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateAccountPass(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> verifyAccountPass(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertBlackList(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findByKeyBlackList(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> findByVBlackList(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> blackToWhite(Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public byte[] saleRecordExport(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }

            @Override
            public byte[] changeGoodsExport(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }

            @Override
            public byte[] cleanAccountExport(Map<String, Object> param) {
                logger.error("cleanAccountExport is request error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] blackListExport(Map<String, Object> param) {
                logger.error("blackListExport is request error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> findPrkList(Map<String, Object> param) {
                logger.error("findPrkList is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public byte[] findPrkListExport(Map<String, Object> param) {
                logger.error("findPrkListExport is request error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> findCardFillMoney(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }

            @Override
            public byte[] closeoutExport(@RequestBody Map<String, Object> param) {
                logger.error("addorEditUser is request error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> fullComplement(@RequestBody Map<String, Object> param) {
                logger.error("fullComplement is request error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }

            @Override
            public byte[] fullComplExport(@RequestBody Map<String, Object> param) {
                logger.error("fullComplExport is request error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> findAllCarTwo(Map<String, Object> param) {
                logger.error("findAllCarTwo is request error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }

            @Override
            public Json reportBlackAgain(@RequestBody Map<String, Object> param) {
                logger.error("request is error :" + throwable.toString());
                throwable.printStackTrace();
                Json response = new Json();
                response.setSuccess(false);
                response.setMessage("重新上报失败");
                return response;
            }

            @Override
            public Map<String, Object> findBlackLog(@RequestBody Map<String, Object> param) {
                logger.error("findBlackLog is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> likeFind(Map<String, Object> param) {
                logger.error("likeFind is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> likeFindTwo(Map<String, Object> param) {
                logger.error("likeFindTwo is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> nationalSoleCar(Map<String, Object> param) {
                logger.error("nationalSoleCar is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateCerNo(Map<String, Object> param) {
                logger.error("updateCerNo is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> pageSet(Map<String, Object> param) {
                logger.error("pageSet is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> reviseReject(Map<String, Object> param) {
                logger.error("reviseReject is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> registerRevise(Map<String, Object> param) {
                logger.error("registerRevise is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> passRevise(Map<String, Object> param) {
                logger.error("passRevise is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> errorRevise(Map<String, Object> param) {
                logger.error("errorRevise is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> goRevise(Map<String, Object> param) {
                logger.error("goRevise is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> auditList(Map<String, Object> param) {
                logger.error("auditList is request error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("error");
            }

            @Override
            public byte[] auditExport(Map<String, Object> param) {
                logger.error("auditExport is request error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }
        };
    }
}
