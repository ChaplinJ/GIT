package com.owinfo.web.service.hystrix;

import com.alibaba.fastjson.JSONObject;
import com.owinfo.web.service.AccountMergeService;
import com.owinfo.web.util.JSONResultUtil;
import feign.hystrix.FallbackFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 * Created by liyue on 2018/2/2.
 */
@Component
public class AccountMergeHystrix implements FallbackFactory<AccountMergeService> {

    @Override
    public AccountMergeService create(Throwable throwable) {
        return new AccountMergeService() {
            @Override
            public JSONObject queryAccount(@RequestParam("certificateNumber") String certificateNumber) {
                throwable.printStackTrace();
                return JSONResultUtil.errorResult(null, "调用服务失败");
            }

            @Override
            public JSONObject queryAccountDetail(@RequestParam("spare") String spare) {
                throwable.printStackTrace();
                return JSONResultUtil.errorResult(null, "调用服务失败");
            }

            @Override
            public JSONObject accountUnified(@RequestBody Map<String, Object> param) {
                throwable.printStackTrace();
                return JSONResultUtil.errorResult(null, "调用服务失败");
            }
        };
    }
}
