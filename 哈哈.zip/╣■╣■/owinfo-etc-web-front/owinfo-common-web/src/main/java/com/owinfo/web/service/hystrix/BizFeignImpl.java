package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.BizFeign;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@Component
public class BizFeignImpl implements FallbackFactory<BizFeign> {

    private static Logger logger = LoggerFactory.getLogger(BizFeignImpl.class);

    @Override
    public BizFeign create(Throwable throwable) {
        return new BizFeign() {
            @Override
            public Map<String, Object> install(@RequestBody Map<String, Object> map) {
                logger.error("电子标签激活异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签激活异常，请联系管理员");
            }

            @Override
            public Map<String, Object> reportLoss(@RequestBody Map<String, Object> map) {
                logger.error("电子标签挂失异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签挂失异常，请联系管理员");
            }

            @Override
            public Map<String, Object> relieve(@RequestBody Map<String, Object> map) {
                logger.error("电子标签解挂失异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签解挂失异常，请联系管理员");
            }

            @Override
            public Map<String, Object> renewal(@RequestBody Map<String, Object> map) {
                logger.error("电子标签续期异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签续期异常，请联系管理员");
            }

            @Override
            public Map<String, Object> hang(@RequestBody Map<String, Object> map) {
                logger.error("电子标签挂起异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签挂起异常，请联系管理员");
            }

            @Override
            public Map<String, Object> suspendRelease(@RequestBody Map<String, Object> map) {
                logger.error("电子标签解挂起异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签解挂起异常，请联系管理员");
            }

            @Override
            public Map<String, Object> transfer(@RequestBody Map<String, Object> map) {
                logger.error("电子标签过户异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签过户异常，请联系管理员");
            }

            @Override
            public Map<String, Object> cancel(@RequestBody Map<String, Object> map) {
                logger.error("电子标签注销异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签注销异常，请联系管理员");
            }

            @Override
            public Map<String, Object> damage(@RequestBody Map<String, Object> map) {
                logger.error("电子标签损坏登记异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签损坏登记异常，请联系管理员");
            }

            @Override
            public Map<String, Object> recovery(@RequestBody Map<String, Object> map) {
                logger.error("电子标签回收异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签回收异常，请联系管理员");
            }

            @Override
            public Map<String, Object> serch(@RequestBody Map<String, Object> map) {
                logger.error("电子标签查询信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签查询信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> register(@RequestBody Map<String, Object> map) {
                logger.error("电子标签注册异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("电子标签注册异常，请联系管理员");
            }

            @Override
            public Map<String, Object> insertAccount(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateAccount(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> vehicleObuCardSetZero(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertVehicle(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateVehicle(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> deleteAccount(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> groupTransferAccount(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> updateAccountPass(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> resetAccountPass(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> upUserMsg(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> insertBlackList(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> blackToWhite(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public byte[] obuInfoExport(@RequestBody Map<String, Object> map) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] obuBusinessExport(@RequestBody Map<String, Object> map) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] closeOutExport(@RequestBody Map<String, Object> map) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> blackList(Map<String, Object> param) {
                logger.error("web层获取黑名单列表出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("web层获取黑名单列表出错");
            }

            @Override
            public Map<String, Object> blackUpdate(Map<String, Object> param) {
                logger.error("web层修改黑名单出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("web层修改黑名单出错");
            }

            @Override
            public Map<String, Object> insertCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> loseCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> loseReleaseCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> reissueCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> reissueOilCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> renewCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> hangCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> hangReleaseCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> logOffCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> breakCard(Map<String, Object> data) {
                logger.error(" error" + throwable.getMessage());
                return null;
            }

            @Override
            public Map<String, Object> changePass(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> activeCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> seeCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> gethangCardLog(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> gethangRCardLog(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> getCardLog(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> getUserByCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> getCardDetail(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> correctDeduction(@RequestBody Map<String, Object> params) {
                logger.error("冲正失败 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("冲正失败：网络超时");
            }

            @Override
            public Map<String, Object> payBack(@RequestBody Map<String, Object> params) {
                logger.error("补交失败 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("补交失败：网络超时");
            }

            @Override
            public byte[] CardInfoExport(@RequestBody Map<String, Object> params) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] CardDetailExport(@RequestBody Map<String, Object> params) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] CardListExport(@RequestBody Map<String, Object> params) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] CardUpExport(@RequestBody Map<String, Object> params) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> selectTradeDetail(@RequestBody Map<String, Object> map) {
                logger.error("selectTradeDetail error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("站点交易明细查询异常");
            }

            @Override
            public byte[] SiteTotalExport(@RequestBody Map<String, Object> params) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public byte[] CardRevokeListExport(@RequestBody Map<String, Object> params) {
                logger.error("export error" + throwable.toString());
                throwable.printStackTrace();
                return new byte[0];
            }

            @Override
            public Map<String, Object> printReceipt(Map<String, Object> map) {
                logger.error("selectTradeDetail error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("打印回执查询异常");
            }
        };
    }
}
