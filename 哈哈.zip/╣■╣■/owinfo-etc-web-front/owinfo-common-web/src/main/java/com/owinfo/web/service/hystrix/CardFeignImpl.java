package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.CardFeign;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

/**
 * Created by admin on 2017/10/25.
 */
@Component
public class CardFeignImpl implements FallbackFactory<CardFeign> {
    private static Logger logger = LoggerFactory.getLogger(CardFeignImpl.class);

    @Override
    public CardFeign create(Throwable throwable) {
        return new CardFeign() {
            @Override
            public Map<String, Object> getCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> getCards(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> insertCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> changeCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> getCardlogs(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> saveLog(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> pcBind(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> pcWrite0016(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> pcWrite0015(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> pcFinish1516(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> renewCardCmd(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> hangCardCmd(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> hangOffCardCmd(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> reissueCardCmd0015(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> reissueCardCmd0016(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> activeCardCmd(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> activeCardTimeCmd(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> ReWriteCard0015(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> ReWriteCard0016(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> getCardBind(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Integer writeDeviceLog(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> queryForKaika(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> queryForGuashi(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }


            @Override
            public Map<String, Object> queryForAllByCardId(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> queryForNoCar(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> queryForNoSingleCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> upgrade(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> logOffCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> reissueCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> reissueOilCard(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> queryForReplace(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> readDeviceLog(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> queryForRevoke(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> updateRevokebackInfo(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

            @Override
            public Map<String, Object> updateRevokeStatus(Map<String, Object> data) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return null;
            }

        };
    }
}
