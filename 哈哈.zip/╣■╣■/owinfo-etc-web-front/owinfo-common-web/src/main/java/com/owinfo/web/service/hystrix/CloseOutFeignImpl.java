package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.CloseOutFeign;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Created by weich on 2017/10/31.
 */
@Component
public class CloseOutFeignImpl implements FallbackFactory<CloseOutFeign> {
    private static Logger logger = LoggerFactory.getLogger(CloseOutFeignImpl.class);

    @Override
    public CloseOutFeign create(Throwable throwable) {
        return new CloseOutFeign() {
            @Override
            public Map<String, Object> selectSelective(@RequestBody Map<String, Object> map) {
                logger.error("查询异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("查询异常");
            }

            @Override
            public Map<String, Object> update(@RequestBody Map<String, Object> map) {
                logger.error("清账异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("清账异常");
            }

            @Override
            public Map<String, Object> agree(@RequestBody Map<String, Object> map) {
                logger.error("退卡补款通过出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("退卡补款通过出错");
            }

            @Override
            public Map<String, Object> findCardFillMoney(@RequestBody Map<String, Object> map) {
                logger.error("退卡补款查询出错 error" + throwable.toString());
                throwable.printStackTrace();
                return ReturnResult.error("退卡补款查询出错");
            }

            @Override
            public Map<String, Object> cleanAccount(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }

            @Override
            public Map<String, Object> cleanAccountList(Map<String, Object> param) {
                logger.error(" error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("error");
            }
        };
    }
}
