package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.FinanceFeign;
import com.owinfo.web.util.*;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月26日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@Component
public class FinanceFeignImpl implements FallbackFactory<FinanceFeign> {
    private static Logger logger = LoggerFactory.getLogger(FinanceFeignImpl.class);

    @Override
    public FinanceFeign create(Throwable throwable) {
        return new FinanceFeign() {
            @Override
            public Map<String, Object> validateOrderNo(@RequestBody Map<String, Object> params) {
                logger.error("验证订单编号接口熔断 error" + throwable.toString());
                return ReturnResult.error("验证失败：网络超时");
            }

            @Override
            public Map<String, Object> validateTicket(@RequestBody Map<String, Object> params) {
                logger.error("验证卡券数据接口熔断 error" + throwable.toString());
                return ReturnResult.error("验证失败：网络超时");
            }

            @Override
            public Map<String, Object> validateRandom(@RequestBody Map<String, Object> params) {
                logger.error("addorEditUser is request error" + throwable.toString());
                return ReturnResult.error("验证失败：网络超时");
            }

            @Override
            public Map<String, Object> getOrderList(@RequestBody Map<String, Object> params) {
                logger.error("获取电商数据接口熔断 error" + throwable.toString());
                return ReturnResult.error("获取失败：网络超时");
            }

            @Override
            public Map<String, Object> addOrder(@RequestBody Map<String, Object> params) {
                logger.error("新增卡券数据接口熔断 error" + throwable.toString());
                return ReturnResult.error("新增失败：网络超时");
            }

            @Override
            public Map<String, Object> deleteOrders(@RequestBody Map<String, Object> params) {
                logger.error("批量删除卡券数据接口熔断 error" + throwable.toString());
                return ReturnResult.error("删除失败：网络超时");
            }

            @Override
            public Map<String, Object> getTicketList(@RequestBody Map<String, Object> params) {
                logger.error("获取卡券数据接口熔断 error" + throwable.toString());
                return ReturnResult.error("获取失败：网络超时");
            }

            @Override
            public Map<String, Object> uploadTickets(@RequestParam(value = "file") MultipartFile file) {
                logger.error("上传卡券接口熔断 error" + throwable.toString());
                return ReturnResult.error("上传失败：网络超时");
            }

            @Override
            public Map<String, Object> changeTicketStatus(@RequestBody Map<String, Object> params) {
                logger.error("变更卡券状态接口熔断 error" + throwable.toString());
                return ReturnResult.error("变更失败：网络超时");
            }

            @Override
            public int addTicket(List<TicketManage> list) {
                logger.error("批量新增卡券接口熔断 error" + throwable.toString());
                return 0;
            }

            @Override
            public boolean validateExitTicket(@RequestBody Map<String, Object> params) {
                logger.error("验证是否存在卡券接口熔断 error" + throwable.toString());
                return false;
            }

            @Override
            public Map<String, Object> getTransferList(@RequestBody Map<String, Object> params) {
                logger.error("获取转账列表接口熔断 error" + throwable.toString());
                return ReturnResult.error("获取失败：网络超时");
            }

            @Override
            public Map<String, Object> addTransfer(@RequestBody TransferAccountManageDto transferAccountManageDto) {
                logger.info("新增转账接口熔断，请求参数为 params=" + transferAccountManageDto);
                logger.error("addorEditUser is request error" + throwable.toString());
                return ReturnResult.error("新增失败：网络超时");
            }

            @Override
            public Map<String, Object> updateTransfer(@RequestBody TransferAccountManageDto transferAccountManageDto) {
                logger.info("修改转账接口熔断，请求参数为 params=" + transferAccountManageDto);
                logger.error("addorEditUser is request error" + throwable.toString());
                return ReturnResult.error("新增失败：网络超时");
            }

            @Override
            public Map<String, Object> deleteTransfers(@RequestBody Map<String, Object> params) {
                logger.error("批量删除转账接口熔断 error" + throwable.toString());
                return ReturnResult.error("删除失败：网络超时");
            }

            @Override
            public Map<String, Object> financeFlowSearch(@RequestBody Map<String, Object> params) {
                logger.error("资金流动查询接口熔断 error" + throwable.toString());
                return ReturnResult.error("查询失败：网络超时");
            }

            @Override
            public byte[] exportUnitSearch(@RequestBody Map<String, Object> params) {
                logger.error("资金流动查询接口熔断 error" + throwable.toString());
                return new byte[0];
            }

            @Override
            public Map<String, Object> etcFinanceFlowSearch(@RequestBody Map<String, Object> params) {
                logger.error("资金流动查询接口熔断 error" + throwable.toString());
                return ReturnResult.error("查询失败：网络超时");
            }

            @Override
            public Map<String, Object> userAccountRechargeSearch(@RequestBody Map<String, Object> params) {
                logger.error("用户账户充值查询接口熔断 error" + throwable.toString());
                return ReturnResult.error("查询失败：网络超时");
            }

            @Override
            public Map<String, Object> getLastTransferOperation(@RequestBody Map<String, Object> params) {
                logger.error("获取最新圈存记录接口熔断 error" + throwable.toString());
                return ReturnResult.errors("查询失败：网络超时");
            }

            @Override
            public int addTransferOperationRecord(@RequestBody Map<String, Object> params) {
                logger.error("新增圈存操作记录接口熔断 error" + throwable.toString());
                return 0;
            }

            @Override
            public Map<String, Object> updateTransferOperation(@RequestBody Map<String, Object> params) {
                logger.error("补圈存记录接口熔断 error" + throwable.toString());
                return ReturnResult.errors("更新失败：网络超时");
            }

            @Override
            public Map<String, Object> updateTransferRecord(@RequestBody Map<String, Object> params) {
                logger.error("更新补圈存状态接口熔断 error" + throwable.toString());
                return ReturnResult.errors("更新失败：网络超时");
            }

            @Override
            public int addAccountRecord(@RequestBody Map<String, Object> params) {
                logger.error("新增账单接口熔断 error" + throwable.toString());
                return 0;
            }

            @Override
            public List<FrontPayBack> getPayBackList(@RequestBody Map<String, Object> params) {
                logger.error("获取待补交数据接口熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public int addPayBackRecord(@RequestBody FrontPayBack frontPayBack) {
                logger.error("新增补交收款接口熔断 error" + throwable.toString());
                return 0;
            }

            @Override
            public int delPayBackRecord(@RequestParam(value = "ids") ArrayList<String> ids) {
                logger.error("删除补交收款接口熔断 error" + throwable.toString());
                return 0;
            }

            @Override
            public int updatePayBackStatus(@RequestBody Map<String, Object> params) {
                logger.error("更新补交状态接口熔断 error" + throwable.toString());
                return 0;
            }

            @Override
            public Map<String, Object> cardAccountSearch(@RequestBody CardAccountSearchVO cardAccountSearchVO) {
                logger.error("卡账查询接口熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Boolean quanCun(@RequestBody QuanCunDTO quanCunDTO) {
                logger.error("圈存初始化查询接口熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> getCardInfo(String cardId) {
                logger.error("卡充值查询接口熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> cardRecharge(Map<String, Object> params) {
                logger.error("卡充值接口（finance服务）熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> getTransferCards(@RequestBody Map<String, Object> params) {
                logger.error("获取卡转账列表熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> cardTransfer(@RequestBody Map<String, Object> params) {
                logger.error("卡转账熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> validateBatchPoint(Map<String, Object> params) {
                logger.error("资金批量分配验证熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> batchTransfer(Map<String, Object> params) {
                logger.error("资金批量分配熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> validatePointTransfer(@RequestBody Map<String, Object> params) {
                logger.error("点对点分配验证熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> pointTransfer(@RequestBody Map<String, Object> params) {
                logger.error("点对点分配熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> accountRearch(@RequestBody Map<String, Object> params) {
                logger.error("用户账户充值查询熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> userAccountRecharge(@RequestBody Map<String, Object> params) {
                logger.error("用户账户充值熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> validateCorrectDedution(@RequestBody Map<String, Object> params) {
                logger.error("冲正查询熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> correctDeduction(@RequestBody Map<String, Object> params) {
                logger.error("冲正熔断 error" + throwable.toString());
                return null;
            }

            @Override
            public Map<String, Object> updateOrder(@RequestBody Map<String, Object> params) {
                logger.error("更新电商数据接口熔断 error" + throwable.toString());
                return ReturnResult.error("获取失败：网络超时");
            }

        };
    }
}
