package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.ObuFeign;
import com.owinfo.web.util.ObuRead;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Created by admin on 2017/10/26.
 */
@Component
public class ObuFeignImpl implements FallbackFactory<ObuFeign> {
    private static Logger logger  = LoggerFactory.getLogger(ObuFeignImpl.class);

    @Override
    public ObuFeign create(Throwable throwable) {
        return new ObuFeign() {
            @Override
            public String selectObuStatus(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签状态异常 error" + throwable.toString());
                throwable.printStackTrace();return "异常";
            }

            @Override
            public ObuRead ObuRead(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签信息 error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }


            @Override
            public Map<String, Object> insertSelective(@RequestBody Map<String, Object> map) {
                logger.error("新增电子标签信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("新增电子标签信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> updateByPrimaryKeySelective(@RequestBody Map<String, Object> map) {
                logger.error("更新电子标签信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("更新电子标签信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> selectByPrimaryKey(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("查询电子标签信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> selectSelective(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("查询电子标签信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> select4Selective(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("查询电子标签信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> insertBusinessSelective(@RequestBody Map<String, Object> map) {
                logger.error("新增电子标签业务信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("新增电子标签业务信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> updateBusinessByPrimaryKeySelective(@RequestBody Map<String, Object> map) {
                logger.error("更新电子标签业务信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("更新电子标签业务信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> selectBusinessByPrimaryKey(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签业务信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("查询电子标签业务信息异常，请联系管理员");
            }

            @Override
            public Map<String, Object> selectBusinessSelective(@RequestBody Map<String, Object> map) {
                logger.error("查询电子标签业务信息异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("查询电子标签业务信息异常，请联系管理员");
            }
        };
    }
}
