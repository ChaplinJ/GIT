package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.OtherFeign;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * 文件名：.java
 * 版权： 北京联众信安成都分公司
 * 描述： 进熔断实现
 * 创建时间：2017年10月26日
 * <p>
 * 〈一句话功能简述〉进熔断实现〈功能详细描述〉
 *
 * @author sun
 * @version [版本号, 2017年10月26日]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
@Component
public class OtherFeignImpl implements FallbackFactory<OtherFeign> {
    private static Logger logger = LoggerFactory.getLogger(OtherFeignImpl.class);

    @Override
    public OtherFeign create(Throwable throwable) {
        return new OtherFeign() {
            @Override
            public Map<String, Object> getGoods(@RequestBody Map<String, Object> params) {
                logger.error("获取商品信息出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取商品信息出错，请联系管理员");
            }

            @Override
            public Map<String, Object> saleGoods(@RequestBody Map<String, Object> params) {
                logger.error("售出商品出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("售出商品出错，请联系管理员");
            }

            @Override
            public Map<String, Object> saleRecord(@RequestBody Map<String, Object> params) {
                logger.error("获取售出记录信息出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取售出记录信息出错，请联系管理员");
            }

            @Override
            public Map<String, Object> getChangeInfo(@RequestBody Map<String, Object> params) {
                logger.error("获取商品信息出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取商品信息出错，请联系管理员");
            }

            @Override
            public Map<String, Object> saveChangeGoods(@RequestBody Map<String, Object> params) {
                logger.error("以旧换新出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("以旧换新出错，请联系管理员");
            }

            @Override
            public Map<String, Object> changeGoods(@RequestBody Map<String, Object> params) {
                logger.error("获取以旧换新列表出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取以旧换新列表出错，请联系管理员");
            }

            @Override
            public Map<String, Object> getCount(@RequestBody Map<String, Object> params) {
                logger.error("获取客户交易流水统计信息出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取客户交易流水统计信息出错，请联系管理员");
            }

            @Override
            public Map<String, Object> getUserInfo(@RequestBody Map<String, Object> params) {
                logger.error("获取用户信息出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取用户信息出错，请联系管理员");
            }

            @Override
            public Map<String, Object> getAllInfo(@RequestBody Map<String, Object> params) {
                logger.error("获取账户查看信息出错 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("获取账户查看信息出错，请联系管理员");
            }

            @Override
            public byte[] transDetailExport(@RequestBody Map<String, Object> params) {
                logger.error("导出客户交易流水列表出错 error" + throwable.toString());
                return new byte[0];
            }

            @Override
            public Map<String, Object> addFullComplement(@RequestBody Map<String, Object> param) {
                logger.error("addFullComplement request error" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }
        };
    }
}
