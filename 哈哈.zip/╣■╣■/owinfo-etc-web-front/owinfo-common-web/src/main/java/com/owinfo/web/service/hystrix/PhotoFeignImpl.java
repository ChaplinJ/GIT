package com.owinfo.web.service.hystrix;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.owinfo.web.service.PhotoFeign;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by weich on 2017/10/26.
 */
@Component
public class PhotoFeignImpl implements FallbackFactory<PhotoFeign> {
    private static Logger logger = LoggerFactory.getLogger(PhotoFeignImpl.class);

    @Override
    public PhotoFeign create(Throwable throwable) {
        return new PhotoFeign() {
            @Override
            public Map<String, Object> savePhoto(@RequestParam String s) {
                logger.error("照片保存出现异常 error" + throwable.toString());
                
                throwable.printStackTrace();return ReturnResult.error("照片保存出现异常，请联系管理员");
            }

            @Override
            public Map<String, Object> selectSelective(@RequestBody Map<String, Object> map) {
                logger.error("证件照查询异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("证件照查询异常，请联系管理员");
            }

            @Override
            public Map<String, Object> updatePhoto(@RequestBody String str) {
                logger.error("证件照更新异常 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("证件照更新异常，请联系管理员");
            }
        };
    }
}
