package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.SiteFeign;
import com.owinfo.web.util.ReturnResult;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Created by admin on 2017/11/30.
 */
@Component
public class SiteFeignImpl implements FallbackFactory<SiteFeign> {

    private static Logger logger = LoggerFactory.getLogger(SiteFeignImpl.class);

    @Override
    public SiteFeign create(Throwable throwable) {
        return new SiteFeign() {
            @Override
            public Map<String, Object> statistics(@RequestBody Map<String, Object> params) {
                logger.error("转账失败 error" + throwable.toString());
                throwable.printStackTrace();return ReturnResult.error("转账失败：网络超时");
            }
        };
    }

}
