package com.owinfo.web.service.hystrix;

import com.owinfo.web.service.UserService;
import feign.hystrix.FallbackFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Set;

/**
 * Created by liyue on 2017/10/17.
 *
 *  用户服务的熔断
 */
@Component
public class UserServiceHystrix implements FallbackFactory<UserService> {

    private Logger logger = LoggerFactory.getLogger(UserServiceHystrix.class);


    @Override
    public UserService create(Throwable throwable) {
        return new UserService() {
            @Override
            public Set<String> authUrls(@RequestParam("userId") String userId) {
                logger.error("获取用户权限数据服务调用失败" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }

            @Override
            public Set<String> roleNames(@RequestParam("userId") String userId) {
                logger.error("获取用户角色数据服务调用失败" + throwable.toString());
                throwable.printStackTrace();
                return null;
            }
        };
    }
}
