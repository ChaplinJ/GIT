package com.owinfo.web.socket;

import com.owinfo.web.util.EncryptorUtils;
import com.owinfo.web.util.ParamClassUtils;
import com.owinfo.web.util.ReturnResult;
import com.owinfo.web.util.ValidateUtils;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年11月03日
 *         github : https://github.com/rexlin600/
 * @Description
 */
@RestController
@RequestMapping("/sjl05")
public class Sjl05Controller {

    private static Logger logger = Logger.getLogger(Sjl05Controller.class);

    /**
     * 测试环境
     * 圈存验证：A014验证接口
     * @param params
     * @return
     */
    @PostMapping("/A014")
    public Map<String,Object> A014(@RequestBody Map<String,Object> params){
        // 获取参数
        if (ValidateUtils.isEmpty(params)){
            logger.error("圈存验证参数为空 params=" + params);
            return ReturnResult.error("请检查圈存验证参数");
        }

        String cardNo = (String) params.get("cardNo");
        Integer amount = (Integer) params.get("amount");
        String cardInfo = (String) params.get("cardInfo");
        String terminalNo = (String) params.get("terminalNo");
        logger.info("A014验证参数 cardNo="+cardNo + " amount="+amount + " cardInfo="+cardInfo + " terminalNo="+terminalNo);

        if (ValidateUtils.isEmpty(cardNo) || ValidateUtils.isEmpty(amount)
                || ValidateUtils.isEmpty(cardInfo) || ValidateUtils.isEmpty(terminalNo)){
            logger.error("参数不完整");
            return ReturnResult.error("圈存失败，验证未通过");
        }

        // A014验证
        boolean flag = EncryptorUtils.a014(cardNo,amount,cardInfo,terminalNo);

        if (!flag){
            logger.error("圈存验证失败 flag=" + flag);
            return ReturnResult.error("圈存验证失败");
        }
        return ReturnResult.success("圈存验证成功");
    }

    /**
     * 测试环境
     * 圈存：A015获取分散次主密钥
     * @param params
     * @return
     */
    @PostMapping("/A015")
    public Map<String,Object> A015(@RequestBody Map<String,Object> params) {
        // 获取参数
        if (ValidateUtils.isEmpty(params)){
            logger.error("圈存参数为空");
            return ReturnResult.error("请求A015参数为空");
        }

        String cardNo = (String) params.get("cardNo");
        Integer amount = (Integer) params.get("amount");
        String cardInfo = (String) params.get("cardInfo");
        String terminalNo = (String) params.get("terminalNo");
        String optDateTime = (String) params.get("optDateTime");
        logger.info("获取分散次主密钥参数 cardNo="+cardNo + " amount=" + amount + "cardInfo=" + cardInfo
                + "terminalNo="+terminalNo + "optDateTime=" + optDateTime);

        if (ValidateUtils.isEmpty(cardNo) || ValidateUtils.isEmpty(amount)
                || ValidateUtils.isEmpty(cardInfo) || ValidateUtils.isEmpty(terminalNo)
                || ValidateUtils.isEmpty(optDateTime)){
            logger.error("参数不完整");
            return ReturnResult.error("参数不正确，请检查参数");
        }
        // A015获取次主密钥
        String str = EncryptorUtils.a015(cardNo,amount,cardInfo,terminalNo,optDateTime);
        logger.info("获取的次主密钥=" + str);

        if (ValidateUtils.isEmpty(str)){
            logger.error("获取分散次主密钥失败");
            return ReturnResult.error("获取分散次主密钥失败");
        }

        String mac2 = "805200000B" + optDateTime + str + "04";

        Map<String,Object> map = new HashMap<>(1);
        map.put("SHSMK",mac2);

        return ReturnResult.successResult("SHSMK",map);
    }

    @PostMapping("/B061")
    public Map<String,Object> B061(@RequestBody Map<String,Object> params){
        // 获取参数
        if (ValidateUtils.isEmpty(params)){
            logger.error("圈存参数为空");
            return ReturnResult.error("请求B061参数为空");
        }

        String cardNo = ParamClassUtils.getParams(params.get("cardNo"));
        String index = ParamClassUtils.getParams(params.get("index"));

        logger.info("获取分散次主密钥参数 cardNo=" + cardNo + " index=" + index);
        if (ValidateUtils.isEmpty(cardNo) || ValidateUtils.isEmpty(index)){
            logger.error("参数不完整");
            return ReturnResult.error("参数不正确，请检查参数");
        }

        // A015获取次主密钥
        String str = EncryptorUtils.b061(cardNo,Integer.parseInt(index)); // 获取DF密钥是14,MF密钥是13
        logger.info("获取的次主密钥=" + str);

        if (ValidateUtils.isEmpty(str)){
            logger.error("获取分散次主密钥失败");
            return ReturnResult.error("获取分散次主密钥失败");
        }

        Map<String,Object> map = new HashMap<>(1);
        map.put("SHSMK",str);

        return ReturnResult.successResult("SHSMK",map);
    }

}
