package com.owinfo.web.util;

import static com.netflix.appinfo.AmazonInfo.MetaDataKey.mac;

/**
 * @author Created by hekunlin on 2018年01月16日
 *         github : https://github.com/rexlin600/
 * @Description 圈存：卡账查询VO
 */
public class CardAccountSearchVO {

    // 卡号
    private String cardNo;

    // 卡信息
    private String cardInfo;

    public CardAccountSearchVO() {
    }

    public CardAccountSearchVO(String cardNo, String cardInfo) {
        this.cardNo = cardNo;
        this.cardInfo = cardInfo;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo;
    }

    @Override
    public String toString() {
        return "CardAccountSearchVO{" +
                "cardNo='" + cardNo + '\'' +
                ", cardInfo='" + cardInfo + '\'' +
                '}';
    }
}
