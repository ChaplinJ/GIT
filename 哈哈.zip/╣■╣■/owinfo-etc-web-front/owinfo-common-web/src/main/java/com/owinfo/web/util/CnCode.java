package com.owinfo.web.util;

import org.apache.commons.codec.binary.Hex;

import java.io.UnsupportedEncodingException;

/**
 * Created by admin on 2017/11/10.
 */
public class CnCode {

    private static String hexString="0123456789ABCDEF";

    //中文转16进制
    public static String EnToHex(String single){
        byte[] bytes= new byte[0];
        try {
            bytes = single.getBytes("gbk");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        StringBuilder sb=new StringBuilder(bytes.length*2);
        //将字节数组中每个字节拆解成2位16进制整数
        for(int i=0;i<bytes.length;i++){
            sb.append(hexString.charAt((bytes[i]&0xf0)>>4));
            sb.append(hexString.charAt((bytes[i]&0x0f)>>0));
        }
        return sb.toString();
    }

    //数字+英文转16进制
    public static String SingleToHex(String en){
        try {
            byte[] b = en.getBytes();
            String str = " ";
            for (int i = 0; i < b.length; i++) {
                Integer I = new Integer(b[i]);
                String strTmp = I.toHexString(b[i]);
                if (strTmp.length() > 2)
                    strTmp = strTmp.substring(strTmp.length() - 2);
                str = str + strTmp;
            }
            return str.toUpperCase();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    //总入口
    public static String StrToHex(String str){

        StringBuffer sb = new StringBuffer();
        char[] charArr = str.toCharArray();
        for(char i : charArr){
            if((i >=48 && i<=57) || (i>=65 && i<=90) || (i>=97 && i<=122)){
                sb.append(SingleToHex(String.valueOf(i)));
            }else{
                sb.append(EnToHex(String.valueOf(i)));
            }
        }

        return sb.toString();
    }

    //asc2tostring
    public static String asciiToString(String value)
    {
        StringBuffer sbu = new StringBuffer();
        String[] chars = value.split(",");
        for (int i = 0; i < chars.length; i++) {
            sbu.append((char) Integer.parseInt(chars[i]));
        }
        return sbu.toString();
    }


    public static String hexStringToString(String s) {

        s = CancelLing(s);

        if (s == null || s.equals("")) {
            return null;
        }
        s = s.replace(" ", "");
        byte[] baKeyword = new byte[s.length() / 2];
        for (int i = 0; i < baKeyword.length; i++) {
            try {
                baKeyword[i] = (byte) (0xff & Integer.parseInt(
                        s.substring(i * 2, i * 2 + 2), 16));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            s = new String(baKeyword, "gbk");
            new String();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return s;
    }


    public static void main(String[] args){
//        String license = "川A12345";
//          B4A8        41 31 32 33 34 35
        String name = "C1AABACFD6DACEAAB9ABCBBE0000000000000000";
        String cert = "3132303100000000000000000000000000000000000000000000000";
                String biaoshi = "BAD3C4CF";
        String license = "1020"; //41  =   1
        //只要30-39的数字



        System.out.println(hexStringToString(CancelLing("0000BACFD6DACEAAB9ABCBBE0000000000000000")));
    }

    public static String CancelLing(String source){
        StringBuffer sb = new StringBuffer();
        for(int i = 0;i<source.length();i+=2){
            if( "00".equals(source.substring(i,i+2) )){
                break;
            }else{
                sb.append(source.substring(i,i+2));
            }
        }
        return sb.toString();
    }

}
