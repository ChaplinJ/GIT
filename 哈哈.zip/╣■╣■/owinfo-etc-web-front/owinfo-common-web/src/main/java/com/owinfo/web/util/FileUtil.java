package com.owinfo.web.util;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by liyue on 2017/11/4.
 */
public class FileUtil {

    public static void fileOutput(HttpServletResponse response, String fileName, byte[] bytes) throws IOException {
        String thizTime = new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + System.currentTimeMillis();
        response.setHeader("content-disposition", "attachment;filename=" + URLEncoder.encode(fileName + "-" + thizTime + ".xlsx", "UTF-8"));
        response.setContentType("application/vnd.ms-excel;charset=utf-8");
        ServletOutputStream outputStream = response.getOutputStream();
        outputStream.write(bytes);
        outputStream.close();
    }
}
