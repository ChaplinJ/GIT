package com.owinfo.web.util;

public class FrontPayBackVO {

    private String certificateNumber;

    private String clientNo;

    private String clientName;

    private String cardId;

    private String vehicleLicense;

    private String vehicleType;

    private Double payMoney;

    private String payReason;

    public FrontPayBackVO() {
    }

    public FrontPayBackVO(String certificateNumber, String clientNo, String clientName, String cardId, String vehicleLicense, String vehicleType, Double payMoney, String payReason) {
        this.certificateNumber = certificateNumber;
        this.clientNo = clientNo;
        this.clientName = clientName;
        this.cardId = cardId;
        this.vehicleLicense = vehicleLicense;
        this.vehicleType = vehicleType;
        this.payMoney = payMoney;
        this.payReason = payReason;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getVehicleLicense() {
        return vehicleLicense;
    }

    public void setVehicleLicense(String vehicleLicense) {
        this.vehicleLicense = vehicleLicense;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public Double getPayMoney() {
        return payMoney;
    }

    public void setPayMoney(Double payMoney) {
        this.payMoney = payMoney;
    }

    public String getPayReason() {
        return payReason;
    }

    public void setPayReason(String payReason) {
        this.payReason = payReason;
    }

    @Override
    public String toString() {
        return "FrontPayBackVO{" +
                "certificateNumber='" + certificateNumber + '\'' +
                ", clientNo='" + clientNo + '\'' +
                ", clientName='" + clientName + '\'' +
                ", cardId='" + cardId + '\'' +
                ", vehicleLicense='" + vehicleLicense + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", payMoney=" + payMoney +
                ", payReason='" + payReason + '\'' +
                '}';
    }
}