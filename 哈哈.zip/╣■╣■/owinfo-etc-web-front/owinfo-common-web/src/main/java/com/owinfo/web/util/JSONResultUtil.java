package com.owinfo.web.util;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;

/**
 * Created by liyue on 2017/10/18.
 */
public class JSONResultUtil {

    private JSONResultUtil(){}

    /**
     * 封装数据返回
     * @param data
     * @param message
     * @return
     */
    public static JSONObject successResult(Object data, String message) {
        JSONObject result = new JSONObject();
        result.put("code", 200);
        result.put("data", data);
        result.put("message", message);
        return result;
    }

    /**
     * 封装数据返回
     * @param data
     * @param message
     * @return
     */
    public static JSONObject errorResult(Object data, String message) {
        JSONObject result = new JSONObject();
        result.put("code", 500);
        result.put("data", data);
        result.put("message", message);
        return result;
    }

    /**
     * 封装分页数据返回
     * @param pageInfo
     * @param data
     * @param message
     * @return
     */
    public static JSONObject listPageResult(PageInfo pageInfo, Object data, String message) {
        JSONObject result = new JSONObject();
        result.put("code", 200);
        result.put("data", data);
        result.put("total", pageInfo.getTotal());
        result.put("page", pageInfo.getPageNum());
        result.put("pageSize", pageInfo.getPageSize());
        result.put("message", message);
        return result;
    }


    /**
     * 封装app结果
     * @param code
     * @param data
     * @param message
     * @return
     */
    public static JSONObject APPResult(int code, Object data, String message) {
        JSONObject result = new JSONObject();
        result.put("status", code);
        result.put("data", data);
        result.put("msg", message);
        return result;
    }
}
