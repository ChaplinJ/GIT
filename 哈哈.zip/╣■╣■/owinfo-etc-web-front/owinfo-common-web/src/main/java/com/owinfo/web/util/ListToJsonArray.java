package com.owinfo.web.util;

import com.alibaba.fastjson.JSONArray;

import java.util.List;

/**
 * 根据List获取到对应的JSONArray
 * @param
 * @return
 */
public class ListToJsonArray {
	public static JSONArray getJSONArrayByList(List<?> list){
	    JSONArray jsonArray = new JSONArray();
	    if (list==null ||list.isEmpty()) {
	        return jsonArray;//nerver return null
	    }
	    for (Object object : list) {
	        jsonArray.add(object);
	    }
	    return jsonArray;
	}

}
