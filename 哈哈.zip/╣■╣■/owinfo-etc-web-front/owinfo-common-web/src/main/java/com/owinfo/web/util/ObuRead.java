package com.owinfo.web.util;

/**
 * Created by admin on 2018/1/31.
 */
public class ObuRead {
    private boolean success;
    private Integer message;
    private String licence;
    private Integer color;
    private Integer type;
    private Integer useCharacter;
    private Integer outsideDimensionsLength;
    private Integer outsideDimensionsWidth;
    private Integer outsideDimensionsHeight;
    private Integer wheelCount;
    private Integer axleCount;
    private Integer axisType;
    private Integer permittedWeight;
    private String vehicleModel;
    private String engineNum;
    private String vin;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Integer getMessage() {
        return message;
    }

    public void setMessage(Integer message) {
        this.message = message;
    }

    public String getLicence() {
        return licence;
    }

    public void setLicence(String licence) {
        this.licence = licence;
    }

    public Integer getColor() {
        return color;
    }

    public void setColor(Integer color) {
        this.color = color;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getUseCharacter() {
        return useCharacter;
    }

    public void setUseCharacter(Integer useCharacter) {
        this.useCharacter = useCharacter;
    }

    public Integer getOutsideDimensionsLength() {
        return outsideDimensionsLength;
    }

    public void setOutsideDimensionsLength(Integer outsideDimensionsLength) {
        this.outsideDimensionsLength = outsideDimensionsLength;
    }

    public Integer getOutsideDimensionsWidth() {
        return outsideDimensionsWidth;
    }

    public void setOutsideDimensionsWidth(Integer outsideDimensionsWidth) {
        this.outsideDimensionsWidth = outsideDimensionsWidth;
    }

    public Integer getOutsideDimensionsHeight() {
        return outsideDimensionsHeight;
    }

    public void setOutsideDimensionsHeight(Integer outsideDimensionsHeight) {
        this.outsideDimensionsHeight = outsideDimensionsHeight;
    }

    public Integer getWheelCount() {
        return wheelCount;
    }

    public void setWheelCount(Integer wheelCount) {
        this.wheelCount = wheelCount;
    }

    public Integer getAxleCount() {
        return axleCount;
    }

    public void setAxleCount(Integer axleCount) {
        this.axleCount = axleCount;
    }

    public Integer getAxisType() {
        return axisType;
    }

    public void setAxisType(Integer axisType) {
        this.axisType = axisType;
    }

    public Integer getPermittedWeight() {
        return permittedWeight;
    }

    public void setPermittedWeight(Integer permittedWeight) {
        this.permittedWeight = permittedWeight;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getEngineNum() {
        return engineNum;
    }

    public void setEngineNum(String engineNum) {
        this.engineNum = engineNum;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }
}
