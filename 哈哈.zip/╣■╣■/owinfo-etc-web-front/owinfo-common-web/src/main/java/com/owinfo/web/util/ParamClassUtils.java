package com.owinfo.web.util;

import org.apache.log4j.Logger;

/**
 * @author Created by hekunlin on 2017年11月04日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class ParamClassUtils {

    /**
    * @description: 校验获取的参数是否为空，属于什么类型
    * @author hekunlin on 2017/11/5 17:49
    */

    private static Logger logger = Logger.getLogger(ParamClassUtils.class);

    public static String getParams(Object k){
        if (k instanceof Integer){
            logger.info("获取到的参数为Integer k = " + k);
            if (ValidateUtils.isEmpty(k)){
                return "0";
            }
            return new String(String.valueOf(k));
        }
        if (k instanceof Double){
            logger.info("获取到的参数为Double k = " + k);
            if (ValidateUtils.isEmpty(k)){
                return "0.00";
            }
            return new String(String.valueOf(k));
        }
        if (k instanceof String){
            logger.info("获取到的参数为String k = " + k);
            if (ValidateUtils.isEmpty(k)){
                return "0";
            }
            return (String) k;
        }
        logger.error("不是Integer、Double、String k=" + k);
        return "0";
    }


}
