package com.owinfo.web.util;

/**
 * @author Created by hekunlin on 2018年01月05日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class PayBackVO {

    private String id;

    private Integer payType;

    private Integer payNum;

    private Double paidMoney;

    public PayBackVO() {
    }

    public PayBackVO(String id, Integer payType, Integer payNum, Double paidMoney) {
        this.id = id;
        this.payType = payType;
        this.payNum = payNum;
        this.paidMoney = paidMoney;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPayType() {
        return payType;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public Integer getPayNum() {
        return payNum;
    }

    public void setPayNum(Integer payNum) {
        this.payNum = payNum;
    }

    public Double getPaidMoney() {
        return paidMoney;
    }

    public void setPaidMoney(Double paidMoney) {
        this.paidMoney = paidMoney;
    }
}
