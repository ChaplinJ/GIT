package com.owinfo.web.util;

import java.util.List;
import java.util.Map;

/**
 * Created by weich on 2017/10/30.
 */
public class PhotoDto {
    private String photoNumber;
    private String businessType;
    private List<Map<String, Object>> list;

    public String getPhotoNumber() {
        return photoNumber;
    }

    public void setPhotoNumber(String photoNumber) {
        this.photoNumber = photoNumber;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public List<Map<String, Object>> getList() {
        return list;
    }

    public void setList(List<Map<String, Object>> list) {
        this.list = list;
    }
}
