package com.owinfo.web.util;

/**
 * @author Created by hekunlin on 2018年01月16日
 *         github : https://github.com/rexlin600/
 * @Description  圈存
 */
public class QuanCunDTO {

    private String cardInfo; // 前端传：卡信息

    private String cardNo; // 前端传：卡号

    private String random; // 前端传：随机数

    private String terminal; // 前端传：设备号

    private int operationMoney; // 前端传：圈存操作金额

    private String optTime; // 前端传： 设备操作时间


    private String channelNum; // session获取：渠道编号

    private String channelType; // session获取：渠道类型

    private String channelName; // session获取：渠道名称

    private String acquirerNo; // session获取：操作人编号

    private String siteName; // session获取：站点名称

    private String employeeNo; // session获取：员工工号

    private String operationUser; // session获取：操作人

    private String createBy; // session获取：创建人


    private String tradeNum; // 后台生成：交易流水号


    private String clientNo; // 后台查询：客户号

    private Integer clientType; // 后台查询：客户类型

    private String clientName; // 后台查询：客户名称

    private String certificateNumber; // 后台查询：证件编号

    private String vehicleLicense; // 后台查询：车牌

    private String vehicleType; // 后台查询：车辆类型

    private String operationTime; // 后台生成：操作时间

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getRandom() {
        return random;
    }

    public void setRandom(String random) {
        this.random = random;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public int getOperationMoney() {
        return operationMoney;
    }

    public void setOperationMoney(int operationMoney) {
        this.operationMoney = operationMoney;
    }

    public String getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(String tradeNum) {
        this.tradeNum = tradeNum;
    }

    public String getChannelNum() {
        return channelNum;
    }

    public void setChannelNum(String channelNum) {
        this.channelNum = channelNum;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getAcquirerNo() {
        return acquirerNo;
    }

    public void setAcquirerNo(String acquirerNo) {
        this.acquirerNo = acquirerNo;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public Integer getClientType() {
        return clientType;
    }

    public void setClientType(Integer clientType) {
        this.clientType = clientType;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getVehicleLicense() {
        return vehicleLicense;
    }

    public void setVehicleLicense(String vehicleLicense) {
        this.vehicleLicense = vehicleLicense;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public String getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(String operationTime) {
        this.operationTime = operationTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getOptTime() {
        return optTime;
    }

    public void setOptTime(String optTime) {
        this.optTime = optTime;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    @Override
    public String toString() {
        return "QuanCunDTO{" +
                "cardInfo='" + cardInfo + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", random='" + random + '\'' +
                ", terminal='" + terminal + '\'' +
                ", operationMoney=" + operationMoney +
                ", optTime='" + optTime + '\'' +
                ", channelNum='" + channelNum + '\'' +
                ", channelType='" + channelType + '\'' +
                ", channelName='" + channelName + '\'' +
                ", acquirerNo='" + acquirerNo + '\'' +
                ", siteName='" + siteName + '\'' +
                ", employeeNo='" + employeeNo + '\'' +
                ", operationUser='" + operationUser + '\'' +
                ", createBy='" + createBy + '\'' +
                ", tradeNum='" + tradeNum + '\'' +
                ", clientNo='" + clientNo + '\'' +
                ", clientType=" + clientType +
                ", clientName='" + clientName + '\'' +
                ", certificateNumber='" + certificateNumber + '\'' +
                ", vehicleLicense='" + vehicleLicense + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", operationTime='" + operationTime + '\'' +
                '}';
    }
}
