package com.owinfo.web.util;

/**
 * @author Created by hekunlin on 2018年01月16日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class QuanCunVO {

    private String cardInfo; // 前端传：卡信息

    private String cardNo; // 前端传：卡号

    private String random; // 前端传：随机数

    private String terminal; // 前端传：设备号

    private int operationMoney; // 前端传：圈存操作金额

    private String optTime; // 前端传： 设备操作时间

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getRandom() {
        return random;
    }

    public void setRandom(String random) {
        this.random = random;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public int getOperationMoney() {
        return operationMoney;
    }

    public void setOperationMoney(int operationMoney) {
        this.operationMoney = operationMoney;
    }

    public String getOptTime() {
        return optTime;
    }

    public void setOptTime(String optTime) {
        this.optTime = optTime;
    }

    @Override
    public String toString() {
        return "QuanCunVO{" +
                "cardInfo='" + cardInfo + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", random='" + random + '\'' +
                ", terminal='" + terminal + '\'' +
                ", operationMoney=" + operationMoney +
                ", optTime='" + optTime + '\'' +
                '}';
    }
}
