package com.owinfo.web.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhangjixiang on 2017/10/16.
 */
public class ReturnResult {

    /**
     * 成功
     */
    public static final int SUCCESS = 1;

    /**
     * 失败
     */
    public static final int ERROR = 0;

    /**
     * 过期
     */
    public static final int EXPIRE = -2;

    /**
     * 返回状态为SUCCESS,描述信息--成功
     * @param msg
     * @return
     */
    public static Map<String, Object> success(String msg){
        Map<String, Object> map = new HashMap<String, Object>(2);
        map.put("status", SUCCESS);
        map.put("msg", msg);
        return map;
    }

    /**
     * 返回时间为过期/超时
     * @param msg
     * @return
     */
    public static Map<String, Object> errors(String msg){
        Map<String, Object> map = new HashMap<String, Object>(2);
        map.put("status", EXPIRE);
        map.put("msg", msg);
        return map;
    }

    /**
     * 返回状态为SUCCESS,描述信息及HashMap--成功
     * @param msg
     * @param data
     * @return
     */
    public static Map<String, Object> successResult(String msg,Map<String, Object> data){
        Map<String, Object> map = new HashMap<String, Object>(3);
        map.put("status", SUCCESS);
        map.put("msg", msg);
        map.put("data", data);
        return map;
    }

    /**
     * 返回状态为ERROR,描述信息--失败
     * @param msg
     * @return
     */
    public static Map<String, Object> error(String msg){
        Map<String, Object> map = new HashMap<String, Object>(2);
        map.put("status", ERROR);
        map.put("msg", msg);
        return map;
    }

    /**
     * 返回状态为EXPIRE,描述信息--过期
     * @param msg
     * @return
     */
    public static Map<String, Object> expire(String msg){
        Map<String, Object> map = new HashMap<String, Object>(2);
        map.put("status", EXPIRE);
        map.put("msg", msg);
        return map;
    }

    /**
     * 返回自定义状态和描述信息
     * @param status
     * @param msg
     * @return
     */
    public static Map<String, Object> getResult(Integer status,String msg){
        Map<String, Object> map = new HashMap<String, Object>(2);
        map.put("status", status);
        map.put("msg", msg);
        return map;
    }

    /**
     * 返回自定义状态、描述信息及HashMap数据
     * @param status
     * @param msg
     * @param data
     * @return
     */
    public static Map<String, Object> getResult(Integer status,String msg,Map<String, Object> data){
        Map<String, Object> map = new HashMap<String, Object>(3);
        map.put("status", status);
        map.put("msg", msg);
        map.put("data", data);
        return map;
    }

}
