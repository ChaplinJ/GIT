package com.owinfo.web.util;

/**
 * @author Created by hekunlin on 2017年10月24日
 *         github : https://github.com/rexlin600/
 * @Description
 */
public class TicketManageDTO {

    private String ticketNo;

    private String ticketName;

    private String ticketType;

    private String ticketFaceValue;

    private String password;

    private String inputPerson;

    private String createBy;

    public TicketManageDTO() {
    }

    public TicketManageDTO(String ticketNo, String ticketName, String ticketType, String ticketFaceValue, String password, String inputPerson, String createBy) {
        this.ticketNo = ticketNo;
        this.ticketName = ticketName;
        this.ticketType = ticketType;
        this.ticketFaceValue = ticketFaceValue;
        this.password = password;
        this.inputPerson = inputPerson;
        this.createBy = createBy;
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    public String getTicketName() {
        return ticketName;
    }

    public void setTicketName(String ticketName) {
        this.ticketName = ticketName;
    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    public String getTicketFaceValue() {
        return ticketFaceValue;
    }

    public void setTicketFaceValue(String ticketFaceValue) {
        this.ticketFaceValue = ticketFaceValue;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getInputPerson() {
        return inputPerson;
    }

    public void setInputPerson(String inputPerson) {
        this.inputPerson = inputPerson;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    @Override
    public String toString() {
        return "TicketManageDTO{" +
                "ticketNo='" + ticketNo + '\'' +
                ", ticketName='" + ticketName + '\'' +
                ", ticketType='" + ticketType + '\'' +
                ", ticketFaceValue='" + ticketFaceValue + '\'' +
                ", password='" + password + '\'' +
                ", inputPerson='" + inputPerson + '\'' +
                ", createBy='" + createBy + '\'' +
                '}';
    }
}
