package com.owinfo.web.util;

import java.util.Date;

public class TransferOperationDTO {

    private String id;

    private Integer tradeNum;

    private String clientNo;

    private String cardInfo;

    private Integer onlineSn;

    private Integer random;

    private Integer operationStatus;

    private String cardNo;

    private String terminalNo;

    private Date optTime;

    private Integer operationPreMoney;

    private Integer operationMoney;

    private Integer operationSufMoney;

    private Integer remove;

    private String signData;

    private String createBy;

    private Date createTime;

    private String updateBy;

    private Date updateTime;

    private Integer keyver;

    private Integer algor;

    private String tac;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getTradeNum() {
        return tradeNum;
    }

    public void setTradeNum(Integer tradeNum) {
        this.tradeNum = tradeNum;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo == null ? null : clientNo.trim();
    }

    public String getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(String cardInfo) {
        this.cardInfo = cardInfo == null ? null : cardInfo.trim();
    }

    public Integer getOnlineSn() {
        return onlineSn;
    }

    public void setOnlineSn(Integer onlineSn) {
        this.onlineSn = onlineSn;
    }

    public Integer getRandom() {
        return random;
    }

    public void setRandom(Integer random) {
        this.random = random;
    }

    public Integer getOperationStatus() {
        return operationStatus;
    }

    public void setOperationStatus(Integer operationStatus) {
        this.operationStatus = operationStatus;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo == null ? null : cardNo.trim();
    }

    public String getTerminalNo() {
        return terminalNo;
    }

    public void setTerminalNo(String terminalNo) {
        this.terminalNo = terminalNo == null ? null : terminalNo.trim();
    }

    public Date getOptTime() {
        return optTime;
    }

    public void setOptTime(Date optTime) {
        this.optTime = optTime;
    }

    public Integer getOperationPreMoney() {
        return operationPreMoney;
    }

    public void setOperationPreMoney(Integer operationPreMoney) {
        this.operationPreMoney = operationPreMoney;
    }

    public Integer getOperationMoney() {
        return operationMoney;
    }

    public void setOperationMoney(Integer operationMoney) {
        this.operationMoney = operationMoney;
    }

    public Integer getOperationSufMoney() {
        return operationSufMoney;
    }

    public void setOperationSufMoney(Integer operationSufMoney) {
        this.operationSufMoney = operationSufMoney;
    }

    public Integer getRemove() {
        return remove;
    }

    public void setRemove(Integer remove) {
        this.remove = remove;
    }

    public String getSignData() {
        return signData;
    }

    public void setSignData(String signData) {
        this.signData = signData == null ? null : signData.trim();
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getKeyver() {
        return keyver;
    }

    public void setKeyver(Integer keyver) {
        this.keyver = keyver;
    }

    public Integer getAlgor() {
        return algor;
    }

    public void setAlgor(Integer algor) {
        this.algor = algor;
    }

    public String getTac() {
        return tac;
    }

    public void setTac(String tac) {
        this.tac = tac == null ? null : tac.trim();
    }

    public static class transferOperation {
        private String id;

        private Integer tradeNum;

        private String clientNo;

        private String cardInfo;

        private Integer onlineSn;

        private Integer random;

        private Integer operationStatus;

        private String cardNo;

        private String terminalNo;

        private Date optTime;

        private Integer operationPreMoney;

        private Integer operationMoney;

        private Integer operationSufMoney;

        private Integer remove;

        private String signData;

        private String createBy;

        private Date createTime;

        private String updateBy;

        private Date updateTime;

        private Integer keyver;

        private Integer algor;

        private String tac;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id == null ? null : id.trim();
        }

        public Integer getTradeNum() {
            return tradeNum;
        }

        public void setTradeNum(Integer tradeNum) {
            this.tradeNum = tradeNum;
        }

        public String getClientNo() {
            return clientNo;
        }

        public void setClientNo(String clientNo) {
            this.clientNo = clientNo == null ? null : clientNo.trim();
        }

        public String getCardInfo() {
            return cardInfo;
        }

        public void setCardInfo(String cardInfo) {
            this.cardInfo = cardInfo == null ? null : cardInfo.trim();
        }

        public Integer getOnlineSn() {
            return onlineSn;
        }

        public void setOnlineSn(Integer onlineSn) {
            this.onlineSn = onlineSn;
        }

        public Integer getRandom() {
            return random;
        }

        public void setRandom(Integer random) {
            this.random = random;
        }

        public Integer getOperationStatus() {
            return operationStatus;
        }

        public void setOperationStatus(Integer operationStatus) {
            this.operationStatus = operationStatus;
        }

        public String getCardNo() {
            return cardNo;
        }

        public void setCardNo(String cardNo) {
            this.cardNo = cardNo == null ? null : cardNo.trim();
        }

        public String getTerminalNo() {
            return terminalNo;
        }

        public void setTerminalNo(String terminalNo) {
            this.terminalNo = terminalNo == null ? null : terminalNo.trim();
        }

        public Date getOptTime() {
            return optTime;
        }

        public void setOptTime(Date optTime) {
            this.optTime = optTime;
        }

        public Integer getOperationPreMoney() {
            return operationPreMoney;
        }

        public void setOperationPreMoney(Integer operationPreMoney) {
            this.operationPreMoney = operationPreMoney;
        }

        public Integer getOperationMoney() {
            return operationMoney;
        }

        public void setOperationMoney(Integer operationMoney) {
            this.operationMoney = operationMoney;
        }

        public Integer getOperationSufMoney() {
            return operationSufMoney;
        }

        public void setOperationSufMoney(Integer operationSufMoney) {
            this.operationSufMoney = operationSufMoney;
        }

        public Integer getRemove() {
            return remove;
        }

        public void setRemove(Integer remove) {
            this.remove = remove;
        }

        public String getSignData() {
            return signData;
        }

        public void setSignData(String signData) {
            this.signData = signData == null ? null : signData.trim();
        }

        public String getCreateBy() {
            return createBy;
        }

        public void setCreateBy(String createBy) {
            this.createBy = createBy == null ? null : createBy.trim();
        }

        public Date getCreateTime() {
            return createTime;
        }

        public void setCreateTime(Date createTime) {
            this.createTime = createTime;
        }

        public String getUpdateBy() {
            return updateBy;
        }

        public void setUpdateBy(String updateBy) {
            this.updateBy = updateBy == null ? null : updateBy.trim();
        }

        public Date getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(Date updateTime) {
            this.updateTime = updateTime;
        }

        public Integer getKeyver() {
            return keyver;
        }

        public void setKeyver(Integer keyver) {
            this.keyver = keyver;
        }

        public Integer getAlgor() {
            return algor;
        }

        public void setAlgor(Integer algor) {
            this.algor = algor;
        }

        public String getTac() {
            return tac;
        }

        public void setTac(String tac) {
            this.tac = tac == null ? null : tac.trim();
        }
    }
}