package com.owinfo.web.util;

import java.util.Collection;
import java.util.Map;

/**
 * @author Created by hekunlin on 2017年10月16日
 *         github : https://github.com/rexlin600/
 * @Description 校验对象是否为空的工具类
 */
@SuppressWarnings("rawtypes")
public class ValidateUtils {

    /**
     * 验证对象是否为空并返回字符串
     * @param object
     * @return
     */
    public static String toString(Object object) {
        return object == null ? "" : object.toString();
    }

    /**
     * 验证集合是否为空或null
     * @param collection
     * @return
     */
    public static boolean isEmpty(Collection collection) {
        return collection == null || collection.isEmpty();
    }

    /**
     * 验证Map是否为null或空
     * @param map
     * @return
     */
    public static boolean isEmpty(Map map) {
        return map == null || map.isEmpty();
    }

    /**
     * 验证字符串是否为空
     * @param string
     * @return
     */
    public static boolean isEmpty(String string) {
        return toString(string).isEmpty();
    }

    /**
     * 验证去掉前后空格后的字符串是否为空
     * @param string
     * @return
     */
    public static boolean isEmptyTrim(String string) {
        return toString(string).trim().isEmpty();
    }

    /**
     * 验证对象是否为空
     * @param object
     * @return
     */
    public static boolean isEmpty(Object object) {
        return toString(object).isEmpty();
    }

    /**
     * 验证对象去掉空格后是否为空
     * @param object
     * @return
     */
    public static boolean isEmptyTrim(Object object) {
        return toString(object).trim().isEmpty();
    }

    /**
     * 验证数组是否为null或数组为空
     * @param array
     * @param <T>
     * @return
     */
    public static <T> boolean isEmpty(T[] array) {
        return array == null || array.length == 0;
    }
}
