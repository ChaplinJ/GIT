package com.owinfo.web.util;


import javax.xml.bind.DatatypeConverter;
import java.io.UnsupportedEncodingException;

public class XgsReadUtils {

	/**
	 * 截取字符串
	 * @param len
	 * @param sb
	 * @return
	 */
	public static String readHexString(int len, StringBuffer sb) {
		String substring = sb.substring(0, len * 2);
		sb.delete(0, len * 2);
		return substring;
	}

	public static String readBcd(int len, StringBuffer sb) {
		String substring = sb.substring(0, len * 2);
		sb.delete(0, len * 2);
		return substring;
	}

	public static String readAsc(StringBuffer sb) throws UnsupportedEncodingException {
		// read ascii
		String substring = sb.substring(0, 1 * 2);
		int len = Integer.parseInt(substring, 16);
		sb.delete(0, 1 * 2);

		if (len == 0) {
			return null;
		}

		String substring2 = sb.substring(0, len * 2);
		sb.delete(0, len * 2);
		return new String(DatatypeConverter.parseHexBinary(substring2), "GBK");
	}



}
