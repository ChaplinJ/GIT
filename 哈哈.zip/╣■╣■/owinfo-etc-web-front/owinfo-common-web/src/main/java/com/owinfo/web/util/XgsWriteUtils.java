package com.owinfo.web.util;


import org.springframework.util.StringUtils;

import javax.xml.bind.DatatypeConverter;
import java.io.UnsupportedEncodingException;

import static java.lang.Long.parseLong;

public class XgsWriteUtils {

	/**
	 * 数字补0, 转HEX 拿到字节数组
	 * 
	 * @param intValue
	 * @param len
	 * @return
	 */
	public static String getHexString(Long intValue, int len) {
		return String.format("%0" + (len * 2) + "X", intValue);
	}

	/**
	 * 数字补0, 转HEX 拿到字节数组
	 * 
	 * @param intValue
	 * @param len
	 * @return
	 */
	public static String getHexString(Integer intValue, int len) {
		return String.format("%0" + (len * 2) + "X", intValue);
	}

	/**
	 * HexString补零
	 * 
	 * @param hexValue
	 * @param len
	 * @return
	 */
	public static String getHexString(String hexValue, int len) {
		return String.format("%0" + (len * 2) + "X", parseLong(hexValue, 16));
	}

	/**
	 * 获取Bcd
	 * 
	 * @param str
	 * @param len
	 * @return
	 */
	public static String getBcdString(String str, int len) {
		return str;
	}

	/**
	 * 获取ASC String
	 * 
	 * @param operatorTime
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String getAscString(String operatorTime) {
		if(!StringUtils.hasText(operatorTime)){
			return getHexString(0, 1);
		}
		
		try {
			byte[] bytes = operatorTime.getBytes("GBK");
			return getHexString(bytes.length, 1) + DatatypeConverter.printHexBinary(bytes);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return getHexString(0, 1);
		}
		
	}

	public static String getByteString(int i) {
		return DatatypeConverter.printHexBinary(new byte[] { (byte) i });
	}

	public static String getHlAddZero(String data) {
		StringBuffer hex = new StringBuffer();
		for (int i = 0; i < data.length(); i++) {
			hex.append("0").append(data.charAt(i));
		}
		return hex.toString();
	}

	public static String getBodyHlRemoveZero(String data) {
		StringBuffer hex = new StringBuffer();
		for (int i = 0; i < data.length(); i++) {
			if (i % 2 == 0){
				continue;
			}
			hex.append(data.charAt(i));
		}
		return hex.toString();
	}
	
	
	/**
	 * 数字补0, 转HEX 拿到字节数组
	 * 
	 * @param intValue
	 * @param len
	 * @return
	 */
	public static StringBuffer writeHexString(Integer intValue, int len, StringBuffer buffer) {
		return buffer.append(String.format("%0" + (len * 2) + "X", intValue));
	}
	
	/**
	 * HexString补零
	 * @param hexValue
	 * @param len
	 * @return
	 */
	public static StringBuffer writeHexString(String hexValue, int len, StringBuffer buffer) {
		Long l = Long.parseLong(hexValue, 16);
		StringBuffer stringBuffer = buffer.append(String.format("%0" + (len * 2) + "X", parseLong(hexValue, 16)));
		return stringBuffer;
	}
}
